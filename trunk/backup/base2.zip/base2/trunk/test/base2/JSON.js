var jsonTests = {};
base2.exec(function(ns) {
  eval(ns);
  jsonTests.testToBoolean = function() {
    assertEqual(JSON.stringify(true), "true");
    assertEqual(JSON.stringify(false), "false");
  };
  jsonTests.testToNumber = function() {
    assertEqual(JSON.stringify(0), "0");
    assertEqual(JSON.stringify(12345), "12345");
    assertEqual(JSON.stringify(-12345), "-12345");
    assertEqual(JSON.stringify(1.2345), "1.2345");
    assertEqual(JSON.stringify(-1.2345), "-1.2345");
    //can't be sure which power of ten the js-engine chooses
    assertEqual(parseFloat(JSON.stringify(12.34567e89)), 12.34567e89);
    assertEqual(parseFloat(JSON.stringify(-12.34567e-89)), -12.34567e-89);
    assertEqual(JSON.stringify(1/0), "null");
    assertEqual(JSON.stringify(-1/0), "null");
    assertEqual(JSON.stringify(Number.NEGATIVE_INFINITY), "null");
    assertEqual(JSON.stringify(Number.POSITIVE_INFINITY), "null");
    assertEqual(JSON.stringify(Number.NaN), "null");
  };
  jsonTests.testToString = function() {
    function quote(s) { return '"'+s+'"'; } //we test agains double quotes
    assertEqual(JSON.stringify(""), quote(""), "empty string");
    assertEqual(JSON.stringify("test"), quote("test"));
    assertEqual(JSON.stringify("I said: 'quiet'!"), quote("I said: 'quiet'!"));
    assertEqual(JSON.stringify("I said: \"quiet\"!"), quote('I said: \\"quiet\\"!'));
    try {
      assertEqual(JSON.stringify("Line1\nLine2\nLine3"), quote("Line1\\u000aLine2\\u000aLine3"));
      assertEqual(JSON.stringify("Line1\rLine2\rLine3"), quote("Line1\\u000dLine2\\u000dLine3"));
      assertEqual(JSON.stringify("Line1\n\rLine2\r\nLine3"), quote("Line1\\u000a\\u000dLine2\\u000d\\u000aLine3"));
      assertEqual(JSON.stringify("Column1\tColumn2"), quote("Column1\\u0009Column2"));
      assertEqual(JSON.stringify("Form1\fForm2"), quote("Form1\\u000cForm2"));
      assertEqual(JSON.stringify("Delete\b\b\b\b\b\bBackspace"), quote("Delete\\u0008\\u0008\\u0008\\u0008\\u0008\\u0008Backspace"));
      assertEqual(JSON.stringify("\x08"), quote("\\u0008"));
      assertEqual(JSON.stringify("\x09"), quote("\\u0009"));
      assertEqual(JSON.stringify("\x0a"), quote("\\u000a"));
      assertEqual(JSON.stringify("\x0c"), quote("\\u000c"));
      assertEqual(JSON.stringify("\x0d"), quote("\\u000d"));
    } catch (x) {
      assertEqual(JSON.stringify("Line1\nLine2\nLine3"), quote("Line1\\nLine2\\nLine3"));
      assertEqual(JSON.stringify("Line1\rLine2\rLine3"), quote("Line1\\rLine2\\rLine3"));
      assertEqual(JSON.stringify("Line1\n\rLine2\r\nLine3"), quote("Line1\\n\\rLine2\\r\\nLine3"));
      assertEqual(JSON.stringify("Column1\tColumn2"), quote("Column1\\tColumn2"));
      assertEqual(JSON.stringify("Form1\fForm2"), quote("Form1\\fForm2"));
      assertEqual(JSON.stringify("Delete\b\b\b\b\b\bBackspace"), quote("Delete\\b\\b\\b\\b\\b\\bBackspace"));
      assertEqual(JSON.stringify("\x08"), quote("\\b"));
      assertEqual(JSON.stringify("\x09"), quote("\\t"));
      assertEqual(JSON.stringify("\x0a"), quote("\\n"));
      assertEqual(JSON.stringify("\x0c"), quote("\\f"));
      assertEqual(JSON.stringify("\x0d"), quote("\\r"));
    }
    assertEqual(JSON.stringify("Del\x7F"), quote("Del\\u007f"));
    assertEqual(JSON.stringify("\x00"), quote("\\u0000"));
    assertEqual(JSON.stringify("\x01"), quote("\\u0001"));
    assertEqual(JSON.stringify("\x02"), quote("\\u0002"));
    assertEqual(JSON.stringify("\x03"), quote("\\u0003"));
    assertEqual(JSON.stringify("\x04"), quote("\\u0004"));
    assertEqual(JSON.stringify("\x05"), quote("\\u0005"));
    assertEqual(JSON.stringify("\x06"), quote("\\u0006"));
    assertEqual(JSON.stringify("\x07"), quote("\\u0007"));
    //Hexadecimal unicode test depends on Number.toString(16) is in lowercase
    assertEqual(JSON.stringify("\x0b"), quote("\\u000b"));
    assertEqual(JSON.stringify("\x0e"), quote("\\u000e"));
    assertEqual(JSON.stringify("\x0f"), quote("\\u000f"));
    assertEqual(JSON.stringify("\x10"), quote("\\u0010"));
    assertEqual(JSON.stringify("\x11"), quote("\\u0011"));
    assertEqual(JSON.stringify("\x12"), quote("\\u0012"));
    assertEqual(JSON.stringify("\x13"), quote("\\u0013"));
    assertEqual(JSON.stringify("\x14"), quote("\\u0014"));
    assertEqual(JSON.stringify("\x15"), quote("\\u0015"));
    assertEqual(JSON.stringify("\x16"), quote("\\u0016"));
    assertEqual(JSON.stringify("\x17"), quote("\\u0017"));
    assertEqual(JSON.stringify("\x18"), quote("\\u0018"));
    assertEqual(JSON.stringify("\x19"), quote("\\u0019"));
    assertEqual(JSON.stringify("\x1a"), quote("\\u001a"));
    assertEqual(JSON.stringify("\x1b"), quote("\\u001b"));
    assertEqual(JSON.stringify("\x1c"), quote("\\u001c"));
    assertEqual(JSON.stringify("\x1d"), quote("\\u001d"));
    assertEqual(JSON.stringify("\x1e"), quote("\\u001e"));
    assertEqual(JSON.stringify("\x1f"), quote("\\u001f"));
  };
  jsonTests.testToDate = function() {
    function d() { return new Date(Date.UTC.apply(this, arguments)); }
    function quote(s) { return '"'+s+'"'; } //we test agains double quotes
    assertEqual(JSON.stringify(d(1972,11-1,14)), quote("1972-11-14T00:00:00.000Z"), "Date: date");
    // d(0,0,0,15,16,17) results in "Mon Jan 01 1900 16:16:17 GMT+0100 (CET)",
    // so don't test that.
    assertEqual(JSON.stringify(d(2007,07-1,28,0,28,10)), quote("2007-07-28T00:28:10.000Z"), "Date: date+time");
  };
  jsonTests.testToArray = function() {
    assertEqual(JSON.stringify([]), "[]");
    assertEqual(JSON.stringify([1,2,3,4]), "[1,2,3,4]");
    assertEqual(JSON.stringify(new Array(2)), "[null,null]");
    assertEqual(JSON.stringify([void 0,1,undefined,2,void true]), "[null,1,null,2,null]");
    assertEqual(JSON.stringify(new Array(0,1,2,3)), "[0,1,2,3]");
  };
  jsonTests.testToObject = function() {
    assertEqual(JSON.stringify({}), "{}");
    assertEqual(JSON.stringify({a:1}), '{"a":1}');
    assertEqual(JSON.stringify({'while':1,'wend':void 0}), '{"while":1}');
    assertEqual(JSON.stringify({'while':1,'wend':2,loop:3}), '{"while":1,"wend":2,"loop":3}');
    assertEqual(JSON.stringify({"§±!@#$%^&*()_+=-[]}{:\"|';,./?><~`™}":1}), "{\"§±!@#$%^&*()_+=-[]}{:\\\"|';,./?><~`™}\":1}");
  };
  jsonTests.testJsonToString = function() {
    function quote(s) { return '"'+s+'"'; } //we test agains double quotes
    //--| first the basics
    assertEqual(JSON.stringify(null), "null", "null");
    assertEqual(JSON.stringify(void 0), undefined, "undefined");
    assertEqual(JSON.stringify(true), "true", "boolean true");
    assertEqual(JSON.stringify(false), "false", "boolean false");
    assertEqual(JSON.stringify(1), "1", "number positive");
    assertEqual(JSON.stringify(0.0), "0", "number zero.zero");
    assertEqual(JSON.stringify(-1), "-1", "number negative");
    assertEqual(JSON.stringify(NaN), "null", "number but really");
    assertEqual(JSON.stringify(1/0), "null", "number infinity");
    assertEqual(JSON.stringify(""), quote(""), "string: empty");
    assertEqual(JSON.stringify("non empty"), quote("non empty"), "string: non empty");
    assertEqual(JSON.stringify([]), "[]", "array: empty");
    assertEqual(JSON.stringify([1,2,3]), "[1,2,3]", "array: 1,2,3");
    assertEqual(JSON.stringify({}), "{}", "object: empty");
    assertEqual(JSON.stringify({a:1,b:2,c:3}), '{"a":1,"b":2,"c":3}', "object: {a:1,b:2,c:3}");
    //--| now combined
    assertEqual(JSON.stringify([/*null,*/true,1234,'abcd']), '[true,1234,"abcd"]',
      "array: mixed values");
    assertEqual(JSON.stringify({/*a:null,*/b:true,c:1234,d:'abcd'}), '{"b":true,"c":1234,"d":"abcd"}',
      "object: mixed values");
    assertEqual(JSON.stringify([[1,2,[3]],[3,[2],1]]), '[[1,2,[3]],[3,[2],1]]',
      "array: nested arrays");
    assertEqual(JSON.stringify([[[[[[true]]]]]]), '[[[[[[true]]]]]]',
      "array: nested arrays, 6 deep (max Safari2/WebKit can handle at the moment)");
    assertEqual(JSON.stringify({a:{b:{c:{d:{e:{f:true}}}}}}),
      '{"a":{"b":{"c":{"d":{"e":{"f":true}}}}}}', "object: nested object, 6 deep");
    /*
    //--| Test for circular references: JSON standard doesn't define this at the moment
    //--| (browsers will generate exception after a while (Safari:max stack size exceeded;
    //--| Firefox: too much recursion; IE: out of stack space))
    var a=[1], b=[a];
    a.push(b);
    JSON.stringify(b);
    */
  };
});