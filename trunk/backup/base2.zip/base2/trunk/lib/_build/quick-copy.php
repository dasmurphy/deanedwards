<?php
$SRC = 'http://rekky.rosso.name/base2/trunk/src/';
$PACKAGES = Array(
	'base2.js'            => 'base2/package.xml&full',
	'base2-dom-f.js'      => 'base2/dom/package.xml&full'
);

foreach ($PACKAGES as $name => $package) {
	file_put_contents('../src/'.$name, file_get_contents($SRC.'build.php?package='.$package));
}
?>
