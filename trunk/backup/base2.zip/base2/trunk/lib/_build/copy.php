<?php

$SRC = 'http://rekky.rosso.name/base2/trunk/src/build.php?package=';

$PACKAGES = Array(
	'base2.js'                 => 'base2/package.xml',
	'base2/events.js'          => 'base2/events/package.xml',
	'base2/dom.js'             => 'base2/dom/package.xml',
	'base2/dom-f.js'           => 'base2/dom/package.xml&full',
	'base2/dom.bind.js'        => 'base2/dom/bind/package.xml',
	'base2/dom.bind-f.js'      => 'base2/dom/bind/package.xml&full',
	'base2/dom-lite.js'        => 'base2/dom/lite/package.xml',
	'base2/dom-lite-f.js'      => 'base2/dom/lite/package.xml&full',
	'base2/fx.js'              => 'base2/fx/package.xml',
	'base2/io.js'              => 'base2/io/package.xml',
	'base2/jsb.js'             => 'base2/jsb/package.xml',
	'base2/jsb-f.js'           => 'base2/jsb/package.xml&full',
	'base2/jsb/chrome.js'      => 'base2/jsb/chrome/package.xml',
	'base2/jst.js'             => 'base2/jst/package.xml'
);

file_put_contents('../../doc/miniweb.js', file_get_contents($SRC.'apps/MiniWeb/package.xml&build=true'));
file_put_contents('../../doc/doc.js', file_get_contents($SRC.'apps/doc/package.xml&build=true'));
foreach ($PACKAGES as $name => $package) {
	file_put_contents('../src/'.$name, file_get_contents($SRC.$package.'&build=true'));
}

?>
