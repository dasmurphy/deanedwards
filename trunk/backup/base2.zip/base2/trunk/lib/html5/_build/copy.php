<?php
$SRC = 'http://rekky.rosso.name/base2/trunk/src/';
$PACKAGES = Array(
	'html5-now.js'    => 'base2/jsb/html5/package.xml',
	'html5-now-f.js'  => 'base2/jsb/html5/package.xml&full',
	'forms.js'        => 'base2/jsb/html5/forms/package.xml',
	'media.js'        => 'base2/jsb/html5/media/package.xml',
	'canvas.js'       => 'base2/jsb/html5/canvas/package.xml'
);

foreach ($PACKAGES as $name => $package) {
	file_put_contents('../src/'.$name, file_get_contents($SRC.'build.php?package='.$package));
}
?>
