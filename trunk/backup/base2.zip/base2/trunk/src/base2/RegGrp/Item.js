
var RegGrp_Item = Base.extend({
  constructor: function RegGrp_Item(source, replacement, dictionary) {
    source = RegGrp__createKey(source);

    var length = source.indexOf("(") === -1 ? 0 : RegGrp_count(source);
    
    if (dictionary && source.indexOf("<#") !== -1) {
      if (REGGRP_DICT_ENTRY.test(source)) {
        var entry = dictionary[CONST_REPLACEMENTS][CONST_HASH + source.slice(2, -1)];
        source = entry.replacement;
        length = entry._length; // get rid of this? -@DRE
      } else {
        source = dictionary.parse(source);
      }
    }
    
    if (replacement == null) {
      replacement = 0;
    } else if (replacement instanceof RegExp) {
      replacement = replacement.source;
    } else if (replacement instanceof RegGrp_Item) {
      replacement = replacement.replacement;
    } else if (typeof replacement != "function") {
      replacement = String(replacement);
    }

    // Does the expression use sub-expression lookups?
    if (typeof replacement == "string" && REGGRP_LOOKUP.test(replacement)) {
      if (REGGRP_LOOKUP_SIMPLE.test(replacement)) { // A simple lookup? (e.g. "$2").
        // Store the index (used for fast retrieval of matched strings).
        var index = +replacement.slice(1);
        if (index && index <= length) replacement = index;
      } else {
        // A complicated lookup (e.g. "Hello $2 $1.").
        var lookup = replacement, regexp;
        replacement = function(match) {
          if (!regexp || regexp.ignoreCase !== this.ignoreCase) {
            regexp = RegExp(source, this.ignoreCase ? "gi": "g");
          }
          return match.replace(regexp, lookup);
        };
      }
    }

    this.length = length;
    this.source = String(source);
    this.replacement = replacement;
  },

  length: 0,
  source: "",
  replacement: "",

  toString: K("[object base2.RegGrp.Item]")
});

RegGrp.Item = RegGrp_Item;
