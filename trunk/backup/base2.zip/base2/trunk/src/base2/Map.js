
// http://wiki.ecmascript.org/doku.php?id=proposals:dictionary

var _HASH = "#";
var _VALUES = _HASH;

var Map = Base.extend({
  constructor: function(values) {
    this[_VALUES] = {};
    if (values) this.merge(values);
  },

  clear: function() {
    this[_VALUES] = {};
    return this;
  },

  copy: function() {
    var result = copy(this, true);
    result[_VALUES] = copy(this[_VALUES]);
    return result;
  },

  forEach: function(eacher, context) {
    var values = this[_VALUES];
    for (var HASH_key in values) {
      eacher.call(context, values[HASH_key], HASH_key.slice(1), this);
    }
  },

  get: function(key) {
    // Avoid warnings in strict engines.
    var value = this[_VALUES][_HASH + key];
    return value;
  },

  getKeys: function() {
    var result = [], i = 0,
        values = this[_VALUES];
    for (var HASH_key in values) {
      result[i++] = HASH_key.slice(1);
    }
    return result; // returns an Array
  },

  getValues: function() {
    var result = [], i = 0,
        values = this[_VALUES];
    for (var HASH_key in values) {
      result[i++] = values[HASH_key];
    }
    return result; // returns an Array
  },

  has: function(key) {
    return _HASH + key in this[_VALUES];
  },

  merge: function(values /*, values2, values3, .. ,valuesN */) {
    for (var i = 0; i < arguments.length; i++) {
      values = arguments[i];
      if (values && typeof values == "object" && values != this) {
        if (values instanceof Map) {
          values = values[_VALUES];
          for (var HASH_key in values) {
            this.put(HASH_key.slice(1), values[HASH_key]);
          }
        } else {
          for (var key in values) if (!_Object_prototype[key]) {
            this.put(key, values[key]);
          }
        }
      }
    }
    return this;
  },

  put: function(key, value) {
    if (arguments.length === 1) value = key;
    // Create the new entry (or overwrite the old entry).
    return this[_VALUES][_HASH + key] = value;
  },

  remove: function(key) {
    delete this[_VALUES][_HASH + key];
  },

  size: function() {
    // This is expensive because we are not storing the keys.
    var size = 0;
    for (var HASH_key in this[_VALUES]) size++;
    return size;
  },

  union: function(values /*, values2, values3, .. ,valuesN */) {
    return this.merge.apply(this.copy(), arguments);
  }
});

Map.implement(Enumerable);

// Optimise map/filter methods.

Map.implement({
  filter: function(test, context) {
    // Returns a clone of the current object with its members filtered by "test".
    var result = copy(this, true),
        resultValues = result[_VALUES] = {},
        values = this[_VALUES];
    for (var HASH_key in values) {
      var value = values[HASH_key];
      if (test.call(context, value, HASH_key.slice(1), this)) {
        resultValues[HASH_key] = value;
      }
    }
    return result; // returns a Map
  },

  map: function(mapper, context) {
    // Returns a new Map containing the mapped values.
    var result = new Map,
        resultValues = result[_VALUES],
        values = this[_VALUES];
    for (var HASH_key in values) {
      resultValues[HASH_key] = mapper.call(context, values[HASH_key], HASH_key.slice(1), this);
    }
    return result; // returns a Map
  }
});
