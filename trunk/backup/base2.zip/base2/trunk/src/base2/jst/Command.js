
var Command = _.Base.extend({
  constructor: function Command__constructor(command) {
    this[CONST_STDOUT] = [];
    // Additional commands.
    if (command) _.extend(this, command, true);
  },
  
  echo: function Command__echo(string) {
    this[CONST_STDOUT].push(string);
  }
});
