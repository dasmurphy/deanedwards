
var Command = Base.extend({
  constructor: function(command) {
    this[STDOUT] = [];
    // Additional commands.
    if (command) extend(this, command);
  },
  
  echo: function(string) {
    this[STDOUT].push(string);
  }
});
