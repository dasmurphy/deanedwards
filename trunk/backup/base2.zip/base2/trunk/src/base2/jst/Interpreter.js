
var Interpreter = Base.extend({
  constructor: function(command, environment) {
    this.command = command || null;
    this.environment = new Environment(environment);
  },
  
  command: null,
  environment: null,

  parse: function(string) {
    var strings = string.split("<%");
    for (var i = 0; i < strings.length; i++) {
      if (i) {
        var blocks = strings[i].split("%>");
        if (blocks[0].indexOf("=") === 0) {
          strings[i] = '\necho(' + trim(blocks[0].slice(1)) + ');';
        } else {
          strings[i] = trim(blocks[0]);
        }
        strings[i] += '\necho("' + ESCAPE.parse(blocks[1]) + '");';
      } else {
        strings[i] = '\necho("' + ESCAPE.parse(strings[i]) + '");';
      }
    }
    return trim(strings.join("\n"));
  },

  interpret: function(template) {
    var command = new Command(this.command);
    var code = namespace +
      "\nwith(arguments[0])with(arguments[1]){\n" +
        this.parse(template) +
      "}\nreturn arguments[0][1].join('')";
    // use new Function() instead of eval() so that the script is evaluated in the global scope
    return new Function(code)(command, this.environment);
  }
});
