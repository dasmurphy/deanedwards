
var Interpreter = _.Base.extend({
  constructor: function Interpreter__constructor(command, environment) {
    this.command = command || null;
    this.environment = new Environment(environment);
  },
  
  command: null,
  environment: null,

  parse: function Interpreter__parse(string) {
    var strings = string.split("<%");
    var length = strings.length;
    for (var i = 0; i < length; i++) {
      if (i === 0) {
        strings[0] = '\necho("' + ESCAPE.parse(strings[0]) + '");';
      } else {
        var blocks = strings[i].split("%>");
        if (blocks[0].indexOf("=") === 0) {
          strings[i] = '\necho(' + _.trim(blocks[0].slice(1)) + ');';
        } else {
          strings[i] = _.trim(blocks[0]);
        }
        strings[i] += '\necho("' + ESCAPE.parse(blocks[1]) + '");';
      }
    }
    return _.trim(strings.join("\n"));
  },

  interpret: function Interpreter__interpret(template, data) {
    if (!data) data = {};
    var namespace = base2.exec(_.I);
    var command = _.bindAll(new Command(this.command));
    var body = NAMESPACE +
      "with(arguments[1]){" +
      buildNamespace("arguments[2]", command) +
      "with(arguments[2]){" +
      "with(arguments[3]){\n" +
      "var data=arguments[1];\n" +
      "var echo=(function(stdout){return function(v){stdout.push(v)}})(arguments[4]);\n" +
      "(function(){\n" +
      this.parse(template) +
      "})();\n" +
      "}}}\nreturn arguments[4].join('')";
    // use Function() instead of eval() so that the script is evaluated in the global scope
    return Function("_", body)(namespace, data, command, this.environment, []);
  }
});
