
// JavaScript Templates

/*
  Based on the work of Erik Arvidsson:

    http://erik.eae.net/archives/2005/05/27/01.03.26/
*/

eval(namespace); // import

var STDOUT = 1;

var ESCAPE = new RegGrp({
  '\\\\': '\\\\',
  '"':    '\\"',
  '\n':  '\\n',
  '\r':  ''
});
