
base2.require("jsb,jst", function(namespace) {
  eval(namespace); // import
  
  var interpreter = new Interpreter;

  new Rule("form", {
    oncontentready: function(form) {
      this.output(form, "");
      this.ready(form);
    },

    onclick: function(form, event) {
      var target = event.target;
      if (target.nodeName === "BUTTON") {
        this[target.id](form);
      }
    },

    clear: function(form) {
      form.input.value = "";
      this.output(form, "");
      this.ready(form);
    },

    output: function(form, value) {
      this.set(this.querySelector(form, "#output"), "textContent", value);
    },

    error: function(form, text, error) {
      this.message(form, text + ": " + error.message, "error");
    },

    message: function(form, text, className) {
      var message = this.querySelector(form, "#message");
      message.innerHTML = text;
      message.className = className || "";
    },

    parse: function(form) {
      try {
        this.output(form, interpreter.parse(form.input.value));
      } catch (error) {
        this.error(form, "error parsing script", error);
      }
    },

    interpret: function(form) {
      try {
        this.output(form, interpreter.interpret(form.input.value));
      } catch (error) {
        this.error(form, "error interpreting script", error);
      }
    },

    ready: function(form) {
      this.message(form, "ready");
      form.input.focus();
    }
  });
});
