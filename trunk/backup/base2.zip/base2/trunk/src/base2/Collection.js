
// A Map that is more array-like (accessible by index).

// Collection classes have a special (optional) property: Item
// The Item property points to a constructor function.
// Members of the collection must be an instance of Item.

// The static createItem() method is responsible for construction of collection items.
// Instance methods that add new items (add, put, insertAt, putAt) pass their arguments
// to the static createItem() method. If you want to modify the way collection items are
// created then you only need to override the createItem() method for custom collections.

var _KEYS  = ".";
var _ITEMS = _VALUES;

var ERR_DUPLICATE_KEY       = "Duplicate key";
var INDEX_OUT_OF_BOUNDS_ERR = "Index out of bounds.";

var Collection = Map.extend({
  constructor: function(items) {
    this[_KEYS] = [];
    this.base(items);
  },
  
  add: function(key, item) {
    // Duplicates not allowed using add().
    // But you can still overwrite entries using put().
    if (_HASH + key in this[_ITEMS]) throw new ReferenceError(ERR_DUPLICATE_KEY);
    return this.put.apply(this, arguments);
  },

  clear: function() {
    this[_KEYS].length = 0;
    this[_ITEMS] = {};
    return this;
  },

  copy: function() {
    var result = this.base();
    result[_KEYS] = this[_KEYS].concat();
    return result;
  },

  filter: function(test, context) {
    // Returns a clone of the current object with its members filtered by "test".
    var keys = this[_KEYS],
        items = this[_ITEMS],
        size = keys.length,
        result = copy(this, true),
        resultKeys = result[_KEYS] = [],
        resultItems = result[_ITEMS] = {};
    for (var i = 0, j = 0, key, HASH_key; i < size; i++) {
      var item = items[HASH_key = _HASH + (key = keys[i])];
      if (test.call(context, item, key, this)) {
        resultKeys[j++] = key;
        resultItems[HASH_key] = item;
      }
    }
    return result;
  },

  forEach: function(eacher, context) {
    var keys = this[_KEYS].concat(), key,
        items = this[_ITEMS],
        size = keys.length;
    for (var i = 0; i < size; i++) {
      eacher.call(context, items[_HASH + (key = keys[i])], key, this);
    }
  },

  getAt: function(index) {
    var key = Array2_item(this[_KEYS], index); // Allow negative indexes.
    return key == null ? undefined : this[_ITEMS][_HASH + key];
  },

  getKeys: function() {
    return this[_KEYS].concat(); // returns an Array
  },

  getValues: function() {
    var keys = this[_KEYS],
        items = this[_ITEMS],
        i = keys.length,
        result = [];
    while (i--) result[i] = items[_HASH + keys[i]];
    return result; // returns an Array
  },

  imap: function(mapper, context) { // the same as Array.map(this.getValues(), ..) but faster.
    var keys = this[_KEYS],
        items = this[_ITEMS],
        size = keys.length,
        result = [];
    for (var i = 0; i < size; i++) {
      result[i] = mapper.call(context, items[_HASH + keys[i]], i, this);
    }
    return result; // returns an Array
  },

  indexOf: function(key) {
    return _HASH + key in this[_ITEMS] ? Array2.indexOf(this[_KEYS], String(key)) : -1;
  },

  insertAt: function(index, key, item) {
    var keys = this[_KEYS],
        items = this[_ITEMS],
        HASH_key = _HASH + key;
    if (HASH_key in items) throw new ReferenceError(ERR_DUPLICATE_KEY);
    if (Array2_item(keys, index) == null) throw new RangeError(INDEX_OUT_OF_BOUNDS_ERR);
    keys.splice(index, 0, String(key));
    items[HASH_key] = "{placeholder}";
    return this.put.apply(this, _slice.call(arguments, 1));
  },

  item: function(keyOrIndex) {
    return this[typeof keyOrIndex == "number" ? "getAt" : "get"](keyOrIndex);
  },

  join: function(separator) {
    return this.getValues().join(separator);
  },

  keyAt: function(index) {
    return Array2_item(this[_KEYS], index); // Allow negative indexes.
  },

  map: function(mapper, context) {
    // Returns a new Collection containing the mapped items.
    var keys = this[_KEYS], key, HASH_key,
        items = this[_ITEMS],
        size = keys.length,
        result = new Collection,
        resultItems = result[_ITEMS];
    result[_KEYS] = keys.concat();
    for (var i = 0; i < size; i++) {
      resultItems[HASH_key = _HASH + (key = keys[i])] =
        mapper.call(context, items[HASH_key], key, this);
    }
    return result; // returns a Collection
  },

  put: function(key, item) {
    var args = arguments;
    if (args.length === 1) {
      args[args.length++] = item = key;
    }
    
    // Make sure it's an instance of Item.
    var klass = this.constructor;
    if (klass.Item && !(item instanceof klass.Item)) {
      args[args.length++] = this;
      item = klass.createItem.apply(klass, args);
    }
    
    // Update the keys array.
    var keys, items = this[_ITEMS];
    var HASH_key = _HASH + key;
    if (!(HASH_key in items)) {
      (keys = this[_KEYS])[keys.length] = String(key);
    }
    
    // Write the new item.
    items[HASH_key] = item;
    
    return item;
  },

  putAt: function(index, item) {
    var key = Array2_item(this[_KEYS], index); // Allow negative indexes.
    if (key == null) throw new RangeError(INDEX_OUT_OF_BOUNDS_ERR);
    arguments[0] = key;
    return this.put.apply(this, arguments);
  },

  remove: function(key) {
    // The remove() method can be slow so check if the key exists first.
    var items = this[_ITEMS];
    var HASH_key = _HASH + key;
    if (HASH_key in items) {
      delete items[HASH_key];
      var keys = this[_KEYS],
          index = Array2.indexOf(keys, String(key));
      if (index !== -1) keys.splice(index, 1);
    }
  },

  removeAt: function(index) {
    var removed = this[_KEYS].splice(index, 1);
    if (removed.length) {
      delete this[_ITEMS][_HASH + removed[0]];
    }
  },

  reverse: function() {
    this[_KEYS].reverse();
    return this;
  },

  size: function() {
    return this[_KEYS].length;
  },

  slice: function(start, end) {
    var result = this.copy();
    if (arguments.length > 0) {
      var removed = result[_KEYS],
          size = removed.length;
      start = _clamp(start, size);
      end = isNaN(end) ? size : _clamp(end, size);
      var keys = removed.splice(start, end - start),
          i = removed.length,
          resultItems = result[_ITEMS];
      while (i--) delete resultItems[_HASH + removed[i]];
      result[_KEYS] = keys;
    }
    return result;
  },

  sort: function(compare) {
    if (compare) {
      var items = this[_ITEMS];
      this[_KEYS].sort(function(key1, key2) {
        return compare(items[_HASH + key1], items[_HASH + key2], key1, key2);
      });
    } else {
      this[_KEYS].sort();
    }
    return this;
  },

  toString: function() {
    return "(" + (this[_KEYS] || "") + ")";
  }
}, {
  Item: null, // If specified, all members of the collection must be instances of Item.

  createItem: function(key, item, owner) {
    return this.Item ? new this.Item(key, item, owner) : item;
  },
  
  extend: function(_instance, _static) {
    var klass = this.base(_instance);
    klass.createItem = this.createItem;
    if (_static) extend(klass, _static);
    if (!klass.Item) {
      klass.Item = this.Item;
    } else if (typeof klass.Item != "function") {
      klass.Item = (this.Item || Base).extend(klass.Item);
    }
    if (klass.init) klass.init();
    return klass;
  }
});
