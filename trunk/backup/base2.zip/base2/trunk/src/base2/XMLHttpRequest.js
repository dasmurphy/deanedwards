
// http://www.w3.org/TR/XMLHttpRequest2/

// Credits: Sergey Ilinsky (http://www.ilinsky.com/articles/XMLHttpRequest/)

base2.require("events", function(namespace) { // begin: closure

eval(namespace); // import

var _private = $$base2;

/*@cc_on @*/

var UNSENT =            0,
    OPENED =            1,
    HEADERS_RECEIVED =  2,
    LOADING =           3,
    DONE =              4;

var XHR_INVALID_STATE_ERR = "INVALID_STATE_ERR: XMLHttpRequest";

var XHR_DEFAULT_VALUES = {
  responseXML: null,
  responseText: "",
  status: 0,
  statusText: ""
};

var XHR_PROPERTIES = pcopy(XHR_DEFAULT_VALUES, {readyState: UNSENT});

function XMLHttpRequest() {
  if (_private.createXHR == Null) {
    throw new Error("XMLHttpRequest is not supported on this platform.");
  }

  var self = this;
  var transport, headers;
  var isAsync, requestMethod;
  var sent, error; // flags
  var timeout, timer, started;

  var properties = pcopy(XHR_PROPERTIES);

  forEach (properties, function(value, propertyName) {
    createGetter(self, propertyName, value, function() {
      return properties[propertyName];
    });
  });

  if (!self.__defineGetter__) {
    properties = self; // properties are writeable
  }

  this.abort = function() {
    error = true;
    abort();
    if (sent && properties.readyState < DONE) {
      properties.readyState = DONE;
      sent = false;
      dispatchEvent("readystatechange");
      dispatchEvent("abort");
      dispatchEvent("loadend");
    }
    properties.readyState = UNSENT;
  };

  this.open = function(method, url, async, user, password) {
    switch (arguments.length) {
      case 2: async = true;
      case 3: user = "";
      case 4: password = "";
        break;
      default:
        assertArity(arguments, 2);
    }

    if (transport) abort();
    
    isAsync = async;
    requestMethod = String2.toUpperCase(method);
    sent = error = false;
    headers = {};
    timeout = 0;

    try {
      transport = _private.createXHR();
      transport.open(method, url, async, user, password);
    } catch (ex) {
      error = ex;
    }
    properties.readyState = OPENED;
    dispatchEvent("readystatechange");
  };

  this.send = function(data) {
    if (sent || properties.readyState !== OPENED) {
      throw new TypeError(XHR_INVALID_STATE_ERR);
    }
    if (arguments.length === 0 || requestMethod === "GET" || requestMethod === "HEAD") {
      data = null;
    }
    /*
    // http://www.ilinsky.com/articles/XMLHttpRequest/#bugs-safari-send-document
    if (data && "nodeType" in data) {
      data = global.XMLSerializer ? new XMLSerializer().serializeToString(data) : data.xml || data;
      if (!headers["content-type"]) {
        transport.setRequestHeader("Content-Type", "application/xml");
      }
    }
    */
    timeout = self.timeout;
    if (!error) {
      try {
        transport.send(data);
        started = now();
      } catch (ex) {
        error = ex;
      }
    }
    if (isAsync) {
      sent = true;
      dispatchEvent("loadstart");
    }
    if (error) {
      properties.readyState = DONE;
      dispatchEvent("readystatechange");
      dispatchEvent("error");
      throw error;
    }
    if ("onerror" in transport) {
      transport.onerror = partial(dispatchError, "error");
    }
    if (timeout && !isNaN(timeout)) {
      timer = setTimeout(partial(dispatchError, "timeout"), timeout + started - now());
    }
    if (isAsync && "onprogress" in transport) {
      transport.onprogress = partial(dispatchEvent, "progress");
    }
    transport.onreadystatechange = onreadystatechange;
    onreadystatechange();
  };

  this.setRequestHeader = function(header, value) {
    if (sent || properties.readyState !== OPENED) {
      throw new TypeError(XHR_INVALID_STATE_ERR);
    }
    headers[String2.toLowerCase(header)] = value;
    transport.setRequestHeader(header, value);
  };

  this.getAllResponseHeaders = function() {
    if (properties.readyState < HEADERS_RECEIVED || error) return null;
    return transport.getAllResponseHeaders();
  };

  this.getResponseHeader = function(header) {
    if (properties.readyState < HEADERS_RECEIVED || error) return null;
    return transport.getResponseHeader(header);
  };

  function abort() {
    if (transport) {
      clearTimeout(timer);
      extend(properties, XHR_DEFAULT_VALUES);
      transport.onreadystatechange = Undefined;
      if (_NativeXHR) {
        transport.onprogress = null;
        transport.onerror = null;
      }
      try {
        transport.abort();
      } catch(ex) {
        // ignore
      }
      transport = null; // de-reference
    }
  };

  function dispatchError(type) {
    error = true;
    abort();
    properties.readyState = DONE;
    dispatchEvent(type);
    dispatchEvent("loadend");
    properties.readyState = UNSENT;
  };

  function dispatchEvent(type) {
    return EventTarget.dispatchEvent(self, new Event(type));
  };

  function onreadystatechange() {
    if (timeout && (now() - started > timeout)) {
      dispatchError("timeout");
      return;
    }
    while (properties.readyState < transport.readyState) {
      switch (properties.readyState + 1) {
        case HEADERS_RECEIVED:
          try {
            transport.getAllResponseHeaders(); // test readyState
          } catch (ex) {  // MISE6-7 and Opera 9
            return; // process this readyState the next time round
          }
          if (transport.status === 304 && !headers["if-none-match"] && !headers["if-modified-since"]) {
            properties.status = 200;
            properties.statusText = "OK";
          } else {
            properties.status = transport.status;
            properties.statusText = transport.statusText;
          }
          break;

        case LOADING:
          properties.responseText = transport.responseText;
          break;

        case DONE:
          clearTimeout(timer);
          var xml = transport.responseXML;
          if (xml) {
            var root = xml.documentElement;
            /*@if (@_jscript)
            // http://www.ilinsky.com/articles/XMLHttpRequest/#bugs-ie-responseXML-content-type
            if (!root && /\+xml$/i.test(transport.getResponseHeader("Content-Type"))) {
              xml = _private.createCOMObject("Microsoft.XMLDOM");
              xml.async = false;
              xml.validateOnParse = false;
              xml.loadXML(properties.responseText);
            }
            properties.responseXML = xml.parseError == 0 ? xml : null;
            @else @*/
            if (root && !/parsererror/.test(root.namespaceURI)) {
              properties.responseXML = xml;
            }
            /*@end @*/
          }
          transport.onreadystatechange = Undefined; // prevent memory leaks
          // I could destroy the transport object here but it seems to be garbage collected anyway
          break;
      }
      properties.readyState++;
      dispatchEvent("readystatechange");
      if (properties.readyState === DONE) {
        dispatchEvent("load");
        dispatchEvent("loadend");
      }
    }
  };
};

// Instantiate the constructor above so that the source text of methods is visible.
XMLHttpRequest = Base.extend(XMLHttpRequest.prototype = new XMLHttpRequest);

forEach ({ // Add the constants to both interfaces
  UNSENT:            UNSENT,
  OPENED:            OPENED,
  HEADERS_RECEIVED:  HEADERS_RECEIVED,
  LOADING:           LOADING,
  DONE:              DONE
}, function(value, propertyName) {
  createGetter(XMLHttpRequest, propertyName, value);
  createGetter(XMLHttpRequest.prototype, propertyName, value);
});

XMLHttpRequest.implement({
  timeout: 0,
  onloadstart: null,
  onprogress:  null,
  onabort:     null,
  onerror:     null,
  onload:      null,
  ontimeout:   null,
  onloadend:   null
});

XMLHttpRequest.implement(EventTarget);

base2.addName("XMLHttpRequest", XMLHttpRequest);

}); // end: closure
