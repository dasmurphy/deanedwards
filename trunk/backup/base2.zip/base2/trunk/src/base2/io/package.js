
base2.io = new _.Package({
  name:   "base2.io",
  version: base2.version,
  
  NOT_SUPPORTED: NOT_SUPPORTED,
  
  READ: READ,
  WRITE: WRITE,
  
  FileSystem: FileSystem,
  Directory: Directory,
  LocalFileSystem: LocalFileSystem,
  LocalDirectory: LocalDirectory,
  LocalFile: LocalFile
});
