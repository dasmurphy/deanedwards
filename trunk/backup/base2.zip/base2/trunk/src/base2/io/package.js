
var io = new Package({
  name:    "io",
  version: base2.version,
  
  exports: {
    NOT_SUPPORTED: NOT_SUPPORTED,
    READ: READ,
    WRITE: WRITE,
    FileSystem: FileSystem,
    Directory: Directory,
    LocalFileSystem: LocalFileSystem,
    LocalDirectory: LocalDirectory,
    LocalFile: LocalFile,
    JSONFileSystem: JSONFileSystem,
    JSONDirectory: JSONDirectory
  }
});
