
var JSONDirectory = Directory.extend(null, {
  createItem: function(name, item) {
    return new this.Item(name, typeof item == "object", typeof item == "string" ? item.length : 0);
  }
});
