
var Requirements = Collection.extend({
  constructor: function(requirements, callback, async) {
    this.async = async !== false;

    this.base(requirements);

    var already = isBrowser && (_private.isReady || "complete" === document.readyState);
    
    requirements = this;
    
    deferUntil(function() { // defer
      requirements.namespace = requirements.reduce(function(namespace, requirement) {
        return namespace += requirement.object.namespace || "";
      }, "");
      // Execute the callback function.
      if (typeof callback == "function") {
        _exec(callback, requirements.namespace, requirements.pluck("object"));
        // Cater for occassions where scripts are required in the <head> but
        // the DOMContentLoaded event has passed before the required script is loaded.
        if (isBrowser && !already && _private.isReady && _private.dispatchReady) {
          _private.dispatchReady(document);
        }
      }
    }, function() { // until
      requirements.invoke("tick");
      return requirements.every(function(requirement) {
        return !!requirement.object;
      });
    }, 0, require.TIMEOUT, function() { // timeout
      throw new Error("Failed to load requirements.");
    });
  },
  
  toString: function() {
    return this.join(",");
  }
},{
  Item: Requirement
});
