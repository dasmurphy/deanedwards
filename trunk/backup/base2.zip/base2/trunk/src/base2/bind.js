
var isBound = false;
var ES5_METHODS = {every:1, filter:1, forEach:1, indexOf:1, lastIndexOf:1, map:1, reduce:1, reduceRight:1, some:1, toISOString:1, bind:1, trim:1};

base2.bind = function(host, useBase2Extensions) {
  forEach.csv("Array,Date,String,Function", function(name) {
    var _proto = host[name].prototype;
    if (useBase2Extensions) {
      extend(host[name], base2[name+2]);
    }
    var _proto2 = base2[name+2].prototype;
    for (var i in _proto2) if (useBase2Extensions || ES5_METHODS[i] === 1) {
      _proto[i] = _proto2[i];
    }
  });
  host.Array.isArray = Array2.isArray;
  if (Date2.parse != Date_parse) {
    host.Date = base2_Date;
  }
  if (useBase2Extensions) {
    host.Date.toISOString = Date2.toISOString;
  }
  host.Date.now = now;
  if (!host.JSON) host.JSON = base2.JSON;
  if (host == global) isBound = useBase2Extensions;
  return host;
};

if (global.JSON) {
  base2.namespace = base2.namespace.replace(/var JSON=[^;]+;/, "");
}
