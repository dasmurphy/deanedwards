
// http://www.w3.org/TR/DOM-Level-2-Events/events.html#Events-Registration-interfaces

_addEventListener = function addEventListener(type, listener, useCapture) {
  var methodName = "addEventListener";

  if (arguments.length < 2) {
    throw new ArityError(methodName);
  }

  if (eventWrappers[type]) {
    if (type == "DOMContentLoaded") useCapture = false;
    listener = eventWrappers[type](type, listener);
    type = wrappedTypes[type] || type;
  } else if (!SUPPORTS_OBJECT_LISTENER && typeof listener == "object") {
    listener = wrapObjectListener(type, listener);
  } else if (SILENT_DISPATCH || FORGETS_CUSTOM_DATA) {
    listener = wrapListener(type, listener);
  }

  if (SUPPORTS_EVENT_TARGET) {
    var method = protoMethods[this[PROTO_TYPE] + methodName] || this[methodName];
    method.call(this, type, listener, !!useCapture);
  } else {
    _DocumentState.getInstance(this)[methodName](this, type, listener, useCapture);
  }
};

_removeEventListener = function removeEventListener(type, listener, useCapture) {
  var methodName = "removeEventListener";

  if (arguments.length < 2) {
    throw new ArityError(methodName);
  }
  
  if (type == "DOMContentLoaded") {
    useCapture = false;
  }

  listener = _unwrap(type, listener);
  type = wrappedTypes[type] || type;

  if (SUPPORTS_EVENT_TARGET) {
    var method = protoMethods[this[PROTO_TYPE] + methodName] || this[methodName];
    method.call(this, type, listener, !!useCapture);
  } else {
    _DocumentState.getInstance(this)[methodName](this, type, listener, useCapture);
  }
};

// feature tests
if (element.dispatchEvent) {
  SUPPORTS_OBJECT_LISTENER = false;
  testEvent({
    handleEvent: function() {
      SUPPORTS_OBJECT_LISTENER = true;
    }
  });
  testEvent(function(event) {
    FORGETS_CUSTOM_DATA = event._customData !== true;
  }, {_customData: true});
  if (FORGETS_CUSTOM_DATA) _createEvent = createEventFix;
}

if (!SUPPORTS_EVENT_TARGET || SILENT_DISPATCH || FORGETS_CUSTOM_DATA) {
  _dispatchEvent = function dispatchEvent(event) {
    var methodName = "dispatchEvent";

    if (arguments.length < 1) {
      throw new ArityError(methodName);
    }

    event._userGenerated = true;
    
    if (SUPPORTS_EVENT_TARGET) {
      customEvents[event.detail] = event;
      var method = protoMethods[this[PROTO_TYPE] + methodName] || this[methodName];
      var returnValue = method.call(this, event);
      delete customEvents[event.detail];
      return returnValue;
    } else {
      event.target = this;
      return _DocumentState.getInstance(this)[methodName](this, event);
    }
  };
}

function testEvent(listener, data) {
  try {
    var event = document.createEvent("Event");
    var type = "base2:test";
    event.initEvent(type, true, false);
    for (var i in data) event[i] = data[i];
    documentElement.addEventListener(type, listener, false);
    documentElement.dispatchEvent(event);
    documentElement.removeEventListener(type, listener, false);
  } catch (ex) {}
}
