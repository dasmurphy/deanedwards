
var classList = (function() {
  var FN = 'return function {1}(e, c) {\n' +
    '  if (arguments.length < 2) {\n' +
    '    throw new SyntaxError("' + DOM_ARITY_ERR + '");\n' +
    '  }\n' +
    '  if (!e || e.nodeType !== 1) {\n' +
    '    throw new TypeError("' + DOM_TYPE_ERR + '");\n' +
    '  }\n' +
    '  if (c === "") {\n' +
    '    throw new Error("c cannot be an empty string: {0}().");\n' +
    '  }\n' +
    '  if (/\\s/.test(c)) {\n' +
    '    throw new Error("c cannot contain spaces: {0}().");\n' +
    '  }\n' +
    '  return e.{0}(c);\n' +
    '}';

  ;doc; FN = FN.replace(/\bc\b/g, "className").replace(/\be\b/g, "element");

  function createMethod(name) {
    return new Function("r", _.format(FN, "classList." + name, name))();
  }

  return {
    add:      createMethod("add"),
    contains: createMethod("contains"),
    remove:   createMethod("remove"),
    toggle:   createMethod("toggle"),

    toString: _.K("[base2.dom.classList]")
  };
})();
