
var IGNORE = _.RegGrp.IGNORE;

var prependScope = new CSSSelectorParser([
  /^\s*:scope/,  IGNORE,
  "<#string>",   IGNORE,
  /\\./,         IGNORE,
  /,\s*:scope/,  IGNORE,
  /^\s*(.)/,     ":scope $1",
  ",",           ",:scope "
]);

var scopeToId = new CSSSelectorParser([
  "<#string>", IGNORE,
  /\\./,       IGNORE,
  ":scope",    "" // set later
]);

var scopeId = scopeToId.getAt(2);

if (!element.matches) {
  var _matches = _private.get(element, "matchesSelector");
}

if (!element.find) {
  var _find = function find(selector) {
    if (arguments.length < 1) {
      throw TypeError(Arity("find"));
    }

    selector = prependScope.parse(selector);

    var node = this;
    if (node.nodeType === 1) {
      var scope = this;
      node = node.parentNode || node;
    }

    return executeQuery("querySelector", node, selector, scope);
  };

  var _findAll = function findAll(selector) {
    if (arguments.length < 1) {
      throw TypeError(Arity("findAll"));
    }

    selector = prependScope.parse(selector);

    var node = this;
    if (node.nodeType === 1) {
      var scope = this;
      node = node.parentNode || node;
    }

    return executeQuery("querySelectorAll", node, selector, scope);
  };
}

function executeQuery(methodName, node, selector, scope) {
  var document = node.ownerDocument || node;
  var scopedNode = scope || node;
  var scopedSelector = selector;

  if (selector.indexOf(":scope") !== -1) { // Probably. :) It's not worth parsing it fully just yet.
    if (scopedNode == document) {
      scopedNode = document.documentElement;
      scopeId.replacement = ":root";
    } else {
      var fakeId = !scopedNode.id;
      if (fakeId) scopedNode.id = _.assignID();
      scopeId.replacement = '[id="' + scopedNode.id + '"]';
    }
    scopedSelector = scopeToId.parse(selector);
  }

  var result = node[methodName].call(node, scopedSelector);

  if (fakeId) {
    scopedNode.removeAttribute("id");
  }

  return result;
};
