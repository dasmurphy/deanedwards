
// a constructor that binds ClassList objects to elements
function _HTMLElement_ClassList(data) {
  // For most platforms, data is the element itself.
  // For MSIE6, data is a pointer to the element in the document.
  this._data = data;
};

var _classList_element = detect("(jscript<5.7)") ? "document[this._data]" : "this._data";

forEach.csv("add,contains,remove,toggle", function(methodName) {
  _HTMLElement_ClassList.prototype[methodName] = new Function("t", format("return base2.dom.classList.%1(%2,t)", methodName, _classList_element));
});
