
var EventDispatcher = events.Dispatcher.extend({
  constructor: function(state) {
    this.state = state;
    this.events = state.events;
  },

  dispatch: function(event) {
    event = new Event(event);
    if (MOUSE_BUTTON.test(event.type)) {
      var button = MOUSE_CLICK.test(event.type) ? this.state._button : event.button;
      event.button = BUTTON_MAP[button] || 0;
    }
    return this.base(event);
  }
}, {
  BUBBLE_TARGET: "parentNode"
});
