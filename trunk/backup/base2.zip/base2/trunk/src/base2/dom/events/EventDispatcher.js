
var EventDispatcher = events.Dispatcher.extend({
  constructor: function(state) {
    this.state = state;
    this.events = state.events;
  },

  dispatch: function(event) {
    var type = event.type;
    if (!event.timeStamp) {
      event.bubbles = !NO_BUBBLE.test(type);
      event.cancelable = CANCELABLE.test(type);
      event.timeStamp = now();
    }
    extend(event, Event.prototype);
    event = Event.cloneEvent(event);
    event.relatedTarget = event[(event.target == event.fromElement ? "to" : "from") + "Element"] || null;
    if (EVENT_MAP[type]) {
      type = event.type = EVENT_MAP[type];
      event.bubbles = !NO_BUBBLE.test(type);
    }
    if (MOUSE_BUTTON.test(type)) {
      var button = MOUSE_CLICK.test(type) ? this.state._button : event.button;
      event.button = BUTTON_MAP[button] || 0;
    }
    return this.base(event);
  }
}, {
  BUBBLE_TARGET: "parentNode"
});
