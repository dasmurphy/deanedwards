
var CUBIC_BEZIER = /^cubic\-bezier\([.\d]+,[.\d]+,[.\d]+,[.\d]+\)$/;

function cubizBezier(x1, y1, x2, y2) {
  // Based on https://github.com/rdallasgray/bez/
  return function(t, b, c, d) {
    var C = 3 * x1;
    var B = 3 * (x2 - x1) - C;
    var A = 1 - C - B;
    var x = (t /= d), z;
    var i = 0;
    while (++i < 14) {
      z = (x * (C + x * (B + x * A))) - t;
      if (z === 0 || (z > 0 && z < 1e-3) || (z < 0 && z > -1e-3)) break;
      x -= z / (C + x * (2 * B + 3 * A * x));
    }
    C = 3 * y1;
    B = 3 * (y2 - y1) - C;
    A = 1 - C - B;
    return c * (x * (C + x * (B + x * A))) + b;
  };
}

var ease = cubizBezier(0.25, 0.1, 0.25, 1); // default

var parseTimingFunction = _.memoize(function(fn) {
  fn = String(fn).replace(/\s+/g, "");
  if (CUBIC_BEZIER.test(fn)) {
    return cubizBezier.apply(null, fn.slice(13, -1).split(","));
  }
  return ease; // default
});

parseTimingFunction.cache = {
  "ease": ease,
  "ease-in": cubizBezier(0.42, 0, 1, 1),
  "ease-out": cubizBezier(0, 0, 0.58, 1),
  "ease-in-out": cubizBezier(0.42, 0, 0.58, 1),

  "linear": function(t, b, c, d) {
    return c*t/d + b;
  }
};

_private.parseTimingFunction = parseTimingFunction;
