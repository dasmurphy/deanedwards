
var HTMLElement = Element.extend({
  // The spec says return an empty string, most browsers disagree and return null.
  // base2 agrees with most browsers.
  "@(element.getAttribute('made-up')===''||element.getAttribute('id')!=null||element.getAttribute('expando'))": {
    getAttribute: _getAttribute,

    "@(jscript)": {
      hasAttribute: _hasAttribute,
      
      removeAttribute: function(element, name) {
        var attribute = element.getAttributeNode(name);
        if (attribute) {
          if ("className" in element) {
            name = String2.toLowerCase(name);

            if (name === "class") {
              element.className = "";
            } else if (name === "style") {
              element.style.cssText = "";
            } else {
              var nodeName = element.nodeName;
              if (nodeName === "INPUT") {
                switch (name) {
                  case "type":
                    return; // can't remove the type attribute but try not to error

                  case "checked":
                    element.checked = element.defaultChecked = false;
                    return;

                  case "value":
                    element.value = element.defaultValue = "";
                }
              }
              if (_EVENT_ATTRIBUTE.test(name)) {
                element[name] = null;
              } else {
                // reset the nodeValue to its default
                var defaultValues = _DEFAULT_VALUES[nodeName];
                if (defaultValues && name in defaultValues) {
                  attribute.nodeValue = defaultValues[name];
                }
              }
            }
          }
          element.removeAttributeNode(attribute);
        }
      },

      setAttribute: function(element, name, value) {
        name = String2.toLowerCase(name);
        value = String(value);
        
        var isHTML = "className" in element;

        if (isHTML && name === "style") {
          element.style.cssText = value;
        } else {
          if (isHTML && element.nodeName === "INPUT") {
            switch (name) {
              case "checked":
                element.checked = element.defaultChecked = true;
                return;

              case "value":
                element.value = element.defaultValue = value;
            }
          }
          if (isHTML && _EVENT_ATTRIBUTE.test(name)) {
            var dummy = document.createElement(element.nodeName);
            dummy.setAttribute(name, value);
            element.mergeAttributes(dummy);
          } else {
            var attribute = element.getAttributeNode(name);
            try {
              if (attribute) {
                attribute.nodeValue = typeof attribute.nodeValue == "boolean" ? true : value;
              } else {
                var method = "setAttribute";
                if (element["_" + method]) method = "_" + method;
                element[method](name, value);
                if (isHTML) element.className += ""; // recalc
              }
            } catch (ex) {
              // not much we can do here
            }
          }
        }
      }
    }
  }
});

/*@if (@_jscript)
var _DEFAULT_PROPERTY  = {checked:"defaultChecked", selected:"defaultSelected", value:"defaultValue"};
var _USE_IFLAG         = {action:1, cite:1, colspan:1, codebase:1, data:1, dynsrc:1, enctype:1, href:1, longdesc:1, lowsrc:1, profile:1, rowspan:1, src:1, type:1, usemap:1, url:1};
var _BOOLEAN_ALIASES   = {readonly: "readOnly", ismap: "isMap"};
var _EVENT_ATTRIBUTE   = /^on[a-z]{3,}$/;
var _DEFAULT_VALUES = {
  COL:      {span: 1},
  COLGROUP: {span: 1},
  FORM:     {enctype: "application/x-www-form-urlencoded"},
  TEXTAREA: {rows: 2, cols: 20},
  TD:       {rowspan: 1, colspan: 1},
  TH:       {rowspan: 1, colspan: 1}
};
/*@end @*/

function _getAttribute(element, name) {
  name = String2.toLowerCase(name);

  var attribute = element.getAttributeNode(name);
  var specified = attribute && attribute.specified;

  /*@if (@_jscript)
    if ("className" in element) {
      var defaultName = _DEFAULT_PROPERTY[name];
      if (typeof defaultName == "string" && defaultName in element) {
        if (name === "value") {
          if (element.nodeName === "INPUT") {
            return element.defaultValue || null;
          }
        } else return element[defaultName] ? "" : null;
      }

      var name2 = _BOOLEAN_ALIASES[name] || name;
      if (typeof element[name2] == "boolean") return element[name2] ? "" : null;

      if (specified && name === "style") return element.style.cssText.toLowerCase();

      if ((specified && _USE_IFLAG[name]) || name === "enctype") {
        var method = "getAttribute";
        if (element["_" + method]) method = "_" + method;
        value = element[method](name, 2);
        return value == null ? null : String(value);
      }
    }
  /*@end @*/

  return specified ? String(attribute.nodeValue) : null;
};

function _hasAttribute(element, name) {
  return _getAttribute(element, name) != null;
};
