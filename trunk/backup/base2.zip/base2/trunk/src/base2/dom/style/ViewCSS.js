
// http://www.w3.org/TR/DOM-Level-2-Style/css.html#CSS-ViewCSS

var ViewCSS = Trait.extend({
  "@!(document.defaultView.getComputedStyle)": {
    getComputedStyle: function(view, element, pseudoElement) {
      // pseudoElement parameter is not supported
      var currentStyle  = element.currentStyle,
          computedStyle = _CSSStyleDeclaration_ReadOnly({});
          
      for (var propertyName in currentStyle) {
        if (_METRICS.test(propertyName) || _COLOR.test(propertyName)) {
          computedStyle[propertyName] = this.getComputedPropertyValue(view, element, propertyName);
        } else if (propertyName.indexOf("ruby") !== 0) {
          computedStyle[propertyName] = currentStyle[propertyName];
        }
      }
      for (var i = 0; propertyName = _CALCULATED_STYLE_PROPERTIES[i]; i++) {
        computedStyle[propertyName] = this.getComputedPropertyValue(view, element, propertyName);
      }
      return computedStyle;
    }
  },

  "@(getComputedStyle(document.documentElement,null).color.charAt(0)==='#')": { // For Opera 9
    getComputedStyle: function(view, element, pseudoElement) {
      var computedStyle = this.base(view, element, pseudoElement),
          fixedStyle = pcopy(computedStyle);
      for (var propertyName in computedStyle) {
        if (_COLOR.test(propertyName)) {
          fixedStyle[propertyName] = _toRGB(computedStyle[propertyName]);
        } else if (typeof computedStyle[propertyName] == "function") {
          fixedStyle[propertyName] = function() {
            return computedStyle[propertyName].apply(computedStyle, arguments);
          };
        }
      }
      return fixedStyle;
    }
  }
}, {
  prefix: "",
  "@Gecko":  {prefix: "Moz"},
  "@KHTML":  {prefix: "Khtml"},
  "@Webkit": {prefix: "Webkit"},
  "@Opera":  {prefix: "O"},
  "@MSIE":   {prefix: "Ms"},
  
  getComputedPropertyValue: function(view, element, propertyName) {
    return CSSStyleDeclaration.getPropertyValue(this.getComputedStyle(view, element, null), propertyName);
  },

  "@!(document.defaultView.getComputedStyle)": {
    getComputedPropertyValue: function(view, element, propertyName) {
      var currentStyle = element.currentStyle,
          value = currentStyle[propertyName];

      if (value == null) {
        propertyName = _getPropertyName(propertyName);
        value = currentStyle[propertyName] || "";
      }
      
      switch (propertyName) {
        case "float":
        case "cssFloat":
          return currentStyle.cssFloat || currentStyle.styleFloat || "";
          
        case "opacity":
          return value === "" ? "1" : value;
          
        case "clip":
          return "rect(" + [
            currentStyle.clipTop,
            currentStyle.clipRight,
            currentStyle.clipBottom,
            currentStyle.clipLeft
          ].join(", ") + ")";
          
        case "backgroundPosition":
          return currentStyle.backgroundPositionX + " " + currentStyle.backgroundPositionY;
          
        case "boxSizing":
          return value === ""
            ? /^CSS/.test(element.ownerDocument.compatMode)
              ? "content-box"
              : "border-box"
            : value;
      }

      if (value.indexOf(" ") > 0) return value;
      
      if (_METRICS.test(propertyName)) {
        if (_PIXEL.test(value)) return value;
        if (value === "auto") return "0px";
        if (propertyName.indexOf("border") === 0) {
          if (currentStyle[propertyName.replace("Width", "Style")] === "none") return "0px";
          value = _NAMED_BORDER_WIDTH[value] || value;
          if (typeof value == "number") return value + "px";
        }
        /*@if (@_jscript)
          if (_NUMBER.test(value)) return _MSIE_getPixelValue(element, /[Ww]idth|[lL]eft|X/.test(propertyName) ? "left" : "top", value);
        /*@end @*/
      } else if (_COLOR.test(propertyName)) {
        if (value === "transparent") return value;
        if (/^(#|rgb)/.test(value)) return _toRGB(value);
        /*@if (@_jscript)
          return _MSIE_getColorValue(value);
        /*@end @*/
      }
      
      return value;
    }
  }
});
