
HTMLDocument.bind = function(document) {
  _DocumentState.getInstance(document);
  return Document.bind(document);
};
