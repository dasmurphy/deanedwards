
// This object can be instantiated, however it is probably better to use
// the querySelector/querySelectorAll methods on DOM nodes.

// It is analogous to a RegExp for the DOM. ;)

// There is no public standard for this object.

// Usage:
//
// var sel = new Selector("span#example a:first-child");
//
// var elements = sel.exec(document);         // Find all matching elements in the document.
// var elements = sel.exec(element);          // Find all matching elements contained by the element.
// var elements = sel.exec();                 // The host document is the default context.
// var elements = sel.exec(document, true);   // Retrieve a single element.
// var elements = sel.exec(fragment);         // Querying documents fragments is allowed.
// var elements = sel.exec(xmlDocument);      // Querying XML documents/elements is allowed.
//

var EXTENDED_CONTEXT = /^[+~>]/;

var Selector = Base.extend({
  constructor: function(selector) {
    this.toString = K(trim(selector));
  },

  exec: function(node, isSingleSelection, useBase2API) {
    var result = isSingleSelection ? null : new StaticNodeList;
    if (arguments.length === 0) node = document;
    var context = node,
        ref = null,
        selector = this;
    if (useBase2API) {
      ref = node;
      if (EXTENDED_CONTEXT.test(this)) {
        context = node.parentNode;
        selector = "*" + this;
      } else {
        useBase2API = false;
      }
    }
    return selectQuery.create(selector, useBase2API)(context, result, ref);
  },

  split: function() {
    return Array2.map(String2.csv(escape(this)), function(selector) {
      return new Selector(unescape(selector));
    });
  },

  test: function(element) {
    return matchQuery.create(this)(element);
  }
});
