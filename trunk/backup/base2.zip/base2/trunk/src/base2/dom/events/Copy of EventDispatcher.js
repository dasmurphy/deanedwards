
var EventDispatcher = Base.extend({
  constructor: function(state) {
    this.state = state;
  },

  dispatch: function(nodes, event, phase, map) {
    event.eventPhase = phase;
    var i = nodes.length;
    var ontype = "on" + event.type;
    while (i-- && !event.cancelBubble) {
      var target = event.currentTarget = nodes[i],
          listeners = map[target.nodeType === 1 ? target.uniqueID : target.base2ID];
      event.eventPhase = target == event.target ? AT_TARGET : phase;
      if (target[ontype]) {
        callOutOfContext(target[ontype], target, event);
      }
      if (listeners) {
        listeners = copy(listeners);
        for (var listenerID in listeners) {
          var listener = listeners[listenerID];
          if (typeof listener == "function") {
            callOutOfContext(listener, target, event);
          } else {
            callOutOfContext(listener.handleEvent, listener, event);
          }
          if (event.returnValue === false) {
            event.preventDefault();
          }
        }
      }
    }
  },

  handleEvent: function(event) {
    event = Event.cloneEvent(Event.bind(event));
    var type = event.type;
    
    if (EVENT_MAP[type]) {
      type = event.type = EVENT_MAP[type];
      event.bubbles = !NO_BUBBLE.test(type);
    }

    var typeMap = this.state.events[type];
    if (typeMap) {
      // Fix the mouse button (left=0, middle=1, right=2)
      if (MOUSE_BUTTON.test(type)) {
        var button = MOUSE_CLICK.test(type) ? this.state._button : event.button;
        event.button = BUTTON_MAP[button] || 0;
      }

      // Collect nodes in the event hierarchy
      var target = event.target, nodes = [], i = 0;
      while (target) {
        nodes[i++] = target;
        target = target.parentNode;
      }

      // Dispatch.
      var map = typeMap[CAPTURING_PHASE];
      if (map) this.dispatch(nodes, event, CAPTURING_PHASE, map);
      map = typeMap[BUBBLING_PHASE];
      if (map && !event.cancelBubble) {
        if (event.bubbles) {
          nodes.reverse();
        } else {
          nodes.length = 1;
        }
        this.dispatch(nodes, event, BUBBLING_PHASE, map);
      }
    }
    return event.returnValue !== false;
  }
});
