
// http://www.w3.org/TR/DOM-Level-3-Core/core.html#ID-B63ED1A3

var DocumentFragment = Node.extend();
