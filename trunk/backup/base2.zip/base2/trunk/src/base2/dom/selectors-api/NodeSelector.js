
// http://www.w3.org/TR/selectors-api/#nodeselector

var NodeSelector = Trait.extend({
  querySelector: function(node, selector) {
    if (selector == null) {
      assertArity(arguments, 2);
      return null;
    }
    return executeQuery(node, "querySelector", selector, true);
  },
  
  querySelectorAll: function(node, selector) {
    if (selector == null) {
      assertArity(arguments, 2);
      return new StaticNodeList;
    }
    return executeQuery(node, "querySelectorAll", selector);
  }
});

function executeQuery(node, method, selector, isSingleSelection) {
  if (SUPPORTS_QSA) {
    if (!(selector in useBase2)) {
      useBase2[selector] = USE_BASE2.test(selector) || (FIX_CAPS_SELECTOR && CAPS_SELECTOR.test(selector) && !/^CSS/.test((node.ownerDocument || node).compatMode));
    }
    var shouldUseBase2 = useBase2[selector];
    /*@if (@_jscript)
      shouldUseBase2 |= _BUGGY_OBJECT_QSA && node.nodeName === "OBJECT";
    /*@end @*/
    if (!shouldUseBase2) {
      var ancestor = node[method].ancestor;
      if (selector in safeSelectors) {
        result = ancestor ? ancestor.call(node, selector) : node[method](selector);
      } else {
        try {
          var result = ancestor ? ancestor.call(node, selector) : node[method](selector);
          safeSelectors[selector] = true;
        } catch (ex) {
          // assume it's an unsupported selector
          shouldUseBase2 = useBase2[selector] = true;
        }
      }
      if (!shouldUseBase2) {
        return !isSingleSelection && StaticNodeList.extended ? StaticNodeList(result) : result; // cast
      }
    }
  }
  var query = selectQuery.cache[selector];
  if (!query) {
    query = selectQuery.create(selector);
  }
  return query(node, isSingleSelection ? null : new StaticNodeList);
};
