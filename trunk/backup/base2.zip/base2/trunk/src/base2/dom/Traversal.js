
// DOM Traversal. Just the basics.

var Traversal = Trait.extend({
  contains: contains,

  getFirstElementChild: function(element) {
    return _getElementChild(element, "first");
  },

  getLastElementChild: function(element) {
    return _getElementChild(element, "last");
  },

  getNextElementSibling: function(element) {
    return _getElementSibling(element, "next");
  },
  
  getPreviousElementSibling: function(element) {
    return _getElementSibling(element, "previous");
  }
});

function contains(node, target) {
  while (target && (target = target.parentNode) && node != target) continue;
  return !!target;
};

function includes(node, target) {
  return !!target && (node == target || contains(node, target));
};

// These functions are passed to Selectors API queries.

function _getElementChild(element, type) {
  element = element[type + "Child"];
  if (!element) return null;
  if (element.nodeType === 1) return element;
  return _getElementSibling(element, type === "first" ? "next" : "previous");
};

function _getElementSibling(element, direction) {
  direction += SIBLING;
  do {
    element = element[direction];
    if (element && element.nodeType === 1) break;
  } while (element);
  return element;
};

function _getElementSiblingByType(element, direction) {
  var tagName = element.nodeName;
  direction += SIBLING;
  do {
    element = element[direction];
    if (element && element.nodeName === tagName) break;
  } while (element);
  return element;
};

function _isEmpty(element) {
  if (element.canHaveChildren === false) return false;
  if (element.style && NO_CHILDREN.test(element.nodeName)) return false;
  var node = element.firstChild;
  while (node) {
    if (node.nodeType === 3 || node.nodeType === 1) return false;
    node = node.nextSibling;
  }
  return true;
};
