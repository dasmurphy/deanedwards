
var undefined;
var _private = _._;
var base2    = _.base2;
var forEach  = _.forEach;

var Arity = _private.Arity;
var Target = _private.Target;

var _getVendorPropertyName = _private.getVendorPropertyName;

var Function__call = Function.prototype.call;

var element = document.createElement("div");
var styleObject = element.style;

var CSSSelectorParser;
