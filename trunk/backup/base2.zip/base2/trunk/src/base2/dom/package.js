
var dom = new Package({
  name:    "dom",
  version:  base2.version,
  
  TEXT_CONTENT: TEXT_CONTENT,

  Node: Node,
  Element: Element,
  Document: Document,
  DocumentFragment: DocumentFragment,
  AbstractView: AbstractView,
  Event: Event,
  EventTarget: EventTarget,
  DocumentEvent: DocumentEvent,
  ViewCSS: ViewCSS,
  CSSStyleDeclaration: CSSStyleDeclaration,
  NodeSelector: NodeSelector,
  StaticNodeList: StaticNodeList,
  HTMLDocument: HTMLDocument,
  HTMLElement: HTMLElement,
  ElementView: ElementView,
  
  CSSSelectorParser: CSSSelectorParser,
  
  exports: {
    Traversal: Traversal,
    // For convenience, also export the main DOM methods
    getComputedStyle: function(element, pseudoElement) {
      return ViewCSS.getComputedStyle(element.ownerDocument.defaultView, element, pseudoElement);
    },
    // EventTarget
    addEventListener: EventTarget.addEventListener,
    removeEventListener: EventTarget.removeEventListener,
    dispatchEvent: EventTarget.dispatchEvent,
    // NodeSelector
    querySelector: NodeSelector.querySelector,
    querySelectorAll: NodeSelector.querySelectorAll,
    // Node
    compareDocumentPosition: Node.compareDocumentPosition,
    getUserData: Node.getUserData,
    setUserData: Node.setUserData,
    // Document
    createEvent: DocumentEvent.createEvent,
    // Element
    matchesSelector: Element.matchesSelector,
    // ElementView
    getBoundingClientRect: ElementView.getBoundingClientRect,
    // HTMLElement
    classList: classList,
    getAttribute: HTMLElement.getAttribute,
    hasAttribute: HTMLElement.hasAttribute,
    removeAttribute: HTMLElement.removeAttribute,
    setAttribute: HTMLElement.setAttribute
  }
});

new _DocumentState(document);
