
// http://www.w3.org/TR/DOM-Level-2-Events/events.html#Events-DocumentEvent

var DocumentEvent = Trait.extend({
  "@!(document.createEvent)": {
    createEvent: function(document, type) {
      return new Event;
    }
  },
  
  "@(document.createEvent)": {
    "@!(document.createEvent('Events'))": { // before Safari 3
      createEvent: function(document, type) {
        return this.base(document, type == "Events" ? "UIEvents" : type);
      }
    }
  }
}, {
  cloneEvent: cloneEvent
});

function cloneEvent(event) {
  if (event.isClone) return event;
  var clone = copy(event);
  clone.isClone = true;
  clone.stopPropagation = function() {
    if (event.stopPropagation) {
      event.stopPropagation();
    } else {
      event.cancelBubble = true;
    }
  };
  clone.preventDefault = function() {
    if (event.preventDefault) {
      event.preventDefault();
    } else {
      event.returnValue = false;
    }
  };
  return clone;
};
