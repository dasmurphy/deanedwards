
// http://www.w3.org/TR/DOM-Level-2-Views/views.html#Views-AbstractView

var AbstractView = Trait.extend();
