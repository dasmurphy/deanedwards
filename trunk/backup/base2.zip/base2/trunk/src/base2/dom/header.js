
;doc; var doc;

//@cc_on

var undefined;
var _private = _._;
var base2    = _.base2;
var forEach  = _.forEach;

var documentElement = document.documentElement;
var element = document.createElement("unknown");
var styleObject = element.style;

var Function__call = Function.prototype.call;

var DOM_ARITY_ERR = "Not enough arguments for {0}().";
var DOM_TYPE_ERR  = "Invalid target for {0}().";

var ArityError = _private.ArityError;
var TargetError = _private.TargetError;

var getVendorPropertyName = _private.getVendorPropertyName;

var QSA_VALID_TYPES = {1:1, 9:1, 11:1};

var SUPPORTS_EVENT_TARGET = !!element.addEventListener;
var SUPPORTS_TRANSITION_END = _.detect("(document.createEvent('TransitionEvent'))");

var EVENT_API = SUPPORTS_EVENT_TARGET ? "addEventListener" : "attachEvent";

var PARENT_ELEMENT = "parentElement" in element ? "parentElement" : "parentNode"; // fixes a bug with detached elements
var IS_CONNECTED   = PARENT_ELEMENT;

var NON_TEXT_ELEMENT = /^(button|checkbox|image|radio|reset|submit)$/;

var DOMContentLoadedEvent, _DocumentState_msie, _DOMContentLoaded_msie, msieCache;
var _addEventListener, _removeEventListener, _dispatchEvent, _createEvent;
var style, _getComputedStyle, _getBoundingClientRect, style_compute;
var CSSSelectorParser, _matches, _querySelector, _querySelectorAll, _getElementById, _executeQuery, _find, _findAll;
var _after, _before, _append, _prepend, _replace, _remove;
var _createElement = document.createElement;

var _contains = function contains(child) {
  if (arguments.length < 1) {
    throw new ArityError("contains");
  }

  if (!child || !child.nodeType) {
    throw new TargetError(DOM_TYPE_ERR, "contains");
  }

  while (child && (child = child.parentNode) && this != child) continue;

  return !!child;
};

function _includes(node, target) {
  while (target && node != target && (target = target.parentNode)) continue;
  return !!target;
}
