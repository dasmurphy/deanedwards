
eval(namespace); // import

/*@cc_on @*/

var _private = $$base2;

var document = global.document;

var SPACE = /\s/;

var INVALID_ARGUMENT = "Invalid argument.";

var TEXT_CONTENT = detect("(element.textContent)") ? "textContent" : "innerText";

var NO_CHILDREN  = /^(base|br|hr|img|input|link|meta|param|source)$/i;

var QUIRKS_MODE            = detect("QuirksMode"),
    MSIE                   = detect("MSIE"),
    MSIE6                  = MSIE && detect("MSIE6"),
    SUPPORTS_SOURCE_INDEX  = detect("(element.sourceIndex)"),
    SUPPORTS_CHILDREN      = detect("(element.children)"),
    SUPPORTS_TRAVERSAL_API = detect("(element.nextElementSibling)");
    
var SIBLING = (SUPPORTS_TRAVERSAL_API ? "Element" : "") + "Sibling";

var _element = document.createElement("div"),
    _style   = _element.style;

var _parents1 = []; // used by compareDocumentPosition()

var userData = {};
function _userData(op, node, key, value) {
  var id = (node.nodeType === 1 ? node.uniqueID : node.base2ID) || assignID(node);
  var data = userData[id];
  if (!data) data = userData[id] = new Map;
  var returnValue = data.get(key);
  if (typeof returnValue == "undefined" && !data.has(key)) {
    returnValue = null;
  }
  if (op === "set") {
    data.put(key, value);
  }
  return returnValue;
};
