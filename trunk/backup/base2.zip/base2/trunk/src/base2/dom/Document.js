
// http://www.w3.org/TR/DOM-Level-3-Core/core.html#i-Document

var Document = Node.extend();
