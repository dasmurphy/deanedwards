
// http://www.w3.org/TR/DOM-Level-3-Core/core.html#ID-745549614

var Element = Node.extend({
  // http://dev.w3.org/2006/webapi/selectors-api2/#matchtesting
  "@!(element.matchesSelector)": {
    matchesSelector: matchesSelector
  }
});

function matchesSelector(element, selector) {
  if (selector == null) {
    assertArity(arguments, 2);
    return false;
  }
  var query = matchQuery.cache[selector];
  if (!query) {
    query = matchQuery.create(selector);
  }
  return query(element);
};
