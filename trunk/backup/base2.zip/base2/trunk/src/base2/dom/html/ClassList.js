
// http://dev.w3.org/html5/spec/Overview.html#domtokenlist

var INVALID_CHARACTER_ERR = "INVALID_CHARACTER_ERR: classList";

var classList = {
  add: function(element, token) {
    if (SPACE.test(token)) throw new Error(INVALID_CHARACTER_ERR);
    if ((" " + element.className + " ").indexOf(" " + token + " ") === -1) {
      element.className += (element.className ? " " : "") + token;
    }
  },

  contains: function(element, token) {
    if (SPACE.test(token)) throw new Error(INVALID_CHARACTER_ERR);
    return (" " + element.className + " ").indexOf(" " + token + " ") !== -1;
  },

  remove: function(element, token) {
    if (SPACE.test(token)) throw new Error(INVALID_CHARACTER_ERR);
    var regexp = new RegExp("(^|\\s)" + token + "(\\s|$)", "g");
    element.className = trim(element.className.replace(regexp, "$2"));
  },

  toggle: function(element, token) {
    if (SPACE.test(token)) throw new Error(INVALID_CHARACTER_ERR);
    this[(" " + element.className + " ").indexOf(" " + token + " ") === -1 ? "add" : "remove"](element, token);
    return true;
  }
};
