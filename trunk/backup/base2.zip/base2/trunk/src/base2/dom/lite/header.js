
eval(namespace);

var vendorPrefix = new Base({
  "@Gecko":  {prefix: "moz"},
  "@KHTML":  {prefix: "khtml"},
  "@Webkit": {prefix: "webkit"},
  "@Opera":  {prefix: "o"},
  "@MSIE":   {prefix: "ms"}
}).prefix;

var vendorMatch = vendorPrefix + "MatchesSelector";

var NATIVE_MATCH_NAME = detect("element.matchesSelector") ? "matchesSelector" : detect("element." + vendorMatch) ? vendorMatch : "";

var SUPPORTS_MATCHING = !!NATIVE_MATCH_NAME;
