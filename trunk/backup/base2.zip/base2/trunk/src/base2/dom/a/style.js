
var SUPPORTS_VENDOR_EXTENSIONS = !_.detect("MSIE[678]");

var styleObject = document.createElement("div").style;

var getStylePropertyName = _.memoize(function getStylePropertyName(propertyName) {
  if (!(propertyName in styleObject)) {
    propertyName = _private.getVendorPropertyName(styleObject, propertyName);
  }
  return propertyName;
});

_private.getStylePropertyName = getStylePropertyName;

var vendorPropertyNames = getStylePropertyName.cache;

style = {
  toString: _.K("[base2.dom.style]"),

  get: function style_get(element, propertyName) {
    if (arguments.length < 2) {
      throw new ArityError("style.get");
    }
    if (!element || element.nodeType !== 1) {
      throw new TargetError(DOM_TYPE_ERR, "style.get");
    }

    var vendorName = vendorPropertyNames[propertyName];
    if (vendorName) {
      propertyName = vendorName;
    } else if (!(propertyName in styleObject)) {
      propertyName = getStylePropertyName(propertyName);
    }

    var value;
    if (propertyName in styleObject) {
      value = element.style[propertyName] || "";
    }
    return value;
  },

  set: function style_set(element, propertyName, value, important) {
    if (arguments.length < 2) {
      throw new ArityError("style.set");
    }
    if (!element || element.nodeType !== 1) {
      throw new TargetError(DOM_TYPE_ERR, "style.set");
    }

    if (arguments.length > 2) {
      var properties = {};
      properties[propertyName] = value;
    } else {
      properties = _.extend({}, arguments[1]);
    }

    var style = element.style;

    for (propertyName in properties) {
      var vendorName = vendorPropertyNames[propertyName];
      if (vendorName) {
        propertyName = vendorName;
      } else if (!(propertyName in styleObject)) {
        propertyName = getStylePropertyName(propertyName);
      }
      value = properties[propertyName];
      if (propertyName in styleObject) {
        if (important) {
          propertyName = propertyName.replace(/([A-Z])/g, "-$1").toLowerCase();
          style.setProperty(propertyName, String(value), "important");
        } else {
          style[propertyName] = String(value);
        }
      }
    }
  }
};

_private.compute = function style_compute(element, propertyName) {
  if (arguments.length < 2) {
    throw new ArityError("style.compute");
  }
  if (!element || element.nodeType !== 1) {
    throw new TargetError(DOM_TYPE_ERR, "style.compute");
  }

  var vendorName = vendorPropertyNames[propertyName];
  if (vendorName) {
    propertyName = vendorName;
  } else if (SUPPORTS_VENDOR_EXTENSIONS && !(propertyName in styleObject)) {
    propertyName = getStylePropertyName(propertyName);
  }

  var view = element.ownerDocument.defaultView;
  return view.getComputedStyle(element, null)[propertyName];
};
