
extend(HTMLElement, {
  bindings: {},
  tags: "*",

  bind: function(element) {
    var data = element;

    /*@if (@_jscript)
      for (var name, i = 0; name = _PREFIXES[i]; i++) {
        name += "Attribute";
        if (element[name]) element["_" + name] = element[name];
      }
      if (@_jscript_version < 5.7) {
        data = element.uniqueID;
        document[data] = element;
      }
    /*@end @*/

    if (!element.classList) {
      element.classList = new _HTMLElement_ClassList(data);
    }

    extend(element, HTMLElement.prototype);

    /*@if (@_jscript) {
      try {
        return element;
      } finally {
        element = null;
      }
    }
    @else @*/
      return element;
    /*@end @*/
  },

  extend: function() {
    // Maintain HTML element bindings.
    // This allows us to map specific interfaces to elements by reference
    // to tag name.
    var binding = this.base.apply(this, arguments);
    forEach.csv(binding.tags, function(tagName) {
      HTMLElement.bindings[tagName.toUpperCase()] = binding;
    });
    return binding;
  }
});

HTMLElement.extend(null, {
  tags: "APPLET,EMBED,OBJECT",
  bind: I // Binding not allowed for these elements.
});
