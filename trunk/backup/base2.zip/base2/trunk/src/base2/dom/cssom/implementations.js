
HTMLElement.implement(ElementView);
