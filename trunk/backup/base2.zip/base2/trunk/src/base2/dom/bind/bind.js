
var _boundNodeIDs = {};

dom.bind = function(node) {
  // Apply a base2.dom binding to a native DOM node.
  var nodeType = node.nodeType;
  if (nodeType == null) {
    throw new TypeError(INVALID_ARGUMENT);
  }
  var id = (nodeType === 1 ? node.uniqueID : node.base2ID) || assignID(node);
  
  if (_boundNodeIDs[id]) return node;
  _boundNodeIDs[id] = true;
  
  switch (nodeType) {
    case 1: // Element
      if (node.className == null) {
        var binding = Element;
      } else {
        // It's an HTML element, so use bindings based on tag name.
        binding = HTMLElement.bindings[node.nodeName.toUpperCase()] || HTMLElement;
      }
      break;
      
    case 9: // Document
      if (node.getElementById == null) {
        binding = Document;
      } else {
        binding = HTMLDocument;
      }
      break;

    case 11: // DocumentFragment
      binding = DocumentFragment;
      break;
      
    default:
      binding = Node;
  }

  return binding.bind(node);
};

Node.bind =
Element.bind =
AbstractView.bind =
DocumentFragment.bind =
function(node) {
  return extend(node, this.prototype);
};

dom.bind(document);
