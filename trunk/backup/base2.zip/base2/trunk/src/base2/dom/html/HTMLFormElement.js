
// Not used.

var HTMLFormElement = HTMLElement.extend({
  serialize: function(form) {
    var successful = filter(form.elements, HTMLFormItem.isSuccessful);
    return map(successful, HTMLFormItem.serialize).join("&");
  }
}, {
  tags: "FORM"
});
