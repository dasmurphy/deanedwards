
var QUIRKS_MODE  = _.detect("QuirksMode");
var MSIE6        = _.detect("MSIE6");
var FIX_BORDER   = _.detect("WebKit5|KHTML4") ? /^(TABLE|TH|TD)$/ : _.False;
                  
var _offsets = new _.Base({
  _getBodyClient: _.memoize(function _getBodyClient(document) {
    var left = 0;
    var top = 0;
    var view = document.defaultView;
    var body = document.body;
    var bodyStyle = _getComputedStyle(body);
    var position = bodyStyle.position;
    var isAbsolute = position !== "static";
        
    if (isAbsolute) {
      left += parseInt(bodyStyle.left) + parseInt(bodyStyle.marginLeft);
      top  += parseInt(bodyStyle.top) + parseInt(bodyStyle.marginTop);
      if (position === "relative") {
        var rootStyle = _getComputedStyle(document.documentElement);
        left += parseInt(rootStyle.paddingLeft) + parseInt(rootStyle.borderLeftWidth);
        top  += parseInt(rootStyle.paddingTop) + parseInt(rootStyle.borderTopWidth);
        if (!MSIE6) { // MSIE6 stores the margin but doesn't apply it.
          left += parseInt(rootStyle.marginLeft);
          top += parseInt(rootStyle.marginTop);
        }
      }
    } else {
      var dummy = Function__call.call(_createElement, document, "div");
      body.insertBefore(dummy, body.firstChild);
      left += dummy.offsetLeft - parseInt(bodyStyle.paddingLeft);
      top += dummy.offsetTop - parseInt(bodyStyle.paddingTop);
      body.removeChild(dummy);
    }

    return {
      position: position,
      isAbsolute: isAbsolute,
      left: left,
      top: top
    };
  }, keyFunction),

  _getBodyOffset: _.memoize(function _getBodyOffset(document) {
    var client = this._getBodyClient(document);
    var view = document.defaultView;
    var body = document.body;
    
    return {
      isAbsolute: client.isAbsolute,
      left: client.left + parseInt(style_compute(body, "borderLeftWidth")),
      top: client.top + parseInt(style_compute(body, "borderTopWidth"))
    };
  }, keyFunction),

  _getViewport: _.memoize(function _getViewport(document) {
    var view = document.defaultView;
    var documentElement = document.documentElement;
    return {
      left: parseInt(style_compute(documentElement, "marginLeft")),
      top: parseInt(style_compute(documentElement, "marginTop"))
    };
  }, keyFunction),

  _getGeckoRoot: _.memoize(function _getGeckoRoot(document) {
    var rootStyle = document.defaultView.getComputedStyle(document.documentElement, null);
        
    return {
      x: parseInt(rootStyle.marginLeft) + parseInt(rootStyle.borderLeftWidth),
      y: parseInt(rootStyle.marginTop) + parseInt(rootStyle.borderTopWidth)
    };
  }, keyFunction),

  "@MSIE.+QuirksMode": {
    _getViewport: _.K({left: 0, top: 0})
  }
});

function keyFunction(document) {
  return document.base2ID || _.assignID(document);
}
