
// Many thanks to Diego Perini for testing and inspiration.
// His NWMatcher is awesome: http://javascript.nwbox.com/NWMatcher/

var SUPPORTS_QSA = detect("(element.querySelector)");

// MSIE (and Opera) confuses the name attribute with id for some elements.
// Use document.all to retrieve elements with name/id instead.
var id = "base2_" + now(),
    root = document.documentElement;
_element.innerHTML = '<a name="' + id + '"></a>';
root.insertBefore(_element, root.firstChild);
var BUGGY_BY_ID = document.getElementById(id) == _element.firstChild;
root.removeChild(_element);

var BLOCKS              = /\)\{/g,
    COMMA               = /,/,
    QUOTED              = /^['"]/,
    LAST_CHILD          = /last/i;

var PARENT              = detect("(element.parentElement)") ? "parentElement" : "parentNode", // fixes a bug with detached elements
    CHILDREN            = SUPPORTS_CHILDREN ? "children" : "childNodes",
    NEXT_SIBLING        = SUPPORTS_TRAVERSAL_API ? "e.nextElementSibling" : "(e.nextSibling&&_getElementSibling(e,'next'))",
    PREVIOUS_SIBLING    = NEXT_SIBLING.replace(/next/g, "previous"),
    IS_ELEMENT          = "e.nodeType===1",
    IF_ELEMENT          = "if(" + IS_ELEMENT + "){";

var NOT_NEXT_BY_TYPE     = "!_getElementSiblingByType(e,'next')&&",
    NOT_PREVIOUS_BY_TYPE = NOT_NEXT_BY_TYPE.replace("next", "previous");

var GET_ATTRIBUTE = HTMLElement.prototype.getAttribute ? "_getAttribute(e,'" : "e.getAttribute('",
    HAS_ATTRIBUTE = HTMLElement.prototype.hasAttribute ? "_hasAttribute(e,'" : "e.hasAttribute('",
    ID_ATTRIBUTE  = "(e.nodeName==='FORM'?" + GET_ATTRIBUTE + "id'):e.id)";

var USE_BASE2 = {test: False};

if (SUPPORTS_QSA) {
  var pattern = "";
  _element.innerHTML = '<a href="' + location.href + '"></a>';
  if (_element.querySelector("[href^='']")) {
    pattern += "|[\\^*~|$]=\\s*(['\"])\\1";
  }
  if (_element.querySelector(":visited") != null) {
    pattern += "|:link|:visited";
  }
  if (detect("Gecko1\\.9(\\.[01])?")) {
    pattern += "|:enabled|:disabled";
  }
  /*@if (@_jscript)
    _element.innerHTML = "<object><param></object>";
    var _BUGGY_OBJECT_QSA = !_element.querySelector("param");
    if (_BUGGY_OBJECT_QSA) {
      // I can't be bothered to write feature tests for each of these
      pattern += "|\\[\\s*(value|ismap|checked|disabled|multiple|readonly|selected)|\\b(object|param)\\b";
    }
  /*@end @*/
  pattern = pattern.slice(1);
  if (pattern) {
    USE_BASE2 = new RegExp(pattern, "i");
  }
}

// Fix for Safari 3.1/3.2 (http://code.google.com/p/base2/issues/detail?id=100)
var CAPS_SELECTOR = /[#.](\\.|[\w-]|[^\x00-\xa0])*[A-Z]/;
var FIX_CAPS_SELECTOR = detect("Webkit52"); // This is a browser sniff as the target document may not be in quirks mode

var cachedSelectors = {};
var safeSelectors = {};
var useBase2 = {};

var _byId = BUGGY_BY_ID && document.all ? function(document, id) {
  var result = document.all[id] || null;
  // Returns a single element or a collection.
  if (!result || (result.nodeType && HTMLElement.getAttribute(result, "id") === id)) return result;
  // document.all has returned a collection of elements with name/id
  for (var i = 0; i < result.length; i++) {
    if (HTMLElement.getAttribute(result[i], "id") === id) return result[i];
  }
  return null;
} : null;

// http://dean.edwards.name/weblog/2009/12/getelementsbytagname/
function _getElementsByTagName(node, tagName) {
  var anyTag = tagName === "*";
  var useNativeMethod = true;
  /*@if (@_jscript)
    useNativeMethod = !anyTag || node.nodeName !== "OBJECT";
  /*@end @*/
  if (useNativeMethod && node.getElementsByTagName) {
    return node.getElementsByTagName(tagName);
  }
  var elements = [], i = 0;
  var next = node.firstChild;
  var TAGNAME = tagName.toUpperCase();
  while ((node = next)) {
    if (
      anyTag
        ? node.nodeType === 1
        : node.nodeName === TAGNAME || node.nodeName === tagName
    ) elements[i++] = node;
    next = node.firstChild || node.nextSibling;
    while (!next && (node = node.parentNode)) next = node.nextSibling;
  }
  return elements;
};

// Register a node and index its siblings.
_private.qIndex = 1;
var allIndexes = {qIndex: 1};
function _indexOf(element, last, ofType) {
  var parent = element.parentNode;
  if (!parent || parent.nodeType !== 1) return NaN;
  
  var tagName = ofType ? element.nodeName : "";
  if (tagName === "TR" && element.sectionRowIndex >= 0) {
    var index = element.sectionRowIndex;
    return last ? element.parentNode.rows.length - index + 1 : index;
  }
  if ((tagName === "TD" || tagName === "TH") && element.cellIndex >= 0) {
    index = element.cellIndex;
    return last ? element.parentNode.cells.length - index + 1 : index;
  }
  if (allIndexes.qIndex !== _private.qIndex) {
    allIndexes = {qIndex: _private.qIndex};
  }
  var id = (parent.uniqueID || assignID(parent)) + "-" + tagName,
      indexes = allIndexes[id];
  if (!indexes) {
    indexes = {};
    var index = 0,
        child = parent.firstChild;
    while (child) {
      if (ofType ? child.nodeName === tagName : child.nodeType === 1) {
        indexes[child.uniqueID || assignID(child)] = ++index;
      }
      child = child.nextSibling;
    }
    indexes.length = index;
    allIndexes[id] = indexes;
  }
  index = indexes[element.uniqueID];
  return last ? indexes.length - index + 1 : index;
};

function _getLang(element) {
  var lang = "";
  while (element && element.nodeType === 1) {
    lang = element.lang || element.getAttribute("lang") || "";
    if (lang) break;
    element = element.parentNode;
  }
  return lang;
};
