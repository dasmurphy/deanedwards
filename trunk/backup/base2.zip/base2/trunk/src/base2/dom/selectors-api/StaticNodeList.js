
// http://www.w3.org/TR/selectors-api/#staticnodelist

// A wrapper for an array of elements or a NodeList.

var StaticNodeList = Base.extend({
  constructor: function(nodes) {
    if (nodes && nodes.length > 0) {
      var length = 0, node;
      while ((node = nodes[length])) {
        this[length++] = node;
      }
      this.length = length;
    }
  },
  
  length: 0,
  
  item: function(index) {
    var item;
    if ((index -= 0) >= 0) item = array[index];
    return item;
  }
}, {
  extended: false
});
