
// http://dean.edwards.name/weblog/2006/06/again

var DOMContentLoadedEvent = Base.extend({
  constructor: function(document) {
    var fired = false,
        self  = this;
    this.fire = function() {
      if (document == global.document) {
        _private.isReady = true;
      }
      if (!fired) {
        fired = true;
        if (!self.__constructing) _private.dispatchReady(document);
      }
    };
    if ("complete" === document.readyState) this.fire();
    else this.listen(document);
  },

  listen: function(document) {
    // if all else fails fall back on window.onload
    EventTarget.addEventListener(document.defaultView, "load", this.fire, false);
  },

  "@(document.addEventListener)": {
    constructor: function(document) {
      this.base(document);
      // use the real event for browsers that support it
      var self = this;
      document.addEventListener("DOMContentLoaded", function _listen() {
        document.removeEventListener("DOMContentLoaded", _listen, false);
        self.fire();
      }, false);
    }
  },

  "@MSIE": {
    listen: function(document) {
      // Diego Perini: http://javascript.nwbox.com/IEContentLoaded/
      deferUntil(this.fire, function() {
        try {
          return document.body && (document.body.doScroll("left") || true);
        } catch (x) {
          return false;
        }
      }, 0);
      var self = this;
      _private.attachEvent(document, "onreadystatechange", function() {
    		if (document.readyState === "complete") self.fire();
    	});
    }
  },

  "@KHTML": {
    listen: function(document) {
      this.base(document);
      deferUntil(this.fire, function() {
        return /loaded|complete/.test(document.readyState);
      }, 0);
    }
  }
});

_private.dispatchReady = function(document) {
  var event = DocumentEvent.createEvent(document, "Events");
  Event.initEvent(event, "base2ContentLoaded", false, false);
  EventTarget.dispatchEvent(document, event);
};
