
Element.implement(NodeSelector);
Document.implement(NodeSelector);
DocumentFragment.implement(NodeSelector);
