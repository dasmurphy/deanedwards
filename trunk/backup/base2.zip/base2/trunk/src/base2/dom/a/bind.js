
(function() {
  var IS_ELEMENT      = "{2}.nodeType !== 1";
  var IS_QSA_TARGET   = "!_validType[{2}.nodeType]";
  var QSA_VALID_TYPES = {1:1, 9:1, 11:1};

  var iNode = createInterface(null, {
    find:                  [_find,    IS_QSA_TARGET, "node,selector"],
    findAll:               [_findAll, IS_QSA_TARGET, "node,selector"],

    append:                [_append,  IS_QSA_TARGET, "target"],
    prepend:               [_prepend, IS_QSA_TARGET, "target"]
  });

  var iDocument = createInterface(iNode);

  var iElement = createInterface(iNode, {
    matches:               [_matches, IS_ELEMENT, "element,selector"],

    after:                 [_after,   IS_ELEMENT, "element"],
    before:                [_before,  IS_ELEMENT, "element"],
    replace:               [_replace, IS_ELEMENT, "element"],
    remove:                [_remove,  IS_ELEMENT, "element"]
  });

  var isBound = {};

  function bindDocument(document) {
    _.assignID(document);
    
    isBound[document.base2ID] = true;

    var elementProto = (view.HTMLElement || view.Element).prototype;
    for (var name in iElement) {
      elementProto[name] = iElement[name];
    }
    for (name in iDocument) {
      document[name] = iDocument[name];
    }
  }

  function createInterface(ancestor, methods) {
    var _interface = _private.pcopy(ancestor);
    
    forEach (methods, function(descriptor, methodName) {
      var args = descriptor[2].split(",");
      var test = descriptor[1];
      var method = descriptor[0];

      var CALL = "_call.apply(_method, arguments)";
      var ARGS = "_call,_method,_validType";
      var BODY = 'return function {0}(' + args.join(', ') + ') {\n' +
        '  if (arguments.length < {1}) {\n' +
        '    throw new SyntaxError("' + DOM_ARITY_ERR + '");\n' +
        '  }\n' +
        '  if (!{2} || ' + test + ') {\n' +
        '    throw new TypeError("' + DOM_TYPE_ERR + '");\n' +
        '  }\n' +
        '  return ' + CALL + ';\n' +
        '}';
        
      var body = _.format(BODY, methodName, args.length, args[0], args.slice(1).join(", "), methodName);

      dom[methodName] = new Function(ARGS, body)(Function__call, method, QSA_VALID_TYPES);

      _interface[methodName] = method;
      
      ;doc; dom[methodName]._underlyingFunction = _interface[methodName];
    });
    
    return _interface;
  }
  
  dom.bind = function bind(node) {
    if (!node || !node.nodeType) {
      throw new TargetError(DOM_TYPE_ERR, "dom.bind");
    }

    switch (node.nodeType) {
      case 9: // Document
        if (!isBound[node.base2ID]) bindDocument(node);
        break;

      case 1: // Element
        if (!isBound[node.ownerDocument.base2ID]) {
          throw new Error("Attempt to bind an element in an unbound document.");
        }
        
        if (!isBound[node.uniqueID]) {
          bindElements([node]);
        }
    }

    return node;
  };
})();
