
(function() {
  var methods = {
    contains:              2,
    createEvent:           2,
    addEventListener:      3,
    removeEventListener:   3,
    dispatchEvent:         2,
    getElementById:        2,
    find:                  2,
    findAll:               2,
    querySelector:         2,
    querySelectorAll:      2,
    getAttribute:          2,
    hasAttribute:          2,
    removeAttribute:       2,
    setAttribute:          3,
    matches:               2,
    append:                1,
    prepend:               1,
    after:                 1,
    before:                1,
    replace:               1,
    remove:                1,
    getBoundingClientRect: 1
  };

  var aliases = {
    addEventListener:      "on",
    removeEventListener:   "off",
    getBoundingClientRect: "rect"
  };

  _private.aliases = {};

  forEach (methods, function(arity, name) {
    var alias = aliases[name];

    dom[name] = _createStaticMethod(name, arity, name);

    ;doc; // Try to expose as much raw source code as possible.
    ;doc; var protoMethod = element[name] || document[name];
    ;doc; dom[name]._underlyingFunction = protoMethod._underlyingFunction || protoMethod;

    if (alias) {
      _private.aliases[alias] = _createStaticMethod(name, arity, alias);
      ;doc; // Try to expose as much raw source code as possible.
      ;doc; aliases[alias]._underlyingFunction = dom[name]._underlyingFunction;
    }
  });

  function _createStaticMethod(name, arity, alias) {
    // Delegate a static method to an instance method
    var staticMethod = function _staticMethod(node) {
      if (arguments.length < arity) {
        throw TypeError(Arity(alias, this));
      }
      if (!node || !node[name]) {
        throw TypeError(Target(alias, this));
      }
      return Function__call.apply(node[name], arguments);
    };
    return staticMethod;
  }
  
  dom.bind = _.I;
})();
