
// http://www.w3.org/TR/DOM-Level-2-Events/events.html#Events-Event

var Event = Trait.extend({
  "@!(document.createEvent)": {
    initEvent: function(event, type, bubbles, cancelable) {
      event.type = String(type);
      event.bubbles = !!bubbles;
      event.cancelable = !!cancelable;
    },

    stopPropagation: function(event) {
      event.cancelBubble = true;
    },

    preventDefault: function(event) {
      if (event.cancelable !== false) event.returnValue = false;
      if (event.type === "mousedown") { // cancel a mousedown event
        var target = event.target;
        var document = target.ownerDocument;
        var body = document.body;
        var onbeforedeactivate = function(event) {
          _private.detachEvent(body, "onbeforedeactivate", onbeforedeactivate, true);
          event.returnValue = false;
        };
        _private.attachEvent(body, "onbeforedeactivate", onbeforedeactivate);
      }
    }
  }
}, {
  cloneEvent: function(event) {
    if (event.isClone) return event;
    var clone = copy(event);
    clone.isClone = true;
    clone.stopPropagation = function() {
      event.stopPropagation();
      this.cancelBubble = true;
    };
    clone.preventDefault = function() {
      event.preventDefault();
      this.returnValue = false;
    };
    return clone;
  }
});
