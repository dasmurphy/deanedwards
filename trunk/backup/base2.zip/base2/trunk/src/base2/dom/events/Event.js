
// http://www.w3.org/TR/DOM-Level-2-Events/events.html#Events-Event

var Event = events.Event.extend({
  constructor: function(originalEvent) {
    if (originalEvent) {
      for (var i in originalEvent) {
        this[i] = originalEvent[i];
      }
      var type = this.type;
      type = this.type = EVENT_MAP[type] || type;
      
      if (!this.timeStamp) {
        this.bubbles = !NO_BUBBLE.test(type);
        this.cancelable = CANCELABLE.test(type);
        this.timeStamp = now();
      }

      this.relatedTarget = originalEvent[(originalEvent.srcElement == originalEvent.fromElement ? "to" : "from") + "Element"] || null;
      
      if (this.stopPropagation == Undefined) {
        this.stopPropagation = function() {
          originalEvent.cancelBubble = true;
        };

        this.preventDefault = function() {
          if (this.cancelable !== false) {
            originalEvent.returnValue = false;
          }
          if (type === "mousedown") { // cancel a mousedown event
            var target = this.target;
            var document = target.ownerDocument;
            var body = document.body;
            var onbeforedeactivate = function(event) {
              _private.detachEvent(body, "onbeforedeactivate", onbeforedeactivate, true);
              event.returnValue = false;
            };
            _private.attachEvent(body, "onbeforedeactivate", onbeforedeactivate);
          }
        };
      }
    }
  },

  isClone: true,
  relatedTarget: null,
  
  initEvent: function(type, bubbles, cancelable) {
    this.type = String(type);
    this.bubbles = !!bubbles;
    this.cancelable = !!cancelable;
    this.timeStamp = now();
  }
});
