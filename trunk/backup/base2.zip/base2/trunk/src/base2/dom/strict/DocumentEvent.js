
// http://www.w3.org/TR/DOM-Level-2-Events/events.html#Events-DocumentEvent

DocumentEvent.implement({
  createEvent: function(document, type) {
    assertArity(arguments);
    assert(document && document.nodeType === 1, "Invalid object.");
    
    return this.base(document, type);
  }
});
