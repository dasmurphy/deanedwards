
Document.implement(DocumentEvent);

Document.implement(EventTarget);
Element.implement(EventTarget);
