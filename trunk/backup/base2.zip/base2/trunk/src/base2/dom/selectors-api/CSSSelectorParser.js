
// http://www.w3.org/TR/css3-selectors/#w3cselgrammar (kinda)

var VALID_SELECTOR = /^(\\.|['\s>+~#.\[\]:*(),\w\-\^|$=]|[^\x00-\xa0])+$/;

var CSS_SELECTOR_PARSE_ERR = "SYNTAX_ERR: CSSSelectorParser";

var IMPLIED_ASTERISK    = /(^|[, >+~])([#.:\[])/g;
var SINGLE_QUOTES       = /'/g;
var ESCAPED             = /'(\d+)'/g;
var ESCAPE              = /\\/g;
var HEX_ESCAPE          = /\\([\da-f]{2})/gi;
var UNESCAPE            = /\\([nrtf'"])/g;

var testElement = document.createElement("div");

CSSSelectorParser = _.RegGrp.extend({
  dictionary: new _.RegGrp.Dict([
    "string1",         /'(\\.|[^'\\])*'/,
    "string2",         /"(\\.|[^"\\])*"/,
    "string",          /<#string1>|<#string2>/,
    "ident",           /\-?(\\.|[a-z_]|[^\x00-\xa0])(\\.|[\w\-]|[^\x00-\xa0])*/,
    "combinator",      /[\s>+~]/,
    "operator",        /[\^~|$*]?=/,
    "nth_arg",         /[+-]?\d+|[+-]?\d*n(?:\s*[+-]\s*\d+)?|even|odd/,
    "tag",             /\*|<#ident>/,
    "id",              /#(<#ident>)/,
    "class",           /\.(<#ident>)/,
    "pseudo",          /\:([\w\-]+)(?:\(([^)]+)\))?/,
    "attr",            /\[(<#ident>)(?:(<#operator>)((?:\\.|[^\]\[#.:])+))?\]/,
    "negation",        /:not\((<#tag>|<#id>|<#class>|<#attr>|<#pseudo>)\)/,
    "sequence",        /(\\.|[~*]=|\+\d|\+?\d*n\s*\+\s*\d|[^\s>+~,\*])+/,
    "filter",          /[#.:\[]<#sequence>/,
    "selector",        /[^>+~](\\.|[^,])*/,
    "grammar",         /^(<#selector>)((,<#selector>)*)$/
  ]),

  ignoreCase: true
}, {
  escape: CSSSelectorParser_escape,
  unescape: CSSSelectorParser_unescape,

  split: function CSSSelectorParser_split(selector) {
    return _.map(CSSSelectorParser_escape(selector).split(","), CSSSelectorParser_unescape);
  }
});

var strings;

// Trim and encode strings
var normalize = new CSSSelectorParser([
  /<#string>/, escapeString,
  /\\.|[~*]\s+=|\+\s+\d/, IGNORE,
  /\[\s+/, "[",
  /\(\s+/, "(",
  /\s+\)/, ")",
  /\s+\]/, "]",
  /\s*([,>+~]|<#operator>)\s*/, "$1",
  /\s+$/, "",
  /\s+/, " "
]);

function CSSSelectorParser_escape(selector) {
  strings = [];
  selector =
    normalize.parse(_.trim(selector).replace(HEX_ESCAPE, "\\x$1"))
    .replace(UNESCAPE, "$1")
    .replace(IMPLIED_ASTERISK, "$1*$2");
  if (!VALID_SELECTOR.test(selector)) throwSelectorError();
  return selector;
}

function CSSSelectorParser_unescape(query) {
  // put string values back
  return query.replace(ESCAPED, unescapeString);
}

function escapeString(string) {
  var index = strings.length;
  strings[index] = string.replace(UNESCAPE, "$1");
  return "'" + index + "'";
}

function unescapeString(match, index) {
  return strings[index];
}

function throwSelectorError() {
  var error = new SyntaxError(CSS_SELECTOR_PARSE_ERR);
  error.code = 12;
  throw error;
}
