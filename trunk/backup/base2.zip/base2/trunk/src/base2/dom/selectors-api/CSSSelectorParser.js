
// http://www.w3.org/TR/css3-selectors/#w3cselgrammar (kinda)

var VALID_SELECTOR = /^(\\.|['\s>+~#.\[\]:*(),\w-\^|$=]|[^\x00-\xa0])+$/;

var CSS_SELECTOR_PARSE_ERR = "SYNTAX_ERR: CSSSelectorParser";

var IMPLIED_ASTERISK    = /(^|[, >+~])([#.:\[])/g,
    SINGLE_QUOTES       = /'/g,
    ESCAPED             = /'(\d+)'/g,
    ESCAPE              = /\\/g,
    HEX_ESCAPE          = /\\([\da-f]{2,2})/gi,
    UNESCAPE            = /\\([nrtf'"])/g;

var CSSSelectorParser = RegGrp.extend({
  dictionary: new RegGrp.Dict({
    string1:         /'(\\.|[^'\\])*'/,
    string2:         /"(\\.|[^"\\])*"/,
    string:          /<#string1>|<#string2>/,

    ident:           /\-?(\\.|[_a-z]|[^\x00-\xa0])(\\.|[\w-]|[^\x00-\xa0])*/,
    combinator:      /[\s>+~]/,
    operator:        /[\^~|$*]?=/,
    nth_arg:         /[+-]?\d+|[+-]?\d*n(?:\s*[+-]\s*\d+)?|even|odd/,
    tag:             /\*|<#ident>/,
    id:              /#(<#ident>)/,
    'class':         /\.(<#ident>)/,
    pseudo:          /\:([\w-]+)(?:\(([^)]+)\))?/,
    attr:            /\[(<#ident>)(?:(<#operator>)((?:\\.|[^\]\[#.:])+))?\]/,
    negation:        /:not\((<#tag>|<#id>|<#class>|<#attr>|<#pseudo>)\)/,
    sequence:        /(\\.|[~*]=|\+\d|\+?\d*n\s*\+\s*\d|[^\s>+~,\*])+/,
    filter:          /[#.:\[]<#sequence>/,
    selector:        /[^>+~](\\.|[^,])*?/,
    grammar:         /^(<#selector>)((,<#selector>)*)$/
  }),
  
  ignoreCase: true
}, {
  escape: escape,
  unescape: unescape,

  split: function(selector) {
    return Array2.map(String2.csv(escape(selector)), unescape);
  }
});

var strings;

var normalize = new CSSSelectorParser({
  "<#string>": escapeString,
  "\\\\.|[~*]\\s+=|\\+\\s+\\d": RegGrp.IGNORE,
  "\\[\\s+": "[",
  "\\(\\s+": "(",
  "\\s+\\)": ")",
  "\\s+\\]": "]",
  "\\s*([,>+~]|<#operator>)\\s*": "$1",
  "\\s+$": "",
  "\\s+": " "
});

function escape(selector) {
  strings = [];
  selector =
    normalize.parse(trim(selector).replace(HEX_ESCAPE, "\\x$1"))
    .replace(UNESCAPE, "$1")
    .replace(IMPLIED_ASTERISK, "$1*$2");
  if (!VALID_SELECTOR.test(selector)) throwSelectorError();
  return selector;
};

function unescape(query) {
  // put string values back
  return query.replace(ESCAPED, unescapeString);
};

function escapeString(string) {
  var index = strings.length;
  strings[index] = string.slice(1, -1)
    .replace(UNESCAPE, "$1")
    .replace(SINGLE_QUOTES, "\\'");
  return "'" + index + "'";
};

function unescapeString(match, index) {
  return strings[index - 1];
};

function throwSelectorError() {
  var error = new SyntaxError(CSS_SELECTOR_PARSE_ERR);
  error.code = 12;
  throw error;
};
