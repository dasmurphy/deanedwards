
_private.getOffsetFromBody = function _getOffsetFromBody(element) {
  var left = 0;
  var top = 0;

  if (!/^BODY$/i.test(element.nodeName)) {
    var document = element.ownerDocument;
    var view = document.defaultView;
    var documentElement = document.documentElement;
    var body = document.body;
    var clientRect = element.getBoundingClientRect();

    left = clientRect.left + Math.max(documentElement.scrollLeft, body.scrollLeft);
    top = clientRect.top + Math.max(documentElement.scrollTop, body.scrollTop);
  }

  return {
    left: left,
    top: top
  };
};
