
var exports = {};

forEach.csv("compareDocumentPosition,getUserData,setUserData\
getAttribute,hasAttribute,removeAttribute,setAttribute,\
createEvent,addEventListener,removeEventListener,dispatchEvent,\
querySelector,querySelectorAll,\
getBoundingClientRect", function(name) {
  function _delegatedMethod(object) {
    return object[name].apply(object, Array2.slice(arguments, 1));
  };
  exports[name] = _delegatedMethod;
});

exports.matchesSelector = function _delegatedMethod(element, selector) {
  if (SUPPORTS_MATCHING) {
    return element[NATIVE_MATCH_NAME](selector);
  } else {
    var elements = element.parentNode.querySelectorAll(selector);
    var i = 0, e;
    while ((e = elements[i++])) if (e == element) return true;
    return false;
  }
};

new Package({
  name:    "dom",
  version:  base2.version + "(lite)",

  exports: exports,
  
  getComputedStyle: document.defaultView.getComputedStyle
});
