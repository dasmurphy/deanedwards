
// http://www.w3.org/TR/DOM-Level-3-Core/core.html#ID-1950641247

var Node = Trait.extend({
  // http://www.w3.org/TR/DOM-Level-3-Core/core.html#Node3-compareDocumentPosition
  "@!(element.compareDocumentPosition)": {
    compareDocumentPosition: function(node1, node2) {
      if (node1 == node2) return 0;
      
      var child2,
          length1,
          i = 0,
          node = node1;
      _parents1.length = 0;
      
      while (node) {
        _parents1[i++] = node;
        node = node.parentNode;
        if (node == node2) return 10; // DOCUMENT_POSITION_PRECEDING|DOCUMENT_POSITION_CONTAINS
      }
      length1 = i;
      
      node = node2;
      while (node) {
        i = 0;
        while (i < length1) {
          if (node == _parents1[i]) {
            node = _parents1[i - 1];
            do {
              node = node.nextSibling;
              if (node == child2) return 4; // DOCUMENT_POSITION_FOLLOWING
            } while (node)
            return 2; // DOCUMENT_POSITION_PRECEDING
          }
          i++;
        }
        child2 = node;
        node = node.parentNode;
        if (node == node1) return 20; // DOCUMENT_POSITION_FOLLOWING|DOCUMENT_POSITION_IS_CONTAINED
      }
      
      return 33; // DOCUMENT_POSITION_DISCONNECTED|DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC
    }
  },

  // http://www.w3.org/TR/DOM-Level-3-Core/core.html#Node3-getUserData
  // http://www.w3.org/TR/DOM-Level-3-Core/core.html#Node3-setUserData
  "@!(element.getUserData('')==null)": {
    getUserData: function(node, key) {
      if (arguments.length < 2) assertArity(arguments, 2);
      return _userData("get", node, key);
    },
    
    setUserData: function(node, key, value, handler) {
      if (arguments.length < 4) assertArity(arguments, 4);
      return _userData("set", node, key, value); // handler is ignored
    }
  }
});
