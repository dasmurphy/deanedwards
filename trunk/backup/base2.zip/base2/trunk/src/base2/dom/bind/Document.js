
extend(Document, {
  bind: function(document) {
    extend(document, "createElement", _bind);
    extend(document, "createDocumentFragment", _bind);
    if (!document.defaultView) {
      document.defaultView = document.parentWindow;
    }
    AbstractView.bind(document.defaultView);
    
    return extend(document, this.prototype);
  },

  "@Gecko": {
    bind: function(document) {
      return extend(extend(document, this.prototype), "removeEventListener", delegate(EventTarget.removeEventListener));
    }
  }
});

function _bind() {
  return dom.bind(this.base.apply(this, arguments));
};
