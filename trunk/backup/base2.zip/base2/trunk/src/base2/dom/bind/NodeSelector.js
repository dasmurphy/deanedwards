
// Automatically bind objects retrieved using the Selectors API on a bound node.
extend(NodeSelector.prototype, {
  querySelector: function(selector) {
    return dom.bind(this.base(selector));
  },

  querySelectorAll: function(selector) {
    var result = this.base(selector),
        i = result.length;
    while (i--) {
      var element = result[i];
      if (!_boundNodeIDs[element.uniqueID]) dom.bind(element);
    }
    return result;
  }
});
