
// Store some state for HTML documents.
// Used for fixing event handlers and supporting the Selectors API.

var _DocumentState = Base.extend({
  constructor: function(document) {
    this.document = document;
    this.events = document == global.document ? _private.events : {};
    this._hoverElement = document.documentElement;
    var EVENT_HANDLER = /^on((DOM)?\w+|[a-z]+)$/;
    for (var name in this) {
      if (EVENT_HANDLER.test(name)) {
        this.registerEvent(name.slice(2));
      }
    }
    _DocumentState[assignID(document)] = this;
    new DOMContentLoadedEvent(document);
  },

  _activeElement: null,
  _hoverElement: null,

  isHover: function(element) {
    return includes(element, this._hoverElement);
  },

  handleEvent: function(event) {
    if (!event._userGenerated) {
      this["on" + event.type](event);
    }
  },

  onmouseout: function(event) {
    this._hoverElement = null;
  },

  onmouseover: function(event) {
    this._hoverElement = event.target;
  },

  onmousedown: function(event) {
    var element = event.target;
    if (element.href || element.tabIndex || (element.disabled === false && "form" in element)) {
      this._activeElement = event.target;
    }
  },

  onmouseup: function() {
    this._activeElement = null;
  },

  registerEvent: function(type) {
    EventTarget.addEventListener(this.document, type, this, true);
    this.events[type] = true;
  },

  "@!(document.activeElement)": {
    constructor: function(document) {
      this.base(document);
      document.activeElement = document.documentElement;
    },

    onfocus: function(event) {
      this.document.activeElement = event.target;
    },

    onblur: function() {
      this.document.activeElement = null;
    }
  },

  "@!(element.addEventListener)": {
    constructor: function(document) {
      this.base(document);
      var eventDispatcher = new EventDispatcher(this);
      this._dispatch = function(event) {
        event.target = event.target || event.srcElement || document;
        eventDispatcher.dispatch(event);
      };
      this.handleEvent = function(event) {
        if (this["on" + event.type]) {
          this["on" + event.type](event);
        }
        return eventDispatcher.dispatch(event);
      };
      // Allow form events to bubble
      var forms = {};
      this._registerForm = function(form) {
        var formID = assignID(form);
        if (!forms[formID]) {
          forms[formID] = true;
          _private.attachEvent(form, "onsubmit", this._dispatch);
          _private.attachEvent(form, "onreset", this._dispatch);
        }
      };
      // Allow select events to bubble
      var state = this;
      this._onselect = function(event) {
        if (state._activeElement == event.target) {
          state._selectEvent = copy(event);
        } else {
          state._dispatch(event);
        }
      };
      if (document.readyState === "complete") {
        this.onDOMContentLoaded();
      }
    },

    registerEvent: function(type, target) {
      var targetIsWindow = target && target.Infinity;
      var canDelegate = !targetIsWindow && !CANNOT_DELEGATE.test(type);
      if (!this.events[type] || !canDelegate) {
        if (!events) events = this.events[type] = {1:{}, 2:{}, 3:{}};
        if (canDelegate || !target) target = this.document;
        this.addEvent(type, target || this.document);
      }
    },

    registered: {},

    fireEvent: function(type, event) {
      event = cloneEvent(event);
      event.type = type;
      this.handleEvent(event);
    },

    addEvent: function(type, target) {
      // Make sure that all events are marshalled through this object
      var key = assignID(target) + type;
      if (!this.registered[key] && ("on" + type) in target) {
        this.registered[key] = true;
        var state = this;
        _private.attachEvent(target, "on" + type, function(event) {
          event.target = event.srcElement || target;
          state.handleEvent(event);
          if (state["after" + type]) {
            state["after" + type](event);
          }
        });
      }
    },

    onDOMContentLoaded: function(event) {
      // register forms so that we can bubble form events
      forEach (this.document.forms, this._registerForm, this);
      this.onactivate(this.document.activeElement);
      this.onDOMContentLoaded = Undefined;
    },

    onmousedown: function(event) {
      this.base(event);
      // remember the button number (it's missing in some event types)
      this._button = event.button;
    },

    onmouseup: function(event) {
      this.base(event);
      // Fire missing mousedown event in MSIE (on dblclick)
      if (!event._userGenerated && this._button == null) {
        this.fireEvent("mousedown", event);
      }
      delete this._button;
    },

    onfocusin: function(event) {
      this.onactivate(event.target);
    },

    aftermouseup: function() {
      // Allow select events to bubble
      if (this._selectEvent) {
        this._dispatch(this._selectEvent);
        delete this._selectEvent;
      }
    },

    onactivate: function(element) {
      // Allow change events to bubble
      var change = this.events.change && "onchange" in element,
         select = this.events.select && "onselect" in element;
      if (change || select) {
        var dispatch = this._dispatch, onselect = this._onselect;
        if (change) _private.attachEvent(element, "onchange", dispatch);
        if (select) _private.attachEvent(element, "onselect", onselect);
        var onblur = function() {
          _private.detachEvent(element, "onblur", onblur, true);
          if (change) _private.detachEvent(element, "onchange", dispatch);
          if (select) _private.detachEvent(element, "onselect", onselect);
        };
        _private.attachEvent(element, "onblur", onblur);
      }
    },

    onclick: function(event) {
      var target = event.target;
      // register forms so that we can bubble form events
      if (target.form) this._registerForm(target.form);
    },

    ondblclick: function(event) {
      // Fire missing click event in MSIE
      if (!event._userGenerated) this.fireEvent("click", event);
    }
  }
}, {
  getInstance: function(node) {
    var document = node.ownerDocument || node.document || node;
    return this[document.base2ID] || new this(document);
  }
});
