
// Store some state for HTML documents.
// Used for fixing event handlers and supporting the Selectors API.

var _DocumentState = _.Base.extend({
  constructor: function DocumentState__constructor(document) {
    this.document = document;
    this._hoverElement = document.documentElement;
    var EVENT_HANDLER = /^on((DOM)?\w+|[a-z]+)$/;
    for (var name in this) if (EVENT_HANDLER.test(name)) {
      this._registerEvent(document, name.slice(2));
    }
    _DocumentState[_.assignID(document)] = this;
    new DOMContentLoadedEvent(document);
  },

  _activeElement: null,
  _hoverElement: null,

  onmouseover: function DocumentState__onmouseover(event) {
    this._hoverElement = event.target;
  },

  onmouseout: function DocumentState__onmouseout(event) {
    this._hoverElement = null;
  },

  onmousedown: function DocumentState__onmousedown(event) {
    var element = event.target;
    if (element.href || element.tabIndex || (element.disabled === false && "form" in element)) {
      this._activeElement = event.target;
    }
  },

  onmouseup: function DocumentState__onmouseup() {
    this._activeElement = null;
  },

  handleEvent: function DocumentState__handleEvent(event) {
    this["on" + event.type](event);
  },

  isHover: function DocumentState__isHover(element) {
    return _includes(element, this._hoverElement);
  },

  _registerEvent: function DocumentState__registerEvent(document, type) {
    document.addEventListener(type, this, true);
  },

  _dispatchInputEvent: function(target, type) {
    var inputEvent = dom.createEvent(target.ownerDocument, "Event");
    inputEvent.initEvent("input", true, false);
    dom.dispatchEvent(target, inputEvent);
  },

  "@WebKit(4|5[012])": {
    "ontextInput": function(event) {
      // Fix the input event.
      var target = event.target;
      if (target.nodeName === "TEXTAREA") {
        this._dispatchInputEvent(target);
      }
    }
  },

  "@MSIE9": {
    "onactivate": function(event) {
      // Fix the input event.
      var target = event.target;
      if (target.nodeName === "TEXTAREA" || (target.nodeName === "INPUT" && !NON_TEXT_ELEMENT.test(target.type))) {
        var state = this;
        var currentValue = target.value;
        var onkeypress = function(event) {
          switch (event.keyCode) {
            case 89: // undo/redo
            case 90:
              if (!event.ctrlKey) break;
            case 8: // delete
            case 46:
              if (currentValue !== target.value) {
                currentValue = target.value;
                state._dispatchInputEvent(target);
              }
          }
        };
        var events = {
          cut: function() {
            setTimeout(function() {
              state._dispatchInputEvent(target);
            }, 4);
          },
          propertychange: function() {
            currentValue = target.value;
          },
          keyup: onkeypress,
          keydown: onkeypress,
          deactivate: function() {
            for (type in events) {
              target.detachEvent("on" + type, events[type]);
            }
          }
        };
        for (var type in events) {
          target.attachEvent("on" + type, events[type]);
        }
      }
    }
  },

  "@!(document.activeElement)": {
    constructor: function DocumentState__constructor(document) {
      this.base(document);
      document.activeElement = document.documentElement;
    },

    onfocus: function DocumentState__onfocus(event) {
      this.document.activeElement = event.target;
    },

    onblur: function DocumentState__onblur() {
      this.document.activeElement = null;
    }
  },

  "@MSIE[678]": _DocumentState_msie
}, {
  getInstance: function(node) {
    var document = node.ownerDocument || node.document || node;
    return this[document.base2ID] || new this(document);
  }
});
