
element.innerHTML = "";
element.appendChild(document.createComment(""));

var GEBT_INCLUDES_COMMENTS = element.getElementsByTagName('*').length !== 0;

var BRACES = /\{/g;
var BRACES_ESCAPED = /\\\{/g;
var SPACES = / /g;
var ONE    = {"+": 1, "-": -1};

var FILTER = new CSSSelectorParser([
  /:nth(\-last)?\-(?:child|(of\-type))\((<#nth_arg>)\)(<#filter>)?/, function(match, last, ofType, args, filters) { // :nth- pseudo classes
    args = args.replace(SPACES, "");

    var index = "_indexOf(e," + !!last + "," + !!ofType + ")";

    if (args === "even") args = "2n";
    else if (args === "odd") args = "2n+1";
    else if (!isNaN(args)) args = "0n" + ~~args;

    args = args.split("n");
    var a = ~~(ONE[args[0]] || args[0] || 1),
        b = ~~args[1];
    if (a === 0) {
      var expr = index + "===" + b;
    } else {
      expr = "((ii=" + index + ")-(" + b + "))%" + a + "===0&&ii" + (a < 0 ? "<" : ">") + "=" + b;
    }
    return this.parse(filters) + expr + "&&";
  },

  "<#negation>", function(match, simple) {
    if (/:not/i.test(simple)) throwSelectorError();

    if (/^[#.:\[]/.test(simple)) {
      simple = "*" + simple;
    }
    return "!(" + MATCHER.parse(simple).slice(3, -2) + ")&&";
  },

  "<#attr>", function(match, name, operator, value) {
    var attr = (operator ? QSA_GET_ATTRIBUTE : QSA_HAS_ATTRIBUTE) + name + "')";
    if (QUOTED.test(value)) {
      value = strings[value.slice(1, -1)].slice(1, -1).replace(SINGLE_QUOTES, "\\'");
    }
    if (operator.length > 1) {
      if (!value || operator === "~=" && SPACE.test(value)) {
        return "false&&";
      }
      attr = "(" + attr + "||'')";
    }
    return "(" + _.format(ATTR[operator], attr, value) + ")&&";
  },

  "<#id>",    ID_ATTRIBUTE + "==='$1'&&",

  "<#class>", "e.className&&(e.className==='$1'||(' '+e.className+' ').indexOf(' $1 ')!==-1)&&",

  // PSEDUO
  ":checked",         "e.checked===true&&(e.type==='checkbox'||e.type==='radio')&&",
  ":disabled",        "(e.disabled===true&&'form'in e&&e.type!=='hidden')&&",
  ":enabled",         "(e.disabled===false&&'form'in e&&e.type!=='hidden')&&",
  ":first-child",     "!" + PREVIOUS_SIBLING + "&&",
  ":last-child",      "!" + NEXT_SIBLING + "&&",
  ":only-child",      "!" + PREVIOUS_SIBLING + "&&!" + NEXT_SIBLING + "&&",
  ":first-of-type",   NOT_PREVIOUS_BY_TYPE,
  ":last-of-type",    NOT_NEXT_BY_TYPE,
  ":only-of-type",    NOT_PREVIOUS_BY_TYPE + NOT_NEXT_BY_TYPE,

  // not currently supported
  //":selected",      BUGGY_SELECTED ? 'e.selected||((ii=e.parentNode)&&ii.options[ii.selectedIndex]===e)&&' : '',

  /:lang\(([^)]+)\)/, "((ii=_getLang(e))==='$1'||ii.indexOf('$1-')===0)&&",

  ":empty",          "_isEmpty(e)&&",
  ":root",           "e==R&&",
  ":target",         "e==T&&",

  ":hover",          "D&&D.isHover(e)&&",
  ":active",         "D&&e==D._activeElement&&",
  ":focus",          "e==F&&",

  ":link",           "e.href&&(e.nodeName==='A'||e.nodeName==='LINK'||e.nodeName==='AREA')&&",
  ":visited",        "false&&", // not implemented (security)

  ":scope",          "e===S&&", // Selectors API 2

  ".", throwSelectorError
]);

var ATTR = {
  "=":  "{0}==='{1}'",                           // "[@{0}='{1}']"
  "~=": "(' '+{0}+' ').indexOf(' {1} ')!==-1",   // "[contains(concat(' ',@{0},' '),' {1} ')]",
  "|=": "{0}==='{1}'||{0}.indexOf('{1}-')===0",  // "[@{0}='{1}' or starts-with(@{0},'{1}-')]",
  "^=": "{0}.indexOf('{1}')===0",                // "[starts-with(@{0},'{1}')]",
  "$=": "{0}.slice(-'{1}'.length)==='{1}'",      // "[ends-with(@{0},'{1}')]",
  "*=": "{0}.indexOf('{1}')!==-1"                // "[contains(@{0},'{1}')]"
};
ATTR[""] = "{0}";                                // "[@{0}]"

var DS    = /:(hover|active|focus)/i;
var HASH  = /:target/i;
var FOCUS = /:focus/i;
var ROOT  = /:root/i;
var NTH   = /:nth/i;

var COMBINATOR = {
  " ":   ";while(e!=s&&(e=e.parentNode)&&e.nodeType===1){",
  ">":   "." + PARENT_ELEMENT + ";if(e){",
  "+":   (SUPPORTS_TRAVERSAL_API ? ".previousElementSibling" : ";while((e=e.previousSibling)&&e.nodeType!==1)continue") + ";if(e){" ,
  "~":   ";while((e=e.previous" + SIBLING + ")){" + (SUPPORTS_TRAVERSAL_API ? "" : "if(e.nodeType===1){")
};

var TOKENS = new _.RegGrp([
  normalize.getAt(0).source, null,
  /\be\b/, null
]);

var TOKEN = TOKENS.getAt(1);

var MATCHER = new CSSSelectorParser([
  "(?:(<#selector>)(<#combinator>))?(<#tag>)(<#filter>)?$", function(match, before, combinator, tag, filters) {
    var group = "";
    if (tag !== "*") {
      var TAG = tag.toUpperCase();
      group += "if(e.nodeName==='" + TAG + (TAG === tag ? "" : "'||e.nodeName==='" + tag) + "'){";
    }
    if (filters) {
      group += "if(" + FILTER.parse(filters).slice(0, -2) + "){";
    }
    TOKEN.replacement = "e" + this.index;
    group = TOKENS.parse(group);
    if (combinator) {
      group += "var e=e" + (this.index++) + COMBINATOR[combinator];
      TOKEN.replacement = "e" + this.index;
      group = TOKENS.parse(group);
    }
    if (before) {
      group += this.parse(before);
    }
    return group;
  }
]);

var matchQuery = new CSSSelectorParser([
  "<#grammar>", function(match, selector, selectors) {
    selector = CSSSelectorParser_escape(selector);
    MATCHER.index = 0;
    var group = MATCHER.parse(selector) + "return true;";
    group += closeBlock(group) + matchQuery.parse(selectors.replace(COMMA, ""));
    return CSSSelectorParser_unescape(group);
  },

  ".", throwSelectorError
]);

matchQuery.create = _.memoize(function(selector) {
  selector = CSSSelectorParser_escape(selector);
  return createQuery("function(s){" +
    "var c=this;" +
    getConstants(selector) +
    "var e0=c;" + CSSSelectorParser_unescape(matchQuery.parse(selector)) +
    "return false}"
  );
});

matchQuery.cache = matchQuery.create.cache = {"*": _.True};

_private.createMatcher = matchQuery.create;

var selectQuery = (function() {
  var BY_ID       = "e0=" + (_getElementById ? "_getElementById.call(d,'{0}')" : "d.getElementById('{0}')") + ";if(e0){";
  var BY_TAG_NAME = "var n=_getElementsByTagName(c,'{0}');";
  var STORE       = "if(r==null)return e0;r[k++]=e0;";

  var SELECTOR = new CSSSelectorParser([
    "^((?:<#selector>)?(?:<#combinator>))(<#tag>)(<#filter>)?$", true
  ]);

  var selectById = new CSSSelectorParser([
    "^(<#tag>)#(<#ident>)(<#filter>)?( [^,]*)?$", function(match, tagName, id, filters, after) {
      var block = _.format(BY_ID, id);
      var endBlock = "}";
      if (filters) {
        block += MATCHER.parse(tagName + filters);
        endBlock = closeBlock(block);
      }
      if (after) {
        block += "s=c=e0;" + selectQuery.parse("*" + after);
      } else {
        block += STORE;
      }
      return block + endBlock;
    },

    "^([^#,]+)#(<#ident>)(<#filter>)?$", function(match, before, id, filters) {
      var block = _.format(BY_ID, id);
      if (before === "*") {
        block += STORE;
      } else {
        block += MATCHER.parse(before + filters) + STORE + "break";
      }
      return block + closeBlock(block);
    },

    "^.*$", ""
  ]);

  var TAG_NAME = 1;

  var selectQuery = new CSSSelectorParser([
    "<#grammar>", function(match, selector, remainingSelectors) {
      if (!this.groups) this.groups = [];

      var group = SELECTOR.exec(" " + selector);

      if (!group) throwSelectorError();

      this.groups.push(group.slice(1));

      if (remainingSelectors) {
        return this.parse(remainingSelectors.replace(COMMA, ""));
      }

      var groups = this.groups;
      var tagName = groups[0][TAG_NAME]; // first tag name

      for (var i = 1; group = groups[i]; i++) { // search tag names
        if (tagName !== group[TAG_NAME]) {
          tagName = "*"; // mixed tag names, so use "*"
          break;
        }
      }

      var matcher = "", store = STORE + "continue _filtering;";

      for (var i = 0; group = groups[i]; i++) {
        MATCHER.index = 0;
        if (tagName !== "*") group[TAG_NAME] = "*"; // we are already filtering by tagName
        group = group.join("");
        if (group === " *") { // select all
          matcher = store;
          break;
        } else {
          group = MATCHER.parse(group);
          matcher += group + store + closeBlock(group);
        }
      }

      // reduce to a single loop
      return _.format(BY_TAG_NAME, tagName) +
        "_filtering:while((e0=n[i++]))" +
        (GEBT_INCLUDES_COMMENTS && tagName === "*" ? "if(e0.nodeType===1){" : "{") +
          matcher +
        "}";
    },

    ".", throwSelectorError
  ]);

  var REDUNDANT_NODETYPE = /\&\&(e\d+)\.nodeType===1(\)\{\s*if\(\1\.nodeName=)/g;

  selectQuery.create = _.memoize(function(selector) {
    try {
      selector = CSSSelectorParser_escape(selector);
      this.groups = null;
      MATCHER.index = 0;
      var block = this.parse(selector);
      this.groups = null;
      MATCHER.index = 0;
      if (selector.indexOf("#") !== -1) {
        var byId  = selectById.parse(selector);
        if (byId) {
          block =
            "if(t===1||t===11||!c.getElementById){" +
              block +
            "}else{" +
              byId +
            "}";
        }
      }
      // remove redundant nodeType==1 checks
      block = block.replace(REDUNDANT_NODETYPE, "$2");
      block = getConstants(selector) + CSSSelectorParser_unescape(block);
      return createQuery("function(r,s){var c=this,i=0,k=0,e0;" + block + "if(r)r.length=k;return r}");
    } catch (error) {
      return _.K(error);
    }
  });

  selectQuery.cache = selectQuery.create.cache;

  return selectQuery;
})();

function getConstants(selector) {
  var constants = "";
  if (ROOT.test(selector)) constants += ",R=d.documentElement";
  if (HASH.test(selector)) constants += ",H=d.location,H=H&&H.hash.replace('#',''),T=H&&d.getElementById(H)";
  if (DS.test(selector)) constants += ",D=_DocumentState[d.base2ID]";
  if (FOCUS.test(selector)) constants += ",F=!d.hasFocus||d.hasFocus()?d.activeElement:null";
  if (constants || selector.indexOf("#") !== -1) {
    constants = ",d=t===9?c:c.ownerDocument" + constants;
  }
  var increment = NTH.test(selector) ? "if(_private.isReady)_private.qIndex++;" : "";
  return "var ii,t=c.nodeType,S=s||(t===9?c.documentElement:c)" + constants + ";" + increment;
}

function createQuery(query) {
  return new Function(
    "_getElementById,_getElementsByTagName,_getAttribute,_hasAttribute,_indexOf,_getNextElementSibling,_getPreviousElementSibling,_getElementSiblingByType,_isEmpty,_getLang,_DocumentState,_private",
      "return " + query
    )(
     _getElementById,_getElementsByTagName,_getAttribute,_hasAttribute,_indexOf,_getNextElementSibling,_getPreviousElementSibling,_getElementSiblingByType,_isEmpty,_getLang,_DocumentState,_private
  );
}

function closeBlock(group) {
  return Array((group.replace(BRACES_ESCAPED, "").match(BRACES) || "").length + 1).join("}");
}

setTimeout(function() {
  selectQuery.create("a #b[c]"); // initialise parsers
}, 4);
