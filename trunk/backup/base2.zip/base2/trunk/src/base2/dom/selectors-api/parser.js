
function createQuery(query) {
  return new Function(
    "_byId,_getElementsByTagName,_getAttribute,_hasAttribute,_indexOf,_getElementSibling,_getElementSiblingByType,_isEmpty,_getLang,_DocumentState",
      "return " + query
    )(
     _byId,_getElementsByTagName,_getAttribute,_hasAttribute,_indexOf,_getElementSibling,_getElementSiblingByType,_isEmpty,_getLang,_DocumentState
  );
};

var BRACES = /\{/g, BRACES_ESCAPED = /\\\{/g;

function closeBlock(group) {
  return Array((group.replace(BRACES_ESCAPED, "").match(BRACES) || "").length + 1).join("}");
};

var ONE    = {"+": 1, "-": -1},
    SPACES = / /g;

var FILTER = new CSSSelectorParser({
  ":nth(-last)?-(?:child|(of-type))\\((<#nth_arg>)\\)(<#filter>)?": function(match, last, ofType, args, filters) { // :nth- pseudo classes
    args = args.replace(SPACES, "");

    var index = "_indexOf(e," + !!last + "," + !!ofType + ")";

    if (args === "even") args = "2n";
    else if (args === "odd") args = "2n+1";
    else if (!isNaN(args)) args = "0n" + ~~args;

    args = args.split("n");
    var a = ~~(ONE[args[0]] || args[0] || 1),
        b = ~~args[1];
    if (a === 0) {
      var expr = index + "===" + b;
    } else {
      expr = "((ii=" + index + ")-(" + b + "))%" + a + "===0&&ii" + (a < 0 ? "<" : ">") + "=" + b;
    }
    return this.parse(filters) + expr + "&&";
  },

  "<#negation>": function(match, simple) {
    if (/:not/i.test(simple)) throwSelectorError();

    if (/^[#.:\[]/.test(simple)) {
      simple = "*" + simple;
    }
    return "!(" + MATCHER.parse(simple).slice(3, -2) + ")&&";
  },

  "<#attr>": function(match, name, operator, value) {
    var attr = (operator ? GET_ATTRIBUTE : HAS_ATTRIBUTE) + name + "')";
    if (QUOTED.test(value)) {
      value = strings[value.slice(1, -1)]
    }
    if (operator.length > 1) {
      if (!value || operator === "~=" && SPACE.test(value)) {
        return "false&&";
      }
      attr = "(" + attr + "||'')";
    }
    return "(" + format(ATTR[operator], attr, value) + ")&&";
  },

  "<#id>":    ID_ATTRIBUTE + "==='$1'&&",

  "<#class>": "e.className&&(' '+e.className+' ').indexOf(' $1 ')!==-1&&",

  // PSEDUO
  ":checked":         "e.checked===true&&(e.type==='checkbox'||e.type==='radio')&&",
  ":disabled":        "(e.disabled===true&&'form'in e&&e.type!=='hidden')&&",
  ":enabled":         "(e.disabled===false&&'form'in e&&e.type!=='hidden')&&",
  ":first-child":     "!" + PREVIOUS_SIBLING + "&&",
  ":last-child":      "!" + NEXT_SIBLING + "&&",
  ":only-child":      "!" + PREVIOUS_SIBLING + "&&!" + NEXT_SIBLING + "&&",
  ":first-of-type":   NOT_PREVIOUS_BY_TYPE,
  ":last-of-type":    NOT_NEXT_BY_TYPE,
  ":only-of-type":    NOT_PREVIOUS_BY_TYPE + NOT_NEXT_BY_TYPE,

  // not currently supported
  //":contains\\(([^)]+)\\)":    "e." + TEXT_CONTENT + ".indexOf('$1')!==-1&&",
  //":selected":                 BUGGY_SELECTED ? 'e.selected||((ii=e.parentNode)&&ii.options[ii.selectedIndex]===e)&&' : '',

  ":lang\\(([^)]+)\\)":    "((ii=_getLang(e))==='$1'||ii.indexOf('$1-')===0)&&",

  ":empty":          "_isEmpty(e)&&",
  ":root":           "e==R&&",
  ":target":         "e==T&&",

  ":hover":          "D&&D.isHover(e)&&",
  ":active":         "D&&e==D._activeElement&&",
  ":focus":          "e==F&&",

  ":link":           "e.href&&(e.nodeName==='A'||e.nodeName==='AREA'||e.nodeName==='LINK')&&",
  ":visited":        "false&&", // not implemented (security)

  ".": throwSelectorError
});

var ATTR = {
  "=":  "%1==='%2'",                           // "[@%1='%2']"
  "~=": "(' '+%1+' ').indexOf(' %2 ')!==-1",   // "[contains(concat(' ',@%1,' '),' %2 ')]",
  "|=": "%1==='%2'||%1.indexOf('%2-')===0",    // "[@%1='%2' or starts-with(@%1,'%2-')]",
  "^=": "%1.indexOf('%2')===0",                // "[starts-with(@%1,'%2')]",
  "$=": "%1.slice(-'%2'.length)==='%2'",       // "[ends-with(@%1,'%2')]",
  "*=": "%1.indexOf('%2')!==-1"                // "[contains(@%1,'%2')]"
};
ATTR[""] = "%1";                               // "[@%1]"

var DS   = /:(hover|active|focus)/i,
    HASH = /:target/i,
    FOCUS = /:focus/i,
    ROOT = /:root/i;

function getConstants(selector) {
  var constants = "";
  if (ROOT.test(selector)) constants += ",R=d.documentElement";
  if (HASH.test(selector)) constants += ",H=d.location,H=H&&H.hash.replace('#',''),T=H&&d.getElementById(H)";
  if (DS.test(selector)) constants += ",D=_DocumentState[d.base2ID]";
  if (FOCUS.test(selector)) constants += ",F=!d.hasFocus||d.hasFocus()?d.activeElement:null";
  if (constants || selector.indexOf("#") !== -1) {
    constants = ",t=c.nodeType,d=t===9?c:c.ownerDocument" + constants;
  }
  return "var ii" + constants + ";";
};

var COMBINATOR = {
  " ":   ";while(e!=s&&(e=e.parentNode)&&e.nodeType===1){",
  ">":   "." + PARENT + ";if(e){",
  "+":   (SUPPORTS_TRAVERSAL_API ? ".previousElementSibling" : ";while((e=e.previousSibling)&&!(" + IS_ELEMENT + "))continue") + ";if(e){" ,
  "~":   ";while((e=e.previous" + SIBLING + ")){" + (SUPPORTS_TRAVERSAL_API ? "" : IF_ELEMENT)
};

var TOKENS = /\be\b/g;

var MATCHER = new CSSSelectorParser({
  "(?:(<#selector>)(<#combinator>))?(<#tag>)(<#filter>)?$": function(match, before, combinator, tag, filters) {
    var group = "";
    if (tag !== "*") {
      var TAG = tag.toUpperCase();
      group += "if(e.nodeName==='" + TAG + (TAG === tag ? "" : "'||e.nodeName==='" + tag) + "'){";
    }
    if (filters) {
      group += "if(" + FILTER.parse(filters).slice(0, -2) + "){";
    }
    group = group.replace(TOKENS, "e" + this.index);
    if (combinator) {
      group += "var e=e" + (this.index++) + COMBINATOR[combinator];
      group = group.replace(TOKENS, "e" + this.index);
    }
    if (before) {
      group += this.parse(before);
    }
    return group;
  }
});

var matchQuery = new CSSSelectorParser({
  "<#grammar>": function(match, selector, selectors) {
    selector = escape(selector);
    MATCHER.index = 0;
    var group = MATCHER.parse(selector) + "return true;";
    group += closeBlock(group) + this.parse(selectors.replace(COMMA, ""));
    return unescape(group);
  },

  ".": throwSelectorError
});

var cache = matchQuery.cache = {"*": True};

matchQuery.create = function(selector) {
  if (!cache[selector]) {
    selector = escape(selector);
    cache[selector] = createQuery("function(c,s){" + getConstants(selector) + "var e0=c;" + unescape(this.parse(selector)) + "return false}");
  }
  return cache[selector];
};

var selectQuery = (function() {
  var BY_ID       = "e0=" + (_byId ? "_byId(d,'%1')" : "d.getElementById('%1')") + ";if(e0){",
      BY_TAG_NAME = "var n=_getElementsByTagName(c,'%1');",
      STORE       = "if(r==null)return e0;r[k++]=e0;";

  var SELECTOR = new CSSSelectorParser({
    "^((?:<#selector>)?(?:<#combinator>))(<#tag>)(<#filter>)?$": true
  });

  var selectById = new CSSSelectorParser({
    "^(<#tag>)#(<#ident>)(<#filter>)?( [^,]*)?$": function(match, tagName, id, filters, after) {
      var block = format(BY_ID, id), endBlock = "}";
      if (filters) {
        block += MATCHER.parse(tagName + filters);
        endBlock = closeBlock(block);
      }
      if (after) {
        block += "s=c=e0;" + selectQuery.parse("*" + after);
      } else {
        block += STORE;
      }
      return block + endBlock;
    },

    "^([^#,]+)#(<#ident>)(<#filter>)?$": function(match, before, id, filters) {
      var block = format(BY_ID, id);
      if (before === "*") {
        block += STORE;
      } else {
        block += MATCHER.parse(before + filters) + STORE + "break";
      }
      return block + closeBlock(block);
    },

    "^.*$": ""
  });


  var TAG_NAME    = 1;

  var selectQuery = new CSSSelectorParser({
    "<#grammar>": function(match, selector, remainingSelectors) {
      if (!this.groups) this.groups = [];

      var group = SELECTOR.exec(" " + selector);

      if (!group) throwSelectorError();

      this.groups.push(group.slice(1));

      if (remainingSelectors) {
        return this.parse(remainingSelectors.replace(COMMA, ""));
      }

      var groups = this.groups,
          tagName = groups[0][TAG_NAME]; // first tag name

      for (var i = 1; group = groups[i]; i++) { // search tag names
        if (tagName !== group[TAG_NAME]) {
          tagName = "*"; // mixed tag names, so use "*"
          break;
        }
      }

      var matcher = "", store = STORE + "continue filtering;";

      for (var i = 0; group = groups[i]; i++) {
        MATCHER.index = 0;
        if (tagName !== "*") group[TAG_NAME] = "*"; // we are already filtering by tagName
        group = group.join("");
        if (group === " *") { // select all
          matcher = store;
          break;
        } else {
          group = MATCHER.parse(group);
          matcher += group + store + closeBlock(group);
        }
      }

      // reduce to a single loop
      return format(BY_TAG_NAME, tagName) +
        "filtering:while((e0=n[i++]))" +
        (MSIE && tagName === "*" ? IF_ELEMENT.replace(TOKENS, "e0") : "{") +
          matcher +
        "}";
    },

    ".": throwSelectorError
  });

  var cache = selectQuery.cache = {};

  var REDUNDANT_NODETYPE_CHECKS = /\&\&(e\d+)\.nodeType===1(\)\{\s*if\(\1\.nodeName=)/g;

  selectQuery.create = function(selector) {
    if (!cache[selector]) {
      selector = escape(selector);
      this.groups = null;
      MATCHER.index = 0;
      var block = this.parse(selector);
      this.groups = null;
      MATCHER.index = 0;
      if (selector.indexOf("#") !== -1) {
        var byId  = selectById.parse(selector);
        if (byId) {
          block =
            "if(t===1||t===11|!c.getElementById){" +
              block +
            "}else{" +
              byId +
            "}";
        }
      }
      // remove redundant nodeType==1 checks
      block = block.replace(REDUNDANT_NODETYPE_CHECKS, "$2");
      block = getConstants(selector) + unescape(block);
      cache[selector] = createQuery("function(c,r,s){var i=0,k=0,e0;if($$base2.isReady)$$base2.qIndex++;" + block + "if(r)r.length=k;return r}");
    }
    return cache[selector];
  };

  return selectQuery;
})();

setTimeout(function() {
  selectQuery.create("a #b[c]"); // initialise parsers
}, 4);
