
var dom = base2.dom = new _.Package({
  name:    "base.dom",
  version:  base2.version,

  CSSSelectorParser: CSSSelectorParser,

  classList: classList,
  style: style,

  get: function dom_get(node, propertyName) {
    return node[propertyName];
  },

  set: function dom_set(node, propertyName, value) {
    return node[propertyName] = value;
  },

  getComputedStyle: function getComputedStyle(element, pseudoElement) {
    if (arguments.length < 1) {
      throw TypeError(Arity("getComputedStyle"));
    }
    if (!element || element.nodeType !== 1) {
      throw TypeError(Target("getComputedStyle"));
    }

    var view = element.ownerDocument.defaultView;
    return view.getComputedStyle(element, pseudoElement || null);
  }
});
