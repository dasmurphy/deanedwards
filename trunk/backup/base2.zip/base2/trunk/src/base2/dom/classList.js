
// http://dev.w3.org/html5/spec/Overview.html#domtokenlist

var SUPPORTS_CLASS_LIST = "classList" in element;

// a constructor that binds ClassList objects to elements
function ClassList(element) {
  /*@if (@_jscript_version < 5.7)
    msieCache[this._element = element.uniqueID] = element;
  @else @*/
    this._element = element;
  /*@end @*/
}

ClassList.prototype.toString = function(token) {
  var element = this._element;
  /*@if (@_jscript_version < 5.7)
     element = msieCache[element];
  /*@end @*/
  return _.trim(element.className).split(/\s+/).join(" ");
};

var classList = (function() {
  var HAS_CLASS     = 'e.c && (e.c === c || (" " + e.c + " ").indexOf(" " + c + " ") !== -1)';
  var NOT_HAS_CLASS = "!(" + HAS_CLASS + ")";
  var ADD_CLASS     = 'e.c += (e.c ? " " : "") + c;';
  var REMOVE_CLASS  = 'e.c = e.c.replace(new RegExp("(^|\\\\s)" + c.replace(r,"\\\\$1") + "(\\\\s|$)", "g"), "$2");';

  var REGEXP_ESCAPE = /([\/()[\]{}|*+-.,^$?\\])/g;

  var FN = 'return function {1}({2}) {\n' +
    '{4}' +
    '  if (arguments.length < {3}) {\n' +
    '    throw new SyntaxError("' + DOM_ARITY_ERR + '");\n' +
    '  }\n' +
    '  if (!e || e.nodeType !== 1) {\n' +
    '    throw new TypeError("' + DOM_TYPE_ERR + '");\n' +
    '  }\n' +
    '  if (c === "") {\n' +
    '    throw new Error("c cannot be an empty string: {0}().");\n' +
    '  }\n' +
    '  if (/\\s/.test(c)) {\n' +
    '    throw new Error("c cannot contain spaces: {0}().");\n' +
    '  }\n  ';

  /*@if (@_jscript_version < 5.7)
     var ELEMENT = "  var e = window['#base2_msie'][this._element];\n";
  @else @*/
     var ELEMENT = "  var e = this._element;\n";
  /*@end @*/

  function createMethod(name, body) {
    if (SUPPORTS_CLASS_LIST) body = "return e.{0}(c);";
    ;doc; if (!SUPPORTS_CLASS_LIST) body = body.split("\n").join("\n  ");
    var fn = _.format(FN + body + '\n}\n', "classList." + name, name, "c", 1, ELEMENT);
    ;doc; fn = fn.replace(/\bc\b/g, "className").replace(/\be\b/g, "element");
    ClassList.prototype[name] = new Function("r", fn)(REGEXP_ESCAPE);
    fn = _.format(FN + body + '\n}\n', "classList." + name, name, "e, c", 2, "");
    ;doc; fn = fn.replace(/\bc\b/g, "className").replace(/\be\b/g, "element");
    return new Function("r", fn)(REGEXP_ESCAPE);
  }

  return {
    add:      createMethod("add", 'if (' + NOT_HAS_CLASS + ') {\n  ' + ADD_CLASS + '\n}'),
    contains: createMethod("contains", 'return ' + HAS_CLASS + ';'),
    remove:   createMethod("remove", REMOVE_CLASS),
    toggle:   createMethod("toggle", 'if (' + NOT_HAS_CLASS + ') {\n  ' + ADD_CLASS + '\n} else {\n  ' + REMOVE_CLASS + '\n}'),

    toString: _.K("[base2.dom.classList]")
  };
})();
