
// employ strict validation of DOM calls

eval(
  base2.namespace +
  base2.dom.namespace +
  base2.lang.namespace
);
