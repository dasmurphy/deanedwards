
RegGrp.Item = Base.extend({
  constructor: function(source, replacement, owner) {
    var length = source.indexOf("(") === -1 ? 0 : RegGrp.count(source);
    
    var dictionary = owner.dictionary;
    if (dictionary && source.indexOf("<#") !== -1) {
      if (_REGGRP_DICT_ENTRY.test(source)) {
        var entry = dictionary[_ITEMS][_HASH + source.slice(2, -1)];
        source = entry.replacement;
        length = entry._length;
      } else {
        source = dictionary.parse(source);
      }
    }
    
    if (replacement == null) {
      replacement = 0;
    } else if (replacement.replacement != null) {
      replacement = replacement.replacement;
    } else if (typeof replacement == "number") {
      replacement = String(replacement);
    }

    // Does the expression use sub-expression lookups?
    if (typeof replacement == "string" && _REGGRP_LOOKUP.test(replacement)) {
      if (_REGGRP_LOOKUP_SIMPLE.test(replacement)) { // A simple lookup? (e.g. "$2").
        // Store the index (used for fast retrieval of matched strings).
        var index = replacement.slice(1) - 0;
        if (index && index <= length) replacement = index;
      } else {
        // A complicated lookup (e.g. "Hello $2 $1.").
        var lookup = replacement, regexp;
        replacement = function(match) {
          if (!regexp || regexp.ignoreCase !== this.ignoreCase) {
            regexp = new RegExp(source, "g" + (this.ignoreCase ? "i": ""));
          }
          return match.replace(regexp, lookup);
        };
      }
    }

    this.length = length;
    this.source = String(source);
    this.replacement = replacement;
  },

  length: 0,
  source: "",
  replacement: ""
});
