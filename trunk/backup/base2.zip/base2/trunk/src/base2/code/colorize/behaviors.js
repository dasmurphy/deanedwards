
base2.require("jsb", function(namespace) {
  eval(namespace); // import

  new Rule("form", {
    oncontentready: function(form) {
      this.output(form, "");
      this.ready(form);
    },

    onclick: function(form, event) {
      var target = event.target;
      if (target.tagName == "BUTTON") {
        this[target.id](form);
      }
    },

    clear: function(form) {
      form.input.value = "";
      this.output(form, "");
      this.ready(form);
    },

    output: function(form, value) {
      this.querySelector(form, "#output").innerHTML = value;
    },

    error: function(form, text, error) {
      this.message(form, text + ": " + error.message, "error");
    },

    message: function(form, text, className) {
      var message = this.querySelector(form, "#message");
      message.innerHTML = text;
      message.className = className || "";
    },

    colorize: function(form) {
      try {
        this.output(form, "");
        if (form.input.value) {
          var language = form.language.value;
          var scheme = colorize[language];
          var value = "Scheme not found."
          var output = this.querySelector(form, "#output");
          output.className = "";
          if (scheme) {
            var value = scheme.parse(form.input.value);
            this.output(form, value);
            output.className = "colorized colorize-" + language;
          } else {
            this.error(form, "scheme not found: " + language);
          }
        }
      } catch (error) {
        this.error(form, "error colorizing text", error);
      }
    },

    ready: function(form) {
      this.message(form, "ready");
      form.input.focus();
    }
  });
});
