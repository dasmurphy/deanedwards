
base2.exec(function(namespace) {
  eval(namespace);
  var javascript = colorize.javascript;
  javascript.add("\\b(" + ([extractNames(base2),extractNames(lang),extractNames(Function2),extractNames(Enumerable)].join(",") + ",base,base2,implement").match(/[^\s,]+/g).join("|") + ")\\b", '<span class="base2">$1</span>');
  javascript.insertAt(0, /("@[^"]+"):/, '<span class="colorize-special">$1</span>:');
  javascript.tabStop = 2;
  function extractNames(object) {
    return Array2.map(object.namespace.match(/var \w+/g), function(match) {
      return match.slice(4);
    }).join(",");
  };
});
