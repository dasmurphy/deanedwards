
base2.exec(function(namespace) { // begin: closure

  eval(namespace); // import
  
  var IGNORE = RegGrp.IGNORE;

  var TAB  = /\t/g;
  var TABS = /\n([\t \xa0]*)/g;

  // Use a srting to create the CHAR pattern.
  // This protects against a bug in Safari 2.
  // Finally, we need to separate the \uffff char (this is for Opera).
  var CHAR = "\\w\u00a1-\ufffe\uffff";
  
  var BLOCK_COMMENT = /\/\*[^*]*\*+([^\/][^*]*\*+)*\//;
  var LINE_COMMENT  = /\/\/[^\r\n]*/;
  var NUMBER        = /\b\-?(0|[1-9]\d*)(\.\d+)?([eE][-+]?\d+)?\b/;
  var STRING1       = /'(\\.|[^'\\])*'/;
  var STRING2       = /"(\\.|[^"\\])*"/;
  var EMAIL         = /(mailto:)?([<#CHAR>.+-]+@[<#CHAR>.-]+\.[<#CHAR>]+)/;
  var URL           = /https?:\/\/+[<#CHAR>\/\-%&#=.,?+$]+/;

  var escape = new RegGrp({
    "<":       "\x01",
    ">":       "\x02",
    "&":       "\x03"
  });

  var unescape = new RegGrp({
    "\x01":    "&lt;",
    "\x02":    "&gt;",
    "\x03":    "&amp;"
  });

  var Colorizer = RegGrp.extend({
    constructor: function(dictionary, values, options) {
      extend(this, options);
      this.dictionary = new Colorizer.Dict(dictionary);
      this.base(values);
    },

    escapeChar: "",
    parseUrls: true,
    tabStop: 4,

    parse: function(text, preParsed) {
      text = escape.parse(text);
      if (!preParsed && this.before) {
        text = this.before(text);
      }
      text = this.base(text);
      if (!preParsed) { // Not a secondary parse of the text (e.g. CSS within an HTML sample).
        text = this.parseWhiteSpace(text);
        if (this.parseUrls) text = urls.parse(text);
      }
      if (!preParsed && this.after) {
        text = this.after(text);
      }
      return unescape.parse(text);
    },
    
    put: function(pattern, replacement) {
      if (/^colorize\-/.test(replacement)) {
        replacement = '<span class="' + replacement + '">$1</span>';
      }
      return this.base(pattern, replacement);
    },

    parseWhiteSpace: function(text) {
      // Convert tabs to spaces and then convert spaces to "&nbsp;".
      var tabStop = this.tabStop;
      if (tabStop > 0) {
        var tab = Array(tabStop + 1).join(" ");
        return text.replace(TABS, function(match) {
          match = match.replace(TAB, tab);
          if (tabStop > 1) {
            var padding = (match.length - 1) % tabStop;
            if (padding) match = match.slice(0, padding);
          }
          return match.replace(/ /g, "&nbsp;");
        });
      }
      return text;
    },

    "@MSIE": {
      parseWhiteSpace: function(text) {
        return this.base(text).replace(/\r?\n/g, "<br>");
      }
    }
  });

  Colorizer.Dict = RegGrp.Dict.extend({
    parse: function(phrase) {
      return escape.parse(this.base(phrase));
    }
  });

  // ------------------------------------------------------
  // Package.
  // ------------------------------------------------------

  var colorize = new Package({
    name:    "colorize",
    version: "0.9",
    //parent:  tools?, // -@DRE

    exports: {
      CHAR:          CHAR,
      BLOCK_COMMENT: BLOCK_COMMENT,
      LINE_COMMENT:  LINE_COMMENT,
      NUMBER:        NUMBER,
      STRING1:       STRING1,
      STRING2:       STRING2,
      
      Colorizer:     Colorizer,
      
      addScheme:     addScheme
    }
  });
  
  global.colorize = colorize; // -@DRE

  var RULE = "pre:not(.colorized).colorize-";

  function addScheme(name, dictionary, values, options) {
    if (arguments.length == 2 && arguments[1] instanceof Colorizer) {
      var scheme = arguments[1];
    } else {
      scheme = new Colorizer(dictionary, values, options);
    }
    if (base2.jsb) {
      new jsb.Rule(RULE + name, {
        oncontentready: function(element) {
          var textContent = this.get(element, "textContent");
          element.innerHTML = scheme.parse(textContent);
          this.classList.add(element, "colorized");
        }
      });
    } else if (global.jQuery) {
      jQuery(function($) {
        $(RULE + name).each(function() {
          var textContent = $(this).text();
          this.innerHTML = scheme.parse(textContent);
          $(this).addClass("colorized");
        });
      });
    }
    return colorize.addName(name, scheme);
  };

  // ------------------------------------------------------
  // URL parser.
  // ------------------------------------------------------

  var urls = new RegGrp({
    CHAR:   CHAR,
    EMAIL:  EMAIL,
    URL:    URL
  }, {
    '<#EMAIL>': '<a href="mailto:$2">$1$2</a>',
    '(<#URL>)':   '<a href="$1">$1</a>'
  });

  // ------------------------------------------------------
  // JavaScript parser.
  // ------------------------------------------------------

  var javascript = addScheme("javascript", {
    OPERATOR:      /[\[(\^=,:;&|!*?]/,
    BLOCK_COMMENT: BLOCK_COMMENT,
    LINE_COMMENT:  LINE_COMMENT,
    COMMENT:       /<#BLOCK_COMMENT>|<#LINE_COMMENT>/,
    NUMBER:        NUMBER,
    STRING1:       STRING1,
    STRING2:       STRING2,
    STRING:        /<#STRING1>|<#STRING2>/,
    CONDITIONAL:   /\/\*@if\s*\([^\)]*\)|\/\*@[\s\w]*|@\*\/|\/\/@\w+|@else[\s\w]*/, // conditional comments
    GLOBAL:        /\b(clearInterval|clearTimeout|confirm|constructor|document|escape|hasOwnProperty|Infinity|isNaN|isPrototypeOf|NaN|parseFloat|parseInt|prompt|propertyIsEnumerable|prototype|setInterval|setTimeout|toString|toLocaleString|unescape|valueOf|window)\b/,
    KEYWORD:       /\b(&&|\|\||arguments|break|case|continue|default|delete|do|else|false|for|function|if|in|instanceof|new|null|return|switch|this|true|typeof|var|void|while|with|undefined)\b/,
    REGEXP:        /\/(\[(\\.|[^\n\]\\])+\]|\\.|[^\/\n\\])+\/[gim]*/,
    SPECIAL:       /\b(assert\w*|alert|catch|console|debug|debugger|eval|finally|throw|try)\b/
  }, {
    "(<#LINE_COMMENT>)(\\n\\s*)(<#REGEXP>)?": '<span class="colorize-comment">$1</span>$2<span class="colorize-regexp">$3</span>',
    "(<#BLOCK_COMMENT)(\\s*)(<#REGEXP>)?": '<span class="colorize-comment">$1</span>$2<span class="colorize-regexp">$3</span>',
    "(<#OPERATOR>)(\\s*)(<#REGEXP>)": '$1$2<span class="colorize-regexp">$3</span>',
    "(return|typeof)(\\s*)(<#REGEXP>)": '<span class="colorize-keyword">$1</span>$2<span class="colorize-regexp">$3</span>',
    '(<#COMMENT>)':       'colorize-comment',
    '(<#STRING>)':        'colorize-string',
    '(<#NUMBER>)':        'colorize-number',
    '(<#CONDITIONAL>)':   'colorize-conditional-comment',
    '(<#GLOBAL>)':        'colorize-global',
    '(<#KEYWORD>)':       'colorize-keyword',
    '(<#SPECIAL>)':       'colorize-special'
  });

  // ------------------------------------------------------
  // CSS parser.
  // ------------------------------------------------------
  
  var css = addScheme("css", {
    CHAR:              CHAR,
    AT_RULE:           /@\w[^;{]+/,
    BRACKETED:         /\([^'\x22)]*\)/,
    COMMENT:           BLOCK_COMMENT,
    PROPERTY:          /(\w[\w-]*\s*):([^;}]+)/,
    VENDOR_SPECIFIC:   /(\-[\w-]+\s*):([^;}]+)/,
    SELECTOR:          /([<#CHAR>:\[.#-](\\.|[^{\\])*)\{/
  }, {
    '(<#AT_RULE>)':       'colorize-at_rule',
    '<#BRACKETED>':       IGNORE,
    '(<#COMMENT>)':       'colorize-comment',
    '<#PROPERTY>':        '<span class="colorize-property-name">$1</span>:<span class="colorize-property-value">$2</span>',
    '<#VENDOR_SPECIFIC>': '<span class="colorize-vendor-specific"><span class="colorize-property-name">$1</span>:<span class="colorize-property-value">$2</span></span>',
    '<#SELECTOR>':        '<span class="colorize-selector">$1</span>{'
  }, {
    ignoreCase: true
  });

  // ------------------------------------------------------
  // XML parser.
  // ------------------------------------------------------

  var xml = addScheme("xml", {
    CHAR:      CHAR,
    PI:        /<\?[^>]+>/,
    COMMENT:   /<!\s*(--([^-]|[\r\n]|-[^-])*--\s*)>/,
    CDATA:     /<!\[CDATA\[([^\]]|\][^\]]|\]\][^>])*\]\]>/,
    ENTITY:    /&(#\d+|\w+);/,
    TAG:       /(<\/?)([<#CHAR>\-]+(?:\:[<#CHAR>\-]+)?\s*)((?:\/[^>]|[^/>])*)(\/?>)/
  }, {
    '(<#PI>)':      'colorize-processing-instruction',
    '(<#COMMENT>)': 'colorize-comment',
    '(<#CDATA>)':   'colorize-cdata',
    '(<#ENTITY>)':  'colorize-entity',
    
    '<#TAG>': function(match, openTag, tagName, attributes, closeTag) {
      return openTag + '<span class="colorize-tag">' + tagName + '</span>' + attr.parse(attributes) + closeTag;
    }
  }, {
    ignoreCase: true,
    tabStop: 1
  });

  var attr = new RegGrp({
    CHAR:      CHAR,
    STRING1:   STRING1,
    STRING2:   STRING2,
    STRING:    /<#STRING1>|<#STRING2>/
  }, {
    '([<#CHAR>-]+)(?:(\\s*=\\s*)(<#STRING>))?': '<span class="colorize-attribute-name">$1</span>$2<span class="colorize-attribute-value">$3</span>'
  });

  // ------------------------------------------------------
  // HTML parser.
  // ------------------------------------------------------

  var html = xml.copy();

  html.dictionary.merge({
    DOCTYPE:     /<!doctype[^>]+>/,
    CONDITIONAL: /<!(--)?\[[^\]]*\]>|<!\[endif\](--)?>/, // conditional comments
    BLOCK:       /(<)(script|style)([^>]*)(>)([^<]*)<\/\2>/
  });

  // Parse a script or style block.
  html.insertAt(-1, "<#BLOCK>", parseBlock);

  html.merge({
    '(<#DOCTYPE>)':     'colorize-doctype',
    '(<#CONDITIONAL>)': 'colorize-conditional-comment'
  });

  function parseBlock(match, openTag, tagName, attributes, closeTag, cdata) {
    return openTag + '<span class="colorize-tag">' + tagName + '</span>' + attr.parse(attributes) + closeTag +
      cdata + openTag + '/<span class="colorize-tag">' + tagName + '</span>' + closeTag;
  };

  addScheme("html", html);

  // ------------------------------------------------------
  // HTML+CSS+JS parser.
  // ------------------------------------------------------

  addScheme("html_multi", html.union({
    '<#BLOCK>': function(match, openTag, tagName, attributes, closeTag, cdata) {
      var type = /style/i.test(tagName) ? "css" : "javascript";
      cdata = '<span class="colorize-' + type + ' colorize-block">' + colorize[type].parse(cdata, true) + '</span>';
      return parseBlock(match, openTag, tagName, attributes, closeTag, cdata);
    }
  }));
  
}); // end: closure
