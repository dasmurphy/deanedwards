
base2.exec(function(namespace) { // begin: closure

  eval(namespace); // import
  
  var IGNORE = RegGrp.IGNORE;
  
  var NUMBER   = /\b\-?(0|[1-9]\d*)(\.\d+)?([eE][-+]?\d+)?\b/;
  var STRING   = /"(\\.|[^"\\])*"/;
  
}); // end: closure
