
var Package = Base.extend({
  constructor: function(properties) {
    if (properties) {
      extend(this, properties);
      if (properties != base2 && !("parent" in properties)) {
        this.parent = base2;
      }
    }
    
    var packageID = this.name;
    if (packageID) {
      if (this.parent instanceof Package) {
        this.parent.addName(packageID, this);
        packageID = this.parent.toString().slice(1, -1) + "." + packageID;
      }
      this.toString = K("[" + packageID + "]");
      if (packageID != this.name) {
        this.namespace = "var " + this.name + "=" + packageID + ";";
      }
    } else {
      _Anonymous(this);
      packageID = this.toString().slice(1, -1);
    }
    
    var self = this;
    function addName(value, name) {
      if (!(name in self.exports)) {
        self.namespace += "var " + name + "=" + (self.name || packageID) + "." + name + ";";
      }
      self.exports[name] = self[name] = value;
      // Provide objects and classes with pretty toString methods
      if (value && value.ancestorOf) { // it's a class
        var classID = packageID + "." + name;
        if (value.namespace) {
          var anonID = value.toString().slice(1, -1);
          value.namespace = "var " + name + "=" + classID + ";" +
            value.namespace.replace(new RegExp(rescape(anonID), "g"), name);
        }
        value.toString = K("[" + classID + "]");
      }
      return value;
    };

    var exports = this.exports;
    this.exports = {};
    if (exports) forEach(exports, addName);
    this.addName = flip(addName);
  },

  exports: null,
  name: "",
  namespace: "",
  parent: null,
  version: "",

  addName: Undefined,

  applyTo: function(object) {
    forEach (this.exports, function(value, name) {
      object[name] = this[value];
    }, this);
  }
});
