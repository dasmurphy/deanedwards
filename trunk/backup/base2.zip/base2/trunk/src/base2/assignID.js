
function assignID(object, name) {
  // Assign a unique ID to an object.
  if (object == null) object = {};
  if (!name) name = object.nodeType === 1 ? "uniqueID" : "base2ID";
  if (!object[name]) object[name] = "b2_" + _private.inc++;
  return object[name];
};
