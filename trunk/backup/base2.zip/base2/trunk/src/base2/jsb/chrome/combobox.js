
var combobox = dropdown.extend({
  // properties
  role: "combobox",
  spellcheck: true,
  
  // methods

  get: function(element, propertyName) {
    if (propertyName == "list") {
      var id = this.getAttribute(element, "list");
      return id ? this.querySelector(document, "#" + id) : null;
    }
    return this.base(element, propertyName);
  },

  "@(input.list)": {
    isNativeControl: function(element) {
      return element.nodeName === "INPUT" && element.list;
    }
  },

  Popup: MenuList
});
