
var styleObject = document.createElement("span").style;

extend(jsb, "createStyleSheet", function(cssText) {
  if (typeof cssText != "string") {
    var rules = cssText;

    var styleSheet = {
      toString: function() {
        return reduce(this, function(rules, properties, selector) {
          rules.push(selector + properties);
          return rules;
        }, []).join("\n").replace(/!([^\w])/g, "!important$1");
      }
    };

    var baseRule;
    
    var createRule = function(properties, selector) {
      if (/,/.test(selector)) {
        forEach (dom.CSSSelectorParser.split(selector), partial(createRule, properties));
      } else {
        if (!baseRule) {
          baseRule = selector === "*" ? properties : {};
        }
        if (selector !== "*") {
          var rule = styleSheet[selector];
          if (!rule) {
            rule = styleSheet[selector] = extend({toString: function() {
              return " {\n" +
                reduce(this, function(propertyList, value, propertyName) {
                  if (typeof value == "function") value = "none";
                  propertyList.push("  " + propertyName.replace(/[A-Z]/g, function(capitalLetter) {
                    return "-" + capitalLetter.toLowerCase();
                  }) + ": " + value);
                  return propertyList;
                }, []).join(";\n") +
              "\n}";
            }}, baseRule);
          }
          forEach.detect (properties, function(value, propertyName) {
            var isFloat = propertyName === "float";
            if (!isFloat && !(propertyName in styleObject)) {
              propertyName = dom.CSSStyleDeclaration.getPropertyName(propertyName);
            }
            if (isFloat || propertyName in styleObject) {
              if (value === "initial") {
                forEach (rule, function(initialPropertyValue, initialPropertyName) {
                  if (initialPropertyName.indexOf(propertyName) === 0) {
                    delete rule[initialPropertyName];
                  }
                });
                delete rule[propertyName];
              } else {
                rule[propertyName] = value;
              }
            }
          });
        }
      }
    };
    
    forEach.detect (rules, createRule);

    cssText = styleSheet.toString();
  }

  // This shouldn't really be here.
  // JSB shouldn't really know about Chrome. Oh well.
  cssText = cssText.replace(/%theme%/g, "themes/" + jsb.theme);
  
  var URL = /(url\s*\(\s*['"]?)([\w\.]+[^:\)]*['"]?\))/gi;
  this.base(cssText.replace(URL, "$1" + getCurrentHost() + "$2"));
  
  return cssText;
});
