
var control = behavior.extend({
  // constants

  _CURSOR: "",
  _IMAGE_WIDTH: 17,

  states: {
    normal:   0,
    hover:    1,
    active:   2,
    disabled: 3,
    length:   4
  },
  
  // properties

  type: "text", // Web Forms 2.0 type
  appearance: "none",
  allowVertical: false,
  spellcheck: false,

  onattach: function(element) {
    if (this.isNativeControl != False && this.isNativeControl(element)) {
      this.detach(element, true);
    } else {
      _attachments[element.uniqueID] = this;
      
      if (this.allowVertical && element[_HEIGHT] > element[_WIDTH]) {
        this.setOrientation(element, "vertical");
      }
      
      // Prevent autocomplete popups.
      // It's OK to do this here.
      // This library provides UI support, automplete popups will conflict with
      // the provided UI.
      if (element.name && element.form) {
        // setting this attribute does not seem to cause a reflow
        element.setAttribute("autocomplete", "off");
      }
      
      this.layout(element, this.states[element.disabled ? "disabled" : "normal"]); // initial state
    }
  },

  "@MSIE[67]": { // -@DRE
    onattach: function(element) {
      // We cannot style based on attribute selectors, so we'll add a class
      if (this.appearance !== "none") {
        this.classList.add(element, "jsb-" + this.appearance);
      }
      this.base(element);
    }
  },

  onlosecapture: function(element) {
    delete control._active;
    delete control._dragging;
    delete control._activeThumb;
    this.setUnselectable(element, false);
    this.layout(element);
  },

  onmousedown: function(element, event, x, y) {
    control._active = element;

    if (!this.isEditable(element)) return;

    control._activeThumb = this.hitTest(element, x, y);
    if (control._activeThumb) {
      this.setCapture(element);
      control._dragging = true;
      this.setTimeout("setUnselectable", 1, element, true); // use onselectstart instead? -@DRE
    }
    this.layout(element);
  },

  onmouseup: function(element, event) {
    this.releaseCapture();
  },

  onmousemove: function(element, event, x, y) {
    var thumb = this.hitTest(element, x, y);
    if (thumb != control._hoverThumb) {
      control._hoverThumb = thumb;
      this.layout(element);
    }
    if (control._dragging) {
      event.preventDefault();
    }
  },

  onmouseover: function(element, event, x, y) {
    control._hover = element;
    control._hoverThumb = this.hitTest(element, x, y);
    this.layout(element);
  },

  onmouseout: function(element) {
    delete control._activeThumb;
    delete control._hoverThumb;
    delete control._hover;
    this.layout(element);
  },

  onfocus: function(element) {
    control._focus = element;
    this.layout(element);
    this.setAttributes(element);
  },

  onblur: function(element) {
    delete control._focus;
    this.classList.remove(element, this.appearance + _FOCUS);
    this.layout(element);
    this.hideToolTip();
  },

  onpropertyset: function(element, event, propertyName) {
    if (/^(disabled|readOnly)$/.test(propertyName)) {
      this.layout(element);
    }
  },
  
  // methods

  getCursor: function(element) {
    return (control._activeThumb || control._hoverThumb || element != control._hover || control._dragging) ? "default" : this._CURSOR;
  },

  getState: K(0),

  getValue: function(element) {
    return element.value;
  },

  setValue: function(element, value) {
    if (value != element.value) {
      element.value = value;
      this.fire(element, "change");
      this.layout(element);
    }
  },

  hitTest: function(element, x) {
    return x >= element[_WIDTH] - this._IMAGE_WIDTH;
  },

  isActive: function(element) {
    return control._activeThumb && (control._activeThumb == control._hoverThumb);
  },

  isEditable: function(element) {
    return (!element.disabled && !element.readOnly) || element == control._readOnlyTemp;
  },

  isNativeControl: function(element) {
    return element.nodeName === "INPUT" && element.type === this.type;
  },

  layout: function(element, state) {
    if (state == null) {
      state = this.getState(element);
      this.syncCursor(element);
    }
    
    var clientHeight = element[_HEIGHT],
        top = - this.states.length * (clientHeight / 2 * (clientHeight - 1)),
        style = element.style;
        
    top -= clientHeight * state;

    var backgroundPosition = "100% " + top + PX;
    if (style.backgroundPosition !== backgroundPosition) {
      style.backgroundPosition = backgroundPosition;
    }
  },

  setAttributes: function(element) {
    if (!this.spellcheck) {
      element.setAttribute("spellcheck", "false");
    }
    if (this.role) {
      element.setAttribute("role", this.role);
    }
  },

  setOrientation: function(element, orientation) {
    if (orientation == "vertical") {
      var backgroundImage = this.style.compute(element, "backgroundImage");
      this.style.set(element, "backgroundImage", backgroundImage.replace(/\.png/i, "-vertical.png"), true);
    } else if (element.style.backgroundImage) {
      element.style.backgroundImage = "";
    }
    //this.setUserData(element, "orientation", orientation, null);
  },

  setUnselectable: Undefined,

  "@!KHTML": { // This seems to make things worse on Webkit-based browsers.
    setUnselectable: function(element, unselectable) {
      this.style.set(element, "userSelect", unselectable ? "none" : "");
    }
  },

  "@MSIE": { // can't detect the "unselectable" property
    setUnselectable: function(element, unselectable) {
      if (unselectable) {
        element.unselectable = "on";
      } else {
        element.removeAttribute("unselectable");
      }
    }
  },

  hideToolTip: function() {
    if (control.tooltip) {
      control.tooltip.hide();
    }
  },

  showToolTip: function(element, text, duration) {
    var tooltip = control.tooltip;
    if (!tooltip) {
      tooltip = control.tooltip = new ToolTip;
    }
    setTimeout(function() {
      tooltip.show(element, text, duration);
    }, 1);
  },

  syncCursor: function(element) {
    element.style.cursor = this.getCursor(element);
  },

  hasTimer: function(element, id) {
    id = element.uniqueID + (id || _TIMER);
    return !!_timers[id];
  },

  startTimer: function(element, id, interval) {
    id = element.uniqueID + (id || _TIMER);
    if (!_timers[id]) {
      _timers[id] = this.setInterval(this.tick, 100, element);
    }
  },

  stopTimer: function(element, id) {
    id = element.uniqueID + (id || _TIMER);
    if (_timers[id]) {
      clearInterval(_timers[id]);
      delete _timers[id];
    }
  },

  tick: Undefined,

  "@Opera": {
    syncCursor: Undefined
  }
});
