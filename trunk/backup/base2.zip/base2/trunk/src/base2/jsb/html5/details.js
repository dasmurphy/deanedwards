
var DETAILS_OPEN    = (new Image).src = IMAGES_URL + "arrow-up.png",
    DETAILS_CLOSED  = (new Image).src = IMAGES_URL + "arrow-down.png";
    
registerElement("details", {
  detect: "open",

  display: "block",
  
  style: {
    paddingLeft:            "40px",
    backgroundPosition:     "22px 2px!",
    backgroundAttachment:   "scroll!",
    backgroundRepeat:       "no-repeat!",
    backgroundImage:        "url(images/arrow-up.png)"
  },

  extraStyles: {
    // The real display is handled by the layout() method.
    // This speeds things up a little for CSS3 compliant browsers.
    
    "details[open]": {
      backgroundImage:      "url(images/arrow-down.png)"
    },

    "details:not([open]) > :not(summary)": {
      display:              "none!"
    }
  },

  behavior: {
    open: false,

    oncontentready: function(element) {
      // Create a summary if the <summary> element is missing.
      var summary = this.querySelector(element, "*>summary:first-of-type");
      if (!summary) {
        summary = document.createElement("summary");
        summary.innerHTML = "Details";
        element.insertBefore(summary, element.firstChild);
      }
      this.layout(element);
    },

    onpropertyset: function(element, event, propertyName) {
      // If the "open" property is set then redraw.
      if (propertyName == "open") this.layout(element);
    },

    onclick: function(element, event, x, y) {
      // Toggle open state if the up/down-arrow is clicked.
      if (x >= 20 && x <= 40 && y <= 20) {
        this.toggle(element);
        event.preventDefault();
      }
    },

    layout: function(element, state) {
      var open = this.get(element, "open"),
          content = this.querySelectorAll(element, "*>:not(summary)");
      this.style.set(element, "backgroundImage", "url(" + (open ? DETAILS_OPEN : DETAILS_CLOSED) + ")", true); // !important
      return; // -@DRE
      if (content) {
        content.style.display = open ? "block" : "none";
      }
    },

    toggle: function(element) {
      this.set(element, "open", !this.get(element, "open"));
    }
  }
});
