
var moveup = move.extend({
  RELATIVE_NODE:  "previousSibling",
  DIRECTION:      -1
});
