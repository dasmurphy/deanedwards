
registerElement("datalist", {
  options: null,
  
  get: function(element, propertyName) {
    return propertyName == "options"
      ? element.getElementsByTagName("option")
      : this.base(element, propertyName);
  }
});
