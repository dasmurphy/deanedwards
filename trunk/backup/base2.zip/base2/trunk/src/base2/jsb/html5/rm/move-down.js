
var movedown = move.extend({
  RELATIVE_NODE:  "nextSibling",
  DIRECTION:      1
});
