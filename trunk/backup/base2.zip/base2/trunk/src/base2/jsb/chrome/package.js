
// Browser chrome.

// Credits: some code written by Erik Arvidsson.

global.chrome = new Package({
  name:    "chrome",
  version: "0.9.2",
  parent:  base2.jsb,
  
  exports: {
    combobox: combobox,
    progressbar: progressbar,
    slider: slider,
    spinner: spinner,
    colorpicker: colorpicker,
    datepicker: datepicker,
    weekpicker: weekpicker,
    monthpicker: monthpicker,
    timepicker: timepicker,
    // these are for extensibility
    dropdown: dropdown,
    Popup: Popup,
    PopupWindow: PopupWindow,
    MenuList: MenuList,
    ToolTip: ToolTip
  },
  
  locale: new Locale(navigator.language || navigator.systemLanguage),
  
  getBehavior: function(element) {
    return _attachments[element.uniqueID] || null;
  }
});
