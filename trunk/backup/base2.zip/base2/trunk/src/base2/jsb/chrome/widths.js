
jsb.theme.cssText = jsb.createStyleSheet({
  "*": {
    "@!theme=classic": {
      padding:                 "2px"
    },

    "@theme=aqua": {
      padding:                 "1px 2px 2px 2px"
    }
  },

  ".jsb-spinner,.jsb-timepicker,.jsb-monthpicker": {
    width:              "5em",

    "@!theme=aqua": {
      paddingRight:     "19px!"
    },

    "@!(style.borderImage)": {
      paddingRight:     "19px!"
    }
  },

  ".jsb-timepicker,.jsb-monthpicker": {
    width:              "8ex",

    "@QuirksMode": {
      width:            "6em"
    }
  },

  ".jsb-timepicker": {
    "@theme=aqua": {
      width:              "5em"
    }
  },

  ".jsb-dropdown,.jsb-combobox,.jsb-colorpicker,.jsb-datepicker,.jsb-weekpicker": {
    
    "@theme=aqua": {
      "@(style.borderImage)": {
        borderWidth:          "1px 18px 1px 4px!",
        padding:              "1px"
      },

      "@!(style.borderImage)": {
        padding:              "1px 22px 1px 4px!"
      }
    },

    "@!theme=aqua": {
      paddingRight:           "19px!"
    }
  },

  ".jsb-colorpicker,.jsb-datepicker,.jsb-weekpicker": {
    width:                    "8em"
  },

  ".jsb-slider": {
    height:               "21px",
    minHeight:            "21px",
    padding:              0,
    border:               "none"
  },

  ".jsb-colorpicker": {
    width:         "4em",

    "@QuirksMode": {
      width:       "6em"
    }
  },

  ".jsb-datepicker": {
    width:         "6em",

    "@QuirksMode": {
      width:       "8em"
    }
  },

  ".jsb-weekpicker": {
    width:         "6em",

    "@QuirksMode": {
      width:       "7em"
    }
  },

  "@theme=aqua": {
    ".jsb-spinner,.jsb-timepicker,.jsb-monthpicker": {
      borderTopWidth:                  "1px",
      paddingTop:                      "2px"
    },

    "@(style.borderImage)": {
      ".jsb-spinner,.jsb-timepicker,.jsb-monthpicker": {
        paddingRight:           "19px!"
      }
    },
    
    ".jsb-datepicker": {
      width:         "7em"
    },

    ".jsb-weekpicker": {
      width:         "6em"
    },

    ".jsb-monthpicker": {
      width:         "5em"
    }
  }
});
