
var PopupWindow = Popup.extend({
  constructor: function(owner) {
    this.base();
    this.owner = owner;
    this.body.id = "jsb-popup-window";
  },
  
  // properties

  controls: null,
  owner: null,
  scrollX: true,
  scrollY: true,
  role: "application",
  
  // events

  onkeydown: function(event) {
    switch (event.keyCode) {
      case 13: // enter
      case 27: // escape
        this.hide();
        this.element.focus();
        event.preventDefault();
        break;
        
      case 9: // tab
        if (this.tab(event.shiftKey ? -1 : 1)) {
          event.preventDefault();
        }
        break;
    }
  },
  
  // methods

  focus: function() {
    this.controls[0].focus();
  },

  getTabStops: function() {
    return this.controls;
  },

  hide: function() {
    PopupWindow.current = null;
    forEach (this.controls, function(control) {
      if (control.blur) control.blur();
    });
    this.base();
    classList.remove(document.body, "jsb-showingpopup");
    this.element.removeAttribute("aria-expanded");
    this.element.removeAttribute("aria-owns");
  },

  isActive: function() {
    return matchesSelector(this.body, ":hover") || matchesSelector(this.body, ":focus");
  },

  render: function(html) {
    this.base(html);
    this.controls = this.querySelectorAll("button,input,select,textarea");
  },

  show: function(element) {
    classList.add(document.body, "jsb-showingpopup");
    this.base(element);
    PopupWindow.current = this;
    element.setAttribute("aria-owns", "jsb-popup-window");
    element.setAttribute("aria-expanded", true);
  },

  tab: function(direction) {
    var controls = this.getTabStops(),
        firstControl = controls[0],
        lastControl = controls[controls.length - 1],
        current = this.querySelector(":focus");
        
    if (!current) return false;

    if (direction === 1) {
      if (current == lastControl) {
        var nextControl = firstControl;
      }
    } else {
      if (current == firstControl) {
        nextControl = lastControl;
      }
    }
    
    if (nextControl) {
      nextControl.focus();
      if (nextControl.select) nextControl.select();
      return true;
    }

    return false;
  }
}, {
  current: null,
  
  init: function() {
    var mousedown = true;
    addEventListener(window, "blur", hidePopup, true);
    addEventListener(document, "mousedown", hidePopup, true);
    addEventListener(document, "mouseup", function() {
      mousedown = false;
    }, true);
    function hidePopup(event) {
      var popup = PopupWindow.current,
          target = event.target;
          
      if (event.type === "blur" && mousedown) return;
      mousedown = event.type === "mousedown";
      
      if (popup && target != document && target != popup.element && target != shim.control && target != popup.body && !Traversal.contains(popup.body, target)) {
        popup.hide();
      }
    };
  }
});
