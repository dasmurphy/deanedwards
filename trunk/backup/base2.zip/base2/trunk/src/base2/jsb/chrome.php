<?php

header("Location: /base2/trunk/src/build.php?package=base2/jsb/chrome/package.xml&full");

?>
