
var CANVAS_JS = "canvas.js";
;;; CANVAS_JS = "canvas.php";

/*var _hasSilverlight = false;
try {
  new ActiveXObject('AgControl.AgControl');
  _hasSilverlight = true;
} catch (ex) {}*/

registerElement("canvas", {
  detect: "getContext",

  display: "block",

  // if <canvas> is not implemented then we can at least support it for MSIE
  //behavior: detect("MSIE") ? _CANVAS_JS + "#html5.canvas_" + (_hasSilverlight ? "silverlight" : "vml") : null,
  behavior: detect("MSIE") ? CANVAS_JS + "#html5.canvas" : null,
  
  methods: "getContext"
});
