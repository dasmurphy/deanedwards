
eval(namespace); // import

var document = global.document;

var SUPPORTS_BORDER_BOX  = detect("QuirksMode") || (7 !== document.documentMode && detect("(style.boxSizing)"));
    
var HOST          = jsb.host,
    IMAGES_URL    = HOST + "images/";

var styleSheet = {
  "[hidden],[repeat=template],datalist,menu[type=context]": {
    display: "none",
    visibility: "collapse"
  }
};

var rules = {};
