
jsb.createStyleSheet({
  "[repeat=template],.jsb-template": {
    display: "none!"
  }
});
