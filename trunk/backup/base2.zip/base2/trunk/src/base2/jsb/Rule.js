
// A CSS selector associated with a behavior.

var Rule = Base.extend({
  constructor: function(selector, behavior) {
    if (typeof behavior == "string") { // external resource
      var resource = behavior;
      behavior = {
        attach: function(element) {
          base2.require(resource, function(namespace, behavior) {
            if (behavior && behavior.attach) behavior.attach(element);
          });
        }
      };
    } else if (behavior instanceof Modification) {
      behavior._registerModification(selector);
    } else if (!jsb.behavior.ancestorOf(behavior)) {
      behavior = jsb.behavior.extend(behavior);
    }

    this.toString = K(selector);

    this.refresh = function() {
      if (typeof behavior.attach == "function") {
        querySelectorAll(document, selector).forEach(behavior.attach);
      }
    };

    // Split comma separated selectors.
    var selectors = dom.CSSSelectorParser.split(selector);
    
    forEach (selectors, function(selector) {
      engine.addRule(selector, behavior);
    });
  },
  
  // defined in the constructor function
  refresh: Undefined
});
