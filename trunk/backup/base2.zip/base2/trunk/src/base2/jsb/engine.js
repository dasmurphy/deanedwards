
var parser = new dom.CSSSelectorParser({
  "^((?:<#selector>)?(?:<#combinator>))(<#tag>)(<#filter>)?$": true
});

var all = document.getElementsByTagName("*");

var contentReadyQueue  = [],
    documentReadyQueue = [];

var engine = {
  busy: false,
  timestamp: now(),
  loaded: _private.isReady,
  ready: false,

  onblur: function() {
    engine._lastFocusElement = engine._focusElement;
    engine._focusElement = null;
  },

  onfocus: function(event) {
    engine._focusElement = event.target;
  },

  onmousedown: function(event) {
    engine.busy = true;
  },

  onmouseup: function() {
    engine.busy = false;
  },

  addRule: function(selector, behavior) {
    var parsed = parser.exec(" " + dom.CSSSelectorParser.escape(selector)),
        tagName = parsed[2];
    parsed[2] = "*";
    selector = dom.CSSSelectorParser.unescape(parsed.slice(1).join("").slice(1));
    matchesSelector(document.documentElement, selector); // validate the selector
    var rule = {
      tagName: tagName,
      selector: selector,
      behavior: behavior
    };
    if (!rulesByTagName[tagName]) {
      rulesByTagName[tagName] = rulesByTagName[tagName.toUpperCase()] = [];
    }
    rulesByTagName[tagName].push(rule);
    ;;; rule.toString = selector.toString;
    if (!engine.started) {
      engine.started = true;
      engine.tick(0); // start the timer
    }
  },

  fireReady: function() {
    if (!engine.ready) {
      engine.ready = true;
      Array2.batch(documentReadyQueue, function(item) {
        dispatchJSBEvent(item.behavior, item.element, "documentready");
      }, jsb.TIMEOUT, engine.parseComplete);
      documentReadyQueue = [];
    }
  },

  parseComplete: function() {
    engine.tick(0);
  },

  tick: function(i) {
    var start = now();
    
    if (!engine.busy && engine.timestamp - start <= jsb.INTERVAL) {
      engine.timestamp = start;
      
      // Process the contentready queue.
      
      while (contentReadyQueue.length) {
        var item = contentReadyQueue.shift();
        if (isContentReady(item.element)) {
          dispatchJSBEvent(item.behavior, item.element, "contentready");
        } else {
          contentReadyQueue.push(item); // add it to the end
        }
        if (new Date - start > jsb.TIMEOUT) break;
      }

      // Process the contentready queue.
      var wildCards = rulesByTagName["*"], rule, element;
          
      while ((element = all[i++])) {
        /*@if (@_jscript)
        if (element.nodeType !== 1) continue;
        /*@end @*/
        var tagName = element.nodeName,
            byTagName = rulesByTagName[tagName];
        if (byTagName) for (var j = 0; rule = byTagName[j]; j++) {
          if (matchesSelector(element, rule.selector)) {
            rule.behavior.attach(element);
          }
        }
        if (wildCards) for (var j = 0; rule = wildCards[j]; j++) {
          if (matchesSelector(element, rule.selector)) {
            rule.behavior.attach(element);
          }
        }
        if (new Date - start > jsb.TIMEOUT) break;
      }
    }
    if (!engine.loaded || all[i]) {
      var callback = function(){engine.tick(i)};
    } else {
      if (engine.ready) {
        callback = engine.parseComplete;
      } else {
        callback = engine.fireReady;
      }
    }
    setTimeout(callback, engine.busy ? jsb.INTERVAL * 10 : jsb.INTERVAL);
  }
};

for (var i in engine) if (EVENT.test(i)) {
  addEventListener(document, i.slice(2), engine[i], true);
}

base2.ready(function() {
  engine.loaded = true;
});
