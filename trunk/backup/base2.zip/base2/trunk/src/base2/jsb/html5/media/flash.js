
// Uses JW Player: http://www.longtailvideo.com/players/jw-flv-player/

// http://developer.longtailvideo.com/trac/wiki/FlashVars
var ENCODER = new RegGrp({
  "\\?":   "%3F",
    "=":   "%3D",
    "&":   "%26"
});

var FLASH_VARS = jsb.host +
  "player.swf?autostart={AUTOPLAY}&amp;repeat={LOOP}&amp;volume={VOLUME}&amp;mute={MUTED}&amp;image={POSTER}&amp;file={SRC}";

var FLASH_PLAYER = '\
<object width="{WIDTH}" height="{HEIGHT+20}" type="application/x-shockwave-flash" data="{VARS}">\
<param name="movie" value="{VARS}">\
</object>';

var FLASH_INSTALLER = format('\
<object id="html5-flash-installer" type="application/x-shockwave-flash" data="%1" width="{WIDTH}" height="{HEIGHT}">\
<param name="movie" value="%1">\
</object>',
  format("%1expressInstall.swf?MMredirectURL=%2&amp;MMplayerType=%3&amp;MMdoctitle=%4",
    jsb.host, ENCODER.parse(location.href), detect("(jscript)") ? "ActiveX" : "PlugIn", ENCODER.parse(document.title)));
      
var FLASH_VERSION = 0;
/*@if (@_jscript)
try {
  FLASH_VERSION = new ActiveXObject("ShockwaveFlash.ShockwaveFlash").GetVariable("$version").match(/\d+/)[0] - 0;
} catch (ex) {
  for (var i = 9; i > 5; i--) {
    try {
      new ActiveXObject("ShockwaveFlash.ShockwaveFlash." + i);
      FLASH_VERSION = i;
      break;
    } catch (ex){}
  }
}
@else @*/
try {
  FLASH_VERSION = navigator.mimeTypes["application/x-shockwave-flash"].enabledPlugin.description.match(/\d+/)[0] - 0;
} catch (ex){}
/*@end @*/
