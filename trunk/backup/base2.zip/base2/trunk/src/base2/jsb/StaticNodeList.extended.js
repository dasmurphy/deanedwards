
var StaticNodeList = dom.StaticNodeList;

StaticNodeList.implement({
  forEach: function(eacher, context) {
    var length = this.length;
    for (var i = 0; i < length; i++) {
      eacher.call(context, this[i], i, this);
    }
  },

  indexOf: function(element) {
    return Array2.indexOf(this, element);
  },

  item: function(index) {
    return Array2.item(this, index);
  },

  not: function(test, context) {
    return this.filter(not(test), context);
  },

  slice: function(start, end) {
    return new StaticNodeList(Array2.slice(this, start, end));
  }
});

StaticNodeList.implement(Enumerable);

StaticNodeList.implement({
  every: StaticNodeList_matchesSelector,
  filter: StaticNodeList_matchesSelector,
  not: StaticNodeList_matchesSelector,
  some: StaticNodeList_matchesSelector
});

StaticNodeList.implement({
  filter: function(test, context) {
    return new StaticNodeList(this.base(test, context));
  }
});

StaticNodeList.extended = true;

function StaticNodeList_matchesSelector(test, context) {
  if (typeof test != "function") {
    var selector = test;
    test = function(element) {
      return matchesSelector(element, selector);
    };
  }
  return this.base(test, context);
};
