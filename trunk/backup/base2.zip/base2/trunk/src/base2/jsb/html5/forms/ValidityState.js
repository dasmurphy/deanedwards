
var ValidityState = Base.extend({
});
