
var HTMLFormElement = HTMLElement.extend({
  checkValidity: function(form) {
    var isValid = true,
        elements = form.elements,
        element;
    for (var i = 0; element = form.elements[i]; i++) {
      var behavior = html5.getBehavior(element);
      if (behavior.get(element, "willValidate")) {
        isValid &= behavior.checkValidity(element);
      }
    }
    return !!isValid;
  },

  dispatchFormChange: function(form) {
    behavior.fire(form, "formchange");
  },

  dispatchFormInput: function(form) {
    behavior.fire(form, "forminput");
  }
}, {
  tags: "FORM"
});
