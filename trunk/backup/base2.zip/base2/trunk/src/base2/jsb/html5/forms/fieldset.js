
registerElement("fieldset", {
  "implements": [noValidation],

  get: function(element, propertyName) {
    switch (propertyName) {
      case "type":
        return "fieldset";

      case "elements":
        return this.querySelectorAll(element, "button,fieldset,input,output,select,textarea");
    }
    return this.base(element, propertyName);
  }
});
