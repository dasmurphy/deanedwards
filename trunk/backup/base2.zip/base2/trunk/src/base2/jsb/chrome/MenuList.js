
var MenuList = PopupWindow.extend({
  constructor: function(owner) {
    this.base(owner);
    this.data = {};
  },

  // properties

  appearance: "menulist",
  role: "menu",

  // events

  onmouseup: function(event) {
    this.select(this.currentItem);
  },

  onkeydown: function(event) {
    switch (event.keyCode) {
      case 9: // tab
        this.hide();
        this.element.focus();
        return;
      case 13: // return
        event.preventDefault();
        this.select(this.currentItem);
        break;
      case 38: // up
        if (this.currentItem) {
          this.highlight(Traversal.getPreviousElementSibling(this.currentItem), true);
        } else {
          this.highlight(Traversal.getFirstElementChild(this.body), true);
        }
        break;
      case 40: // down
        if (this.currentItem) {
          this.highlight(Traversal.getNextElementSibling(this.currentItem), true);
        } else {
          this.highlight(Traversal.getFirstElementChild(this.body), true);
        }
        break;
      case 36: // home
        this.highlight(Traversal.getFirstElementChild(this.body), true);
        break;
      case 35: // end
        this.highlight(Traversal.getLastElementChild(this.body), true);
        break;
      default:
        this.base(event);
        return;
    }
    event.preventDefault();
  },

  onmouseover: function(event) {
    this.highlight(event.target);
  },

  // methods

  focus: function() {
    var item = this.currentItem;
    if (item && item.focus) item.focus();
  },

  getUnitHeight: function() {
    var item = Traversal.getFirstElementChild(this.body);
    return item ? item.offsetHeight : 1;
  },

  highlight: function(item, focus) {
    if (item) {
      this.reset(this.currentItem);
      this.currentItem = item;
      classList.add(item, "jsb-selected");
      item.tabIndex = 0;
      item.setAttribute("aria-selected", true);
      if (focus && item.focus) item.focus();
    }
  },

  reset: function(item) {
    if (item) {
      classList.remove(item, "jsb-selected");
      item.removeAttribute("aria-selected");
      item.tabIndex = -1;
    }
  },

  layout: function() {
    this.currentItem = null;
    var data = this.data[this.element.uniqueID];
    var element = data
      ? this.body.childNodes[data.index]
      : Traversal.getFirstElementChild(this.body);
    this.highlight(element, true);
  },

  render: function() {
    var list = this.owner.get(this.element, "list"),
        html = "";
    if (list) {
      var attributes = 'role="menuitem" unselectable="on" tabindex="-1"';
      if (list.nodeType === 1) {
        if (list.nodeName !== "SELECT") {
          list = querySelector(list, "select");
        }
        if (list) {
          var options = list.innerHTML.split(/<\/option>/i).join("");
          html = trim(options).replace(/<option/gi, '</div><div ' + attributes).slice(6) + '</div>';
        }
      } else {
        if (isArray(list)) {
          html = wrap(list, "div", attributes);
        } else {
          html = reduce(list, function(html, text, value) {
            return html += '<div ' + attributes + ' value="' + value + '">' + text + '</div>';
          });
        }
      }
    }
    this.base(html);
  },

  getNodeIndex: function(node) {
    var index = 0;
    while (node && (node = node.previousSibling)) index++;
    return index;
  },

  select: function(item) {
    var value = item.getAttribute("value") || trim(item[TEXT_CONTENT]),
        element = this.element;

    this.data[element.uniqueID] = {
      index: this.getNodeIndex(item),
      value: value
    };
    this.owner.setValue(element, value);
    this.hide();
    element.focus();
    element.select();
  }
});
