
var eventDispatcher = {
  dispatch: function(behavior, element, event, isPseudoEvent) {
    var type = event.type;
    var listener = behavior["on" + type];
    if (!listener || listener == Undefined) return;

    var args = [element, event];

    // Build the event signature.
    if (EVENT_MOUSE.test(type)) {
      if (type === "mousewheel") {
        args.push(event.wheelDelta);
      } else {
        if (EVENT_BUTTON.test(type)) {
          if (behavior.jsbExtendedMouse) {
            args.push(event.button);
          } else {
            if (!MOUSE_BUTTON_LEFT.test(event.button || 0)) return;
          }
        }
        if (element == event.target) {
          var x = event.offsetX,
              y = event.offsetY;
        } else {
          var offset = dom.ElementView.getOffsetXY(element, event.clientX, event.clientY);
          x = offset.x;
          y = offset.y;
        }
        args.push(x, y, event.screenX, event.screenY);
      }
    } else if (EVENT_TEXT.test(type)) {
      args.push(event.keyCode, event.shiftKey, event.ctrlKey, event.altKey, event.metaKey);
    } else if (type === "propertychange" || type === "propertyset" || type === "transitionend") {
      args.push(event.propertyName);
      if (type === "propertyset") args.push(event.newValue);
    }

    // Trigger the underlying event.
    // Use the host's event dispatch mechanism so that we get a real
    // execution context.
    if (behavior.jsbUseDispatch && (isPseudoEvent || event.bubbles || event.eventPhase === CAPTURING_PHASE)) {
      callOutOfContext(function() {
        listener.apply(behavior, args);
      });
    } else {
      listener.apply(behavior, args);
    }
  }
};

var jsbPseudoEvent = createEvent(document, "Events");
jsbPseudoEvent.initEvent("dummy", false, false);
jsbPseudoEvent = dom.DocumentEvent.cloneEvent(jsbPseudoEvent);

function dispatchJSBEvent(behavior, element, type) {
  jsbPseudoEvent.target = element;
  jsbPseudoEvent.type = type;
  eventDispatcher.dispatch(behavior, element, jsbPseudoEvent, true);
};
