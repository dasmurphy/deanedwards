
var eventDelegator = {
  types: {},

  addEventListener: function(type, attachments) {
    var types = this.types;
    if (!types[type]) {
      types[type] = [];
      addEventListener(document, type, this, EVENT_USE_CAPTURE.test(type));
    }
    types[type].push(attachments);
  },

  handleEvent: function(event) {
    var target = event.target;
    
    if (target.nodeType !== 1) return;
    
    var type = event.type,
        isMouseEvent = EVENT_MOUSE.test(type),
        capture = isMouseEvent && captureElement;
        
    // Don't process mouseover/out when using mouse capture.
    if (capture && EVENT_OVER_OUT.test(type)) return;

    var map = this.types[type];
    if (!map || !map.length) return;

    // Fix offsetX/Y.
    if (isMouseEvent && type !== "mousewheel") {
      if (event.offsetX != null) {
        event = dom.DocumentEvent.cloneEvent(event);
      }
      var offset = dom.ElementView.getOffsetXY(target, event.clientX, event.clientY);
      event.offsetX = offset.x;
      event.offsetY = offset.y;
    }
    
    var cancelBubble = capture || !event.bubbles,
        element = capture ? captureElement : target;

    if (!cancelBubble) {
      extend(event, "stopPropagation", function() {
        this.base();
        cancelBubble = true;
      });
    }
    
    // Dispatch events.
    do {
      var uniqueID = element.uniqueID;
      if (allAttachments[uniqueID]) {
        for (var i = 0, attachments; attachments = map[i]; i++) {
          // make sure it's an attached element
          if (attachments[uniqueID]) {
            eventDispatcher.dispatch(attachments.behavior, element, event);
          }
        }
      }
      element = element.parentNode;
    } while (element && !cancelBubble);
  }
};
