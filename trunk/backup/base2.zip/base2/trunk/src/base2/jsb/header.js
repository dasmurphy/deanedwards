
eval(namespace); // import

/*@cc_on @*/

var _private = $$base2;

var document = global.document;

var EVENT              = /^on([a-z]{3,}|DOM[A-Z]\w+)$/,
    EVENT_BUTTON       = /^mouse(up|down)|click$/,
    EVENT_CLICK        = /click$/,
    EVENT_MOUSE        = /^mouse|click$/,
    EVENT_OVER_OUT     = /^mouse(enter|leave|over|out)$/,
    EVENT_PSEUDO       = /^(attach|detach|(content|document)ready)$/,
    EVENT_TEXT         = /^(key|text)/,
    EVENT_USE_CAPTURE  = /^(focus|blur)$/;

var CAPTURING_PHASE    = 1;

var CANNOT_DELEGATE    = /^(abort|error|load|scroll|DOMAttrModified|mouse(enter|leave)|(readystate|property|filter)change)$/;

var MOUSE_BUTTON_LEFT  = /^[^12]$/;

var SPECIFICITY_ID     = /#/g,
    SPECIFICITY_CLASS  = /[.:\[]/g,
    SPECIFICITY_TAG    = /^[^*]|[\s>+~][^*=]/g;

var allAttachments     = {};
var rulesByTagName     = {};

var captureElement = null;
var dummyDIV = document.createElement("div");

var elementTraversal = {
  childElementCount: function(element) {
    var count = 0;
    element = element.firstChild;
    while (element) {
      if (element.nodeType === 1) count++;
      element = element.nextSibling;
    }
    return count;
  },

  firstElementChild: Traversal.getFirstElementChild,
  lastElementChild: Traversal.getLastElementChild,
  nextElementSibling: Traversal.getNextElementSibling,
  previousElementSibling: Traversal.getPreviousElementSibling
};

function setCapture(element) {
  if (element != captureElement) releaseCapture();
  if (!captureElement) {
    captureElement = element;
  }
};

function releaseCapture() {
  var element = captureElement;
  if (element) {
    captureElement = null;
    this.fire(element, "losecapture");
    if (!matchesSelector(element, ":hover")) {
      fire(element, "mouseout");
    }
  }
};

function fire(node, type, data) {
  var event = createEvent(document, "Events");
  var bubbles = true;
  var cancelable = false;
  if (data) {
    if ("bubbles" in data) {
      bubbles = !!data.bubbles;
      delete data.bubbles;
    }
    if ("cancelable" in data) {
      cancelable = !!data.cancelable;
      delete data.cancelable;
    }
  }
  event.initEvent(type, bubbles, cancelable);
  if (data) extend(event, data);
  return dispatchEvent(node, event);
};

function Modification(behavior, attributes, modifications) {
  extend(this, attributes);
  this.attach = behavior.attach;
  this._registerModification = function(selector) {
    this._selector = selector;
    this._specificity = getSpecificity(selector);
    modifications.push(this);
    modifications.sort(function(selector1, selector2) {
      return selector2._specificity - selector1._specificity;
    });
  };
};

function getSpecificity(selector) {
  selector = dom.CSSSelectorParser.escape(selector);
  return match(selector, SPECIFICITY_ID).length * 10000 +
    match(selector, SPECIFICITY_CLASS).length * 100 +
    match(selector, SPECIFICITY_TAG).length;
};

function getCurrentHost() {
  var host = location.pathname,
      script = Array2.item(querySelectorAll(document, "script"), -1);

  if (script) host = script.src || host;
  ;;; host = host.replace(/build\.php\?package=([\w\/]+)package\.xml.*$/, "$1");
  return host.replace(/[\?#].*$/, "").replace(/[^\/]*$/, "");
};

function isContentReady(element) {
  if (engine.loaded) return true;
  if (element.nodeName === "HTML" || element.nodeName === "BODY") return false;
  while (element && !element.nextSibling) {
    element = element.parentNode;
  }
  return !!element;
};
