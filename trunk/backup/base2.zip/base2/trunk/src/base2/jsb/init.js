
// release capture

addEventListener(window, "blur", function(event) {
  var element = captureElement;
  if (element && document.body == engine._lastFocusElement) {
    behavior.releaseCapture();
    if (behavior.matchesSelector(element, ":hover")) {
      behavior.fire(element, "mouseout");
    }
  }
}, false);

classList.add(document.documentElement, "jsb-enabled");
