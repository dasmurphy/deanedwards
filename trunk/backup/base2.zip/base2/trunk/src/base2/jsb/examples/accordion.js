
var accordion = jsb.behavior.extend({
  pane: ".pane",
  defaultPane: 0,
  min: 0,
  max: 200,
  sticky: false,
  duration: 0.5,
  timing: "ease-out",
  event: "mouseenter",
  
  properties: {
    horizontal: {
      size: "width",
      offset: "offsetWidth"
    },
    
    vertical: {
      size: "height",
      offset: "offsetHeight"
    }
  },

  oncontentready: function(element) {
    var panes = this.getPanes(element);
    if (panes.length) {
      var orientation = this.classList.contains(element, "horizontal") ? "horizontal" : "vertical";
      var properties = this.properties[orientation];

      if (orientation === "horizontal") {
        var nextElement = base2.dom.Traversal.getNextElementSibling(element);
        if (nextElement) nextElement.style.clear = "left";
        var lastPane = Array2.item(panes, -1);
        this.style.set(element, {
          width:  lastPane.offsetLeft + lastPane.offsetWidth - panes[0].offsetLeft,
          height: lastPane.offsetHeight,
          overflow: "hidden"
        });
      }
      var data = {
        properties: properties,
        size: panes[0][properties.offset]
      };
      this.setUserData(element, "accordion", data, null);
      var eventType = this.get(element, "event"),
          max = this.get(element, "max"),
          min = this.get(element, "min");
      panes.forEach(function(pane) {
        this.addEventListener(pane, eventType, base2.lang.bind(function() {
          this.animatePanes(element, pane, max, min);
        }, this), false);
      }, this);
      
      if (this.get(element, "sticky")) {
        this.animatePanes(element, panes[this.get(element, "defaultPane")], max, min, 0.01);
      }
    }
  },

  getPanes: function(element) {
    return this.querySelectorAll(element, this.pane);
  },

  animatePanes: function(element, currentPane, max, min, duration) {
    if (!currentPane) return;

    if (duration == null) {
      duration = this.get(element, "duration");
    }
    
    var panes = this.getPanes(element),
        count = panes.length,
        data = this.getUserData(element, "accordion"),
        properties = data.properties,
        totalSize = data.size * count;

    data.current = currentPane;
    panes = panes.filter(function(pane) {
      return pane != currentPane;
    });
    count--;

    var sizes = panes.pluck(properties.offset);

    var collapsedSize = min || Math.round((totalSize - max) / count);

    var ease = this.get(element, "timing");
    if (typeof ease != "function") {
      ease = base2.fx.timingFunctions[ease];
    }
    var propertyName = properties.size;
    data.step = 0;
    new base2.fx.Animation(data, {
      step: {
        end: 1,
        duration: duration,
        timing: function(t) {
          var step = ease(t, 0, 1, duration * 1000);
          var expandedSize = totalSize;
          for (var i = 0; i < count; i++) {
            var value = sizes[i] + Math.round(step * (collapsedSize - sizes[i]));
            if (value < 0) value = 0;
            panes[i].style[propertyName] = value + "px";
            expandedSize -= value;
          }
          currentPane.style[propertyName] = expandedSize + "px";
          return step;
        }
      }
    });
  },

  onmouseleave: function(element) {
    if (!this.get(element, "sticky")) {
      var data = this.getUserData(element, "accordion");
      if (data) this.animatePanes(element, data.current, data.size);
    }
  }
});
