
registerElement("abbr");

registerElement("article", {
  detect:  "cite",

  display: "block",

  behavior: {
    onattach: function(element) {
      element.setAttribute("role", "article");
    }
  }
});

registerElement("aside", {
  display: "block",

  behavior: {
    onattach: function(element) {
      element.setAttribute("role", "note");
    }
  }
});

forEach.csv("figcaption,footer,header,hgroup,summary", partial(registerElement, undefined, "block"));

registerElement("section", {
  detect:  "cite",

  display: "block",

  behavior: {
    onattach: function(element) {
      element.setAttribute("role", "section");
    }
  }
});

registerElement("figure", {
  display: "block",

  style: {
    margin: "1em 40px"
  }
});

registerElement("nav", {
  display: "block",

  behavior: {
    onattach: function(element) {
      element.setAttribute("role", "navigation");
    }
  }
});

registerElement("mark", {
  style: {
    background: "yellow"
  }
});

// Can't use registerElement because it is not a flow element.
// It's harmless to just declare default property values.
html5.source = behavior.extend({
  src: "",
  type: "",
  codecs: ""
});

registerElement("title", {
  detect: "text",

  behavior: {
    text: "",
    
    onpropertyset: function(element, propertyName, newValue) {
      if (propertyName == "text") {
        this.set(element, "textContent", newValue);
      }
    },

    get: function(element, propertyName) {
      return propertyName == "text"
        ? this.get(element, "textContent")
        : this.base(element, propertyName);
    }
  }
});

registerElement("img", {
  detect: "naturalWidth",

  behavior: {
    naturalWidth: 0,
    naturalHeight: 0,

    get: function(element, propertyName) {
      if (/^(natural(Width|Height))$/.test(propertyName)) {
        var img = new Image;
        img.src = element.src;
        return img[propertyName.slice(7).toLowerCase()] || 0;
      }
      return this.base(element, propertyName);
    }
  }
});

registerElement("map", {
  detect: "images",

  behavior: {
    images: null,

    get: function(element, propertyName) {
      if (propertyName == "images") {
        var id = element.id;
        return id
          ? this.querySelectorAll("img[usemap=#" + id + "],object[type^=image/][usemap=#" + id + "]")
          : new StaticNodeList;
      }
      return this.base(element, propertyName);
    }
  }
});

// Create stubs for all remaining elements
var _stub = behavior.extend();
forEach.csv("\
html,head,base,link,meta,style,script,noscript,body,h1,h2,h3,h4,h5,h6,address,\
p,hr,br,pre,blockquote,ol,ul,li,dl,dt,dd,div,a,em,strong,small,cite,q,dfn,code,\
var,samp,kbd,sub,sup,i,b,ruby,rt,rp,bdo,span,ins,del,iframe,embed,object,param,\
area,table,caption,colgroup,col,tbody,thead,tfoot,tr,td,th,legend,optgroup,option", function(tagName) {
  html5[tagName] = _stub;
});

// Create the style sheet.
jsb.createStyleSheet(styleSheet);

// Create the rules.
html5.rules = new jsb.RuleList(rules);
