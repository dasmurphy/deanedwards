
registerElement("input", {
  "implements": [validation],
  
  pattern: "",
  placeholder: "",
  autofocus: false,
  required: false,

  onfocus: function(element) {
    if (this.get(element, "required")) {
      element.setAttribute("aria-required", "true");
    }
  },

  get: function(element, propertyName) {
    switch (propertyName) {
      case "valueAsNumber":
        return _getChromeValue(element, _TYPE_NUMBER, NaN);

      case "valueAsDate":
        return _getChromeValue(element, _TYPE_DATE, null);

      case "list":
        var id = this.getAttribute(element, "list");
        return id ? this.querySelector("#" + id) : null;
    }
    return this.base(element, propertyName);
  },
  
  stepDown: function(element, n) {
    _step(element, -n);
  },

  setUp: function(element, n) {
    _step(element, n);
  }
}, formitem);
