
var label = behavior.extend({
  control: null,

  get: function(element, propertyName) {
    return propertyName == "control"
      ? element.htmlFor
        ? this.querySelector("#" + element.htmlFor)
        : null
      : this.base(element, propertyName);
  }
});
