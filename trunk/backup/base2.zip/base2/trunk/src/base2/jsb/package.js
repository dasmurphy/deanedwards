
// JavaScript Behaviors.
var jsb = global.jsb = new Package({
  name:    "jsb",
  version: "1.0a",
  
  exports: {
    Rule: Rule,
    RuleList: RuleList,
    behavior: behavior
  },
  
  host: getCurrentHost(),

  // Interval between refreshes of the rule engine.
  INTERVAL:  50, // milliseconds

  // Max time for hogging the processor.
  TIMEOUT: 100, // milliseconds

  // Simple style sheet creation.
  // This is overridden later to provide more complex style sheet creation.

  createStyleSheet: function(cssText) {
    var style = document.createElement("style");
    style.appendChild(document.createTextNode(cssText));
    querySelector(document, "head,html").appendChild(style);
  },

  "@(document.createStyleSheet)": {
    createStyleSheet: function(cssText) {
      document.createStyleSheet().cssText = cssText;
    }
  }
});
