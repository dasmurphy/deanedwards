
var dropdown = control.extend({
  appearance: "combobox",
  
  extend: function(_interface) {
    var dropdown = this.base(_interface);
    if (!PopupWindow.ancestorOf(dropdown.Popup)) {
      dropdown.Popup = this.Popup.extend(dropdown.Popup);
    }
    return dropdown;
  },

  "@MSIE.+win": _MSIEShim, // prevent typing over the background image
  
  _KEYCODE_ACTIVATE: /^(38|40)$/,
  
  // properties

  Popup: PopupWindow, // popup class
  
  // events

  onblur: function(element, event) {
    if (this.isOpen(element) && !dropdown._active && !this.popup.isActive()) {
      this.hidePopup();
    }
    this.base(element, event);
  },

  "@Opera9\\.[0-4]": {
    onblur: function(element, event) {
      // Early Opera: mousedown doesn't cancel but blur does. I should fix this in base2.dom. -@DRE
      if (dropdown._active || (this.isOpen(element) && this.popup.isActive())) {
        event.preventDefault();
      } else {
        this.base(element, event);
      }
    },

    onkeypress: function(element, event, keyCode) {
      if (this.isOpen(element) && keyCode === 13) {
        event.preventDefault();
      }
    }
  },

  onkeydown: function(element, event, keyCode) {
    dropdown._active = true;
    if (this.isEditable(element)) {
      if (this._KEYCODE_ACTIVATE.test(keyCode) && !this.isOpen(element)) {
        this.showPopup(element);
        this.popup.focus();
        event.preventDefault();
      } else if (this.isOpen(element)) {
        this.popup.focus();
        this.popup.onkeydown(event);
      }
    }
    delete dropdown._active;
  },

  onmousedown: function(element, event, x) {
    dropdown._active = true;
    this.base.apply(this, arguments);
    if (this.isEditable(element)) {
      if (this.hitTest(element, x)) {
        if (this.isOpen(element)) {
          this.hidePopup();
        } else {
          this.showPopup(element);
        }
      } else {
        this.hidePopup();
      }
    }
    delete dropdown._active;
  },
  
  // methods

  getState: function(element) {
    if (element.disabled) {
      var state = "disabled";
    } else if (element.readOnly && element != control._readOnlyTemp) {
      state = "normal";
    } else if (element == control._active && control._activeThumb) {
      state = "active";
    } else if (element == control._hover && control._hoverThumb) {
      state = "hover";
    } else {
      state = "normal";
    }
    return this.states[state];
  },

  hidePopup: function() {
    if (this.popup) this.popup.hide();
  },

  isOpen: function(element) {
    var popup = this.popup;
    return popup && popup == PopupWindow.current && popup.element == element && popup.isOpen();
  },

  setAttributes: function(element) {
    element.setAttribute("aria-haspopup", true);
    this.base(element);
  },

  showPopup: function(element) {
    this.hideToolTip();
    if (!this.popup) {
      this.popup = new this.Popup(this);
    }
    this.popup.show(element);
  },

  "@theme=aqua": {
    "@(style.borderImage)": {
      hitTest: function(element, x) {
        return x >= element[_WIDTH];
      }
    },

    layout: function(element, state) {
      if (state == null) this.syncCursor(element);
    }
  }
});
