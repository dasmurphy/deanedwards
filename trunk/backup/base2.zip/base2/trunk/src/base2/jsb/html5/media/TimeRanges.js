
html5.TimeRanges = Base.extend({
  length: 0,
  
  start: Undefined,
  end: Undefined
});
