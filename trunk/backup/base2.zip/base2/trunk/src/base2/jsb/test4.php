<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
 <title>chrome: Test Page</title>
 <script src="/base2/trunk/src/legacy.js" type="text/javascript"></script>
 <script src="/base2/trunk/src/console2.js" type="text/javascript"></script>
 <script src="/base2/trunk/src/build.php?package=base2/jsb/package.xml&amp;full&<?php echo time() ?>" type="text/javascript"></script>

 <script type="text/javascript">
  var bounce = jsb.behavior.extend({
    animation: null,

    onattach: function(element) {
      this.animation = this.animate(element, this.animation);
    },

    ontransitionend: function(element, event, propertyName) {
      if (propertyName == "backgroundColor") {
        this.animation.reverse();
      }
    }
  });

  new jsb.RuleList({
    "#box1": bounce.extend({animation: {left: "198px", backgroundColor: "orange"}}),
    "#box2": bounce.extend({animation: {top: "198px", backgroundColor: "lime"}}),
    "#box3": bounce.extend({animation: {left: "0px", backgroundColor: "red"}}),
    "#box4": bounce.extend({animation: {top: "0px", backgroundColor: "orange"}})
  });
 </script>

 <style type="text/css">
  #container {
    position: absolute;
    border: 10px solid black;
    cursor: default;
    width: 300px;
    height: 300px;
    
  }
  
  .box {
    position: absolute;
    border: 1px solid black;
  }

  #box1 {
    background: yellow;
    top: 50px;
    width: 100px;
    height: 100px;
  }

  #box2 {
    background: yellow;
    left: 50px;
    width: 100px;
    height: 100px;
  }

  #box3 {
    background: lime;
    left: 198px;
    top: 148px;
    width: 100px;
    height: 100px;
  }

  #box4 {
    background: red;
    top: 198px;
    left: 148px;
    width: 100px;
    height: 100px;
  }
 </style>
</head>

<body lang="en">
<h1>JSB: Animation Test Page</h1>

<div id="container">
 <div class="box" id="box1"></div>
 <div class="box" id="box2"></div>
 <div class="box" id="box3"></div>
 <div class="box" id="box4"></div>
</div>
</body>
</html>
