
registerElement("select", {
  "implements": [validation],
  autofocus: false
}, formitem);
