
// Damn. This is way too big. :-(
// All this because MSIE does not respect padding in <input> elements.

// Basically, this code places a little widget over the current <input> element.
// The little widget looks exactly like the chrome control and forwards its
// events.

var _MSIEShim = {
  onfocus: function(element) {
    this.base.apply(this, arguments);
    var behavior = this, timer;
    if (!shim.control) {
      var control = shim.control = document.createElement("x");
      document.body.insertBefore(control, document.body.firstChild);
      addEventListener(control, "mousedown", _shimMouse, false);
      addEventListener(control, "mousemove", _shimMouse, false);
      shim.attach(control);
    }
    shim.element = element;
    shim.behavior = behavior;
    var style = shim.control.style;
    style.display = "none";
    style.position = "absolute";
    style.fontSize = "0";
    style.border = "0";
    style.height = element.clientHeight + PX;
    style.width = behavior._IMAGE_WIDTH + PX;
    style.backgroundImage = this.style.compute(element, "backgroundImage");
    shim.layout();
    var blurType = "onfocusout";
    _private.attachEvent(element, "onpropertychange", change);
    _private.attachEvent(element, blurType, onblur);
    
    function change(event) {
      if (event.propertyName === "value") resetScroll();
    };
    function resetScroll() {
      element.scrollLeft = 9999;
    };
    function position() {
      var offset = dom.ElementView.getOffsetFromBody(element),
          rect = getBoundingClientRect(element),
          adjustRight = rect.right - rect.left - element.offsetWidth;
      style.left = (offset.left + adjustRight + element[_WIDTH] - behavior._IMAGE_WIDTH + element.clientLeft) + PX;
      style.top = (offset.top + element.clientTop) + PX;
      timer = null;
    };
    function onblur() {
      _private.detachEvent(element, "onpropertychange", change, true);
      _private.detachEvent(element, blurType, onblur, true);
      _private.detachEvent(window, "onresize", resize, true);
      style.display = "none";
      resetScroll();
      delete shim.element;
    };
    function resize() {
      if (!timer) timer = setTimeout(position, 50);
    };
    _private.attachEvent(window, "onresize", resize);
    position();
    setTimeout(function() {
      if (shim.element) {
        style.display = "block";
      }
    }, 1);
  },
  
  onmouseover: _shimMouseOverOut,
  onmouseout: _shimMouseOverOut,

  onmousedown: _shimLayout,
  onmouseup: _shimLayout,
  onkeydown: _shimLayout,

  onkeyup: function(element, event, keyCode) {
    if (!PopupWindow.current && keyCode === 35) { // END key
      element.scrollLeft = 9999;
    } else {
      this.base(element, event, keyCode);
    }
    if (shim.element == element) shim.layout();
  },
  
  layout: function(element, state) {
    this.base(element, state);
    if (element == shim.element) {
      shim.layout();
    }
  },
  
  matchesSelector: function(element, selector) {
    return this.base(element, selector) ||
      (/^:(hover|active)$/.test(selector) && element == shim.element && this.base(shim.control, selector));
  }
};

var shim = behavior.extend({
  jsbExtendedMouse: true,

  onmouseover: _shimMouseOverOut2,
  onmouseout: _shimMouseOverOut2,

  layout: function() {
    if (this.element) {
      this.control.style.backgroundPosition = this.element.style.backgroundPosition;
    }
  }
});

function _shimLayout(element, event) {
  this.base.apply(this, arguments);
  if (element == shim.element) shim.layout();
};

function _shimMouse(event) {
  if (event.type === "mousedown") event.preventDefault();
  shim.fire(shim.element, event.type, event);
  event.stopPropagation();
  shim.layout();
};

function _shimMouseOverOut(element, event, x, y) {
  if (element != shim.element || (event.relatedTarget && event.relatedTarget != shim.control)) {
    this.base(element, event, x, y);
  }
  if (shim.element == element) shim.layout();
};

function _shimMouseOverOut2(element, event, x, y) {
  event.stopPropagation();
  if (this.element && event.relatedTarget != this.element) {
    event.target = this.element;
    this.behavior["on" + event.type](this.element, event, x, y);
  }
  this.layout();
};
