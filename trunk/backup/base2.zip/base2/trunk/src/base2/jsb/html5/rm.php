<?php

header("Location: /base2/trunk/src/build.php?package=base2/jsb/html5/rm/package.xml");

?>
