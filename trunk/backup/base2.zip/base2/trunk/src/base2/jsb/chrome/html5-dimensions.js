
var _WIDTH = "clientWidth",
    _HEIGHT = "clientHeight";

if (jsb.clientWidth2) {
  _WIDTH = "clientWidth2";
  _HEIGHT = "clientHeight2";
}
