
var formitem = behavior.extend({
  labels: null,

  get: function(element, propertyName) {
    return propertyName == "labels"
      ? element.id
        ? this.querySelectorAll("label[for=" + element.id + "]")
        : new StaticNodeList
      : this.base(element, propertyName);
  }
});
