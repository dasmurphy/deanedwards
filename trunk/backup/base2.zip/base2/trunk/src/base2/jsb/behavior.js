
var _Behavior = Base.extend({
  attach: Undefined, // these three methods are defined when the behavior is created
  detach: Undefined,
  modify: Null,

  jsbExtendedMouse:      false, // allow right and middle button clicks
  jsbUseDelegation:      true,  // use event delegation (appropriate events are handled by the document object)
  jsbUseDispatch:        true,  // use event dispatch (not a callback)

  ancestorOf: function(behavior) {
    return behavior instanceof this.constructor;
  },

  extend: function(_interface) {
    // Extend a behavior to create a new behavior.

    if (!_interface) _interface = {};
    
    // Create the Behavior constructor.
    var Behavior = new Function;
    (Behavior.prototype = new this.constructor).constructor = Behavior;

    // Decorate the prototype.
    var interfaces = _interface["implements"] || [];
    delete _interface["implements"];
    interfaces.push(_interface);
    for (var i = 0; i < interfaces.length; i++) {
      extend(Behavior.prototype, interfaces[i]);
    }

    // Single instance.
    var behavior = new Behavior;

    // Extract event handlers.
    
    var delegatedEvents = [],
        events,
        eventListener = {
          handleEvent: function(event) {
            eventDispatcher.dispatch(behavior, event.target, event);
          }
        };
        
    for (var name in behavior) {
      if (typeof behavior[name] == "function" && EVENT.test(name)) {
        var type = name.slice(2);
        // Store event handlers.
        if (!behavior.jsbUseDelegation || CANNOT_DELEGATE.test(type)) {
          if (!events) events = [];
          events.push(type);
        } else if (!EVENT_PSEUDO.test(type)) {
          delegatedEvents.push(type);
        }
      }
    }

    // Maintain attachments.

    var attachments = {behavior: behavior};

    behavior.attach = function(element) {
      var uniqueID = element.uniqueID || assignID(element);

      if (!attachments[uniqueID]) { // don't attach more than once
        // Maintain attachment state.
        attachments[uniqueID] = true;
        if (!allAttachments[uniqueID]) allAttachments[uniqueID] = 0;
        allAttachments[uniqueID]++;

        // Add event handlers
        if (delegatedEvents) {
          for (var i = 0; type = delegatedEvents[i]; i++) {
            eventDelegator.addEventListener(type, attachments);
          }
          delegatedEvents = null; // we only need to attach these once per document
        }
        if (events) { // these events cannot be delegated
          for (var i = 0; type = events[i]; i++) {
            addEventListener(element, type, eventListener, false);
          }
        }

        // JSB events.
        if (behavior.onattach) {
          dispatchJSBEvent(behavior, element, "attach");
        }
        if (behavior.oncontentready) {
          if (isContentReady(element)) {
            dispatchJSBEvent(behavior, element, "contentready");
          } else {
            contentReadyQueue.push({behavior: behavior, element: element});
          }
        }
        if (behavior.ondocumentready) {
          if (engine.ready) {
            dispatchJSBEvent(behavior, element, "documentready");
          } else {
            documentReadyQueue.push({behavior: behavior, element: element});
          }
        }
        if (behavior.onfocus && element == document.activeElement) {
          behavior.fire(element, "focus");
        }
      }
    };

    behavior.detach = function(element) {
      var uniqueID = element.uniqueID;
      if (attachments[uniqueID]) {
        if (arguments[1]) { // events only
          attachments[uniqueID] = false;
        } else {
          delete attachments[uniqueID];
        }
        allAttachments[uniqueID]--;
        if (events) {
          for (var i = 0; type = events[i]; i++) {
            removeEventListener(element, type, eventListener, false);
          }
        }
      }
    };

    // Maintain modifications.

    var modifications = [];
    
    Behavior._get = function(element, propertyName) {
      for (var i = 0, modification; modification = modifications[i]; i++) {
        if (propertyName in modification && matchesSelector(element, modification._selector)) {
          return modification[propertyName];
        }
      }
      return behavior[propertyName];
    };

    behavior.modify = function(attributes) {
      Behavior._isModified = true;
      return new Modification(behavior, attributes, modifications);
    };

    return behavior;
  },

  // DOM properties.

  get: function(element, propertyName) {
    // Retrieve a DOM property.

    // special cases
    if (propertyName == "textContent") {
      return element[dom.TEXT_CONTENT] || "";
    }

    var defaultValue = this[propertyName];

    if (propertyName != "type") {
      var value = element[propertyName];
    }
    if (typeof value == "undefined") {
      if (propertyName in elementTraversal) {
        return elementTraversal[propertyName](element);
      } else {
        value = getAttribute(element, propertyName);
      }
    }
    
    if (value == null) {
      var Behavior = this.constructor;
      return Behavior._isModified
        ? Behavior._get(element, propertyName)
        : defaultValue;
    }

    // Cast.
    switch (typeof defaultValue) {
      case "boolean": return value !== false;
      case "number":  return value - 0;
    }
    return value;
  },

  set: function(element, propertyName, value) {
    // Set a DOM property.

    var originalValue = this.get(element, propertyName);
    
    // special cases
    if (propertyName == "textContent") {
      element[dom.TEXT_CONTENT] = value;
    } else if (propertyName == "innerHTML") {
      try {
        element.innerHTML = value;
      } catch(ex) {
        element.innerHTML = "";
        dummyDIV.innerHTML = value;
        while (dummyDIV.firstChild) {
          element.appendChild(dummyDIV.firstChild);
        }
      }
    } else {
      if (typeof this[propertyName] == "boolean" && !value) {
        removeAttribute(element, propertyName);
      } else {
        setAttribute(element, propertyName, value);
      }
    }
    
    if (typeof value != typeof originalValue) {
      value = this.get(element, propertyName);
    }
    
    // If the value has changed then dispatch a "propertyset" event.
    if (originalValue !== value) {
      this.fire(element, "propertyset", {
        propertyName: propertyName,
        originalValue: originalValue,
        newValue: value
      });
    }
    return value;
  },

  // Node.

  compareDocumentPosition: compareDocumentPosition,
  
  getUserData: getUserData,
  setUserData: setUserData,
  
  // Attributes.
  
  classList: classList,

  getAttribute: getAttribute,
  hasAttribute: hasAttribute,
  removeAttribute: removeAttribute,
  setAttribute: setAttribute,
  
  // Selectors API

  matchesSelector: matchesSelector,
  querySelector: querySelector,
  querySelectorAll: querySelectorAll,

  // EventTarget.

  addEventListener: addEventListener,
  removeEventListener: removeEventListener,
  dispatchEvent: dispatchEvent,

  fire: fire,

  // Style.
  
  style: {
   /*calc: function(element, propertyName, expression) { //slow
      var style = element.style;
      var display = style.display;
      var metric = /[Ww]idth|[lL]eft|X/.test(propertyName) ? "width" : "height";
      var restore = style[metric];
      style.display = "block";
      expression = expression.replace(/([\d\.]+)(\w+|%)/g, function(match, length, unit) {
        if (unit !== "px") {
          style[metric] = match;
          length = dom.ViewCSS.getComputedPropertyValue(document.defaultView, element, metric).slice(0, -2);
        }
        return length;
      });
      style[metric] = restore;
      style.display = display;
      return new Function("return " + expression)();
    },*/

    compute: function(element, propertyName) {
      // faster than getComputedStyle in MSIE
      return dom.ViewCSS.getComputedPropertyValue(document.defaultView, element, propertyName);
    },

    get: function(element, propertyName) {
      // You should mostly use element.style.
      // Use this to retrieve newer properties like "opacity".
      return dom.CSSStyleDeclaration.getPropertyValue(element.style, propertyName);
    },

    set: function(element, propertyName, value, important) {
      // element.style is quicker but this offers cross-browser safety and the
      // ability to set the !important flag.
      if (arguments.length > 2) {
        dom.CSSStyleDeclaration.setProperty(element.style, propertyName, value, important ? "important" : "");
      } else {
        dom.CSSStyleDeclaration.setProperties(element.style, arguments[1]);
      }
    }
  },

  getComputedStyle: getComputedStyle,

  animate: function(element, transitions) {
    if (!base2.fx) throw new ReferenceError("base2.fx is not loaded.");
    new base2.fx.Animation(element.style, transitions, element, true);
  },

  // CSS Object Model.

  getBoundingClientRect: getBoundingClientRect,
  getOffsetFromBody: dom.ElementView.getOffsetFromBody,

  // Mouse capture.

  setCapture: setCapture,
  releaseCapture: releaseCapture
});

var behavior = _Behavior.prototype;

// Bind timers to behaviors.

forEach.csv ("setInterval,setTimeout", function(name) {
  behavior[name] = function(callback, delay) {
    if (typeof callback == "string") callback = this[callback];
    var args = Array2.slice(arguments, 2);
    var self = this;
    return global[name](function() {
      callback.apply(self, args);
    }, delay || 15);
  };
});

behavior = new _Behavior; // seal-off
