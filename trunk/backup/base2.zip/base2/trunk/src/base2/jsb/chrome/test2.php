<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
 <title>chrome: Test Page</title>
 <script src="/base2/trunk/src/console2.js"></script>
 <script src="/base2/trunk/src/base2/jsb/chrome/chrome.php"></script>
 <style>
 /*input, select {margin-bottom: 20px; border: 10px solid red; color: blue; background-color: orange;}*/
 li {line-height: 3;}
 input,select {line-height: normal;}
 #dummy {
  text-align: right;
  padding-right: 25px;
 }
 input[expando] {color: red;}
 </style>
</head>

<body>
<form action="" method="post" enctype="multipart/form-data">
<h1 style="background-color:activecaption;color:captiontext"><b>chrome</b>: Test Page</h1>
<p><input style="height:204px;width:18px" class="jsb-progressbar" type="text" value="<?php echo rand(1,99) ?>">
<input style="height:204px;width:22px" class="jsb-slider" type="text" value="<?php echo rand(1,99) ?>" disabled>
<input style="height:204px;width:18px" class="jsb-progressbar" type="text" value="<?php echo rand(1,99) ?>"  readonly>
<input style="height:204px;width:22px" class="jsb-slider" type="text" value="<?php echo rand(1,99) ?>"></p>

<p><input id="dummy" type="text" value="xyz" aria-required="true"></p>

<?php
for ($i = 0; $i < 1; $i++) {
?>
<h2>Block <?php echo $i+1 ?></h2>
<ol style="width:70%">
<?php
  for ($j = 1; $j < 4; $j++) {
?>
 <li><p><input role="combobox" name="combobox<?php echo $i.$j; ?>" class="jsb-combobox" value="test" type="text" list="titles"<?php if($j==2)echo 'disabled' ?>/>
  <select name="select<?php echo $i.$j; ?>" <?php if($j==2)echo 'disabled' ?>>
    <option>Baroness
    <option>Dr
    <option>Lady
    <option>Lord
    <option>Miss
    <option>Mr
    <option>Mrs
    <option>Prof
    <option>Rt Hon
    <option>Sir
  </select>
  <input name="colorpicker<?php echo $i.$j; ?>" class="jsb-colorpicker" value="#<?php
    for ($k = 0; $k < 3; $k++) {
      $r = rand(0, 255);
      if ($r < 16) echo "0";
      echo dechex($r);
    }
   ?>" <?php if($j==2)echo 'disabled' ?>/>
  <input id="tester" name="text<?php echo $i.$j; ?>" type="text" <?php if($j==2)echo 'disabled' ?>/>
  <input name="spinner<?php echo $i.$j; ?>" class="jsb-spinner"<?php if($j==2)echo 'disabled' ?>>
  <input role="slider" name="slider<?php echo $i.$j; ?>" class="jsb-slider" value="<?php echo rand(1,99) ?>" <?php if($j==2)echo 'disabled' ?>>
  <input name="monthpicker<?php echo $i.$j; ?>" class="jsb-monthpicker" step="2" value="2009-03" <?php if($j==2)echo 'disabled' ?>>
  <input name="timepicker<?php echo $i.$j; ?>" class="jsb-timepicker" value="12:00" <?php if($j==2)echo 'disabled' ?>>
  <input name="datepicker<?php echo $i.$j; ?>" class="jsb-datepicker" min="2007-08-28" max="2010-08-28" value="" <?php if($j==2)echo 'disabled' ?>>
  <input name="weekpicker<?php echo $i.$j; ?>" class="jsb-weekpicker" step="2" value="" <?php if($j==2)echo 'disabled' ?> required>
  <input name="progressbar<?php echo $i.$j; ?>" class="jsb-progressbar" value="<?php echo rand(1,99) ?>" <?php if($j==2)echo 'disabled' ?>  readonly>
  <label for="checkbox<?php echo $i.$j; ?>"><input name="checkbox<?php echo $i.$j; ?>" type="checkbox" id="checkbox<?php echo $i.$j; ?>" <?php if($j==2)echo 'disabled' ?>> oranges</label>
  <label for="radio<?php echo $i.$j; ?>"><input name="radio<?php echo $i.$j; ?>" type="radio" id="radio<?php echo $i.$j; ?>" <?php if($j==2)echo 'disabled' ?>> apples</label>
  <!--input name="combobox<?php echo $i.$j; ?>" class="jsb-combobox" type="text" <?php if($j==2)echo 'disabled' ?>>
  <input name="text<?php echo $i.$j; ?>" class="chrome" type="text" <?php if($j==2)echo 'disabled' ?>--></p></li>
<?php
  }
?>
</ol>
<!--script type="text/javascript">
console2.log("Loading blocking script...");
document.write('<script src="block.js.php?' + (new Date().valueOf()) + '" type="text/javascript"><\/script>');
</script-->
<?php
}
?>
<p><button type="submit">Submit</button></p>
</form>
<select class="jsb-datalist" id="titles">
 <option>Baroness
 <option>Dr
 <option>Lady
 <option>Lord
 <option>Miss
 <option>Mr
 <option>Mrs
 <option>Prof
 <option>Rt Hon
 <option>Sir
</select>
</body>
</html>
