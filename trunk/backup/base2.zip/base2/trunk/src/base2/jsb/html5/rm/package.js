
var rm = new Package({
  name:    "rm",
  version: "0.1",
  parent:  jsb,
  
  template: template,
  add: add,
  remove: remove,
  moveup: moveup,
  movedown: movedown
});

eval(namespace);
