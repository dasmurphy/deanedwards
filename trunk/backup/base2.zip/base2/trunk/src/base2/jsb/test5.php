<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
 <title>chrome: Test Page</title>
 <script src="/base2/trunk/src/console2.js" type="text/javascript"></script>
 <script src="/base2/trunk/src/build.php?package=base2/jsb/package.xml&amp;full" type="text/javascript"></script>

 <script type="text/javascript">
 new jsb.RuleList({
  "#example": {
  
    onattach: function(element) {
      this.setPrivateData(element, "animation", new base2.fx.Animation(element.style, {opacity: 0.25}, element, false));
    },
    
    onmouseover: function(element) {
      this.getAnimation(element).start();
    },
    
    onmouseout: function(element) {
      this.getAnimation(element).reverse();
    },
    
    getAnimation: function(element) {
      return this.getPrivateData(element, "animation");
    }
    
  }
 });
 </script>

 <style type="text/css">
  #example {
    background: purple;
    border: 10px dashed black;
    padding: 50px;
    width: 60px;
    vertical-align: middle;
    text-align: center;
    color: white;
    font-weight: bold;
    cursor: default;
  }
 </style>
</head>

<body lang="en">
<h1>JSB: Animation Test Page</h1>

<p id="example">Hover to start the animation.</p>
</body>
</html>
