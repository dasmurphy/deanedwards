
global.html5 = new Package({
  name:    "html5",
  version: "0.6",
  
  NOT_SUPPORTED: function() {
    throw new Error("Not supported in html5-now.js.");
  },
  
  cssParser: new RegGrp({
    "\\*?\\.jsb\\-combobox": "input[list]",
    "\\*?\\.jsb\\-spinner": "input[type=number]",
    "\\*?\\.jsb\\-(\\w+)picker([^-])": "input[type=$1]$2",
    "\\*?\\.jsb\\-slider": "input[type=range]",
    "\\*?\\.jsb\\-error": "input.jsb-error"
  }),

  get: function(element, propertyName) {
    return this.getBehavior(element).get(element, propertyName);
  },

  set: function(element, propertyName, value) {
    this.getBehavior(element).set(element, propertyName, value);
  },

  getBehavior: function(element) {
    return this[element.nodeName.toLowerCase()] || behavior;
  }
});
