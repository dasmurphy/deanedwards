
registerElement("output", {
  "implements": [noValidation],
  
  name: "",
  value: "",
  defaultValue: "",
  
  onattach: function(element) {
    this.setUserData(element, "mode", "default", null);
    element.setAttribute("role", "status");
  },

  onpropertyset: function(element, event, propertyName, newValue) {
    var mode = this.getUserData(element, "mode");
    
    if (mode == "default" || propertyName == "value") {
      switch (propertyName) {
        case "innerHTML":
          newValue = this.get(element, "textContent");

        case "textContent":
          this.set(element, "defaultValue", newValue);
          break;

        case "defaultValue":
          this.set(element, "textContent", newValue);
          break;

        case "value":
          this.setUserData(element, "mode", "value", null);
          this.set(element, "textContent", newValue);
      }
    }
  },

  get: function(element, propertyName) {
    switch (propertyName) {
      case "type":
        return "output";

      case "value":
        return this.get(element, "textContent");

      case "htmlFor":
        var htmlFor = this.getAttribute(element, "for");
        return htmlFor
          ? this.querySelectorAll("#" + htmlFor.match(/[^\s]+/g).join(",#"))
          : new StaticNodeList;
    }
    return this.base(element, propertyName);
  }
}, formitem);
