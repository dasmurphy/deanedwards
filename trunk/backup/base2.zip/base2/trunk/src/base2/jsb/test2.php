<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
 <title>chrome: Test Page</title>
 <script src="/base2/trunk/src/console2.js"></script>
 <script src="/base2/trunk/src/build.php?package=base2/jsb/package.xml&amp;full"></script>

 <script>
 new base2.jsb.RuleList({
  "#example": {
  
    onmousedown: function(element) {
      console2.log("mousedown");
    },

    onmouseup: function(element) {
      console2.log("mouseup");
    },

    onclick: function(element) {
      console2.log("onclick");
    },

    ondblclick: function(element) {
      console2.log("ondblclick");
    }
    
  }
 });
 </script>

 <style>
  #example {
    background: purple;
    border: 10px dashed black;
    padding: 50px;
    width: 60px;
    vertical-align: middle;
    text-align: center;
    color: white;
    font-weight: bold;
    cursor: default;
  }
 </style>
</head>

<body>
<h1>JSB: Animation Test Page</h1>

<p id="example">Hover to start the animation.</p>
</body>
</html>
