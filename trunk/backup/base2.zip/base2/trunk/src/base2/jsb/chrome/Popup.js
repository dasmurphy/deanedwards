
var Popup = Base.extend({
  constructor: function() {
    var body = this.body = this.createBody();
    body.className = "jsb-popup";
    if (this.role) {
      body.setAttribute("role", this.role);
    }
    var appearance = this.appearance;
    if (appearance && appearance !== "popup") {
      body.className += " jsb-" + appearance;
    }
    for (var i in this) {
      if (EVENT.test(i)) {
        addEventListener(body, i.slice(2), this, true);
      }
    }
  },

  // properties

  appearance: "popup",
  element: null,
  body: null,
  
  // the following properties describe how the popup should be positioned.
  
  width: "auto", // "auto" or length
  height: "auto",
  
  position: "below", // show above or below the control?

  scrollX: false, // allow scrolling?
  scrollY: false,

  offsetX: 0, // offset distance from the control
  offsetY: 0,
  
  // events

  "@Gecko1\\.[^9]": {
    onmousedown: function(event) {
      event.preventDefault();
    }
  },

  handleEvent: function(event) {
    switch (event.type) {
      case "mouseover":
      case "mouseout":
        if (event.target == this.body) return;
    }
    this["on" + event.type](event);
  },
  
  // methods

  createBody: function() {
    return document.createElement("div");
  },

  getRect: function() {
    var viewport = QUIRKS_MODE ? document.body : document.documentElement,
        popup    = this.body,
        element  = this.element,
        rect     = getBoundingClientRect(element),
        left     = 0,
        top      = this.position === "below" ? element.offsetHeight - 1 : - 1 - element.offsetHeight,
        width    = this.width,
        height   = this.height,
        offsetX  = this.offsetX,
        offsetY  = this.offsetY;

    if (width === "base") {
      width = element.offsetWidth;
    }

    // resize
    if (width === "auto" || height === "auto") {
      if (height === "auto") {
        height = popup.scrollHeight + 2;
        var unitHeight = this.getUnitHeight();
        if (this.scrollY) {
          height = Math.min(height, Math.max(viewport[_HEIGHT] - rect.bottom - 2, rect.top - 2));
        }
        if (unitHeight > 1) height = 2 + ~~(height / unitHeight) * unitHeight;
      }
      if (width === "auto") {
        width = popup.scrollWidth + 2;
        if (height < popup.scrollHeight + 2) width += 22; // scrollbars
        if (this.scrollX) {
          width = Math.min(width, Math.max(viewport[_WIDTH] - rect.left - 2, rect.right - 2));
        }
        width =  Math.max(width, element.offsetWidth);
      }
    }
    if (height > viewport[_HEIGHT] - rect.bottom && height < rect.bottom) {
      top = -height;
      offsetY *= -1;
    }
    if (width > viewport[_WIDTH] - rect.right && width < rect.right) {
      left = element.offsetWidth - width;
      offsetX *= -1;
    }
    return new Rect(left + offsetX, top + offsetY, width, height);
  },
  
  getUnitHeight: K(1),

  hide: function() {
    this.removeBody();
  },

  isOpen: function() {
    return !!this.body[_PARENT];
  },

  layout: Undefined,

  movesize: function() {
    var rect    = this.getRect(),
        adjust   = QUIRKS_MODE ? 0 : 2,
        offset  = dom.ElementView.getOffsetFromBody(this.element);
    behavior.style.set(this.body, {
      left: offset.left,
      top: offset.top + rect.top,
      width: Math.max(rect.width - adjust, 100),
      height: Math.max(rect.height - adjust, 22)
    });
  },

  querySelector: function(selector) {
    return querySelector(this.body, selector);
  },

  querySelectorAll: function(selector) {
    return querySelectorAll(this.body, selector);
  },

  removeBody: function() {
    var parent = this.body[_PARENT];
    if (parent) parent.removeChild(this.body);
  },

  render: function(html) {
    this.body.innerHTML = trim(html) || "";
  },

  setUnselectable: function(element) {
    element.unselectable = "on";
    behavior.style.set(element, "userSelect", "none");
  },

  show: function(element) {
    this.element = element;
    this.render();
    this.style();
    document.body.appendChild(this.body);
    this.movesize();
    this.body.style.visibility = "visible";
    this.layout();
  },

  style: Undefined,

  "@MSIE6": { // prevent <select> boxes from bleeding through
    removeBody: function() {
      var iframe = Popup._iframe;
      if (iframe[_PARENT]) {
        document.body.removeChild(iframe);
      }
      this.base();
    },

    createBody: function() {
      var iframe = Popup._iframe;
      if (!iframe) {
        iframe = Popup._iframe = document.createElement("iframe"),
        iframe.style.cssText = "position:absolute;z-index:999998!important";
        iframe.frameBorder = "0";
        iframe.scrolling = "no";
        iframe.src = "javascript:''";
        iframe.tabIndex = -1;
        iframe.setAttribute("role", "presentation");
        iframe.setAttribute("aria-hidden", "true");
      }
      return this.base();
    },

    show: function(element) {
      this.base(element);
      var iframe = Popup._iframe,
          body = this.body,
          bodyStyle = body.currentStyle;
      behavior.style.set(iframe, {
        left: bodyStyle.left,
        top: bodyStyle.top,
        width: body.offsetWidth,
        height: body.offsetHeight,
        backgroundColor: bodyStyle.backgroundColor
      });
      document.body.appendChild(iframe);
    }
  }
});
