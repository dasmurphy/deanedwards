
var HTMLButtonElement = HTMLElement.extend(_noValidationMethods, {
  tags: "BUTTON"
});
