
var HTMLButtonElement = HTMLElement.extend(_noValidationMethods, {
  tags: "OUTPUT"
});
