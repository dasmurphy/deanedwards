<!doctype html>
<html>
<head>
 <title>chrome: Test Page</title>
 <script src="/base2/trunk/src/legacy.js"></script>
 <script src="/base2/trunk/src/console2.js"></script>
 <script src="/base2/trunk/src/build.php?package=base2/jsb/package.xml&amp;full&<?php echo time() ?>"></script>

 <script type="text/javascript">
  new jsb.Rule("#example", {
    onmouseenter: function(element) { // start the animation
      console2.log("onmouseenter");
      this.currentAnimation = this.animate(element, {
        width: {
          end: "300px",
          duration: 2,
          timing: "linear"
        },
        backgroundColor: "blue",
        borderColor: "yellow"
      });
    },

    onmouseleave: function(element) { // reverse the animation
      console2.log("onmouseleave");
      if (this.currentAnimation) this.currentAnimation.reverse(0.5);
      this.currentAnimation = null;
    },

    onclick: function(element) {  // accelerate the animation
      if (this.currentAnimation) this.currentAnimation.accelerate(4);
    }
  });
 </script>

 <style type="text/css">
  #example {
    background: red;
    border: 10px solid lime;
    padding: 50px;
    width: 10em;
    color: white;
    font-weight: bold;
    cursor: default;
  }
  #example p {
    background: white;
    color: red;
    width: 80px;
    padding: 5px;
  }
 </style>
</head>

<body lang="en">
<h1>JSB: Animation Test Page</h1>

<div id="example"><p>Hover to start the animation, click to accelerate.</p></div>

</body>
</html>
