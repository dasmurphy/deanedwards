
var DataTransfer = Base.extend({
  constructor: function() {
    var _data = {};
    var _elements = {};
    var _dragImage;

    this.clearData = function(format) {
      delete _data[format];
    };

    this.setData = function(format, data) {
      _data[format] = data;
    };

    this.getData = function(format) {
      return _data[format];
    };

    this.setDragImage = function(image, x, y) {
      _dragImage = {
        image: image,
        x: x,
        y: y
      };
    };

    this.addElement = function(element) {
      _elements[assignID(element)] = element;
    };
  },
  
  dropEffect: "none",
  effectAllowed: "uninitialized",
  
  addElement: Undefined,
  clearData: Undefined,
  getData: Undefined,
  setData: Undefined,
  setDragImage: Undefined,
});
