
var MEDIA_JS = "media.js";
;;; MEDIA_JS = "media.php";

var MEDIA_METHODS = "canPlayType,load,play,pause";

registerElement("audio", {
  detect: "play",
  
  display: "none",
  
  extraStyles: {
    "audio[controls]": {
      display: "inline"
    }
  },
  
  methods: MEDIA_METHODS,

  behavior: MEDIA_JS + "#html5.audio"
});

html5.Audio = html5.NOT_SUPPORTED; // TO DO

registerElement("video", {
  detect:  "play",

  display: "block",
  
  style: {
    width: "300px",
    height: "150px"
  },

  methods: MEDIA_METHODS,

  behavior: MEDIA_JS + "#html5.video"
});
