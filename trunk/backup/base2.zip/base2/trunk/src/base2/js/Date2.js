
// http://developer.mozilla.org/es4/proposals/date_and_time.html

// big, ugly, regular expression
var _DATE_PATTERN = /^(([+-]\d{6}|\d{4})(-(\d{2})(-(\d{2}))?)?)?(T(\d{2}):(\d{2})((:(\d{2})(\.(\d{1,3})(\d)?\d*)?)?)?)?(([+-])(\d{2})(:(\d{2}))?|Z)?$/,
    _DATE_PARTS   = { // indexes to the sub-expressions of the RegExp above
      FullYear: 2,
      Month: 4,
      Date: 6,
      Hours: 8,
      Minutes: 9,
      Seconds: 12,
      Milliseconds: 14
    },
    _TIMEZONE_PARTS = { // idem, but without the getter/setter usage on Date object
      Hectomicroseconds: 15, // :-P
      UTC: 16,
      Sign: 17,
      Hours: 18,
      Minutes: 20
    };

var Date2 = _createObject2(
  "Date",
  base2_Date,
  "", {now: now}, {
    toISOString: function(date) {
      var string = "####-##-##T##:##:##.###Z";
      for (var part in _DATE_PARTS) {
        string = string.replace(/#+/, function(digits) {
          var value = date["getUTC" + part]();
          if (part === "Month") value++; // js month starts at zero
          return ("000" + value).slice(-digits.length); // pad
        });
      }
      return string;
    }
  }
);

function base2_Date(yy, mm, dd, h, m, s, ms) { // faux constructor
  switch (arguments.length) {
    case 0: return new Date;
    case 1: return typeof yy == "string" ? new Date(Date2.parse(yy)) : new Date(yy - 0);
    default: return new Date(yy, mm, arguments.length === 2 ? 1 : dd, h || 0, m || 0, s || 0, ms || 0);
  }
};

base2_Date.prototype = Date.prototype;
base2_Date.prototype.constructor = Date;

var Date_parse = Date.parse;

base2_Date.now   = Date2.now;
base2_Date.parse = Date2.parse = Date_parse("T00:00") === 0 && Date_parse("1970") === 0 ? Date_parse : Date2_parse;
base2_Date.UTC   = Date2.UTC = Date.UTC;

function Date2_parse(string) {
  // parse ISO date
  var parts = String(string).match(_DATE_PATTERN);
  if (parts) {
    var month = parts[_DATE_PARTS.Month];
    if (month) parts[_DATE_PARTS.Month] = String(month - 1); // js months start at zero
    // round milliseconds on 3 digits
    if (parts[_TIMEZONE_PARTS.Hectomicroseconds] >= 5) parts[_DATE_PARTS.Milliseconds]++;
    var utc = parts[_TIMEZONE_PARTS.UTC] || parts[_TIMEZONE_PARTS.Hours] ? "UTC" : "";
    var date = new Date(0);
    if (parts[_DATE_PARTS.Date]) date["set" + utc + "Date"](14);
    for (var part in _DATE_PARTS) {
      var value = parts[_DATE_PARTS[part]];
      if (value) {
        // set a date part
        date["set" + utc + part](value);
        // make sure that this setting does not overflow
        if (date["get" + utc + part]() != parts[_DATE_PARTS[part]]) {
          return NaN;
        }
      }
    }
    // timezone can be set, without time being available
    // without a timezone, local timezone is respected
    if (parts[_TIMEZONE_PARTS.Hours]) {
      var hours = Number(parts[_TIMEZONE_PARTS.Sign] + parts[_TIMEZONE_PARTS.Hours]);
      var minutes = Number(parts[_TIMEZONE_PARTS.Sign] + (parts[_TIMEZONE_PARTS.Minutes] || 0));
      date.setUTCMinutes(date.getUTCMinutes() + (hours * 60) + minutes);
    }
    return date - 0;
  } else {
    return /^[TZ\d:.+-]+$/.test(string) ? NaN : Date_parse(string);
  }
};
