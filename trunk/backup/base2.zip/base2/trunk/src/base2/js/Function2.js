
var Function2 = _createObject2(
  "Function",
  Function,
  "", {
    I: I, // base2
    II: II,
    K: K
  }, {
    bind: bind, // ES5
    
    delegate: delegate, // base2
    flip: flip,
    not: not,
    partial: partial,
    unbind: unbind
  }
);

if (I.bind) {
  Function2.bind = unbind(I.bind);
}

function I(i) { // Return first argument.
  return i;
};

function II(i, ii) { // Return second argument.
  return ii;
};

function K(k) {
  return function() {
    return k;
  };
};

function bind(fn, context) {
  ;;; assertType(fn, Function); // removed in packed version
  if (arguments.length > 2) {
    var args = _slice.call(arguments, 2);
    var bound = function _boundFunction() {
      return fn.apply(context, _concat.apply(args, arguments));
    };
  } else { // Faster if there are no additional arguments.
    bound = function _boundFunction() {
      return fn.apply(context, arguments);
    };
  }
  ;;; bound._underlyingFunction = fn._underlyingFunction || fn;
  return bound;
};

function delegate(fn) {
  ;;; assertType(fn, Function); // removed in packed version
  function _delegatedMethod() {
    _unshift.call(arguments, this);
    return fn.apply(this, arguments);
  };
  ;;; _delegatedMethod._underlyingFunction = fn._underlyingFunction || fn;
  return _delegatedMethod;
};

function flip(fn) {
  ;;; assertType(fn, Function); // removed in packed version
  // Swap the first two arguments in a function.
  function _flippedFunction() {
    return fn.apply(this, Array2_swap(arguments, 0, 1));
  };
  ;;; _flippedFunction._underlyingFunction = fn._underlyingFunction || fn;
  return _flippedFunction;
};

function not(fn) {
  ;;; assertType(fn, Function); // removed in packed version
  // Negate the return value of a function.
  function _notFunction() {
    return !fn.apply(this, arguments);
  };
  ;;; _notFunction._underlyingFunction = fn._underlyingFunction || fn;
  return _notFunction;
};

function partial(fn) { // Based on Oliver Steele's version.
  ;;; assertType(fn, Function); // removed in packed version
  // Partial evaluation.
  var args = _slice.call(arguments, 1);
  function _partialFunction() {
    var specialised = args.concat(), i = 0, j = 0;
    while (i < args.length && j < arguments.length) {
      if (typeof specialised[i] == "undefined") {
        specialised[i] = arguments[j++];
      }
      i++;
    }
    while (j < arguments.length) {
      specialised[i++] = arguments[j++];
    }
    if (Array2.indexOf(specialised, undefined) !== -1) {
      specialised.unshift(fn);
      return partial.apply(null, specialised);
    }
    return fn.apply(this, specialised);
  };
  ;;; _partialFunction._underlyingFunction = fn._underlyingFunction || fn;
  return _partialFunction;
};

function unbind(fn) {
  ;;; assertType(fn, Function); // removed in packed version
  // Unbind a method from an object, returns a function that takes a new parameter which would have been the "this" object
  function _unboundFunction() {
    return arguments.length > 1 ? fn.apply(arguments[0], _slice.call(arguments, 1)) : fn.call(arguments[0]);
  };
  ;;; _unboundFunction._underlyingFunction = fn._underlyingFunction || fn;
  return _unboundFunction;
};
