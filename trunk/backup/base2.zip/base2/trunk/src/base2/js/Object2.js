
// Some code from the Narwhal project:

// -- kriskowal Kris Kowal Copyright (C) 2009-2010 MIT License
// -- tlrobinson Tom Robinson
// dantman Daniel Friesen

/*!
    Copyright (c) 2009, 280 North Inc. http://280north.com/
    MIT License. http://github.com/280north/narwhal/blob/master/README.md
*/

var SUPPORTS_GETTERS = !!_Object_prototype.__defineGetter__;

var _hasOwnProperty = _Object_prototype.hasOwnProperty;

var Object2 = _createObject2(
  "Object",
  Object,
  "", {
    create: Object2_create,
    defineProperties: Object2_defineProperties,
    defineProperty: Object2_defineProperty,
    getOwnPropertyNames: Object2_getOwnPropertyNames,
    getPrototypeOf: Object2_getPrototypeOf,
    keys: Object2_keys,

    // Fake the rest
    freeze: I,
    getOwnPropertyDescriptor: Undefined,
    isExtensible: True,
    isFrozen: False,
    isSealed: False,
    preventExtensions: I,
    seal: I
  }
);

function Object2_keys(object) {
  var keys = [], i = 0;
  for (var propertyName in object) {
    if (_hasOwnProperty.call(object, propertyName)) {
      keys[i++] = propertyName;
    }
  }
  return keys;
};

function Object2_getOwnPropertyNames(object) {
  var keys = [], i = 0;
  for (var propertyName in object) {
    if (_hasOwnProperty.call(object, propertyName)) {
      keys[i++] = propertyName;
    }
  }
  return keys;
};

function Object2_getPrototypeOf(object) {
  return object.__proto__ || object.constructor.prototype;
};

function Object2_getOwnPropertyDescriptor() {
  return {}; // XXX
};

function Object2_create(prototype, properties) {
  var object = pcopy(prototype);
  if (properties != null) {
    Object2_defineProperties(object, properties);
  }
  return object;
};

function Object2_defineProperties(object, properties) {
  for (var propertyName in properties) {
    if (_hasOwnProperty.call(properties, propertyName))
      Object2_defineProperty(object, propertyName, properties[propertyName]);
  }
  return object;
};

function Object2_defineProperty(object, propertyName, descriptor) {
  if (descriptor == null) {
    throw new TypeError("Property descriptor cannot be null");
  }
  if ("get" in descriptor) {
    var get = descriptor.get;
    if (typeof get != "function") {
      throw new TypeError("Getter must be a function");
    }
  }
  if ("set" in descriptor) {
    var set = descriptor.set;
    if (typeof set != "function") {
      throw new TypeError("Setter must be a function");
    }
  }
  if ((get || set) && (descriptor.writable || "value" in descriptor)) {
    throw new TypeError("A property cannot both have accessors and be writable or have a value");
  }
  if ("value" in descriptor) {
    object[propertyName] = descriptor.value;
  } else if (SUPPORTS_GETTERS) {
    if (get) object.__defineGetter__(propertyName, get);
    if (set) object.__defineSetter__(propertyName, set);
  } else {
    object[propertyName] = undefined;
  }
  return object;
};
