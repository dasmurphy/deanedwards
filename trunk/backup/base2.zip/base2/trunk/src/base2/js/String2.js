
var String2 = _createObject2(
  "String",
  function(string) { // faux constructor
    return new String(arguments.length === 0 ? "" : string);
  },
  "charAt,charCodeAt,concat,indexOf,lastIndexOf,match,replace,search,slice,split,substr,substring,toLowerCase,toUpperCase", // generics (Mozilla)
  {
    csv: csv // base2
  },
  {
    trim: trim, // ES5
    
    trimLeft: String2_trimLeft, // Mozilla
    trimRight: String2_trimRight
    
  }
);

function csv(string) {
  return String(string).split(/\s*,\s*/);
};

// http://blog.stevenlevithan.com/archives/faster-trim-javascript
function trim(string) {
  return String(string).replace(_LTRIM, "").replace(_RTRIM, "");
};

function String2_trimLeft(string) {
  return String(string).replace(_LTRIM, "");
};

function String2_trimRight(string) {
  return String(string).replace(_RTRIM, "");
};
