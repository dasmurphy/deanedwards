
var Array2_methods = pcopy(_Enumerable_methods, {
  filter: Array2_filter, // ES5
  forEach: Array2_forEach,
  indexOf: Array2_indexOf,
  lastIndexOf: Array2_lastIndexOf,
  map: Array2_map,
  reduce: Array2_reduce,
  reduceRight: Array2_reduceRight,

  batch: Array2_batch, // base2
  combine: Array2_combine,
  contains: Array2_contains,
  flatten: Array2_flatten,
  insertAt: Array2_insertAt,
  item: Array2_item,
  remove: Array2_remove,
  removeAt: Array2_removeAt,
  swap: Array2_swap
});

var Array2 = _createObject2(
  "Array",
  Array,
  "concat,join,pop,push,reverse,shift,slice,sort,splice,unshift", // generics (Mozilla)
  {isArray: Array2_isArray}, // ES5
  Array2_methods
);

if (!Array2.some("a", True)) { // generic function can't handle strings
  Base.forEach (Array2_methods, function(method, name) {
    Array2[name] = method;
  });
}

function Array2_isArray(object) {
  return instanceOf(object, Array);
};

function Array2_filter(array, test, context) {
  var enumerable = array;
  if (array == null) {
    enumerable = array = global;
  } else if (typeof array == "string") {
    enumerable = array.split("");
    array = new String(array);
  }
  var length = array.length || 0; // preserve length
  var result = [];
  var item, j = 0;
  for (var i = 0; i < length; i++) if (i in enumerable) {
    if (test.call(context, item = enumerable[i], i, array)) {
      result[j++] = item;
    }
  }
  return result;
};

function Array2_forEach(array, eacher, context) {
  var enumerable = array;
  if (array == null) {
    enumerable = array = global;
  } else if (typeof array == "string") {
    enumerable = array.split("");
    array = new String(array);
  }
  var length = array.length || 0; // preserve length
  for (var i = 0; i < length; i++) if (i in enumerable) {
    eacher.call(context, enumerable[i], i, array);
  }
};

function Array2_indexOf(array, item, fromIndex) {
  if (typeof array == "string") {
    array = array.split("");
  }
  if (array) {
    var length = array.length;
    if (fromIndex == null) {
      fromIndex = 0;
    } else if (fromIndex < 0) {
      fromIndex = Math.max(0, length + fromIndex);
    }
    for (var i = fromIndex; i < length; i++) {
      if (array[i] === item) return i;
    }
  }
  return -1;
};

function Array2_lastIndexOf(array, item, fromIndex) {
  if (typeof array == "string") {
    array = array.split("");
  }
  if (array) {
    var length = array.length;
    if (fromIndex == null) {
      fromIndex = length - 1;
    } else if (fromIndex < 0) {
      fromIndex = Math.max(0, length + fromIndex);
    }
    for (var i = fromIndex; i >= 0; i--) {
      if (array[i] === item) return i;
    }
  }
  return -1;
};

function Array2_map(array, mapper, context) {
  var enumerable = array;
  if (array == null) {
    enumerable = array = global;
  } else if (typeof array == "string") {
    enumerable = array.split("");
    array = new String(array);
  }
  var length = array.length || 0; // preserve length
  var result = [];
  for (var i = 0; i < length; i++) if (i in enumerable) {
    result[i] = mapper.call(context, enumerable[i], i, array);
  }
  return result;
};

function Array2_reduce(array, reducer, result) {
  var enumerable = array;
  if (array == null) {
    enumerable = array = global;
  } else if (typeof array == "string") {
    enumerable = array.split("");
    array = new String(array);
  }
  var length = array.length || 0; // preserve length
  var initialised = arguments.length > 2;
  for (var i = 0; i < length; i++) if (i in enumerable) {
    if (initialised) {
      result = reducer.call(null, result, enumerable[i], i, array);
    } else {
      result = enumerable[i];
      initialised = true;
    }
  }
  if (!initialised) throw new TypeError(NOTHING_TO_REDUCE_ERR);
  return result;
};

function Array2_reduceRight(array, reducer, result) {
  var enumerable = array;
  if (array == null) {
    enumerable = array = global;
  } else if (typeof array == "string") {
    enumerable = array.split("");
    array = new String(array);
  }
  var length = array.length || 0; // preserve length
  var initialised = arguments.length > 2;
  for (var i = length - 1; i >= 0; i--) if (i in enumerable) {
    if (initialised) {
      result = reducer.call(null, result, enumerable[i], i, array);
    } else {
      result = enumerable[i];
      initialised = true;
    }
  }
  if (!initialised) throw new TypeError(NOTHING_TO_REDUCE_ERR);
  return result;
};

function Array2_slice(array, start, end) {
  if (!array || !array.length) return [];

  if (typeof array == "string") {
    array = array.split("");
  }

  if (typeof array.constructor == "function") {
    return _slice.apply(array, _slice.call(arguments, 1));
  }
  
  var result = [],
      length = array.length;

  start = _clamp(start, length);
  end = isNaN(end) ? length : _clamp(end, length);

  for (var i = start, j = 0; i < end; i++) {
    result[j++] = array[i];
  }

  return result;
};

try {
  var canSliceNodeLists = _slice.call(document.childNodes) instanceof Array;
} catch (ex) {}

if (!canSliceNodeLists) {
  Array2.slice = Array2_slice;
}

function _clamp(value, length) {
  value |= 0;
  if (value < 0) value += length;
  return value < 0 ? 0 : value > length ? length : value;
};

// base2 extensions

function _isArrayLike(object) {
  // is the object like an array?
  return object && typeof object == "object" && typeof object.length == "number";
};

function Array2_batch(array, block, timeout, oncomplete, context) {
  var index = 0,
      length = array.length;
  function _batch_function() {
    var time = now(), start = time, k = 0;
    while (index < length && (time - start < timeout)) {
      block.call(context, array[index], index++, array);
      if (k++ < 5 || k % 50 === 0) time = now();
    }
    if (index < length) {
      setTimeout(_batch_function, 50);
    } else {
      if (oncomplete) oncomplete.call(context);
    }
  };
  setTimeout(_batch_function, 1);
};

function Array2_combine(keys, values) {//#0
  // Combine two arrays to make a hash.
  if (!values) values = keys;
  return Array2.reduce(keys, function(hash, key, index) {
    hash[key] = values[index];
    return hash;
  }, {});
};

function Array2_contains(array, item) {//#1
  return Array2.indexOf(array, item) !== -1;
};

function Array2_flatten(array) {//#1
  var i = 0;
  function _flatten(result, item) {
    if (_isArrayLike(item)) {
      Array2.reduce(item, _flatten, result);
    } else {
      result[i++] = item;
    }
    return result;
  };
  return Array2.reduce(array, _flatten, []);
};

function Array2_insertAt(array, index, item) {//#0
  Array2.splice(array, index, 0, item);
};

function Array2_item(array, index) {
  if (typeof array == "string") {
    array = array.split("");
  }
  var item;
  if ((index -= 0) < 0) index += array.length;
  if (index >= 0) item = array[index];
  return item;
};

function Array2_remove(array, item) {//#0
  var index = Array2.indexOf(array, item);
  if (index !== -1) Array2.splice(array, index, 1);
};

function Array2_removeAt(array, index) {//#0
  Array2.splice(array, index, 1);
};

function Array2_swap(array, index1, index2) {
  if (index1 < 0) index1 += array.length; // starting from the end
  if (index2 < 0) index2 += array.length;
  var temp = array[index1];
  array[index1] = array[index2];
  array[index2] = temp;
  return array;
};

// introspection (removed when packed)
;;; Enumerable["#implemented_by"].push(Array2);
;;; Array2["#implements"].push(Enumerable);
