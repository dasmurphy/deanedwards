
function _createObject2(name, _constructor, generics, statics, extensions) {
  // Clone native objects and extend them.
  
  var Native = global[name],
      proto = Native.prototype,
      name2 = name + 2,
      Native2 = function() {
        if (this.constructor == Native2) { // constructing
          var object2 = _constructor.apply(null, arguments);
          var shouldBind = !isBound;
        } else { // casting
          object2 = arguments[0];
          shouldBind = !(isBound && object2 instanceof Native);
        }
        if (shouldBind) {
          for (var i in proto2) {
            object2[i] = proto2[i];
          }
        }
        return object2;
      },
      proto2 = Native2.prototype,
      namespace = "";
  
  // http://developer.mozilla.org/en/docs/New_in_JavaScript_1.6#Array_and_String_generics
  generics = generics.split(",");
  for (var i = 0; name = generics[i]; i++) {
    Native2[name] = Native[name] || unbind(proto[name]);
    namespace += "var " + name + "=" + name2 + "." + name + ";";
  }
  
  for (name in statics) {
    Native2[name] =  Native[name] || statics[name];
    namespace += "var " + name + "=" + name2 + "." + name + ";";
  }
  
  for (var i = 4, methods; methods = arguments[i]; i++) {
    for (name in methods) {
      var method = methods[name];
      var protoMethod = proto[name];
      Native2[name] = Native[name] || (protoMethod ? unbind(protoMethod) : method);
      if (!protoMethod) {
        proto2[name] = delegate(method);
      }
      namespace += "var " + name + "=" + name2 + "." + name + ";";
    }
  }

  Native2.toString = K("[base2." + name2 + "]");
  Native2.namespace = namespace;

  // introspection (removed when packed)
  ;;; Native2["#implements"] = [];
  ;;; Native2["#implemented_by"] = [];

  return Native2;
};
