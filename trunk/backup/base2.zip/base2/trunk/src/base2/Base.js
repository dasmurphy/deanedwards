
// http://dean.edwards.name/weblog/2006/03/base/

var _Base_static = {
  ancestor: Object,
  
  ancestorOf: function(klass) {
    return klass && klass.prototype instanceof this;
  },

  base: function() {
    // Call this method from any other method to invoke that method's ancestor.
  },

  extend: function(_instance, _static) {
    // Build the prototype.
    base2.__prototyping = this.prototype;
    var _prototype = new this;
    if (_instance) extend(_prototype, _instance);
    _prototype.base = function() {
      // Call this method from any other method to invoke that method's ancestor.
    };
    delete base2.__prototyping;

    // Create the wrapper for the constructor function.
    var _constructor = _prototype.constructor;
    function _base2_constructor() {
      // Don't call the constructor function when prototyping.
      if (!base2.__prototyping) {
        if (this.constructor == _base2_constructor || this.__constructing) {
          // Instantiation.
          this.__constructing = true;
          _constructor.apply(this, arguments);
          delete this.__constructing;
        } else {
          // Casting.
          var object = arguments[0];
          // Convert primitives to objects.
          if (_PRIMITIVE_TYPE.test(typeof object)) {
            object = new object.constructor(object);
          }
          base2.__casting = true;
          extend(object, _prototype);
          delete base2.__casting;
          
          return object;
        }
      }
      return this; // for strict engines
    };
    _prototype.constructor = _base2_constructor;

    // Build the static interface.
    for (var i in _Base_static) {
      _base2_constructor[i] = this[i];
    }
    if (_static) extend(_base2_constructor, _static);
    _base2_constructor.ancestor = this;
    _base2_constructor.prototype = _prototype;
    if (_base2_constructor.init) _base2_constructor.init();

    ;;; // introspection (removed when packed)
    ;;; _base2_constructor["#implements"] = [];
    ;;; _base2_constructor["#implemented_by"] = [];

    return _base2_constructor;
  },

  forEach: function(object, eacher, context) {
    _Object_forEach(object, eacher, context, this);
  },

  implement: function(_interface) {
    if (typeof _interface == "function") {
      ;;; // introspection (removed when packed)
      ;;; if (_interface.prototype instanceof Base) {
        ;;; this["#implements"].push(_interface);
        ;;; _interface["#implemented_by"].push(this);
      ;;; }
      _interface = _interface.prototype;
    }
    // Add the interface using the extend() function.
    base2.__casting = true;
    extend(this.prototype, _interface);
    delete base2.__casting;
    return this;
  }
};

var Base = _Base_static.extend.call(Object, {
  constructor: function(properties) {
    if (properties) extend(this, properties);
  },

  toString: function() {
    if (this.constructor.toString == _Function_prototype.toString) {
      return "[object base2.Base]";
    } else {
      return "[object " + this.constructor.toString().slice(1, -1) + "]";
    }
  }
}, _Base_static);

Base.ancestor = null;
