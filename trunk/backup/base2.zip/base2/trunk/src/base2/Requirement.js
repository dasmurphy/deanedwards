
var loadedScripts = {},
    urlResolver = isBrowser ? document.createElement("script") : null;

var Requirement = Base.extend({
  constructor: function(objectID, src, owner) {
    this.toString = K(src + "#" + objectID);
    this.tick = bind(new Function("try{this.object=" + objectID + "}catch(ex){}"), this);
    this.tick();
    if (!this.object && src) {
      src = this.resolve(src);
      if (!loadedScripts[src]) {
        loadedScripts[src] = true;
        this.load(src, owner.async);
        this.tick();
      }
    }
  },

  load: function(src) { // for non-browser environments (e.g. WSH)
    if (_private.createXHR == Null) {
      throw new Error("base2.require is not supported on this platform.");
    } else {
      // This will only work for base2 packages and other scripts that run in a closure.
      new Function(load(src))();
    }
  },

  resolve: I,

  "@(global.load)": { // Rhino
    load: global.load
  },

  "@(base2.userAgent!='')": { // browser
    load: function(src, async) {
      // load the external script
      var firstScript = document.getElementsByTagName("script")[0];
      var script = document.createElement("script");
      if (async || _private.createXHR == Null) {
        script.src = src;
      } else {
        script.text = load(src);
      }
      firstScript.parentNode.insertBefore(script, firstScript);
    },

    resolve: function(src) {
      urlResolver.src = src;
      return urlResolver.src;
    }
  }
});
