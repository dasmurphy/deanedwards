
var OBJECT_REQUIRED_ERR   = "Object required by {0}().";
var FUNCTION_REQUIRED_ERR = "Function required by {0}().";
var REDUCE_ERR = "Nothing to reduce.";

function Arity(/*[message, ]method[, object]*/) {
  return(formatErrorMessage("Not enough arguments for {0}().", arguments));
}

function Target(/*[message, ]method[, object]*/) {
  return(formatErrorMessage("Invalid target for {0}().", arguments));
}

function formatErrorMessage(message, args) {
  var method = args[1];
  var object = args[2];

  switch (args.length) {
    case 0:
      break;

    case 1:
      if (/\s/.test(args[0])) {
        message = args[0];
      } else {
        method = args[0];
      }
      break;

    case 2:
      if (typeof args[1] == "string") {
        message = args[0];
      } else {
        method = args[0];
        object = args[1];
      }
      break;

    default:
      message = args[0];
  }

  if (method == null) {
    return message.replace(/ \w+ \{0\}\(\)/, "");
  } else {
    if (object) {
      if (!method || method in object) {
        var separator = ".";
        if (typeof object == "object") {
          if (typeof object.name == "string") {
            object = object.name;
          } else {
            object = object.constructor;
            separator = "::";
          }
        }
        if (typeof object == "function" || separator === "::") {
          object = getClassName(object);
          if (!object) separator = "";
        }
        method = object + separator + method;
      }
    }
    message = format(message, method);
    message = message.replace("Namespace::", "_.");
    return message;
  }
}
