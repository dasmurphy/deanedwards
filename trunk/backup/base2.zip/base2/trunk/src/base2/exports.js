
base2.exports = {
  Undefined: Undefined,
  Null: Null,
  False: False,
  True: True,
  This : This,
  Base: Base,
  Package: Package,
  Abstract: Abstract,
  Trait: Trait,
  Enumerable: Enumerable,
  Map: Map,
  Collection: Collection,
  RegGrp: RegGrp,
  JSON: base2.JSON,
  Array2: Array2,
  Date2: Date2,
  Function2: Function2,
  String2: String2,
  assignID: assignID,
  detect: detect,
  global: global
};

base2 = global.base2 = new Package(base2);
