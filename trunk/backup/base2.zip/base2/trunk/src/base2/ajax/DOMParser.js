
function DOMParser() {
};

DOMParser.prototype.parseFromString = function(string) {
  var xml	= createCOMOBject("Microsoft.XMLDOM");
  xml.async = false;
  xml.validateOnParse	= false;
  xml.loadXML(string);
  return xml.documentElement ? xml : null;
};
