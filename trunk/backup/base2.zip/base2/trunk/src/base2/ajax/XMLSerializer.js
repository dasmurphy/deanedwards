
function XMLSerializer() {
};

XMLSerializer.prototype.serializeToString = function(node) {
  return node ? node.xml || "" : "";
};
