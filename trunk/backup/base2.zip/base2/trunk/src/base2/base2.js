
base2 = new Package({
  name:   "base2",
  version: "%%VERSION%%",
  
  Base: Base,
  Collection: Collection,
  Package: Package,
  RegGrp: RegGrp,
  Trait: Trait,
  
  ArrayLike: ArrayLike,
  Functional: Functional,

  assignID: assignID,
  detect: detect,
  
  info: function info(key) {
    return key == "*" ? qcopy(base2_info) : base2_info[key];
  }
});

base2.lang = new Package({
  name:   "base2.lang",
  version: "%%VERSION%%",

  extend: extend,
  forEach: forEach,

  isArray: Array_isArray,
  isFunction: isFunction,

  format: format,
  trim: trim
});
