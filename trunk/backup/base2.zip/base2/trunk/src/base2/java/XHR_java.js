
// XMLHttpRequest
// Original by Yehuda Katz

function XMLHttpRequest() {
  this.headers = {};
  this.responseHeaders = {};
};

XMLHttpRequest.prototype = {
  async: true,
  readyState: 0,
  responseText: "",
  status: 0,
  
  open: function(method, url, async, user, password) {
    this.readyState = 1;
    if (async) this.async = true;
    this.method = method;
    this.url = url;
    this.password = password;
    this.onreadystatechange();
  },

  setRequestHeader: function(header, value) {
    this.headers[header] = value;
  },

  send: function(data) {
    var self = this;

    function makeRequest() {
      var url = new java.net.URL((new java.io.File("./")).toURL(), self.url);
      
      var connection = url.openConnection();

      connection.setRequestMethod(self.method);

      // Add headers to Java connection
      for (var header in self.headers) {
        connection.addRequestProperty(header, self.headers[header]);
      }

      connection.connect();

      for (var i = 0; ; i++) {
        var headerName = connection.getHeaderFieldKey(i);
        var headerValue = connection.getHeaderField(i);
        if (!headerName && !headerValue) break;
        if (headerName) {
          self.responseHeaders[headerName] = headerValue;
        }
      }

      self.readyState = 4;
      self.status = parseInt(connection.responseCode) || 0;
      self.statusText = connection.responseMessage || "";
      
      if (self.status === 200 || self.status === 304) {
        var stream = new java.io.InputStreamReader(connection.getInputStream());
        var buffer = new java.io.BufferedReader(stream), line;
        var responseText = "";
        while ((line = buffer.readLine()) != null) {
          responseText += line;
        }
        self.responseText = responseText;

        if (responseText.match(/^\s*</)) {
          try {
            responseText = responseText.replace(/^<\?xml\s+version\s*=\s*(["'])[^\1]+\1[^?]*\?>/, "");
            self.responseXML = new XML(responseText);
          } catch(e) {
            // It might not be XML anyway
          }
        }
      }
      
      connection.disconnect();

      self.onreadystatechange();
    };

    if (this.async) {
      new java.lang.Thread(new java.lang.Runnable({run: makeRequest})).start();
    } else {
      makeRequest();
    }
  },
  
  abort: function(){},
  
  onreadystatechange: function(){},
  
  getResponseHeader: function(header) {
    header = base2.String2.toLowerCase(header);
    return header in this.responseHeaders ? this.responseHeaders[header] : null;
  },
  
  getAllResponseHeaders: function() {
    return base2.Enumerable.reduce(this.headers, function(headers, header, value) {
      headers.push(header + ": " + value);
    }, []).join("\r\n");
  }
};