
// Timers

(function() {
  var timers = {}
  var timer_id = 1337;
  
  var lang = base2.lang;
  lang.addName("clearInterval", clearInterval);
  lang.addName("clearTimeout", clearTimeout);
  lang.addName("setInterval", setInterval);
  lang.addName("setTimeout", setTimeout);

  function clearInterval(id) {
  	destroyTimer(id);
  };

  function clearTimeout(id) {
  	destroyTimer(id);
  };

  function setInterval(fn, interval) {
  	return createTimer(fn, interval, true);
  };

  function setTimeout(fn, interval) {
  	return createTimer(fn, interval);
  };

  function destroyTimer(id) {
  	if (timers[id]) {
  		timers[id].stop();
  		delete timers[id];
  	}
  };

  function createTimer(fn, interval, repeat) {
    var id = timer_id++;
  	var timer = new java.lang.Thread(new java.lang.Runnable({
  		run: function() {
  			do {
  				java.lang.Thread.currentThread().sleep(interval);
  				if (timers[id]) fn();
  				if (!repeat) destroyTimer(id);
  			} while (timers[id]);
  		}
  	}));
  	timers[id] = timer;
    timer.start();
  	return id;
  };
})();