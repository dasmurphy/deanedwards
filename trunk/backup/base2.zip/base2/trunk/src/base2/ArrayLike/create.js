
for (var name in Array_extras) ArrayLike_methods[name] = Array_extras[name];

var Array_extensions = {};
for (name in []) Array_extensions[name] = 1;
for (name in Array_extras) {
  if (Array_prototype[name] && !Array_extensions[name]) {
    ArrayLike_methods[name] = Array_prototype[name];
    delete Array_extras[name];
  }
}

Array__forEach = Array_extras.forEach || Array__forEach;
Array__indexOf = Array_extras.indexOf || Array__indexOf;

Array_extras.slice =
ArrayLike_methods.slice = function ArrayLike__slice(start, end) {
  // You should only see this code in MSIE6-8.
  var result = this;
  if (!result.valueOf) { // not a COM object
    result = [];
    var length = this.length >>> 0;
    for (var i = 0; i < length; i++) {
      result[i] = this[i];
    }
  }
  return Array__slice.apply(result, arguments);
};

try {
  if (!isBrowser || Array__slice.call(document.childNodes) instanceof Array) {
    ArrayLike_methods.slice = Array__slice;
    delete Array_extras.slice;
  }
} catch (ex) {}

ArrayLike = Trait.extend();

extend(ArrayLike.prototype, ArrayLike_methods);

_Trait_createStaticMethods(ArrayLike, Array_prototype);

var ArrayLike_map = ArrayLike.map;
