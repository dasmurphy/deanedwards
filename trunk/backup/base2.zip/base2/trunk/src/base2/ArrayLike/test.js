
Collection.implement(ArrayLike);

ArrayLike.test = function ArrayLike_test(object) {
  if (object == null) return false;

  switch (typeof object) {
    case "string": return true;

    case "function": if (object.call) return false;
      // fall through to catch Safari NodeLists

    case "object":
      if (typeof object.length == "number") return true;
      return /*@ object.imap && @*/ object instanceof Collection;
  }

  return false;
};
