
var NOTHING_TO_REDUCE_ERR = "Nothing to reduce.";

var _Enumerable_methods = {
  every: every,
  filter: filter,
  invoke: invoke,
  map: map,
  plant: plant,
  pluck: pluck,
  reduce: reduce,
  some: some
};

var Enumerable = Trait.extend(_Enumerable_methods);

function every(enumerable, test, context) {
  var result = true;
  try {
    forEach (enumerable, function(item, key) {
      result = test.call(context, item, key, enumerable);
      if (!result) throw StopIteration;
    });
  } catch (error) {
    if (error != StopIteration) throw error;
  }
  return !!result; // cast to boolean
};

function filter(enumerable, test, context) {
  if (enumerable instanceof Map) {
    return enumerable.filter(test, context);
  } else if (_isArrayLike(enumerable) || typeof enumerable == "string") {
    return Array2.filter(enumerable, test, context);
  } else {
    var result = {};
    forEach (enumerable, function(item, key) {
      if (test.call(context, item, key, enumerable)) {
        result[key] = item;
      }
    });
    return result;
  }
};

function invoke(enumerable, method) {
  // Apply a method to each item in the enumerated enumerable.
  var args = _slice.call(arguments, 2);
  return map(enumerable, typeOf(method) === "function" ? function(item) {
    var value = item == null ? undefined : method.apply(item, args);
    return value;
  } : function(item) {
    var value = item == null ? undefined : item[method].apply(item, args);
    return value;
  });
};

function map(enumerable, mapper, context) {
  if (enumerable instanceof Map) {
    return enumerable.map(mapper, context);
  } else if (_isArrayLike(enumerable) || typeof enumerable == "string") {
    return Array2.map(enumerable, mapper, context);
  } else {
    var result = {};
    forEach (enumerable, function(item, key) {
      result[key] = mapper.call(context, item, key, enumerable);
    });
    return result;
  }
};

function plant(enumerable, propertyName, value) {
  forEach (enumerable, typeOf(value) == "function" ? function(item) {
    if (item != null) item[propertyName] = value(item, propertyName);
  } : function(item) {
    if (item != null) item[propertyName] = value;
  });
};

function pluck(enumerable, propertyName) {
  var result = [], i = 0;
  forEach (enumerable, function(item) {
    result[i++] = item == null ? undefined : item[propertyName];
  });
  return result;
};

function reduce(enumerable, reducer, result) {
  if (_isArrayLike(enumerable) || typeof enumerable == "string") {
    return Array2.reduce(enumerable, reducer, result);
  } else {
    var initialised = arguments.length > 2;
    forEach (enumerable, function(item, key) {
      if (initialised) {
        result = reducer(result, item, key, enumerable);
      } else {
        result = item;
        initialised = true;
      }
    });
    if (!initialised) throw new TypeError(NOTHING_TO_REDUCE_ERR);
    return result;
  }
};

function some(enumerable, test, context) {
  return !every(enumerable, not(test), context);
};
