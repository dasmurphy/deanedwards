
var fx = new Package({
  name:    "fx",
  version: "0.5",
  
  exports: {
    Animation: Animation,
    timingFunctions: timingFunctions
  }
});
