
var TransitionQueue = Collection.extend({
  constructor: function(transitions) {
    this.base(transitions);
    this.tick = bind(this.tick, this);
  },
  
  /*add: function(object, propertyName, params) {
    var key = Transition.getKey(object, propertyName, params),
        transition = this.get(key);
    if (transition) {
      if (transition.duration != params.duration) {
        transition.setSpeed(transition.duration / (params.duration || 1)); // change gears
        if (transition.compare(params.end, "end")) {
          return transition;
        }
      }
      if (transition.compare(params.end, "start")) { // flipped start/end points indicate the reversal of a transition
        transition.reverse();
        return transition;
      }
    }
    transition = this.put(key, object, propertyName, params);
    if (!this._timer) {
      this._timer = setTimeout(this.tick, _INTERVAL);
    }
    return transition;
  },*/

  add: function(object, propertyName, params) {
    var transition = this.put(Transition.getKey(object, propertyName, params), object, propertyName, params);
    if (!this._timer) {
      this._timer = setTimeout(this.tick, _INTERVAL);
    }
    return transition;
  },

  tick: function() {
    this.invoke("tick", now());

    var complete = this.filter(function(transition) {
      return transition.complete;
    });

    complete.forEach(this.remove, this);

    complete.forEach(function(transition) {
      var element = transition.styleElement;
      if (element) {
        var event = createEvent(element.ownerDocument, "Events");
        event.initEvent("transitionend", true, false);
        event.propertyName = transition.propertyName;
        event.elapsedTime = transition.elapsedTime / 1000;
        dispatchEvent(element, event);
      }
    });

    delete this._timer;
    if (this.size() > 0) {
      this._timer = setTimeout(this.tick, _INTERVAL);
    }
  }
}, {
  Item: Transition,

  createItem: function(key, object, propertyName, params) {
    return new this.Item(object, propertyName, params);
  }
});

var _queue = new TransitionQueue;
