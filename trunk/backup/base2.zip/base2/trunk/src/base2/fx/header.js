
eval(namespace); // import

var _DIGITS         = /\d+/g,
    _RGB_VALUE      = /\d+%?/g;
    
var _INTERVAL       = 20;

var _parseInt16 = partial(parseInt, undefined, 16);

function _split(value, fill) { // uased for splitting multiple CSS values
  if (value == null) return [];
  value = trim(value).split(/\s+/);
  if (fill) {
    if (value.length === 1) value[1] = value[0];
    if (value.length === 2) value[2] = value[0];
    if (value.length === 3) value[3] = value[1];
  }
  return value;
};
