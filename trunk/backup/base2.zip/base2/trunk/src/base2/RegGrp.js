
// A collection of regular expressions and their associated replacement values.
// A Base class for creating parsers.

var _PATTERNS = _KEYS;
var _COMPILED = "/";

var _REGGRP_BACK_REF        = /\\(\d+)/g,
    _REGGRP_ESCAPE_COUNT    = /\[(\\.|[^\]\\])+\]|\\.|\(\?/g,
    _REGGRP_PAREN           = /\(/g,
    _REGGRP_LOOKUP          = /\$(\d+)/,
    _REGGRP_LOOKUP_SIMPLE   = /^\$\d+$/,
    _REGGRP_LOOKUPS         = /(\[(\\.|[^\]\\])+\]|\\.|\(\?)|\(/g,
    _REGGRP_DICT_ENTRY      = /^<#\w+>$/,
    _REGGRP_DICT_ENTRIES    = /<#(\w+)>/g;

var RegGrp = Collection.extend({
  constructor: function(dictionary, values) {
    if (arguments.length === 1) {
      values = dictionary;
      dictionary = null;
    }
    if (dictionary) {
      this.dictionary = new RegGrp.Dict(dictionary);
    }
    this.base(values);
  },
  
  dictionary: null,
  ignoreCase: false,

  clear: _recompile,

  copy: function() {
    var result = this.base();
    if (this.dictionary) {
      result.dictionary = this.dictionary.copy();
    }
    return result;
  },

  exec: function(string, fn /* optional */) {
    var group = this,
        patterns = group[_PATTERNS],
        items = group[_ITEMS], item;
    group[_COMPILED] = new RegExp(group[_COMPILED] ? group[_COMPILED].source : group, group.ignoreCase ? "gi" : "g");
    var result = group[_COMPILED].exec(string);
    if (result) {
      // Loop through the RegGrp items.
      var i = 0, offset = 1;
      while ((item = items[_HASH + patterns[i++]])) {
        var next = offset + item.length + 1;
        if (result[offset]) { // do we have a result?
          if (item.replacement === 0) {
            return group.exec(string);
          } else {
            var args = result.slice(offset, next),
                j = args.length;
            while (--j) args[j] = args[j] || ""; // some platforms return null/undefined for non-matching sub-expressions
            args[0] = {match: args[0], item: item};
            return typeof fn == "function" ? fn.call(args) : args;
          }
        }
        offset = next;
      }
    }
    return null;
  },

  parse: function(string, _replacement /* optional */) {
    string += ""; // type safe
    var group = this,
        patterns = group[_PATTERNS],
        items = group[_ITEMS],
        regexp = group[_COMPILED];
    if (!patterns.length) return string;
    if (!regexp || regexp.ignoreCase !== !!group.ignoreCase) {
      regexp = group[_COMPILED] = new RegExp(regexp ? regexp.source : group, group.ignoreCase ? "gi" : "g");
    }
    return string.replace(regexp, function(match) {
      var args = [], item, offset = 1, i = arguments.length;
      while (--i) args[i] = arguments[i] || ""; // some platforms return null/undefined for non-matching sub-expressions
      // Loop through the RegGrp items.
      while ((item = items[_HASH + patterns[i++]])) {
        var next = offset + item.length + 1;
        if (args[offset]) { // do we have a result?
          var replacement = _replacement == null ? item.replacement : _replacement;
          switch (typeof replacement) {
            case "function":
              return replacement.apply(group, args.slice(offset, next));
            case "number":
              return args[offset + replacement];
            case "object":
              if (replacement instanceof RegGrp) {
                return replacement.parse(args[offset]);
              }
            default:
              return replacement;
          }
        }
        offset = next;
      }
      return match;
    });
  },

  removeAt: _recompile,
  reverse: _recompile,
  sort: _recompile,

  test: function(string) { // The slow way to do it. Hopefully, this isn't called too often. :)
    return this.parse(string) != string;
  },
  
  toString: function() {
    var patterns = this[_PATTERNS],
        string = patterns.join(")|(");
    if (this.dictionary || /\\\d/.test(string)) { // back refs
      var offset = 1,
          keys = patterns,
          items = this[_ITEMS], item;
      patterns = [];
      for (var i = 0; item = items[_HASH + keys[i]]; i++) {
        patterns[i] = item.source.replace(_REGGRP_BACK_REF, function(match, index) {
          return "\\" + (offset + ~~index);
        });
        offset += item.length + 1;
      }
      string = patterns.join(")|(");
    }
    return "(" + string + ")";
  }
}, {
  IGNORE: null, // a null replacement value means that there is no replacement.

  count: function(expression) {
    return (String(expression).replace(_REGGRP_ESCAPE_COUNT, "").match(_REGGRP_PAREN) || "").length;
  }
});

Array2_forEach("add,get,has,indexOf,insertAt,remove,put".split(","), function(name) {
  var index     = name === "insertAt" ? 1 : 0,
      recompile = name === "put" || name === "remove";
  _override(this, name, function() {
    if (arguments[index] instanceof RegExp) {
      arguments[index] = arguments[index].source;
    }
    if (recompile) delete this[_COMPILED];
    return this.base.apply(this, arguments);
  });
}, RegGrp.prototype);

function _recompile() {
  delete this[_COMPILED];
  return this.base.apply(this, arguments);
};
