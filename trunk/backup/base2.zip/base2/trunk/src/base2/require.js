
var isBrowser = !!base2.userAgent;

require.TIMEOUT = isBrowser ? 10000 : 0;

base2.host = "";

base2.exec = function(fn) {
  _exec(fn);
};

base2.require = require;

base2.ready = base2.exec;

function require(requirements, callback, async) {
  if (typeof requirements == "string") {
    var strings = csv(requirements);
    requirements = {};
    for (var i = 0; i < strings.length; i++) {
      var parts = strings[i].split("#");
      if (parts.length === 1) { // base2 identifiers
        var objectID = parts[0];
        if (!/^base2/.test(objectID)) {
          objectID = "base2." + objectID;
        }
        requirements[objectID] = base2.host + objectID.replace(/\./g, "/") + ".js";
      } else { // 3rd party scripts
        requirements[parts[1]] = parts[0];
      }
    }
  }
  return new Requirements(requirements, callback, async);
};

function _exec(fn, namespace, args) {
  args = args || [];
  args.unshift(
    "var undefined;var base2=$$base2[0].base2;" +
    base2.namespace +
    Enumerable.namespace +
    Function2.namespace +
    (namespace || "") +
    lang.namespace
  );
  fn.apply(null, args);
};

if (isBrowser) {
  if (document.addEventListener) {
    document.addEventListener("DOMContentLoaded", function _checkReadyState() {
      _private.isReady = true;
      this.removeEventListener("DOMContentLoaded", _checkReadyState, false);
    }, false);
  }
  
  // Get the current host.
  var host = location.pathname;
  var scripts = document.getElementsByTagName("script"), script, lastScript;
  var i = 0;
  while ((script = scripts[i++])) {
    if (script.id === "base2.js") break;
    if (script.src.indexOf("base2") !== -1) lastScript = script;
  }
  host = (script || lastScript || "").src || host;
  
  base2.host = host.replace(/[\?#].*$/, "").replace(/[^\/]*$/, "");

  base2.ready = function ready(fn) {
    require("dom", function() {
      deferUntil(function() { // defer
        _exec(fn, base2.dom.namespace);
      }, function() { // until
        return !!_private.isReady;
      });
    });
  };
}

function load(src) {
  var xhr = _private.createXHR();
  xhr.open("GET", src, false);
  xhr.send(null);
  if (xhr.status === 200) {
    return xhr.responseText;
  }
  return "";
};
