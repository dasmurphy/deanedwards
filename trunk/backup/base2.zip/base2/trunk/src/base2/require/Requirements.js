
// Private.

var Requirements = Collection.extend({
  constructor: function _Requirements__constructor(requirements, callback) {
    this.base();

    if (typeof requirements == "string") {
      requirements = csv(requirements);
    }

    if (Array_isArray(requirements)) {
      for (var i = 0; i < requirements.length; i++) {
        if (requirements[i]) this.add(requirements[i]);
      }
    }

    requirements = this;

    var total = requirements.size();
    var newSize = 0;

    deferUntil(function _defer() {
      // Create the namespace object.
      var args = requirements.pluck("object").items();
      args.unshift(new Namespace(args));
      // Execute the callback function.
      callback.apply(undefined, args);
    }, function _until() {
      var complete, oldSize = -1;
      while (newSize > oldSize) {
        oldSize = newSize;
        requirements.invoke("tick");
        complete = requirements.filter(_Requirement_isLoaded);
        newSize = complete.size();
      }
      return newSize === total;
    }, 0, TIMEOUT, function ontimeout() {
      throw new Error("Failed to load requirements: " + requirements);
    });
  },

  createItem: function _Requirements__createItem(requirement) {
    var idIndex = 0;
    var parts = requirement.split("#");
    if (parts.length > 1) {
      var fileName = parts[0];
      idIndex = 1;
    }

    var objectID = parts[idIndex].split("@");
    var test = objectID[1] || "";
    objectID = objectID[0];

    if (!fileName) {
      fileName = base2_host + objectID.replace(/\./g, "/") + ".js";
    }
    return this.base(objectID, fileName, test)
  },

  createKey: function _Requirements__createKey(requirement) {
    var parts = requirement.split("#");
    return parts[parts.length === 1 ? 0 : 1].split("@")[0];
  }
});

Requirements.Item = Requirement;

// help

function _Requirement_isLoaded(requirement) {
  return !!requirement.object;
}
