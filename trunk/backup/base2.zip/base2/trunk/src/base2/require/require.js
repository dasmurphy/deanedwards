
var TIMEOUT = isBrowser ? 20000 : 0;

var base2_host = "";

base2.exec = function exec(fn) {
  if (typeof fn == "string") {
    fn = commands[fn];
  }

  if (!isFunction(fn)) {
    throw new TargetError(FUNCTION_REQUIRED_ERR, "base2.exec");
  }

  return fn.call(undefined, new Namespace);
};

base2.require = function require(requirements, callback) {
  if (arguments.length < 2) {
    throw new ArityError("base2.require");
  }

  if (!isFunction(callback)) {
    throw new TargetError(FUNCTION_REQUIRED_ERR, "base2.require");
  }

  return new Requirements(requirements, callback);
};

base2.ready = function ready(callback) {
  if (!isFunction(callback)) {
    throw new TargetError(FUNCTION_REQUIRED_ERR, "base2.ready");
  }

  return fn.call(undefined, new Namespace);
};

base2.provide = function provide(id, object) {
  provides[id] = object;
};

if (isBrowser) {
  // Get the current host.
  var SUPPORTS_EVENT_LISTENER = !!document.addEventListener;
  var COMPLETE = SUPPORTS_EVENT_LISTENER ? /loaded|complete/ : /complete/;
  var loadedScripts = {};
  var scripts = document.getElementsByTagName("script"), script, firstScript;
  var head = document.getElementsByTagName("head")[0] || document.documentElement;
  var i = 0;
  while ((script = scripts[i++])) {
    if (script.id === "base2.js") break;
    if (!firstScript && /base2\b[\w.-]*\.js/.test(script.src)) firstScript = script;
  }
  base2_host = (script || firstScript || "").src || location.pathname;
  base2_host = base2_host.replace(/\?.*$/, "").replace(/[^\/]*$/, "");
  base2_info.host = base2_host;
  
  base2.ready = function ready(callback) {
    if (!isFunction(callback)) {
      throw new TargetError(FUNCTION_REQUIRED_ERR, "base2.ready");
    }

    base2.require("base2.dom", function(_, dom) {
      callback = Function__bind.call(callback, undefined, _, dom);
      
      deferUntil(callback, function() {
        return _private.isReady;
      });
    });
  };

  _private.isReady = COMPLETE.test(document.readyState);
  
  if (SUPPORTS_EVENT_LISTENER && !_private.isReady) {
    document.addEventListener("DOMContentLoaded", function() {
      _private.isReady = true;
    }, false);
  }
}
