
// Private.

var Requirement = Base.extend({
  constructor: function _Requirement__constructor(objectID, src, test) {
    if (objectID in provides) {
      this.getObject = K(provides[objectID]);
    } else {
      this.getObject = K(get(global, objectID));
    }
    this.objectID = objectID;
    this.test = test;
    this.tick();
    if (!this.object && src) {
      this.getObject = new Function("try{return " + objectID + "}catch(e){}");
      this.tick();
      if (!this.object) this.load(src);
    }
  },
  
  tick: function _Requirement__tick() {
    this.object = provides[this.objectID] || this.getObject();
    if (this.object && this.test) {
      if (!detect(this.test)) {
        delete detectCache[this.test];
        delete this.object;
      }
    }
  },

  load: function _Requirement__load(src) {
    throw new Error("base2: Lazy loading is not supported on this platform.");
  },

  /*
  "@(load)": { // Rhino
    load: function _Requirement__load(src) {
      load(src);
    }
  },

  "@(global.GLOBAL==global)": { // Node.js
    load: function _Requirement__load(src) {
      require(__dirname + "/" + src);
    }
  },
  
  "@(jscript)": { // WSH
    load: function _Requirement__load(src) {
      var xhr = createCOMObject("XMLHTTP");
      xhr.open("GET", src, false);
      xhr.send(null);
      if (xhr.status === 200) {
        var load = Function("g,_", xhr.responseText + ";this.object=g('" + this.objectID + "',_)");
        this.tick = Function__bind.call(load, this, getObject);
      }
    }
  },
  */

  "@(<script>)": { // browser
    load: _Requirement__load
  }
});

function _Requirement__load(src) {
  var i = 0, script;
  while ((script = scripts[i++])) {
    loadedScripts[script.src] = true;
  }
  
  if (loadedScripts[src]) return;
  loadedScripts[src] = true;
  
  script = document.createElement("script");

  /*@if (@_jscript_version < 5.8)
    var loaded = false;
    var isIE7 = detect("MSIE7");

    script.onreadystatechange = function() {
      switch (this.readyState) {
        case "loaded":
          loaded = true;
          if (isIE7) {
            this.onreadystatechange = null;
          } else {
            head.insertBefore(this, head.firstChild);
          }
          break;

        case "loading":
          // If readyState goes from "loaded" to "loading" then
          // something is wrong and we must reload the script.
          if (loaded) {
            this.onreadystatechange = null;
            this.removeAttribute("src");
            setTimeout(function() {
              delete loadedScripts[src];
              _Requirement__load(src);
            }, 500);
          }
          break;

        case "complete":
          this.onreadystatechange = null;
      }
    };
    script.src = src;
    if (isIE7) {
      head.appendChild(script);
    }
  @else @*/
    script.src = src;
    head.appendChild(script);
  /*@end @*/
}
