
var Function__bind = Function_prototype.bind;

function Functional__partial(/*, arg1/undefined, arg2/undefined, .. , argN */) {
  var fn = this;

  // Partial evaluation (based on Oliver Steele's version).
  var args = Array__slice.call(arguments);
  var partialFunction = function _partialFunction() {
    var specialised = args.concat();
    var length = arguments.length;
    var i = 0, j = 0;
    while (i < args.length && j < length) {
      if (typeof specialised[i] == "undefined") {
        specialised[i] = arguments[j++];
      }
      i++;
    }
    while (j < length) {
      specialised[i++] = arguments[j++];
    }
    while (i--) {
      if (typeof specialised[i] == "undefined") {
        return Functional__partial.apply(fn, specialised);
      }
    }
    return fn.apply(this, specialised);
  };
  ;doc; partialFunction._underlyingFunction = fn._underlyingFunction || fn;
  return partialFunction;
}

function isFunction(object) {
  return typeof object == "function" && typeof object.call == "function";
}

function I(i) { // identity
  return i; // returns first argument
}

function II(i, ii) {
  return ii; // returns second argument
}

function K(value) { // returns a constant function that always returns 'value'
  return function() {
    return value;
  };
}

var Functional = Trait.extend({
  bind: Function__bind,

  memoize: function Functional__memoize(keyFunction) {
    if (arguments.length > 0 && !isFunction(keyFunction)) {
      throw new TargetError(FUNCTION_REQUIRED_ERR, "memoize");
    }

    var fn = this;

    var memoizedFunction = function _memoizedFunction() {
      var cache = memoizedFunction.cache;

      if (keyFunction) {
        var key = keyFunction.apply(this, arguments);
      } else if (arguments.length > 1) {
        key = Array__slice.call(arguments, 0, fn.length).join("\x00");
      } else {
        key = String(arguments[0]);
      }

      if (!(key in cache)) {
        cache[key] = fn.apply(this, arguments);
      }

      return cache[key];
    };

    memoizedFunction.cache = {}; // expose the cache

    ;doc; memoizedFunction._underlyingFunction = fn._underlyingFunction || fn;

    return memoizedFunction;
  },

  partial: Functional__partial,

  unbind: function unbind() {
    var fn = this;

    // Unbind a method from an object.
    // Returns a function that has as its first parameter the object that would have been the "this" object.
    //
    // var slice = unbind([].slice);
    // var args = slice(arguments); // cast to Array

    var unboundFunction = function _unboundFunction(object) {
      if (object == null) throw new TargetError(OBJECT_REQUIRED_ERR);
      return Function__call.apply(fn, arguments);
    };
    ;doc; unboundFunction._underlyingFunction = fn._underlyingFunction || fn;
    return unboundFunction;
  }
}, {
  test: isFunction,

  I: I,
  II: II,
  K: K,
  Null: Null,
  False: False,
  True: True,
  Undefined: Undefined
});

;doc; for (var name in Functional) {
;doc;   if (/^(Null|False|True|Undefined)$/.test(name)) {
;doc;     Functional[name].toString = K("function " + name + "() {\n  return " + name.toLowerCase() + ";\n}");
;doc;   }
;doc; }
