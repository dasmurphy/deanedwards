
var Dispatcher = Base.extend({
  constructor: function(events) {
    this.events = events || {};
  },
  
  dispatch: dispatch
}, {
  BUBBLE_TARGET: ""
});

function dispatch(event) {
  var type = event.type;
  var target = event.target;
  var typeMap = this.events[type];
  if (typeMap) {
    // Collect nodes in the event hierarchy
    var BUBBLE_TARGET = this.constructor.BUBBLE_TARGET;
    var nodes = [], i = 0;
    while (target) {
      nodes[i++] = target;
      if (!BUBBLE_TARGET) break;
      target = target[BUBBLE_TARGET];
    }

    // Dispatch.
    var phaseMap = typeMap[CAPTURING_PHASE];
    if (phaseMap) {
      _dispatchPhase(event, CAPTURING_PHASE, nodes, phaseMap);
    }
    phaseMap = typeMap[BUBBLING_PHASE];
    if (phaseMap && !event.cancelBubble) {
      if (event.bubbles) {
        nodes.reverse();
      } else {
        nodes.length = 1;
      }
      _dispatchPhase(event, BUBBLING_PHASE, nodes, phaseMap);
    }
  } else {
    var ontype = "on" + type;
    if (target[ontype]) {
      callOutOfContext(target[ontype], target, event);
    }
  }
  return event.returnValue !== false;
};

function _dispatchPhase(event, phase, nodes, phaseMap) {
  event.eventPhase = phase;
  var i = nodes.length;
  var ontype = "on" + event.type;
  while (i-- && !event.cancelBubble) {
    var target = event.currentTarget = nodes[i];
    var listeners = phaseMap[target.nodeType === 1 ? target.uniqueID : target.base2ID];
    event.eventPhase = target == event.target ? AT_TARGET : phase;
    if (phase == BUBBLING_PHASE && target[ontype]) {
      callOutOfContext(target[ontype], target, event);
    }
    if (listeners) {
      listeners = copy(listeners);
      for (var listenerID in listeners) {
        var listener = listeners[listenerID];
        if (typeof listener == "function") {
          callOutOfContext(listener, target, event);
        } else {
          callOutOfContext(listener.handleEvent, listener, event);
        }
        if (event.returnValue === false) {
          event.preventDefault();
        }
      }
    }
  }
};
