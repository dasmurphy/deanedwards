
var Event = Base.extend({
  constructor: function(type) {
    this.timeStamp = now();
    if (arguments.length) createGetter(this, "type", String(type));
  },
  
  bubbles: false,
  cancelable: false,
  eventPhase: 0,
  target: null,
  type: "",
  currentTarget: null,
  timeStamp: 0,

  stopPropagation: Undefined,
  preventDefault: Undefined
});
