
eval(namespace);

var CAPTURING_PHASE = 1,
    AT_TARGET       = 2,
    BUBBLING_PHASE  = 3;

var _private = $$base2;
