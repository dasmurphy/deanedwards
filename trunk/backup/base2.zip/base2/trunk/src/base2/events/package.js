
var events = new Package({
  name:    "events",
  version: base2.version,

  exports: {
    Dispatcher: Dispatcher,
    Event: Event,
    EventTarget: EventTarget
  }
});

var eventDispatcher = new Dispatcher(_private.events);

if (base2.XMLHttpRequest) {
  base2.XMLHttpRequest.implement(EventTarget);
}
