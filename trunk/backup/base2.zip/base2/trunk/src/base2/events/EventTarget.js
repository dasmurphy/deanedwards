
var EventTarget = Trait.extend({
  addEventListener: function(target, type, listener, useCapture) {
    // assign a unique id to both objects
    var targetID = assignID(target);
    var listenerID = assignID(listener);
    // create a hash table of event types for the target object
    var phase = useCapture ? CAPTURING_PHASE : BUBBLING_PHASE;
    var typeMap = _private.events[type];
    if (!typeMap) typeMap = _private.events[type] = {1:{}, 2:{}, 3:{}};
    var phaseMap = typeMap[phase];
    // create a hash table of event listeners for each object/event pair
    var listeners = phaseMap[targetID];
    if (!listeners) listeners = phaseMap[targetID] = {};
    // store the event listener in the hash table
    listeners[listenerID] = listener;
  },

  dispatchEvent: function(target, event) {
    createGetter(event, "target", target);
    return eventDispatcher.dispatch(event);
  },

  removeEventListener: function(target, type, listener, useCapture) {
    // delete the event listener from the hash table
    var typeMap = _private.events[type];
    if (typeMap) {
      var phaseMap = typeMap[useCapture ? CAPTURING_PHASE : BUBBLING_PHASE];
      if (phaseMap) {
        var listeners = phaseMap[target.nodeType === 1 ? target.uniqueID : target.base2ID];
        if (listeners) delete listeners[listener.base2ID];
      }
    }
  }
});
