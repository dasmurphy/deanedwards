
//@cc_on

;doc; var doc;

var oldBase2 = base2 || {};
if (oldBase2 && oldBase2.version === "%%VERSION%%") return oldBase2;

var undefined;
var document = global.document;

var Object_prototype       = Object.prototype,
    Object__toString       = Object_prototype.toString,
    Array_isArray          = Array.isArray,
    Array_prototype        = Array.prototype,
    Array__concat          = Array_prototype.concat,
    Array__indexOf         = Array_prototype.indexOf,
    Array__forEach         = Array_prototype.forEach,
    Array__slice           = Array_prototype.slice,
    Function_prototype     = Function.prototype,
    Function__bind         = Function_prototype.bind,
    Function__call         = Function_prototype.call,
    Function__toString     = Function_prototype.toString;

function I(i) { // identity
  return i; // returns first argument
}

function II(i, ii) {
  return ii; // returns second argument
}

function K(value) { // returns a constant function that always returns 'value'
  return function() {
    return value;
  };
}

var Undefined = K();
var Null      = K(null);
var False     = K(false); False.contains = False.has = False.test = False;
var True      = K(true);  True.contains  = True.has  = True.test  = True;

var Trait = Undefined; // initialise

var providedDate = Date;
var Date_now = Date.now;

var commands = {"es5-shim": Undefined}; // get rid of this? -@DRE

var base2_info = {version: "%%VERSION%%"};

var idCounter = 0;

var assignID = oldBase2.assignID || function assignID(object, ID) {
  // Assign a unique ID to an object.
  var id = "b2__id" + idCounter++;
  if (object == null) return id;
  if (!ID) ID = object.nodeType === 1 ? "uniqueID" : "base2ID";
  if (!object[ID]) object[ID] = id;
  return object[ID] || id;
};

/*@
var CANNOT_ENUMERATE_BUILTINS = true;
var Object_builtins = "constructor,toLocaleString,toString,valueOf".split(","); // constructor? -@DRE
var Function_builtins = Object_builtins.concat("apply,call".split(","));
for (var i in {toString: 1}) CANNOT_ENUMERATE_BUILTINS = false;
@*/
