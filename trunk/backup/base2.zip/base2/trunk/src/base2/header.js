
/*@cc_on @*/

var undefined,
    base2     = global.base2,
    Date      = global.Date,
    now       = Date.now || function(){return new Date-0}, // milliseconds since the epoch
    document  = global.document,
    Undefined = new Function,
    Null      = K(null),
    True      = K(true),
    False     = K(false),
    This      = function(){return this};
    
base2.namespace = "";

var _Object_prototype   =  Object.prototype,
    _Function_prototype =  Function.prototype,
    _Array_prototype    =  Array.prototype,
    _concat             = _Array_prototype.concat,
    _slice              = _Array_prototype.slice,
    _unshift            = _Array_prototype.unshift,
    _toString           = _Object_prototype.toString;
    
var _OBJECT_TOSTRING    = _toString.call(_Object_prototype),
    _ARRAY_TOSTRING     = _toString.call(_Array_prototype),
    _DATE_TOSTRING      = _toString.call(Date.prototype);

var _PRIMITIVE_TYPE     = /boolean|number|string/,
    _FORMAT             = /%([1-9])/g,
    _LTRIM              = /^\s\s*/,
    _RTRIM              = /\s\s*$/,
    _DECOMPILATION      = /try/.test(detect),                            // some platforms don't allow decompilation
    _TEST_TRUE          = {test: True},
    _BASE               = _DECOMPILATION ? /\bbase\b/ : _TEST_TRUE,
    _THIS               = _DECOMPILATION ? /\bthis\b/ : _TEST_TRUE,
    _MUTABLE            = ["constructor", "toLocaleString", "toString"], // only override these when prototyping
    _FUNCTION_HIDDEN = {
      apply: 1,
      bind: 1,
      call: 1,
      length: 1,
      prototype: 1
    };

// Private data

var _private = global.$$base2;
if (!_private) {
   _private = global.$$base2 = {"0": global, inc: 1, anon: [], events: {}};
  /*@if (@_jscript)
  _private.createCOMObject = function(progId) {
    return global.ActiveXObject ? new ActiveXObject(progId) : WScript.CreateObject(progId);
  };
  /*@end @*/
  var _NativeXHR = global.XMLHttpRequest;
  if (_NativeXHR && _NativeXHR.wrapped) { // old versions of Firebug
    _NativeXHR = _NativeXHR.wrapped;
  }
  _private.createXHR = function() {
    if (_NativeXHR) {
      return new _NativeXHR;
    } else if (_private.createCOMObject) {
      return _private.createCOMObject("Microsoft.XMLHTTP");
    }
    return null;
  };
  if (!detect("($$base2.createXHR())")) {
    _private.createXHR = Null;
  }
}

// Packages and Traits can be anonymous but still define namespaces.
function _Anonymous(object) {
  object.toString = K("[$$base2.anon[" + _private.anon.length + "]]");
  _private.anon.push(object);
  return object;
};

_Object_forEach_check(); // for Safari 2.0
