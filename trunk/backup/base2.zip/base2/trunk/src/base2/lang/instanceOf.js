
function instanceOf(object, klass) {
  // Handle exceptions where the target object originates from another frame.
  // This is handy for JSON parsing (amongst other things).
  
  // COM objects don't have a constructor, they also leak memory when using instanceof
  if (object && !object.constructor) return false;

  if (object instanceof klass) return true;
  
  if (object == null) return false;
  
  switch (klass) {
    case Object:
      return true;
    case Boolean:
    case Number:
    case String:
      if (typeof object != "object") return false;
    case Array:
    case global.Date: // might be different to internal Date
    case Function:
    case RegExp:
      return _toString.call(object) === _toString.call(klass.prototype);
  }
  return false;
};
