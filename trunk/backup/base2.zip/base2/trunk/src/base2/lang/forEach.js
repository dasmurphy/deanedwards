
// http://dean.edwards.name/weblog/2006/07/enum/

if (!global.StopIteration) {
  global.StopIteration = new Error("StopIteration");
}

function forEach(object, eacher, context, fn) {
  if (object == null) return;
  if (!fn) {
    if (typeof object == "function" && object.call) {
      // Functions are a special case.
      fn = Function;
    } else if (typeof object.forEach == "function" && object.forEach != forEach) {
      // The object implements a custom forEach method.
      object.forEach(eacher, context);
      return;
    } else if (typeof object.length == "number") {
      // The object is array-like.
      Array2.forEach(object, eacher, context);
      return;
    }
  }
  _Object_forEach(object, eacher, context, fn);
};

forEach.csv = function(string, eacher, context) {
  Array2.forEach(csv(string), eacher, context);
};

forEach.detect = function(object, eacher, context) {
  var process = function(value, key) {
    if (key.indexOf("@") === 0) { // object/feature detection
      if (detect(key.slice(1))) forEach (value, process);
    } else eacher.call(context, value, key, object);
  };
  forEach (object, process);
};

// These are the two core enumeration methods. All other forEach methods
// eventually call one of these methods.

function _Object_forEach(object, eacher, context, fn) {
  // Enumerate an object and compare its keys with fn's prototype.
  var _proto = fn ? fn == Function ? _FUNCTION_HIDDEN : fn.prototype : _Object_prototype;
  for (var key in object) if (!(key in _proto)) {
    eacher.call(context, object[key], key, object);
  }
};

// http://code.google.com/p/base2/issues/detail?id=10
function _Object_forEach_check() {
  // Run the test for Safari's buggy enumeration.
  var Temp = function(){this.i=1};
  Temp.prototype = {i:1};
  var count = 0;
  for (var i in new Temp) count++;

  if (count > 1) { // Safari (pre version 3) fix.
    _Object_forEach = function(object, eacher, context, fn) {
      var processed = {},
         _proto = fn ? fn == Function ? _FUNCTION_HIDDEN : fn.prototype : _Object_prototype;
      for (var key in object) {
        if (!processed[key] && !(key in _proto)) {
          processed[key] = true;
          eacher.call(context, object[key], key, object);
        }
      }
    };
  }
};
