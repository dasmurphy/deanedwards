
function print(msg) {
  if (isBrowser) {
    if (typeof console == "object" && console && typeof console.log == "function") {
      console.log(msg);
    }
  } else if (global.print) {
    global.print(msg);
  } if (typeof WScript != "undefined") {
    WScript.Echo(msg);
  }
};
