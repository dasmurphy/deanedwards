
var lang = {
  name:      "lang",
  version:   base2.version,
  namespace: ""
};
