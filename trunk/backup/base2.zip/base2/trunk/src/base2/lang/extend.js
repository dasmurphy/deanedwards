
function extend(object, source) { // or extend(object, key, value)
  if (object && source) {
    var enumerateHiddenMembers = !!base2.__prototyping;
    if (arguments.length === 2) { // Extending with an object.
      var isFunction = typeof source == "function" && source.call;
    } else { // Extending with a key/value pair.
      enumerateHiddenMembers = _OBJECT_HIDDEN[key];
      var key = source;
      source = {};
      source[key] = arguments[2];
    }
    
    if (enumerateHiddenMembers) { // Add constructor, toString etc
      var proto = isFunction ? _Function_prototype : _Object_prototype,
          i = _MUTABLE.length, key;
      while ((key = _MUTABLE[--i])) {
        var value = source[key];
        if (value !== proto[key]) {
          if (_BASE.test(value)) {
            _override(object, key, value);
          } else {
            object[key] = value;
          }
        }
      }
    }
    // Copy each of the source object's properties to the target object.
    var immutable = isFunction ? _FUNCTION_HIDDEN : _OBJECT_HIDDEN;
    for (key in source) if (!immutable[key]) {
      value = source[key];
      // Object detection.
      if (key.indexOf("@") === 0) {
        if (detect(key.slice(1))) extend(object, value);
      } else if (key in object) {
        var ancestor = object[key];
        if (value !== ancestor) { // Check for method overriding.
          if (typeof value == "function") {
            if (_BASE.test(value)) {
              _override(object, key, value);
            } else {
              value.ancestor = ancestor;
              object[key] = value;
            }
          } else if (!base2.__casting) {
            object[key] = value;
          }
        }
      } else {
        object[key] = value;
      }
    }
  }
  // http://www.hedgerwow.com/360/dhtml/ie6_memory_leak_fix/
  /*@if (@_jscript) {
    try {
      return object;
    } finally {
      object = null;
    }
  }
  @else @*/
    return object;
  /*@end @*/
};

function _override(object, name, method) {
  // Return a method that overrides an existing method.
  var ancestor = object[name];
  var superObject = base2.__prototyping; // late binding for prototypes
  if (superObject && ancestor != superObject[name]) superObject = null;
  function base() {
    var previous = this.base;
    this.base = superObject ? superObject[name] : ancestor;
    var returnValue = method.apply(this, arguments);
    this.base = previous;
    return returnValue;
  };
  base.ancestor = ancestor;
  // introspection (removed when packed)
  ;;; base.toString = K(method.toString());
  object[name] = base;
  return base;
};
