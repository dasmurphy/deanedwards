
function deferUntil(fn, test, interval, timeout, ontimeout) {
  var startTime = now();
  var tick = function() {
    if (test()) {
      fn();
    } else if (timeout !== 0 || (now() - startTime < timeout)) {
      setTimeout(tick, interval || 4);
    } else if (timeout >= 0 && ontimeout) {
      ontimeout();
    }
  };
  if (interval === 0) tick();
  else setTimeout(tick, interval || 4);
};
