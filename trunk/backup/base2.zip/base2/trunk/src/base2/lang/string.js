
function match2(string, expression) {
  return String(string).match(expression) || [];
};

function format(string) {
  // Replace %n with arguments[n].
  // e.g. format("%1 %2%3 %2a %1%3", "she", "se", "lls");
  // ==> "she sells sea shells"
  // Only %1 - %9 supported.
  var args = arguments;
  var pattern = new RegExp("%([1-" + (args.length - 1) + "])", "g");
  return String(string).replace(pattern, function(match, index) {
    return args[index];
  });
};

function rescape(string) {
  // Make a string safe for creating a RegExp.
  return String(string).replace(/([\/()[\]{}|*+-.,^$?\\])/g, "\\$1");
};
