
if (base2.userAgent) {
  var useFastestMethod = true;
  // Gecko doesn't report errors using the dispatchEvent technique
  ;;; useFastestMethod = !detect("Gecko"); // removed when packed
  var documentElement = document.documentElement;
  if (document.createEvent && useFastestMethod) {
    var GENERIC_EVENTS = detect("(document.createEvent('Events'))") ? "Events" : "UIEvents";
    documentElement.addEventListener("base2Call", function(){$$base2.exec()}, false);
    var callOutOfContext = function() {
      $$base2.exec = bind.apply(null, arguments);
      var dummyEvent = document.createEvent(GENERIC_EVENTS);
      dummyEvent.initEvent("base2Call", false, false);
      documentElement.dispatchEvent(dummyEvent);
    };
  } else if (documentElement.fireEvent) {
    callOutOfContext = function() {
      documentElement.onfilterchange = bind.apply(null, arguments);
      documentElement.fireEvent("onfilterchange");
      documentElement.onfilterchange = null;
    };
  } else {
    callOutOfContext = function() {
      $$base2.exec = bind.apply(null, arguments);
      var script = document.createElement("script");
      script.text = "$$base2.exec()";
      documentElement.appendChild(script);
      documentElement.removeChild(script);
    };
  }
} else {
  callOutOfContext = function() {
    bind.apply(null, arguments)();
  };
}

function createGetter(object, propertyName, value, getter) {
  if (object.__defineGetter__) {
    object.__defineGetter__(propertyName, getter || K(value));
  } else {
    object[propertyName] = value;
  }
};
