
// http://wiki.ecmascript.org/doku.php?id=proposals:typeof

var _MSIE_NATIVE_FUNCTION = detect("(jscript)")
  ? new RegExp("^" + rescape(isNaN).replace(/isNaN/, "\\w+") + "$")
  : {test: False};

function typeOf(object) {
  var type = typeof object;
  
  switch (type) {
    case "object":
      return object == null
        ? "null"
        : typeof object.constructor != "function" // COM object
          ? _MSIE_NATIVE_FUNCTION.test(object)
            ? "function"
            : type
          : _toString.call(object) === _DATE_TOSTRING
            ? type
            : typeof object.constructor.prototype.valueOf(); // underlying type
            
    case "function":
      return typeof object.call == "function" ? type : "object";
      
    default:
      return type;
  }
};
