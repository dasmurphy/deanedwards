
function copy(object, preserveClassInfo) {
  if (preserveClassInfo) {
    base2.__prototyping = true; // We are not really prototyping but it stops base2's [[Construct]] being called.
    var result = new object.constructor;
    delete base2.__prototyping;
    for (var i in result) if (result[i] !== object[i]) {
      result[i] = object[i];
    }
  } else {
    result = {};
    for (var i in object) result[i] = object[i];
  }
  return result;
};

function _PCopier(){};

function pcopy(object, properties) { // Prototype-based copy.
  _PCopier.prototype = object;
  var result = new _PCopier;
  if (properties) extend(result, properties);
  return result;
};
