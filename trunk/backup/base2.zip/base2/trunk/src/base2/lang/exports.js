
lang.exports = {
  assert: assert,
  assertArity: assertArity,
  assertType: assertType,
  bind: Function2.bind,
  callOutOfContext: callOutOfContext,
  copy: copy,
  createGetter: createGetter,
  deferUntil: deferUntil,
  extend: extend,
  forEach: forEach,
  format: format,
  instanceOf: instanceOf,
  match: match2,
  now: now,
  pcopy: pcopy,
  print: print,
  rescape: rescape,
  trim: trim,
  typeOf: typeOf
};

lang = new Package(lang);
