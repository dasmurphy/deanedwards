
base2.require("io", function(ns) {
  eval(ns);

  var x = new base2.XMLHttpRequest;
  x.onreadystatechange = function() {
    print("readyState=" + this.readyState);
    if (this.readyState === 4) {
      if (this.status === 200) {
        print(this.responseText);
        print(this.responseXML);
      } else {
        print("Error: status=" + this.status);
      }
    }
  };
  x.open("GET", "http://rekky.rosso.name/module.xml", false);
  x.send(null);
});
