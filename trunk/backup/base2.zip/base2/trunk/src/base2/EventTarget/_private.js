
// Call a function in a new execution context.
// Even if the function errors, the next line in your program will still execute,
// you will also get an error message in the console.

// http://dean.edwards.name/weblog/2009/03/callbacks-vs-events/

var _continueIfThrow = _private.continueIfThrow;

if (!_continueIfThrow) (function() {
  var Function__bind = _.Functional.prototype.bind;
  var Function__call = Function.prototype.call;

  var SUPPORTS_CLICK = false;

  try {
    var document = window.document;
    var fragment = document.createDocumentFragment();
    var button = document.createElement("button");
    fragment.appendChild(button);
    button.onclick = function() {
      SUPPORTS_CLICK = true;
    };
    button.click();
  } catch (ex) {}

  if (SUPPORTS_CLICK) {
    var buttons = fragment.childNodes;
    var index = 0;
    _continueIfThrow = function continueIfThrow() {
      var button = buttons[index++];
      if (!button) {
        button = buttons[0].cloneNode(false);
        button.onclick = null;
        fragment.appendChild(button);
      }
      button.onclick = Function__call.apply(Function__bind, arguments);
      button.click();
      button.onclick = null;
      index--;
    };
  } else {
    var hasConsole = _.detect("(console.log)");
    _continueIfThrow = function throwLater() {
      try {
        Function__call.apply(Function__bind, arguments)();
      } catch (ex) {
        if (hasConsole) console.log(ex);
        else setTimeout(function(){throw ex}, 4);
      }
    }
  }

  _private.continueIfThrow = _continueIfThrow;

})();

// =========================================================================
// createProperty
// =========================================================================

if (!_private.createProperty) (function(Object) {
  var object = {};
  var SUPPORTS_GETTER_SETTER   = !!object.__defineGetter__;
  var SUPPORTS_DEFINE_PROPERTY = false;

  function READ_ONLY_ERR() {
    throw Error("Cannot set read-only property.");
  };

  var defineProperty = Object.defineProperty;

  if (defineProperty) {
    for (var name in Object) if (name === "defineProperty") {
      defineProperty = null; // It's fake.
      break;
    }
    if (defineProperty) {
      try { // Make sure it works with native JS objects.
        defineProperty(object, "x", {get: _.K(1)});
        SUPPORTS_DEFINE_PROPERTY = object.x === 1;
      } catch(ex){}
    }
  }

  function createProperty(object, propertyName, value, getter, setter) {
    if (SUPPORTS_DEFINE_PROPERTY || (defineProperty && object.componentFromPoint)) { // or HTMLElement (MSIE8)
      defineProperty(object, propertyName, {
        get: getter || _.K(value),
        set: setter || READ_ONLY_ERR
      });
    } else if (SUPPORTS_GETTER_SETTER) {
      object.__defineGetter__(propertyName, getter || _.K(value));
      object.__defineSetter__(propertyName, setter || READ_ONLY_ERR);
    } else {
      object[propertyName] = value;
    }
  }

  var isEffective = SUPPORTS_DEFINE_PROPERTY || SUPPORTS_GETTER_SETTER;

  // This method is internal and probably shouldn't exist.

  _private.createProperty = createProperty;

  _private.createProperties = function createProperties(object, properties, writable) {
    _.forEach (properties, function(value, propertyName) {
      var getter = function _getter() {
        return properties[propertyName];
      };
      var setter = writable ? function _setter(value) {
        return properties[propertyName] = value;
      } : READ_ONLY_ERR;
      createProperty(object, propertyName, value, getter, setter);
    });
    return isEffective ? properties : object;
  };
})(Object);
