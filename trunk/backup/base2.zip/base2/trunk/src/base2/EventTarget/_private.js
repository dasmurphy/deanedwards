
// Call a function in a new execution context.
// Even if the function errors, the next line in your program will still execute,
// you will also get an error message in the console.

// http://dean.edwards.name/weblog/2009/03/callbacks-vs-events/

var _private = _._;
_private.Event = Event;
if (!_private.events) _private.events = {};

var allEvents = _private.events;

var Function__bind = _.Functional.prototype.bind;
var Function__call = Function.prototype.call;

var SUPPORTS_CLICK = false;

try {
  var document = window.document;
  var fragment = document.createDocumentFragment();
  var button = document.createElement("button");
  fragment.appendChild(button);
  button.onclick = function() {
    SUPPORTS_CLICK = true;
  };
  button.click();
} catch (ex) {}

if (SUPPORTS_CLICK) {
  var buttons = fragment.childNodes;
  var index = 0;
  var continueIfThrow = function continueIfThrow() {
    var button = buttons[index++];
    if (!button) {
      button = buttons[0].cloneNode(false);
      button.onclick = null;
      fragment.appendChild(button);
    }
    button.onclick = Function__call.apply(Function__bind, arguments);
    button.click();
    button.onclick = null;
    index--;
  };
} else {
  var hasConsole = _.detect("(console.log)");
  continueIfThrow = function throwLater() {
    try {
      Function__call.apply(Function__bind, arguments)();
    } catch (ex) {
      if (hasConsole) console.log(ex);
      else setTimeout(function(){throw ex}, 4);
    }
  }
}

_private.continueIfThrow = continueIfThrow;

// =========================================================================
// createGetter
// =========================================================================

(function(Object) {
  var object = {};
  var SUPPORTS_OBJECT_DEFINE_GETTER   = !!object.__defineGetter__;
  var SUPPORTS_OBJECT_DEFINE_PROPERTY = false;
  
  function READ_ONLY_ERR() {
    throw new Error("Cannot set read-only property.");
  };
  
  var defineProperty = Object.defineProperty;

  if (defineProperty) {
    for (var name in Object) if (name === "defineProperty") {
      defineProperty = null; // It's fake.
      break;
    }
    if (defineProperty) {
      try { // Make sure it works with native JS objects.
        defineProperty(object, "x", {get: _.K(1)});
        SUPPORTS_OBJECT_DEFINE_PROPERTY = object.x === 1;
      } catch(ex){}
    }
  }
  
  // MSIE8 won't allow enumeration for some reason.
  var ENUMERABLE = defineProperty && SUPPORTS_OBJECT_DEFINE_PROPERTY;
  
  function createGetter(object, propertyName, value, getter) {
    if (SUPPORTS_OBJECT_DEFINE_PROPERTY || (defineProperty && object.componentFromPoint)) { // or HTML element
      defineProperty(object, propertyName, {get: getter || _.K(value), set: READ_ONLY_ERR, enumerable: ENUMERABLE, configurable: true});
    } else if (SUPPORTS_OBJECT_DEFINE_GETTER) {
      object.__defineGetter__(propertyName, getter || _.K(value));
      object.__defineSetter__(propertyName, READ_ONLY_ERR);
    } else {
      object[propertyName] = value;
    }
  }
  
  // This method is internal and probably shouldn't exist. ;)

  _private.createGetter = createGetter;
  
  _private.createGetters = function createGetters(object, properties) {
    forEach (properties, function(value, propertyName) {
      createGetter(object, propertyName, value, function() {
        return properties[propertyName];
      })
    });
  };
})(Object);
