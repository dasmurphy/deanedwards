
RegGrp.Dict = RegGrp.extend({
  parse: function(phrase) {
    // Prevent sub-expressions in dictionary entries from capturing.
    var entries = this[_ITEMS];
    return phrase.replace(_REGGRP_DICT_ENTRIES, function(match, entry) {
      entry = entries[_HASH + entry];
      return entry ? entry._nonCapturing : match;
    });
  },

  put: function(expression, replacement) {
    // Get the underlying replacement value.
    if (replacement instanceof RegGrp.Item) {
      replacement = replacement.replacement;
    } else if (replacement instanceof RegExp) {
      replacement = replacement.source;
    }
    if (typeof replacement == "string") { // Don't translate functions.
      // Translate the replacement.
      // The result is the original replacement recursively parsed by this dictionary.
      var nonCapturing = replacement.replace(_REGGRP_LOOKUPS, _nonCapture);
      if (replacement.indexOf("(") !== -1) {
        var realLength = RegGrp.count(replacement);
      }
      if (replacement.indexOf("<#") !== -1) {
        replacement = this.parse(replacement);
        nonCapturing = this.parse(nonCapturing);
      }
    }
    var item = this.base(expression, replacement);
    item._nonCapturing = nonCapturing;
    item._length = realLength || item.length; // underlying number of sub-groups
    return item;
  },

  toString: function() {
    return "(<#" + this[_PATTERNS].join(">)|(<#") + ">)";
  }
});

function _nonCapture(match, escaped) {
  return escaped || "(?:"; // non-capturing
};
