
var _METHODS = "#methods";

var Trait = Abstract.extend(null, {
  namespace: "",

  extend: function(methods, _static) {
    // Extend a trait to create a new trait.
    var trait = _Anonymous(this.base());
    var traitMethods = trait[_METHODS] = pcopy(this[_METHODS]);
    // Inherit static methods.
    for (var name in this) {
      var method = this[name];
      if (typeof method == "function" && !traitMethods[name] && !_Base_static[name]) {
        trait[name] = method;
      }
    }
    trait.namespace = "";
    // Inherit trait methods.
    trait.implement(this);
    ;;; trait["#implements"].pop();
    ;;; this["#implemented_by"].pop();
    // Implement trait  methods.
    if (methods) trait.implement(methods);
    // Implement static properties and methods.
    if (_static) extend(trait, _static);
    return trait;
  },

  forEach: function(eacher, context) {
    for (var name in this[_METHODS]) {
      eacher.call(context, this[name], name, this);
    }
  },

  implement: function(methods) {
    var traitID = this.toString().slice(1, -1);
    if (typeof methods == "object") {
      // Add new methods from an object literal.
      _extendTrait(this, methods, true, traitID);
    } else if (Trait.ancestorOf(methods)) {
      // Implement the methods from another Trait.
      this.base(methods);
      var traitMethods = this[_METHODS];
      for (var name in methods[_METHODS]) {
        this[name] = methods[name];
        this.namespace += "var " + name + "=" + traitID + "." + name + ";";
        traitMethods[name] = true;
      }
    }
    return this;
  },

  partial: function() {
    // Return a clone of the Trait that contains all of its methods after
    // partial evaluation.
    return _extendTrait(Trait.extend(), map(this, partial), true);
  }
});

Trait[_METHODS] = {};

function _extendTrait(trait, methods, detected, traitID) {
  // Extend a Trait with an object literal.
  // Allow for base2's detect() notation.
  traitID = traitID || trait.toString().slice(1, -1);
  var proto = trait.prototype;
  var traitMethods = trait[_METHODS];
  for (var name in methods) {
    var method = methods[name];
    if (name.indexOf("@") === 0) { // object detection
      _extendTrait(trait, method, detected && detect(name.slice(1)), traitID);
    } else if (typeof method == "function" && method.call) {
      if (!trait[name] && (!detected || _THIS.test(method))) {
        trait[name] = createDelegate(name);
      }
      if (detected) {
        if (_BASE.test(method)) {
          method = _override(trait, name, method);
        } else {
          trait[name] = method;
        }
        if (_THIS.test(method)) {
          trait[name] = bind(method, trait);
        }
        proto[name] = createInstanceMethod(trait, method);
        ;;; trait[name]._underlyingFunction = proto[name]._underlyingFunction = methods[name]._underlyingFunction || methods[name];
      }
      if (!traitMethods[name]) {
        traitMethods[name] = true;
        trait.namespace += "var " + name + "=" + traitID + "." + name + ";";
      }
    }
  }
  return trait;
};

function createInstanceMethod(trait, method) {
  // Pass "this" and all other arguments to the underlying trait method.
  function _traitInstanceMethod() {
    _unshift.call(arguments, this);
    return method.apply(trait, arguments);
  };
  ;;; _traitInstanceMethod._trait = trait;
  return _traitInstanceMethod;
};

function createDelegate(name) {
  function _delegatedTraitMethod(object) {
    var ancestor = object[name].ancestor;
    if (ancestor) object.base = ancestor;
    var methodName = ancestor ? "base" : name;
    var method = object[methodName];
    var args = _slice.call(arguments, 1);
    if (method.apply) {
      return method.apply(object, args);
    }
    return object[methodName](args[0], args[1], args[2], args[3], args[4], args[5]); // that's enough for COM objects
  };
  ;;; _delegatedTraitMethod._isDelegate = true;
  return _delegatedTraitMethod;
};
