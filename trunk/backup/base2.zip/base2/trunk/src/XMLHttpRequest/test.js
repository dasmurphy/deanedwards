
base2.require("XMLHttpRequest@(FormData)", function(_, XMLHttpRequest) {
  var x = new XMLHttpRequest;
  x.onreadystatechange = function() {
    alert("readyState=" + this.readyState);
    if (this.readyState === 4) {
      if (this.status === 200) {
        //console2.log(this.responseText);
        alert(this.responseXML);
      } else {
        alert("Error: status=" + this.status);
      }
    }
  };
  //x.open("POST", "/post.php", false);
  x.open("GET", "/module.xml", true);
  //x.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  //x.setRequestHeader("Content-type", "application/xml");
  x.send(null);
});
