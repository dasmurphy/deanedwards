
// The client object wraps an <iframe> that contains the rendered page

var Client = _.Base.extend({
  constructor: function Client__constructor() {
    var client = this;

    this.history = new History(function _navigate() {
      var address = location.hash.slice(1);
      client.send("GET", address);
      client.address = address;
      client.refresh();
    });
    
    // the url of the hosting page
    this.host = location.href.slice(0, -location.hash.length);
    
    this.view = document.createElement("iframe");
    this.view.style.display = "none";
    document.body.appendChild(this.view);

    var client = this;
    MiniWeb.addEventListener("saved", function _onsave() {
      this.dirty = false;
      var saveButtons = dom.findAll(client.window.document, ".mw-dirty");
      _.forEach (saveButtons, function _eacher(saveButton) {
        dom.classList.remove(saveButton, "mw-dirty");
      });
    });
  },
  
  address: "",
  history: null,
  host: "",
  response: null,
  view: null,
  window: null,
  
  fixForm: function Client__fixForm(form) {
    // intercept form submissions
    form.onsubmit = Client.onsubmit;
  },

  fixLinks: function Client__fixLinks(node) {
    forEach (dom.findAll(node, ":link"), this.fixLink, this);
  },
  
  fixLink: function Client__fixLink(link) {
    // stylise links - add classes for visited etc
    var href = link.getAttribute("href", 2);
    // extract the hash portion and create a path
    if (/^#[^\/]/.test(href)) {
      var hash = location.hash.replace(/^#(.*!)?/, "");
      href = "#" + hash.replace(/[^\/]+$/, "") + href.slice(1);
    }
    if (/^#/.test(href)) {
      if (this.history.visited[href] && !/(^|\s)mw\-visited(\s|$)/.test(link.className)) {
        link.className += " mw-visited";
      }
      link.onclick = Client.onclick;
    }
    if (!/^javascript/i.test(href)) {
      link.target = "_parent";
    }
  },
  
  fixStyle: function Client__fixStyle(style) {
    style.textContent = style.textContent.replace(/:(visited)/g, ".mw-$1");
  },
  
  navigateTo: function Client__navigateTo(url) {
    // load a new page
    var hash = /^#/.test(url) ? url.slice(1) : url;
    if (this.address !== hash) {
      var request = new Request("HEAD", hash);
      if (request.status == 301) {
        hash = request.getResponseHeader("Location");
      }
      this.history.add("#" + hash);
    }
  },

  refresh: function Client__refresh() {
    // refresh the current page from the last response
    
    // insert a script
    var script = "parent.MiniWeb.register(this);";
    script = _.format(INTERNAL_SCRIPT, script);
    var html = this.response.replace(/(<head[^>]*>)/i, function(match) {
      return match + script;
    });
    // create an iframe to display the page
    var iframe = document.createElement(Client.$IFRAME);
    iframe.frameBorder = "0";
    iframe.id = "window";
    document.body.replaceChild(iframe, this.view);
    document.body.scrollTop = 0;
    this.view = iframe;
    
    var client = this;
    // write the html
    var doc = iframe.contentDocument || iframe.contentWindow.document;
    doc.open();
    doc.write(html);
    doc.close();

    // fix the page
    client.fixLinks(doc);
    forEach (doc.getElementsByTagName("style"), client.fixStyle, client);
    forEach (doc.forms, client.fixForm, client);

    // keep the browser title in sync
    var title = doc.title;
    if (!title) {
      var h1 = doc.getElementsByTagName("h1")[0];
      if (h1) title = dom.get(h1, "textContent");
    }
    document.title = title || "MiniWeb";
  },
  
  register: function Client__register(window) {
    this.window = window;
    window.base2 = base2;
    window.MiniWeb = MiniWeb;
    window.doc = MiniWeb.doc;
    window.Date = Date;
    base2.exec(function(_) {
      for (var i in _) if (/^([a-z]\w+)$/i.test(i)) window[i] = _[i];
      window.dom = base2.dom;
    });
  },
  
  reload: function Client__reload() {
    // reload the current page

    var scrollTop = this.window.document.body.scrollTop;

    this.send("GET", this.address);
    this.refresh();

    this.window.document.body.scrollTop = scrollTop;
  },
  
  send: function Client__send(method, url, data, headers) {
    this.response = new Request(method, url, data, headers).responseText;
  },
  
  submit: function Client__submit(form) {
    // post form data
    var successful = _.filter(form.elements, function(element) {
      if (!element.name || element.disabled) return false;
      
      switch (element.type) {
        case "radio":
        case "checkbox":
          return element.checked;

        case "button":
        case "reset":
          return false;
          
        case "image":
        case "submit":
          return element = form.ownerDocument.activeElement;

        default:
          return true;
      }
    });

    var data = _.map(successful, function(element) {
      return element.name + "=" + encodeURIComponent(element.value);
    }).join("&");
    
    this.send("POST", form.action || this.address, data);
    this.refresh();
  },

  "@MSIE[678]": {
    fixStyle: function Client__fixStyle_msie8(style) {
      style = style.styleSheet;
      style.cssText = style.cssText.replace(/:visited/g, ".mw-visited");
    },
    
    "@MSIE[67]": {
      refresh: function Client__refresh_msie7() {
        // IE needs a kick up the butt
        //  this will cause the unload event to fire in the iframe
        this.view.contentWindow.document.write();
        this.base();
      }
    }
  }
}, {
  $IFRAME: "iframe",

  onclick: function Client_onclick() {
    var href = this.getAttribute("href", 2);
    if (href && !/^\w+:/.test(href)) {
      MiniWeb.navigateTo(href);
      return false;
    }
    return true;
  },
  
  onsubmit: function Client_onsubmit() {
    MiniWeb.submit(this);
    return false;
  },

  "@MSIE[678]": {
    $IFRAME: "<iframe scrolling=yes>"
  }
});
