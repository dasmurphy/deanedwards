
var behavior = jsb.element.constructor.prototype;
var dummy = jsb.element.extend();
for (var i in dummy) {
  if (!/^(constructor|ancestor)$/.test(i) && dummy[i] !== behavior[i]) {
    behavior[i] = dummy[i];
  }
}

base2["#name"] = "base2";
jsb["#name"] = "jsb";
MiniWeb["#name"] = "MiniWeb";
MiniWeb.doc["#name"] = "MiniWeb.doc";
base2.Base["#name"] = "base2.Base";
window["#name"] = "window";
FormData["#name"] = "FormData";
XMLHttpRequest2["#name"] = "XMLHttpRequest";
window.XMLHttpRequest = XMLHttpRequest2;
jsb.element["#name"] = "jsb.element";
jsb.form.element["#name"] = "jsb.form.element";
Date["#name"] = "Date";
window.Date = Date;
JSON["#name"] = "JSON";

Date.prototype.toISOString = new Date().toISOString;
Date.prototype.toJSON = new Date().toJSON;

forEach.csv("Command,Terminal", function(className) {
  var klass = MiniWeb[className];
  var instance = new klass;
  (klass.prototype.exec = _.K()).toString = _.K(String(instance.exec));
});

var namespace = base2.exec(_.I);
var Namespace = namespace.constructor;

function createKey(key) {
  return key + "";
}
createKey.toString = _.K(String(String));

base2.Collection.prototype.createKey = createKey;

process(base2, "base2");
process(jsb, "jsb");
process(MiniWeb, "MiniWeb");
forEach (base2, process);
forEach (jsb, process);
forEach (MiniWeb, process);

function process(property, name) {
  if (property instanceof base2.Package) {
    property["#name"] = property.name;
    doc.show[name] = true;
    forEach (property, function(object, name) {
      if ((typeof object == "function" || jsb.element.ancestorOf(object)) && !object["#name"]) {
        object["#name"] = property["#name"] + "." + name;
      } else {
        process(object, name);
      }
    });
  } else if (typeof property == "function" && base2.Trait.ancestorOf(property)) {
    forEach (property["#implements"], function(trait) {
      forEach (trait, function(method, name) {
        if (!base2.Trait[name] && typeof method == "function" && property[name]) {
          property[name]._trait = trait;
          var protoMethod = property.prototype[name];
          if (protoMethod) protoMethod._trait = trait;
        }
      });
    });
  } else if (typeof property == "function" && base2.Collection.ancestorOf(property)) {
    var Item = property.Item;
    if (Item && !Item["#name"]) {
      Item['#name'] = property['#name'] + ".Item";
    }
    if (property == base2.RegGrp) {
      property.Dict['#name'] = property['#name'] + ".Dict";
    }
  }
}

doc.show.io = false;
doc.show.jst = false;

var events = (
  "mousedown|mouseup|mousemove|mouseenter|mouseleave|mouseover|mouseout|mousewheel|click|dblclick|" +
  "touchstart|touchmove|touchend|touchcancel|" +
  "keydown|keyup|input|" +
  "change|reset|submit|" +
  "focus|blur|scroll|select|" +
  "transitionend"
).split("|").sort();

forEach (events, function(name) {
  behavior[":on" + name] = null;
});

events = "attach|contentready|documentready|losecapture".split("|");

forEach (events, function(name) {
  behavior["jsb:on" + name] = null;
});

behavior["window:onresize"] = null;

_.extend(MiniWeb.Client.prototype, "fixLink", function(link) {
  if (/^\/doc\//.test(this.address)) {
    var href = link.getAttribute("href", 2);
    if (!/^(#\/|\w+:)/.test(href)) {
      if (/^#(::|\.)/.test(href)) {
        href = href.replace("#", "#" + this.address.replace(/(::|\.:?)(\w+:)?\w+$/, ""));
      } else {
        href = href.replace("#", "#/doc/!");
      }
      link.setAttribute("href", href);
    }
  }
  this.base(link);
});
