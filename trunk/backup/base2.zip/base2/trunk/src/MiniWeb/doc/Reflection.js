
var Reflection = _.Base.extend({
  constructor: function Reflection__constructor(reference) {
    this.reference = reference;
    this.ancestor = Object.prototype;
    
    this.type = typeof reference;
    
    if (this.type === "null") this.type = "object";
    
    if (reference != null) {
      if (this.type === "function") {
        this.ancestor = Function.prototype;
        if (isClass(reference)) {
          this.ancestor = reference.ancestor || Object;
          if (typeof reference == "function" && _.Trait.ancestorOf(reference)) {
            this.type = "trait";
          } else {
            this.type = "class";
          }
        } else if (reference.prototype) {
          var typeString = Object__toString.call(reference.prototype).slice(8, -1);
          if (!OBJECT.test(typeString)) {
            this.type = "class";
          }
        }
      } else if (this.type === "object") {
        if (jsb.element == reference || jsb.element.ancestorOf(reference)) {
          this.ancestor = reference.ancestor;
          this.type = "behavior";
        } else {
          this.ancestor = reference.constructor.prototype;
          if (reference == this.ancestor || String(this.ancestor) == "[xpconnect wrapped native prototype]") {
            this.ancestor = (reference.constructor.ancestor || Object).prototype;
          }
          if (reference instanceof Namespace) {
            this.type = "namespace";
          } else if (reference instanceof _.Package) {
            this.type = "package";
          }
        }
      }
    }
  },

  ancestor: Object.prototype,
  reference: null,
  type: "undefined",

  getClasses: function Reflection__getClasses() {
    var members = new Members(this, function(ref) {
      return isClass(ref) && !isTrait(ref);
    });
    if (this.reference == window && _.detect("Gecko")) {
      for (var name in Components.interfaces) {
        name = name.slice(3);
        if (name in window) {
          members.set(name, window[name]);
        } else {
          name = name.slice(3);
          if (name in window) {
            members.set(name, window[name]);
          }
        }
      }
    }
    members.sort();
    return members;
  },

  getClassMethods: function Reflection__getClassMethods() {
    var traitMethods = this.type == "trait" ? this.reference.prototype : {};
    var members = new Members(this, function(ref, name) {
      return ref instanceof Function && !traitMethods[name] && !isBaseClass(ref) && ref != Object;
    });
    if (this.reference == Date) {
      members.set("UTC", Date.UTC, true);
      members.set("now", Date.now, false);
      members.set("parse", Date.parse, false);
    }
    if (!traitMethods.bind) {
      var bind = this.reference.bind;
      if (bind != Function.bind) {
        members.set("bind", bind);
      }
    }
    members.set("toString", this.reference.toString, true);
    members.sort();
    return members;
  },

  getClassProperties: function Reflection__getClassProperties() {
    var type = this.type;
    return new Members(this, function(ref, name) {
      return !CONSTANT.test(name) && (typeof ref == "null" || typeof ref == "object" || isPrimitive(ref) || isBaseClass(ref) || ref == Object);
    });
  },

  getConstants: function Reflection__getConstants() {
    return new Members(this, isConstant);
  },

  getEventHandlers: function Reflection__getEventHandlers() {
    return new Members(this, function(ref, name) {
      return ref === null && /^(\w+)?:on[a-z]+$/.test(name);
    });
  },

  getInstanceMethods: function Reflection__getInstanceMethods() {
    var reference = this.reference;
    if (reference == Date) {
      var proto = new Date;
      var members = new Reflection(proto).getMethods();
      forEach.csv(DATE_PROTOTYPE_METHODS, function(name) {
        members.set(name, proto[name], true);
      });
      members.set("toISOString", proto.toISOString, false);
      members.set("toJSON", proto.toJSON, false);
      members.sort();
    } else {
      members = new Reflection(reference.prototype).getMethods();
    }
    if (reference == XMLHttpRequest) {
      members.get("abort").inherited = true;
      members.get("getAllResponseHeaders").inherited = true;
      members.get("getResponseHeader").inherited = true;
      members.get("open").inherited = true;
      members.get("overrideMimeType").inherited = true;
      members.get("send").inherited = true;
      members.get("setRequestHeader").inherited = true;
    }
    return members;
  },

  getInstanceProperties: function Reflection__getInstanceProperties() {
    var reference = this.reference;
    if (reference == Date) {
      var members = new Reflection(new Date).getProperties();
    } else {
      members = new Reflection(reference.prototype).getProperties();
    }
    if (reference == XMLHttpRequest) {
      members.get("onreadystatechange").inherited = true;
      members.set("readyState", 0, true);
      members.set("status", 0, true);
      members.set("statusText", "", true);
      members.set("responseText", "", true);
      members.set("responseXML", null, true);
    }
    return members;
  },

  getMembers: function Reflection__getMembers() {
    var members = new Members(this);
    members.sort();
    return members;
  },

  getMethods: function Reflection__getMethods() {
    var reference = this.reference;
    var members = new Members(this, isFunction);
    if (reference == JSON) {
      members.set("parse", JSON.parse, false);
      members.set("stringify", JSON.stringify, false);
    }
    if (jsb.element.ancestorOf(reference)) {
      forEach.csv("attach,detach,get,modify,setCapture", function(name) {
        var member = members.get(name);
        member.inherited = String(jsb.element[name]) === String(reference[name]);
      });
    }
    members.sort();
    return members;
  },

  getPackages: function Reflection__getPackages() {
    return new Members(this, isPackage);
  },

  getProperties: function Reflection__getProperties() {
    return new Members(this, function(ref, name) {
      return typeof ref != "function" && !isConstant(ref, name) && !(ref instanceof _.Package) && !(ref === null && /^(\w+)?:on[a-z]+$/.test(name));
    });
  },

  getTraits: function Reflection__getTraits() {
    return new Members(this, isTrait);
  },

  getTraitMethods: function Reflection__getTraitMethods() {
    var traitMethods = this.type == "trait" ? this.reference.prototype : {};
    var members = new Members(this, function(ref, name) {
      return !!traitMethods[name] && name != "base";
    });
    if (traitMethods.bind) {
      members.set("bind", this.reference.bind);
      members.sort();
    }
    return members;
  }
});
