
var forEach = _.forEach;

//base2.exec("es5-shim");

var CONSTANT   = /^[A-Z][\dA-Z_]*$/;
var PRIMITIVE  = /^(boolean|number|string)$/;
var OBJECT     = /^(object|package|class|trait)$/;
var PACKAGE    = /^package$/;
var THIS       = /\bthis\./;
var VALID_NAME = /^[a-z]/i;

var mimeTypes = {
  js: "text/javascript",
  css: "text/css",
  html: "text/html",
  xml: "text/xml"
};

var OBJECT = /^(Object|Null|Undefined)$/;

var Object__toString = {}.toString;

var DATE_PROTOTYPE_METHODS =
"getDate,getDay,getFullYear,getHours,getMilliseconds,getMinutes,getMonth,\
getSeconds,getTime,getTimezoneOffset,getUTCDate,getUTCDay,getUTCFullYear,\
getUTCHours,getUTCMilliseconds,getUTCMinutes,getUTCMonth,getUTCSeconds,\
setDate,setFullYear,setHours,setMilliseconds,setMinutes,setMonth,setSeconds,\
setTime,setUTCDate,setUTCFullYear,setUTCHours,setUTCMilliseconds,setUTCMinutes,\
setUTCMonth,setUTCSeconds,toDateString,toLocaleDateString,\
toLocaleTimeString,toTimeString,toUTCString";

function isPrimitive(ref) {
  return PRIMITIVE.test(typeof ref) || ref instanceof RegExp;
}

function isConstant(ref, name) {
  return CONSTANT.test(name) && (ref === null || isPrimitive(ref));
}

function isObject(ref) {
  return typeof ref == "object" || typeof ref == "null";
}

function isClass(ref) {
  if (typeof ref != "function") return false;
  if (ref == window.Date || ref == window.XMLHttpRequest) return true;
  for (var i in ref.prototype) return true;
  if (ref == _.Base || _.Base.ancestorOf(ref)) return true;
  if (ref == createKey) return false;
  return /\s*function\s+[A-Z][^\[]+\[native code/.test(String(ref));
}

function isBaseClass(ref) {
  return typeof ref == "function" && (ref == base2.Base || base2.Base.ancestorOf(ref));
}

function isTrait(ref) {
  return typeof ref == "function" && base2.Trait.ancestorOf(ref);
}

function isPackage(ref, name) {
  return ref instanceof base2.Package && doc.show[name] !== false;
}

function isFunction(ref) {
  return _.isFunction(ref) && !isClass(ref);
}

function isMethod(ref) {
  return isFunction(ref) && /\bthis\./.test(ref);
}
