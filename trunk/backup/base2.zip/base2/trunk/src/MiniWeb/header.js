
var _private = _._;
var forEach  = _.forEach;

var WILD_CARD      = /\*$/;
var TRIM_PATH      = /[^\/]+$/;
var SPACE          = /\s+/;

var DOCTYPE = '<!doctype html>';

var INTERNAL_SCRIPT = '<script>\n{0}\n<\/script>';
var EXTERNAL_SCRIPT = '<script src="{0}"><\/script>';

var ICON_LINK = 'data:image/gif;base64,R0lGODlhCwALAKEDAAAA/1tb/7Cw/////yH5BAEAAAMALAAAAAALAAsAAAIgnAepcNjegjhrCEbxPTNZjAQIAwKdt5mNppYPNC6eUQAAIf4fT3B0aW1pemVkIGJ5IFVsZWFkIFNtYXJ0U2F2ZXIhAAA7';

var HTML_ESCAPE = new _.RegGrp([
  "&", "&amp;",
  "<", "&lt;",
  ">", "&gt;"
]);

var URL = _private.get(window, "URL");
var Blob = _private.get(window, "Blob");

var SUPPORTS_DOWNLOAD = URL && Blob && _.detect("(<a>.download)");

function flatten(array) {
  var i = 0;
  var flattener = function _flattener(result, item) {
    if (_.isArray(item)) {
      _.reduce(item, flattener, result);
    } else {
      result[i++] = item;
    }
    return result;
  };
  return _.reduce(array, flattener, []);
}

function jsonCopy(data) {
  return JSON.parse(JSON.stringify(data))
}

function download(html, name) {
  var pathname = location.pathname.slice(location.pathname.lastIndexOf("/") + 1);
  var blob = new Blob([html], {"type" : "text/plain"});
  var fragment = document.createDocumentFragment();
  var downloader = document.createElement("a");
	downloader.href = URL.createObjectURL(blob);
	downloader.download = name || pathname || "index.html";
  fragment.appendChild(downloader);
	downloader.click();
}
