
var JSONDirectory = io.Directory.extend({
  createKey: function JSONDirectory__createKey(name) {
    return _.trim(name);
  }
}, {
  Item: {
    constructor: function JSONDirectory_Item(name, item) {
      this.name = String(name);
      this.isDirectory = typeof item == "object";
      this.size = this.isDirectory ? 0 : item.length || 0;
    }
  }
});
