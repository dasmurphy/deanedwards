
(function(js) {
  js.add("\\b(ancestorOf|ArrayLike|assignID|attach|Base|base2|base2ID|\
bind|Collection|detach|detect|every|extend|False|filter|format|Functional|I|II|\
implement|indexOf|invoke|isArray|isFunction|K|lastIndexOf|map|memoize|modify|\
now|Null|once|Package|partial|plant|pluck|provide|reduce|reduceRight|RegGrp|\
slice|some|Trait|trim|Trait|True|unbind|Undefined)\\b", '<span class="base2">$1</span>');
  js.add("\\b(behavior)\\b", '<span class="jsb-behavior">$1</span>');
  js.add("\\b(base)\\b", '<span class="colorize-global">$1</span>');
  js.insertAt(0, /("@[^"]+"):/, '<span class="colorize-conditional-comment colorize-string">$1</span>:');
  js.tabStop = 2;
})(Colorizer.getScheme("js"));
