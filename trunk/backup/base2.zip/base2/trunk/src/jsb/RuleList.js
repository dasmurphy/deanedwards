
// A collection of Rule objects

var RuleList = _.Collection.extend({
  constructor: function RuleList__constructor() {
    if (/*@ this.valueOf && @*/ !(this instanceof RuleList)) {
      var rules = new RuleList;
      rules.merge.apply(rules, arguments);
    } else {
      this.base.apply(this, arguments);
    }
  },

  apply: function RuleList__apply(node) {
    this.invoke("apply", node);
  },

  refresh: function RuleList__refresh() {
    this.invoke("refresh");
  },

  set: function Collection__set_detect(selector, behavior) {
    selector = String(selector);
    if (selector < "A" && selector > "@") { // allow feature detection
      if (_.detect(selector.slice(1))) this.merge(behavior);
    } else {
      this.base(selector, behavior);
    }
  }
});

RuleList.Item = Rule;
