<!doctype html>
<title>Animation Test Page</title>
<meta charset="utf-8">
<script src="/base2/trunk/src/console2.js"></script>
<script src="/base2/trunk/src/base2-jsb.js"></script>

<script>
new jsb.RuleList({
  "#start": {
    ":onclick": function(element) {
      var example = this.querySelector(document, "#example1");
      this.animate(example, {
        right: "0px",
        backgroundColor: "lime"
      });
    }
  },

  "#reset": {
    ":onclick": function(element) {
      var example = this.querySelector(document, "#example1");
      this.animate(example, {
        right: "auto",
        backgroundColor: "auto"
      });
    }
  },

  "#example1": {
    ":ontransitionend": function(element, event, propertyName) {
      console2.log(propertyName);
    }
  }
});
</script>

<style>
.example {
  position: absolute;
  background: red;
  height: 50px;
  width: 50px;
  color: white;
  font-weight: bold;
  cursor: default;
  margin-bottom: 10px;
}
.move {
  left: 100%;
}
.container {
  position: relative;
  width: 650px;
  height: 50px;
  background: silver;
}
button {
  font-size: x-large;
}
</style>

<h1>Animation Test Page</h1>

<div class="container">
 <div class="example" id="example1"></div>
</div>
<p>
 <button id="start" type="button">Start</button>
 <button id="reset" type="button">Reset</button>
</p>
