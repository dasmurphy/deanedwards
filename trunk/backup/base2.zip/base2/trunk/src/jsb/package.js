
jsb = new _.Package({
  name:    "jsb",
  version: "%%VERSION%%",

  element: baseBehavior,
  form:    form,
  
  ExtendedNodeList: ExtendedNodeList,

  Rule: Rule,
  RuleList: RuleList,
  StyleSheet: StyleSheet
});
