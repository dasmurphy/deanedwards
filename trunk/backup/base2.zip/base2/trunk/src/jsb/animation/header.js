
var CONST_INTERVAL  = 14; // 70 fps

var TIME = /([\d\.]+)(m)?s$/;

function parseTime(time, defaultValue) {
  if (time == null) return defaultValue || 0;
  return TIME.test(time) ? String(time).replace(TIME, function($, t, ms) {
    return ms ? +t : t * 1000;
  })|0 : 0;
}

function isComplete(animation) {
  return animation.complete;
}
