
var AnimationQueue = _.Collection.extend({
  constructor: function AnimationQueue__constructor(transitions) {
    this.base(transitions);
    this.tick = _.bind(this.tick, this);
  },
  
  add: function AnimationQueue__add(behavior, element, animation) {
    var key = element.uniqueID || _.assignID(element);
    this.set(key, behavior, animation);
    if (!this._started) {
      this._started = true;
      setTimeout(this.tick, 0);
    }
  },

  tick: function AnimationQueue__tick() {
    this.invoke("tick", _.now());

    this.filter(isComplete).forEach(this.remove, this);

    if (this.size() > 0) {
      setTimeout(this.tick, CONST_INTERVAL, null);
    } else {
      delete this._started;
    }
  }
}, {
  Item: Animation
});

animationQueue = new AnimationQueue;
