
var Animation = _.Base.extend({
  constructor: function Animation__constructor(key, behavior, properties) {
    this.timestamp = Date.now();
    this.behavior = behavior;
    this.delay = parseTime(properties.transitionDelay);
    this.duration = parseTime(properties.transitionDuration, 1000);
    this.ease = _private.parseTimingFunction(properties.transitionTimingFunction);
    this.onstep = properties.onstep;
  },

  tick: function Animation__tick(now) {
    if (!this.started && now - this.timestamp >= this.delay) {
      this.started = now;
    }
    if (this.started) {
      var t = now - this.started;

      this.complete = t >= this.duration;

      var value = this.complete ? 1 : this.ease(t, 0, 1, this.duration);

      this.onstep.call(this.behavior, value)
    }
  },

  complete: false,
  started: 0
});
