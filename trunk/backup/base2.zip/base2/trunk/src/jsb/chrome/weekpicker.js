
var weekpicker = datepicker.extend({
  // constants
  
  FORMAT: "yyyy-Www",
  PATTERN: /^\d{4}-W([0-4]\d|5[0-3])$/,
  
  // properties

  baseValue: Date.UTC(1969, 11, 29),
  type: "week", // HTML5 type
  appearance: "weekpicker",
  stepScale: 7 * DAY,
  placeholder: "yyyy-Www",

  showLocaleString: _.Undefined,
  
  "@(<input>.spellcheck)": {
    ":onfocus": function(element, event) {
      element.spellcheck = false;
      this.base(element, event);
    }
  },

  convertValueToNumber: function weekpicker_convertValueToNumber(value) {
    if (!this.PATTERN.test(value)) return NaN;
    var parts = String(value).split("-W");
    var year = parts[0];
    var week1 = this.getFirstWeek(year);
    var week = parts[1];
    var date = new Date(week1.valueOf() + (week - 1) * this.stepScale);
    return (week === 53 && new Date(Date.UTC(year, 0, 1)).getUTCDay() !== chrome.locale.firstDay + 3) ? NaN : +date;
  },

  convertNumberToValue: function weekpicker_convertNumberToValue(number) {
    var date = this.normalise(number);
    var year = date.getUTCFullYear();
    var week1 = this.getFirstWeek(year);
    var week = ~~((date - week1) / this.stepScale) + 1;
    return pad(year, 4) + "-W" + pad(week);
  },
  
  getFirstWeek: function weekpicker_getFirstWeek(year) {
    var date = new Date(Date.UTC(year, 0, 1));
    var day = date.getUTCDay() - chrome.locale.firstDay;
    if (day > 3) day -= 7;
    date.setUTCDate(date.getUTCDate() - day);
    return date;
  },

  normalise: function weekpicker_normalise(value) {
    return new Date(this.baseValue + ~~((value - this.baseValue) / this.stepScale) * this.stepScale + 3 * DAY);
  },

  Popup: {
    "onkeydown": function weekpicker_popup_onkeydown(event) {
      if (!/^(37|39)$/.test(event.keyCode)) { // ignore datepicker behaviour for left/right arrows
        this.base(event);
      }
    },
    
    "onmouseover": function weekpicker_popup_onmouseover(event) {
      var target = this.getTarget(event);
      if (target) {
        var cell = dom.querySelector(target, "td:not(.disabled)");
        if (cell) {
          this.highlight(target);
          this.currentDate = ~~cell[TEXT_CONTENT];
        }
      }
    },

    "onmouseup": function weekpicker_popup_onmouseup(event) {
      if (this.getTarget(event)) this.select();
    },

    getTarget: function weekpicker_popup_getTarget(event) {
      var target = event.target;
      if (target.nodeName === "TD") {
        target = target.parentNode;
      }
      return target.nodeName === "TR" && dom.contains(this.days, target) && !dom.classList.contains(target, "disabled")
        ? target
        : null;
    },

    highlight: function weekpicker_popup_highlight(item) {
      if (item && item.nodeName === "TD") {
        item = item.parentNode;
      }
      if (!dom.classList.contains(item, "disabled")) {
        this.base(item);
      }
    }
  }
});
