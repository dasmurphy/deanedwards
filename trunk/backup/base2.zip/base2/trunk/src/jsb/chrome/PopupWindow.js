
var PopupWindow = Popup.extend({
  constructor: function PopupWindow__constructor(owner) {
    this.base();
    this.owner = owner;
    this.body.id = "jsb-popup-window";
  },
  
  // properties

  controls: null,
  owner: null,
  scrollX: true,
  scrollY: true,
  role: "application",
  
  // events

  "onkeydown": function PopupWindow__onkeydown(event) {
    switch (event.keyCode) {
      case 13: // enter
      case 27: // escape
        event.preventDefault();
        this.element.focus();
        this.hide();
        break;
        
      case 9: // tab
        if (this.tab(event.shiftKey ? -1 : 1)) {
          event.preventDefault();
        }
        break;
    }
  },
  
  // methods

  focus: function PopupWindow__focus() {
    this.controls[0].focus();
  },

  getTabStops: function PopupWindow__getTabStops() {
    return this.controls;
  },

  hide: function PopupWindow__hide() {
    if (this.isOpen()) {
      _PopupWindow_activePopup = null;
      this.base();
      this.element.removeAttribute("aria-expanded");
      this.element.removeAttribute("aria-owns");
    }
  },

  isActive: function PopupWindow__isActive() {
    return !!dom.querySelector(this.body, ":hover,:focus");
  },

  render: function PopupWindow__render(html) {
    this.base(html);
    this.controls = this.findAll("button,input,select,textarea");
  },

  show: function PopupWindow__show(element) {
    this.base(element);
    _PopupWindow_activePopup = this;
    element.setAttribute("aria-owns", "jsb-popup-window");
    element.setAttribute("aria-expanded", true);
  },

  style: function PopupWindow__style() {
    var style = this.body.style;
    style.left = "-9999px";
    style.top = "-9999px";
    style.width = "";
    style.height = "";
    var computedStyle = dom.getComputedStyle(this.element);
    forEach.csv("backgroundColor,color,fontFamily,fontWeight,fontStyle", function(propertyName) {
      style[propertyName] = computedStyle[propertyName];
    });
    if (style.color === "rgb(172, 168, 153)") { // old versions of Gecko truncate this font for some reason
      style.color = "black";
    }
    if (style.fontFamily === "MS She") { // old versions of Gecko truncate this font for some reason
      style.fontFamily = "MS Shell Dlg";
    }
    style.fontSize = computedStyle.fontSize;
    if (style.backgroundColor === "transparent") {
      style.backgroundColor = "white";
    }
  },

  tab: function PopupWindow__tab(direction) {
    var controls = this.getTabStops(),
        firstControl = controls[0],
        lastControl = controls[controls.length - 1],
        current = this.find(":focus");
        
    if (!current) return false;

    if (direction === 1) {
      if (current == lastControl) {
        var nextControl = firstControl;
      }
    } else {
      if (current == firstControl) {
        nextControl = lastControl;
      }
    }
    
    if (nextControl) {
      nextControl.focus();
      if (nextControl.select) nextControl.select();
      return true;
    }

    return false;
  }
});

var _PopupWindow_activePopup = null;
var _PopupWindow_isMouseDown = true;

dom.addEventListener(document, "mousedown", _PopupWindow_hidePopup, true);
dom.addEventListener(document, "mouseup", function() {
  _PopupWindow_isMouseDown = false;
}, true);

function _PopupWindow_hidePopup(event) {
  var target = event.target;
  var popup = _PopupWindow_activePopup;

  if (event.type === "blur" && _PopupWindow_isMouseDown) return;
  
  _PopupWindow_isMouseDown = event.type === "mousedown";

  if (popup && target != document && target != popup.element && target != shim.control && target != popup.body && !dom.contains(popup.body, target)) {
    popup.hide();
  }
}
