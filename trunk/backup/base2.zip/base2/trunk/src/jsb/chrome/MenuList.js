
var MenuList = PopupWindow.extend({
  constructor: function MenuList__constructor(owner) {
    this.base(owner);
    this.data = {};
  },

  // properties

  appearance: "menulist",
  role: "menu",

  // events

  "onmouseup": function MenuList__onmouseup(event) {
    this.select(this.currentItem);
  },

  "onkeydown": function MenuList__onkeydown(event) {
    switch (event.keyCode) {
      case 9: // tab
        this.hide();
        this.element.focus();
        return;
        
      case 13: // return
        event.preventDefault();
        this.select(this.currentItem);
        return;
        
      case 38: // up
        if (this.currentItem) {
          this.highlight(dom.get(this.currentItem, "previousElementSibling"), true);
        } else {
          this.highlight(dom.get(this.body, "firstElementChild"), true);
        }
        break;
        
      case 40: // down
        if (this.currentItem) {
          this.highlight(dom.get(this.currentItem, "nextElementSibling"), true);
        } else {
          this.highlight(dom.get(this.body, "firstElementChild"), true);
        }
        break;
        
      case 36: // home
        this.highlight(dom.get(this.body, "firstElementChild"), true);
        break;
        
      case 35: // end
        this.highlight(dom.get(this.body, "lastElementChild"), true);
        break;
        
      default:
        this.base(event);
        return;
    }
    event.preventDefault();
  },

  "onmouseover": function MenuList__onmouseover(event) {
    this.highlight(event.target);
  },

  // methods

  focus: function MenuList__focus() {
    var item = this.currentItem;
    if (item && item.focus) {
      item.focus();
    }
  },

  getNodeIndex: function MenuList__getNodeIndex(node) {
    var index = 0;
    while (node && (node = node.previousSibling)) index++;
    return index;
  },

  getUnitHeight: function MenuList__getUnitHeight() {
    var item = dom.get(this.body, "firstElementChild");
    return item ? item.offsetHeight : 1;
  },
  
  "@MSIE9": {
    getUnitHeight: function MenuList__getUnitHeight() {
      var items = this.body.getElementsByTagName("div");
      return items.length === 0 ? 1 : this.body.scrollHeight / items.length;
    }
  },

  highlight: function MenuList__highlight(item, focus) {
    if (item) {
      this.reset(this.currentItem);
      this.currentItem = item;
      dom.classList.add(item, "jsb-selected");
      item.tabIndex = 0;
      item.setAttribute("aria-selected", true);
      if (focus && item.focus) item.focus();
    }
  },

  layout: function MenuList__layout() {
    this.currentItem = null;
    var data = this.data[this.element.uniqueID];
    var element = data
      ? this.body.childNodes[data.index]
      : dom.get(this.body, "firstElementChild");
    this.highlight(element, true);
  },

  render: function MenuList__render() {
    var list = this.owner.get(this.element, "list");
    var html = "";
    if (list) {
      var attributes = 'role="menuitem" unselectable="on" tabindex="-1"';
      if (list.nodeType === 1) {
        if (list.nodeName !== "SELECT") {
          list = dom.find(list, "select") || list;
        }
        if (list) {
          var options = list.innerHTML.split(/<\/option>/i).join("");
          html = _.trim(options).replace(/<option/gi, '</div><div ' + attributes).slice(6) + '</div>';
        }
      } else {
        if (_.isArray(list)) {
          html = wrapHTML(list, "div", attributes);
        } else {
          html = _.reduce(list, function(html, text, value) {
            return html += '<div ' + attributes + ' value="' + value + '">' + text + '</div>';
          });
        }
      }
    }
    this.base(html);
  },

  reset: function MenuList__reset(item) {
    if (item) {
      dom.classList.remove(item, "jsb-selected");
      item.removeAttribute("aria-selected");
      item.tabIndex = -1;
    }
  },

  select: function MenuList__select(item) {
    var value = item.getAttribute("value") || _.trim(item[TEXT_CONTENT]);
    var element = this.element;

    this.data[element.uniqueID] = {
      index: this.getNodeIndex(item),
      value: value
    };
    this.owner.setValue(element, value);
    this.hide();
    element.focus();
  }
});
