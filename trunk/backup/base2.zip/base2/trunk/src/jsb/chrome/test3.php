<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
 <title>chrome: Test Page</title>
<script src="/base2/trunk/src/legacy.js" type="text/javascript"></script>
 <script src="/base2/trunk/src/console2.js" type="text/javascript"></script>
 <script src="/base2/trunk/src/base2/jsb/html5/html5.php" type="text/javascript"></script>
 <script>
 onload2=function() {
  var f = document.createElement("form");
  i.type = "number";
  i.value = "0";
  alert(i.valueAsDate);
 }
 new jsb.Rule("form", {
  ondocumentready: function(form) {
    var i = form.elements[0];
    html5.form.checkValidity(form);
  },
  
  oninvalid: function(form, event) {
    console2.log("INVALID: "+ event.target.name);
  }
});
 new jsb.Rule("input,select", {
  onchange: function(element, event) {
    console2.log(event.type + ": " + element.name);
  }
 });
 </script>
</head>

<body lang="en">
<!--h1 style="background-color:ActiveCaption;color:CaptionText">chrome: Test Page</h1>
<p><input style="height:204px;width:18px" class="jsb-progressbar" type="text" value="<?php echo rand(1,99) ?>"/>
<input style="height:204px;width:22px" class="jsb-slider" type="text" value="<?php echo rand(1,99) ?>" disabled />
<input style="height:204px;width:18px" class="jsb-progressbar" type="text" value="<?php echo rand(1,99) ?>"  readonly />
<input style="height:204px;width:22px" class="jsb-slider" type="text" value="<?php echo rand(1,99) ?>"/></p-->
<?php
for ($i = 0; $i < 1; $i++) {
?>
<form action="" method="post" enctype="multipart/form-data">
<h2>Block <?php echo $i+1 ?></h2>
<ol>
<?php
  for ($j = 1; $j < 4; $j++) {
?>
 <li><p><input name="combobox<?php echo $i.$j; ?>" class="jsb-combobox" list="thousands" type="text" value="Gooner!" <?php if($j==2)echo 'disabled' ?>/>
  <select <?php if($j==2)echo 'disabled' ?>>
    <option>Baroness
    <option>Dr
    <option>Dr
    <option>Lady
    <option>Lord
    <option>Miss
    <option>Mr
    <option>Mrs
    <option>Prof
    <option>Rt Hon
    <option>Sir
  </select>
  <input name="colorpicker<?php echo $i.$j; ?>" type="color" value="#<?php
    for ($k = 0; $k < 3; $k++) {
      $r = rand(0, 255);
      if ($r < 16) echo "0";
      echo dechex($r);
    }
   ?>" <?php if($j==2)echo 'disabled' ?>/>
  <input name="text<?php echo $i.$j; ?>" type="text" value="abc" pattern="\d+" <?php if($j==2)echo 'disabled' ?>/>
  <input name="spinner<?php echo $i.$j; ?>" step="2" min="1" max="9" type="number" <?php if($j==2)echo 'disabled' ?>>
  <input name="monthpicker<?php echo $i.$j; ?>" type="month" step="2" value="" <?php if($j==2)echo 'disabled' ?>>
  <input name="timepicker<?php echo $i.$j; ?>" type="time" <?php if($j==2)echo 'disabled' ?>>
  <input name="datepicker<?php echo $i.$j; ?>" min="2007-08-28" type="date" value="" <?php if($j==2)echo 'disabled' ?>><br><br>
  <input name="weekpicker<?php echo $i.$j; ?>" type="week" value="" <?php if($j==2)echo 'disabled' ?> required>
  <input name="progressbar<?php echo $i.$j; ?>" type="text" value="<?php echo rand(1,99) ?>" <?php if($j==2)echo 'disabled' ?>  readonly>
  <input name="slider<?php echo $i.$j; ?>" type="range" value="<?php echo rand(1,99) ?>" <?php if($j==2)echo 'disabled' ?>>
  <!--input name="combobox<?php echo $i.$j; ?>" type="text" <?php if($j==2)echo 'disabled' ?>>
  <input name="text<?php echo $i.$j; ?>" type="text" <?php if($j==2)echo 'disabled' ?>--></p></li>
<?php
  }
?>
</ol>
<p><button type="submit">Submit</button></p>
</form>
<!--script type="text/javascript">
console2.log("Loading blocking script...");
document.write('<script src="block.js.php?' + (new Date().valueOf()) + '" type="text/javascript"><\/script>');
</script-->
<?php
}
?>
<select class="jsb-datalist" id="thousands">
    <option>Gooner!
    <option>Baroness
    <option>Dr
    <option>Dr
    <option>Lady
    <option>Lord
    <option>Miss
    <option>Mr
    <option>Mrs
    <option>Prof
    <option>Rt Hon
    <option>Sir
    <option>Viscount
    <option>Herr
    <option>Monsieur
    <option>Hr
    <option>Frau
    <option>Rekky
</select>
</body>
</html>
