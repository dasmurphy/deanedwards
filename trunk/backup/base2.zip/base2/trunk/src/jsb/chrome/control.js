
var control = jsb.element.extend({
  // constants

  _CURSOR: "",
  _IMAGE_WIDTH: 17,

  states: {
    normal:   0,
    hover:    1,
    active:   2,
    disabled: 3,
    length:   4
  },
  
  // properties

  type: "text", // HTML5 type
  appearance: "none",
  allowVertical: false,
  placeholder: "",

  "jsb:onattach": function control_onattach(element) {
    _attachments[element.uniqueID] = this;

    if (this.placeholder && element.placeholder === "") {
      element.placeholder = this.placeholder;
    }

    // If we cannot style based on attribute selectors then we'll add a class
    if (!SUPPORTS_ATTRIBUTE_SELECTORS && this.appearance !== "none" && element.nodeName !== "progress") {
      this.classList.add(element, "jsb-" + this.appearance);
    }

    if (this.allowVertical && element[HEIGHT] > element[WIDTH]) {
      this.setOrientation(element, "vertical");
    }

    // Prevent autocomplete popups.
    // This library provides UI support, automplete popups will conflict with the provided UI.
    if (element.name && element.form) {
      // setting this attribute does not seem to cause a reflow
      element.setAttribute("autocomplete", "off");
    }

    this.layout(element, this.states[element.disabled ? "disabled" : "normal"]); // initial state
  },

  "jsb:onlosecapture": function control_onlosecapture(element) {
    delete control._active;
    delete control._dragging;
    delete control._activeThumb;
    delete control._dragInfo;
    this.setUnselectable(element, false);
    this.layout(element);
  },

  onmousedown: function control_onmousedown(element, event) {
    control._active = element;

    if (!this.isEditable(element)) return;

    control._activeThumb = this.hitTest(element, event);
    
    if (control._activeThumb) {
      this.setCapture(element);
      control._dragging = true;
      this._unselectableTimer = this.setTimeout("setUnselectable", 1, element, true);
    }
    this.layout(element);
  },

  onmouseup: function control_onmouseup(element, event) {
    this.releaseCapture();
  },

  onmousemove: function control_onmousemove(element, event) {
    var thumb = this.hitTest(element, event);
    if (thumb != control._hoverThumb) {
      control._hoverThumb = thumb;
      this.layout(element);
    }
    if (control._dragging) {
      event.preventDefault();
    }
  },

  onmouseover: function control_onmouseover(element, event) {
    control._hover = element;
    control._hoverThumb = this.hitTest(element, event);
    this.layout(element);
  },

  onmouseout: function control_onmouseout(element) {
    delete control._activeThumb;
    delete control._hoverThumb;
    delete control._hover;
    this.layout(element);
  },

  onfocus: function control_onfocus(element) {
    control._focus = element;
    this.layout(element);
    this.setAttributes(element);
  },

  onblur: function control_onblur(element) {
    delete control._focus;
    this.classList.remove(element, this.appearance + _FOCUS);
    this.layout(element);
    this.hideToolTip();
  },
  
  // methods

  set: function control_set(element, propertyName, value) {
    value = this.base(element, propertyName, value);
    if (/^(disabled|readOnly)$/.test(propertyName)) {
      this.layout(element);
    }
    return value;
  },

  getCursor: function control_getCursor(element) {
    return (control._activeThumb || control._hoverThumb || element != control._hover || control._dragging) ? "default" : this._CURSOR;
  },

  getState: K(0),

  getValue: function control_getValue(element) {
    return element.value;
  },

  setValue: function control_setValue(element, value) {
    if (value != element.value) {
      element.value = value;
      this.fire(element, "input");
      this.fire(element, "change");
      this.layout(element);
    }
  },

  getOffsetXY: function getOffsetXY(element, clientX, clientY) { // faster if clientLeft/Top are defined
    var clientRect = dom.getBoundingClientRect(element);

    return {
      x: clientX - clientRect.left - element.clientLeft,
      y: clientY - clientRect.top - element.clientTop
    }
  },

  "@!(element.clientLeft)": { // Firefox 2 -@DRE
    getOffsetXY: function getOffsetXY(element, clientX, clientY) {
      var clientRect = dom.getBoundingClientRect(element);
      var computedStyle = window.getComputedStyle(element, null);

      return {
        x: clientX - clientRect.left - parseInt(computedStyle.borderLeftWidth),
        y: clientY - clientRect.top - parseInt(computedStyle.borderTopWidth)
      }
    }
  },

  hitTest: function control_hitTest(element, event) {
    var offset = this.getOffsetXY(element, event.clientX, 0);
    return offset.x >= element[WIDTH] - this._IMAGE_WIDTH;
  },

  isActive: function control_isActive(element) {
    return control._activeThumb && (control._activeThumb == control._hoverThumb);
  },

  isEditable: function control_isEditable(element) {
    return (!element.disabled && !element.readOnly) || element == control._readOnlyTemp;
  },

  layout: function control_layout(element, state) {
    if (state == null) {
      state = this.getState(element);
      this.syncCursor(element);
    }

    var clientHeight = element[HEIGHT];
    var top = - this.states.length * (clientHeight / 2 * (clientHeight - 1));
    var style = element.style;
        
    top -= clientHeight * state;

    var backgroundPosition = "100% " + top + "px";
    if (style.backgroundPosition !== backgroundPosition) {
      style.backgroundPosition = backgroundPosition;
    }
  },

  setAttributes: function control_setAttributes(element) {
    if (this.role) element.setAttribute("role", this.role);
  },

  setOrientation: function control_setOrientation(element, orientation) {
    if (orientation == "vertical") {
      var backgroundImage = this.style.compute(element, "backgroundImage");
      this.style.set(element, "backgroundImage", backgroundImage.replace(/\.png/i, "-vertical.png"), true);
    } else if (element.style.backgroundImage) {
      element.style.backgroundImage = "";
    }
    //this.setUserData(element, "orientation", orientation);
  },

  setUnselectable: _.Undefined,

  "@!KHTML": { // This seems to make things worse on KHTML-based browsers.
    setUnselectable: function control_setUnselectable(element, unselectable) {
      this.style.set(element, "userSelect", unselectable ? "none" : "");
      clearTimeout(this._unselectableTimer);
    },

    "@MSIE": { // can't detect the "unselectable" property
      setUnselectable: function control_setUnselectable_msie(element, unselectable) {
        clearTimeout(this._unselectableTimer);
        if (unselectable) {
          element.unselectable = "on";
        } else {
          element.removeAttribute("unselectable");
        }
      }
    }
  },

  hideToolTip: function control_hideToolTip() {
    if (control.tooltip) {
      control.tooltip.hide();
    }
  },

  showToolTip: function control_showToolTip(element, text, duration) {
    var tooltip = control.tooltip;
    if (!tooltip) {
      tooltip = control.tooltip = new ToolTip;
    }
    setTimeout(function() {
      tooltip.show(element, text, duration);
    }, 1);
  },

  syncCursor: function control_syncCursor(element) {
    element.style.cursor = this.getCursor(element);
  },

  hasTimer: function control_hasTimer(element, id) {
    id = element.uniqueID + (id || _TIMER);
    return !!_timers[id];
  },

  startTimer: function control_startTimer(element, id, interval) {
    id = element.uniqueID + (id || _TIMER);
    if (!_timers[id]) {
      _timers[id] = this.setInterval(this.tick, interval || 100, element);
    }
  },

  stopTimer: function control_stopTimer(element, id) {
    id = element.uniqueID + (id || _TIMER);
    if (_timers[id]) {
      clearInterval(_timers[id]);
      delete _timers[id];
    }
  },

  tick: _.Undefined,

  "@Opera": {
    syncCursor: _.Undefined
  }
});
