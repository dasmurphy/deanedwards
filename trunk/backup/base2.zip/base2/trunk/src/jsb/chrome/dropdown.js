
var dropdown = control.extend({
  name: "combobox",
  appearance: "combobox",
  
  extend: function dropdown_extend() {
    for (var i = 0; i < arguments.length; i++) {
      var Popup = arguments[i].Popup;
      if (Popup) {
        delete arguments[i].Popup;
        break;
      }
    }
    var dropdown = this.base.apply(this, arguments);
    if (Popup) dropdown.Popup = Popup;
    if (typeof dropdown.Popup != "function") {
      dropdown.Popup = this.Popup.extend(dropdown.Popup);
    }
    return dropdown;
  },

  "@MSIE": _MSIEShim, // prevent typing over the background image
  
  _KEYCODE_ACTIVATE: /^(38|40)$/,
  
  // properties

  Popup: PopupWindow, // popup class
  
  // events

  ":onblur": function dropdown_onblur(element, event) {
    if (this.isOpen(element) && !dropdown._active && !this.popup.isActive()) {
      this.hidePopup();
    }
    this.base(element, event);
  },

  ":onkeydown": function dropdown_onkeydown(element, event) {
    dropdown._active = true;
    if (this.isEditable(element)) {
      if (this._KEYCODE_ACTIVATE.test(event.keyCode) && !this.isOpen(element)) {
        this.showPopup(element);
        this.popup.focus();
        event.preventDefault();
      } else if (this.isOpen(element)) {
        this.popup.focus();
        this.popup.onkeydown(event);
      }
    }
    delete dropdown._active;
  },

  ":onmousedown": function dropdown_onmousedown(element, event) {
    dropdown._active = true;
    this.base(element, event);
    if (this.isEditable(element)) {
      if (this.hitTest(element, event)) {
        if (this.isOpen(element)) {
          this.hidePopup();
        } else {
          this.showPopup(element);
        }
      } else {
        this.hidePopup();
      }
      element.focus();
    }
    setTimeout(function() {
      delete dropdown._active;
    }, 4);
  },

  "@Opera9\\.[0-4]": {
    ":onblur": function dropdown_onblur_opera9(element, event) {
      // Early Opera: mousedown doesn't cancel but blur does.
      if (dropdown._active || (this.isOpen(element) && this.popup.isActive())) {
        event.preventDefault();
      } else {
        this.base(element, event);
      }
    },

    ":onkeypress": function dropdown_onkeypress_opera9(element, event) {
      if (this.isOpen(element) && event.keyCode === 13) {
        event.preventDefault();
      }
    }
  },
  
  // methods

  getState: function dropdown_getState(element) {
    if (element.disabled) {
      var state = "disabled";
    } else if (element.readOnly && element != control._readOnlyTemp) {
      state = "normal";
    } else if (element == control._active && control._activeThumb) {
      state = "active";
    } else if (element == control._hover && control._hoverThumb) {
      state = "hover";
    } else {
      state = "normal";
    }
    return this.states[state];
  },

  hidePopup: function dropdown_hidePopup() {
    if (this.popup) this.popup.hide();
  },

  isOpen: function dropdown_isOpen(element) {
    var popup = this.popup;
    return popup && popup == _PopupWindow_activePopup && popup.element == element && popup.isOpen();
  },

  setAttributes: function dropdown_setAttributes(element) {
    element.setAttribute("aria-haspopup", true);
    this.base(element);
  },

  showPopup: function dropdown_showPopup(element) {
    this.hideToolTip();
    if (!this.popup) {
      this.popup = new this.Popup(this);
    }
    this.popup.show(element);
  },

  "@theme=aqua": {
    "@(style.borderImage)": {
      hitTest: function dropdown_hitTest_aqua(element, event) {
        var offset = this.getOffsetXY(element, event.clientX, 0);
        return offset.x >= element[WIDTH];
      }
    },

    layout: function dropdown_layout_aqua(element, state) {
      if (state == null) this.syncCursor(element);
    }
  }
});
