
var progressbar = range.extend({
  // constants
  
  _CHUNK_SIZE: 1,

  "@theme=luna": {
    _CHUNK_SIZE: 10
  },

  // properties

  name: "progressbar",
  appearance: "progressbar",
  role: "progressbar",
  
  value: 0,

  // events

  ":onmouseover": null,
  ":onmousemove": null,
  ":onmouseout": null,

  // methods

  hitTest: _.False,

  getValue: function progressbar_getValue(element) {
    return this.getAttribute(element, "value") || "";
  },

  setValue: function progressbar_setValue(element, value) {
    var currentValue = this.getAttribute(element, "value") || "";
    if (value != currentValue) {
      this.setAttribute(element, "value", value);
      this.layout(element);
    }
  },

  layout: function progressbar_layout(element) {
    var clientWidth = element[WIDTH] - 2;
    var clientHeight = element[HEIGHT] - 2;
    var relativeValue = this.getProperties(element).relativeValue;

    if (clientHeight > clientWidth) {
      var left = (-clientWidth / 2) * (clientWidth + 3) - 2;
      var top = ~~(clientHeight * relativeValue);
      top = clientHeight - Math.round(top / this._CHUNK_SIZE) * this._CHUNK_SIZE;
    } else {
      left = ~~(clientWidth * relativeValue) - this._IMAGE_SIZE;
      left = Math.round(left / this._CHUNK_SIZE) * this._CHUNK_SIZE;
      top = (-clientHeight / 2) * (clientHeight + 3) - 2;
    }

    element.style.backgroundPosition = ++left + "px" + " " + ++top + "px";
  }
});
