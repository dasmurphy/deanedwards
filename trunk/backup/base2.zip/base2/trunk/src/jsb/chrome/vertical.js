
var vertical = {
  allowVertical: false, // weird huh?

  "jsb:onattach": function(element) {
    var name = "jsb-" + this.name;
    var isVertical = element[HEIGHT] > element[WIDTH];
    if (isVertical) {
      this.classList.add(element, name);
      this.classList.add(element, name + "-vertical");
      this.base(element);
    } else {
      this.classList.remove(element, name);
      this.detach(element);
    }
    return isVertical;
  },

  "@Opera": {
    "jsb:onattach": function(element) {
      if (this.base(element)) {
        element.value = 0;
      }
    }
  }
};

var vslider      = slider.extend(vertical);
var vprogressbar = progressbar.extend(vertical);
