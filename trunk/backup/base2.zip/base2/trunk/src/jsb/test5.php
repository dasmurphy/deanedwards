<!doctype html>
<title>Animation Test Page</title>
<meta charset="utf-8">
<script src="/base2/trunk/src/console2.js"></script>
<script src="/base2/trunk/src/base2-jsb.js"></script>

<script>
new jsb.RuleList({
  "#start": {
    ":onclick": function(element) {
      this.animate(this.querySelector(document, "#example1"), {
        left: "100%",
        duration: 2000,
        timingFunction: "cubic-bezier(.64,.57,.67,1.53)"
      });

      this.classList.toggle(this.querySelector(document, "#example2"), "move");
      this.classList.toggle(this.querySelector(document, "#example3"), "move");
    }
  },

  "#reverse": {
    ":onclick": function(element) {
      this.animate(this.querySelector(document, "#example1"), {
        left: "0%",
        duration: 2000,
        timingFunction: "cubic-bezier(.64,.57,.67,1.53)"
      });

      this.classList.toggle(this.querySelector(document, "#example2"), "move");
      this.classList.toggle(this.querySelector(document, "#example3"), "move");
    }
  }
});
</script>

<style>
.example {
  position: relative;
  left: 0;
  background: red;
  height: 50px;
  width: 50px;
  color: white;
  font-weight: bold;
  cursor: default;
  margin-bottom: 10px;
}
#example2 {
  -webkit-transition: all 2s cubic-bezier(.64,.57,.67,1.53);
  -o-transition: all 2s cubic-bezier(.64,.57,.67,1.53);
  -moz-transition: all 2s cubic-bezier(.64,.57,.67,1.53);
}
#example3 {
  -webkit-transition: all 2s linear;
  -o-transition: all 2s linear;
  -moz-transition: all 2s linear;
}
.move {
  left: 100%;
}
.container {
  position: relative;
  width: 60%;
  margin: 0 auto;
  background: silver;
}
button {
  font-size: x-large;
}
</style>

<h1>Animation Test Page</h1>

<div class="container">
 <div class="example" id="example1"></div>
 <div class="example" id="example2"></div>
 <div class="example" id="example3"></div>
</div>
<p>
 <button id="start" type="button">Start</button>
 <button id="reverse" type="button">Reverse</button>
</p>
