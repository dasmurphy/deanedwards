
var Behavior = _.Base.extend({
  jsbExtendedMouse: false, // allow right and middle button clicks
  jsbUseDelegation: false, // use event delegation (appropriate events are handled by the document object)

  ancestor: null,

  attach: _.Undefined, // these methods are defined when the behavior is created
  detach: _.Undefined,
  modify: _.Undefined,

  ancestorOf: function ancestorOf(behavior) {
    return behavior != this && behavior instanceof this.constructor;
  },
  
  extend: function extend() {
    // Extend a behavior to create a new behavior.

    // Create the Behavior constructor.
    var attached = {};
    var Behavior = function Behavior() {
      return arguments[0] == SECRET ? attached : undefined;
    };
    (Behavior.prototype = new this.constructor).constructor = Behavior;

    // Decorate the prototype.
    for (var i = 0; i < arguments.length; i++) {
      _.extend(Behavior.prototype, arguments[i], true);
    }

    // Single instance.
    var behavior = new Behavior;
    var forwardListener = {};
    var keyHandlers = new KeyHandlers;
    var meta = {behavior: behavior, keyHandlers: keyHandlers, events: {}, transitionEvents: {}};
    var attachedEvents = {}, allEvents = {};
    var usesDelegation = false;

    function eventListener(event) {
      dispatchEvent(behavior, event.currentTarget, event, meta);
    }

    function forwardEvent(element) {
      var eventListener = function eventListener(event) {
        if (element[IS_CONNECTED]) { // make sure the element is in the DOM
          dispatchEvent(behavior, element, event, meta);
        }
      };
      forwardListener[element.uniqueID] = eventListener;
      return eventListener;
    }

    // Extract event handlers.
    var events = meta.events;

    for (var name in behavior) {
      var handler = behavior[name];
      if (handler && HANDLER_TYPE[typeof handler] && EVENT.test(name)) {
        var type = name.replace(/^:on|(.:)on/, "$1");
        if (EVENT_MULTI.test(type)) {
          var parts = type.split(":");
          if (parts.length === 1) {
            var namespace = "";
            var types = parts[0];
          } else {
            namespace = parts[0] + ":";
            types = parts[1];
          }
          forEach (types.slice(1, -1).split("|"), function(type) {
            events[namespace + type] = handler;
          });
        } else {
          events[type] = handler;
        }
      }
    }

    var onattach = events["jsb:attach"];
    var oncontentready = events["jsb:contentready"];
    var ondocumentready = events["jsb:documentready"];

    for (type in events) {
      handler = events[type];
      if (EVENT_TEXT.test(type)) {
        type = keyHandlers.register(type, handler);
      } else if (EVENT_TRANSITION_PROPERTY.test(type)) {
        meta.transitionEvents[type] = handler;
        type = type.split("(")[0];
      }
      // Store event handlers.
      if (!allEvents[type]) {
        allEvents[type] = true;
        if (behavior.jsbUseDelegation && EVENT_BUBBLES.test(type)) {
          usesDelegation = true;
          if (!delegatedEvents[type]) {
            delegatedEvents[type] = [];
            dom.addEventListener(document, type, delegateEvent);
          }
          delegatedEvents[type].push(meta);
        } else {
          parts = type.split(":");
          if (parts.length === 1) {
            attachedEvents[type] = false; // useCapture=false
          } else {
            namespace = parts[0];
            type = parts[1];
            switch (namespace) {
              case "window":
                attachedEvents[type] = window;
                break;
                
              case "document":
                attachedEvents[type] = document;
                break;
                
              case "capture":
                attachedEvents[type] = true; // useCapture=true
                break;
                
              default:
                attachedEvents[namespace + ":" + type] = false;
            }
          }
        }
      }
    }

    keyHandlers.sort();

    behavior.ancestor = this;

    behavior.setCapture = function setCapture(element) {
      if (!element || element.nodeType !== 1) throw new TargetError(JSB_TYPE_ERR, "setCapture");

      if (element != captureElement) releaseCapture();
      captureElement = element;
      captureBehavior = behavior;
      captureMeta = meta;
      for (var type in captureEvents) {
        dom.addEventListener(document, type, captureEvents[type], true);
      }
    };

    // Maintain attachments.

    behavior.attach = function attach(element) {
      if (!element || element.nodeType !== 1) throw new TargetError(JSB_TYPE_ERR, "behavior.attach");

      var attachedByRuleEngine = _attachedByRuleEngine_;
      _attachedByRuleEngine_ = false;
      
      var uniqueID = element.uniqueID || _.assignID(element);

      //if (!attached[uniqueID] || !attachedByRuleEngine) { -@DRE
      if (!attached[uniqueID]) {
        // Maintain attachment state.
        attached[uniqueID] = true;
        if (usesDelegation) {
          allAttachments[uniqueID] |= 0;
          allAttachments[uniqueID]++;
        }

        // Add event handlers
        for (var type in attachedEvents) {
          var capture = attachedEvents[type];
          if (typeof capture == "boolean") {
            dom.addEventListener(element, type, eventListener, capture);
          } else {
            dom.addEventListener(capture, type, forwardListener[uniqueID] || forwardEvent(element));
          }
        }

        if (onattach) {
          new PseudoEvent(behavior, element, "attach", onattach);
        }
        if (oncontentready) {
          if (attachedByRuleEngine) {
            contentReadyQueue[uniqueID] = true;
            contentReadyCount++;
          } else {
            new PseudoEvent(behavior, element, "contentready", oncontentready);
          }
        }
        if (ondocumentready) {
          if (attachedByRuleEngine || !engine._ready) {
            if (!(uniqueID in documentReadyQueue)) {
              documentReadyQueue[uniqueID] = true;
              documentReadyQueue.push(element);
            }
          } else {
            new PseudoEvent(behavior, element, "documentready", ondocumentready);
          }
        }
        if (events.focus && element == document.activeElement) {
          dispatchFocusEvent(behavior, element, meta);
        }
      }
    };

    behavior.detach = function detach(element) {
      if (!element || element.nodeType !== 1) throw new TargetError(JSB_TYPE_ERR, "behavior.detach");

      var uniqueID = element.uniqueID;
      if (attached[uniqueID]) {
        delete attached[uniqueID];
        if (usesDelegation) allAttachments[uniqueID]--;
        for (var type in attachedEvents) {
          var capture = attachedEvents[type];
          if (typeof capture == "boolean") {
            dom.removeEventListener(element, type, eventListener, capture);
          } else {
            dom.removeEventListener(capture, type, forwardListener[uniqueID]);
          }
        }
        delete forwardListener[uniqueID];
      }
    };

    var isModified = false;
    var modifications = [];

    behavior.modify = function modify(properties) {
      var modification = new Modification(behavior, properties);
      modifications.push(modification);
      isModified = true;
      return modification;
    };

    behavior.get = function get(element, propertyName) {
      if (arguments.length < 2) throw new ArityError("behavior.get");
      if (!element || !element.nodeType) throw new TargetError(JSB_TYPE_ERR, "behavior.get");

      // Retrieve a DOM property.

      var getter = this["get_" + propertyName];
      if (typeof getter == "function") {
        return getter.call(this, element);
      } else if (propertyName in this) {
        var defaultValue = this[propertyName];
        var type = typeof defaultValue;
        if (isModified) {
          var i = modifications.length, modification;
          while ((modification = modifications[--i])) {
            if (propertyName in modification && modification._attached[element.uniqueID]) {
              defaultValue = modification[propertyName];
              break;
            }
          }
        }
        if (SUPPORTS_DATASET) {
          var value = element.dataset[propertyName];
        } else {
          var attributeName = "data-" + propertyName.replace(/([A-Z])/g, "-$1").toLowerCase();
          value = element.getAttribute(attributeName);
        }
        if (value == null) {
          return type === "boolean" ? false : defaultValue;
        }
        // Cast.
        switch (type) {
          case "boolean": return true;
          case "number":  return +value;
        }
        return value;
      }

      if (propertyName in element) {
        return element[propertyName];
      } else if (propertyName in dom.get.properties) {
        return dom.get(element, propertyName); // handled by base2.dom
      }
      return undefined;
    };

    return behavior;
  },

  get: _.Undefined, // defined when the behavior is created

  set: function set(element, propertyName, value) {
    if (arguments.length < 3) throw new ArityError("behavior.set");
    if (!element || !element.nodeType) throw new TargetError(JSB_TYPE_ERR, "behavior.set");

    // Set a DOM property.

    var getter = this["get_" + propertyName];
    if (typeof getter == "function") {
      var setter = this["set_" + propertyName];
      if (typeof setter != "function") {
        throw new TypeError("Property '" + propertyName + "' has no setter.");
      }
      return setter.call(this, element, value);
    } else if (propertyName in this) {
      var type = typeof this[propertyName];
      if (type === "boolean") {
        var isBooleanFalse = !value;
        if (value) value = "";
      }
      if (SUPPORTS_DATASET) {
        if (isBooleanFalse) {
          delete element.dataset[propertyName];
        } else {
          element.dataset[propertyName] = value;
        }
      } else {
        var attributeName = "data-" + propertyName.replace(/([A-Z])/g, "-$1").toLowerCase();
        if (isBooleanFalse) {
          element.removeAttribute(attributeName);
        } else {
          element.setAttribute(attributeName, value);
        }
      }
      switch (type) {
        case "boolean": return !isFalse;
        case "number":  return +value;
      }
      return String(value);
    }

    if (propertyName in dom.get.properties) {
      return dom.set(element, propertyName, value); // handled by base2.dom
    } else {
      return element[propertyName] = value;
    }
  },

  // Node.

  contains: dom.contains,

  // Private data.

  getUserData: getUserData,
  setUserData: setUserData,

  // Attributes.

  classList: dom.classList,

  getAttribute:    dom.getAttribute,
  hasAttribute:    dom.hasAttribute,
  removeAttribute: dom.removeAttribute,
  setAttribute:    dom.setAttribute,

  // Selectors API

  matches: dom.matches,
  find:    dom.find,

  findAll: function findAll(node, selector) {
    // This method returns an ExtendedNodeList object
    var elements = dom.findAll.apply(dom, arguments);
    return ExtendedNodeList(elements);
  },

  // EventTarget.

  addEventListener:    dom.addEventListener,
  removeEventListener: dom.removeEventListener,

  // aliases
  on:  dom.addEventListener,
  off: dom.removeEventListener,

  once: function once(node, type, listener, useCapture) {
    if (arguments.length < 3) throw new ArityError("once");
    if (!node || !node.nodeType) throw new TargetError(JSB_TYPE_ERR, "once");

    var wrapper = function _listener(event) {
      dom.removeEventListener(this, type, wrapper, useCapture);
      listener.call(this, event);
    };

    dom.addEventListener(node, type, wrapper, useCapture);
  },

  fire: fire,

  // Style.

  style: {
    compute:  _private.compute,
    get:      dom.style.get,
    set:      dom.style.set,
    toString: _.K("[jsb.element.style]")
  },

  animate: function animate(element, transition) {
    if (!element || element.nodeType !== 1) throw new TargetError(JSB_TYPE_ERR, "animate");

    var recalc = element.clientWidth; // force through any other style changes

    dom.style.set(element, "transitionProperty", "all");

    for (var i = 1; i < arguments.length; i++) {
      transition = new Transition(arguments[i]);
      if (typeof transition.onstep == "function") {
        animationQueue.add(this, element, transition);
      } else {
        dom.style.set(element, transition);
        recalc = element.clientWidth;
      }
    }

    dom.style.set(element, "transitionDuration", "0s");
  },

  // CSS Object Model.

  getBoundingClientRect: dom.getBoundingClientRect,

  getOffsetFromBody: function getOffsetFromBody(element) {
    if (!element || element.nodeType !== 1) throw new TargetError(JSB_TYPE_ERR, "getOffsetFromBody");

    return _private.getOffsetFromBody(element);
  },

  // Mutation.

  after:   dom.after,
  before:  dom.before,
  append:  dom.append,
  prepend: dom.prepend,
  replace: dom.replace,
  remove:  dom.remove,

  // Mouse capture.

  setCapture: _.Undefined, // defined when the behavior is created
  releaseCapture: releaseCapture,

  toString: _.K("[object Behavior]")
});

forEach.csv("setInterval,setTimeout", function _eacher(timerName) {
  this[timerName] = function _createTimer(callback, delay) {
    if (typeof callback == "string") callback = this[callback];

    var args = _.slice(arguments, 2);
    var self = this;

    return window[timerName](function _wrapper() {
      callback.apply(self, args);
    }, delay || 4);
  };
}, Behavior.prototype);

var baseBehavior = new Behavior;
