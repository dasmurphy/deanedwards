
var element = jsb.element.extend({
  name: "rm.element",

  repeatMax:   MAX_VALUE,
  repeatMin:   0,
  repeatStart: 1,
  
  // getters and setters

  get_repetitionBlocks: function get_repetitionBlocks(element) {
    var blocks = {
      length : 0
    };
    var block = element.parentNode[FIRST_CHILD];
    while (block) {
      if (this.get(block, "repetitionTemplate") == element) {
        blocks[blocks.length++] = block;
      }
      block = block[NEXT_SIBLING];
    }
    return blocks;
  },

  get_repetitionIndex: function get_repetitionIndex(element) {
    switch (this.get(element, "repetitionType")) {
      case REPETITION_TEMPLATE:
        return this.getUserData(element, "repetitionIndex") || 0;

      case REPETITION_BLOCK:
        return Number(this.getAttribute(element, "data-repeat")) || 0;

      default:
        return 0;
    }
  },

  set_repetitionIndex: function set_repetitionIndex(element, index) {
    switch (this.get(element, "repetitionType")) {
      case REPETITION_TEMPLATE:
        this.setUserData(element, "repetitionIndex", index);
        break;

      case REPETITION_BLOCK:
        this.setAttribute(element, "data-repeat", index);
    }
    return index;
  },

  get_repetitionTemplate: function(element) {
    if (this.isBlock(element)) {
      var templateId = this.getAttribute(element, "data-repeat-template");
      if (templateId) {
        var template = dom.getElementById(document, templateId);
      } else {
        template = element;
        while ((template = template[NEXT_SIBLING]) && !this.isTemplate(template)) {
          continue;
        }
      }
      if (template && this.isTemplate(template)) {
        return template;
      }
    }
    return null;
  },

  get_repetitionType: function get_repetitionType(element) {
    if (this.classList.contains(element, "rm-template")) {
      return REPETITION_TEMPLATE;
    }
    var repeat = this.getAttribute(element, "data-repeat");
    if (repeat !== "" && repeat != null && !isNaN(repeat) && repeat >= 0 && repeat < MAX_VALUE) {
      return REPETITION_BLOCK;
    }
    return REPETITION_NONE;
  },

  set_repetitionType: function set_repetitionType(element, type) {
    switch (type) {
      case REPETITION_NONE:
        this.removeAttribute(element, "data-repeat");
        this.classList.remove(element, "rm-template");
        break;

      case REPETITION_TEMPLATE:
        this.setAttribute(element, "data-repeat", "template");
        this.classList.add(element, "rm-template");
        break;

      case REPETITION_BLOCK:
        this.setAttribute(element, "data-repeat", this.get(element, "repetitionIndex"));
        this.classList.remove(element, "rm-template");
    }
    return index;
  },
  
  // methods

  addRepetitionBlock: function addRepetitionBlock(element, refNode) {
    if (!element || element.nodeType !== 1) {
      throw TypeError(Target("addRepetitionBlock", this));
    }

    if (!this.isTemplate(element)) return null;

    // count the preceding repetition blocks
    var count = 0;
    var block = element;
    while ((block = block[PREVIOUS_SIBLING])) {
      if (this.get(block, "repetitionTemplate") == element) {
        var blockIndex = this.get(block, "repetitionIndex");
        if (blockIndex >= this.get(element, "repetitionIndex")) {
          this.set(element, "repetitionIndex", blockIndex + 1);
        }
        count++;
      }
    }

    // quit if we have reached the maximum limit
    if (count >= this.get(element, "repeatMax")) {
      return null;
    }

    // clone this template and initialise the new block
    var block = element.cloneNode(true);

    // replace [indexed] expressions
    // we have to do this for all attribute nodes
    // special characters used by the repetiton model:
    //    '[', '\u02d1', '\u00b7', ']'
    var name = IGNORE_NAME.test(element.id) ? "" : element.id;
    if (name) {
      var attribute;
      var safeName = name.replace(SAFE_NAME, "\\$1");
      var pattern = RegExp("[\\[\\u02d1]" + safeName + "[\\u00b7\\]]", "g");
      var repetitionIndex = this.get(element, "repetitionIndex");
      var dummy = document.createElement("div");
      if (element.nodeName === "TR") {
        var table = document.createElement("table");
        table.appendChild(block);
        dummy.appendChild(table);
      } else {
        dummy.appendChild(block);
      }
      dummy.innerHTML = dummy.innerHTML.replace(FIX_MSIE_BROKEN_TAG, "$1html:").replace(pattern, repetitionIndex);
      block = dummy.getElementsByTagName(element.nodeName)[0];
      block.setAttribute("data-repeat-template", name);
      block.removeAttribute("id");
    }
    block.removeAttribute("data-repeat-start");
    block.removeAttribute("data-repeat-min");
    block.removeAttribute("data-repeat-max");
    block.setAttribute("data-repeat", String(this.get(element, "repetitionIndex")));

    // insert the node
    if (refNode == null) {
      refNode = element;
      while (refNode[PREVIOUS_SIBLING] && !this.isBlock(refNode[PREVIOUS_SIBLING])) {
        refNode = refNode[PREVIOUS_SIBLING];
      }
    } else {
      refNode = refNode[NEXT_SIBLING];
    }
    this.classList.remove(block, "rm-template");
    refNode.parentNode.insertBefore(block, refNode);
    
    var autofocused = this.findAll(block, "input[autofocus],textarea[autofocus],select[autofocus]");
    autofocused.forEach(function(element) {
      try {
        element.focus();
      } catch (ex) {
        // ignore, probably invisible
      }
    });

    // maintain the index
    var index = this.get(element, "repetitionIndex");
    this.set(element, "repetitionIndex", index + 1);
    
    rules.apply(block);

    // fire the "added" event
    dispatchTemplateEvent(element, "added", block);

    // return the newly created block
    return block;
  },

  moveRepetitionBlock: function moveRepetitionBlock(element, distance) {
    if (arguments.length < 2) {
      throw TypeError(Arity("moveRepetitionBlock", this));
    }
    if (!element || element.nodeType !== 1) {
      throw TypeError(Target("moveRepetitionBlock", this));
    }

    if (!distance || !this.isBlock(element)) return;

    var target = element;
    var template = this.get(element, "repetitionTemplate");

    if (distance < 0) {
      while (distance < 0 && target[PREVIOUS_SIBLING] && !this.isTemplate(target)) {
        target = target[PREVIOUS_SIBLING];
        if (this.isBlock(target)) {
          distance++;
        }
      }
    } else {
      while (distance > 0 && target[NEXT_SIBLING] && !this.isTemplate(target)) {
        target = target[NEXT_SIBLING];
        if (this.isBlock(target)) {
          distance--;
        }
      }
      target = target[NEXT_SIBLING];
    }

    // move the block
    element.parentNode.insertBefore(element, target);

    if (template) { // not an orphan
      dispatchTemplateEvent(template, "moved", element);
    }
  },

  removeRepetitionBlock: function removeRepetitionBlock(element) {
    if (!element || element.nodeType !== 1) {
      throw TypeError(Target("removeRepetitionBlock", this));
    }

    var template = this.get(element, "repetitionTemplate");

    element.parentNode.removeChild(element);

    if (template) { // not an orphan
      dispatchTemplateEvent(template, "removed", element);

      // maintain the mimimum number of blocks
      var min = this.get(template, "repeatMin");
      var length = this.get(template, "repetitionBlocks").length;
      while (length++ < min) {
        this.addRepetitionBlock(template, null);
      }
    }
  },

  isBlock: function isBlock(element) {
    return element.nodeType === 1 && this.get(element, "repetitionType") === REPETITION_BLOCK;
  },

  isTemplate: function isTemplate(element) {
    return element.nodeType === 1 && this.get(element, "repetitionType") === REPETITION_TEMPLATE;
  }
});
