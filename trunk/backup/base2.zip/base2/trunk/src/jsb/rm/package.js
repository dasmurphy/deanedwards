
var rm = jsb.rm = new _.Package({
  name:    "jsb.rm",
  version: "%%VERSION%%",
  
  REPETITION_NONE:     0,
  REPETITION_TEMPLATE: 1,
  REPETITION_BLOCK:    2,

  element: element,
  template: template,
  button: button,
  rules: rules
});
