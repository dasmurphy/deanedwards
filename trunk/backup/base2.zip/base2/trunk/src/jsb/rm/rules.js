
var rules = new jsb.RuleList({
  ".rm-template": template,
  "button.rm-add": add,
  "button.rm-remove": remove,
  "button.rm-move-up": moveup,
  "button.rm-move-down": movedown
});
