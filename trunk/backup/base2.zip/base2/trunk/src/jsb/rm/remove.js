
var remove = button.extend({
  "jsb:onattach": function onattach(element) {
    element.disabled = !this.getBlock(element);
  },

  "onclick": function onclick(element, event) {
    event.preventDefault(); // prevent submit
    var block = this.getBlock(element);
    if (block) {
      this.removeRepetitionBlock(block);
    }
  }
});
