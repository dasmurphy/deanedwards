
(function(){
  var head = document.getElementsByTagName("script")[0].parentNode;
  var style = document.createElement("style");
  head.appendChild(style, head);
  base2.dom.set(style, "textContent", ".rm-template{display:none}");
})();
