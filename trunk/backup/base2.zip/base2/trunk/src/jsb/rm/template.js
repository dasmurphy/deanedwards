
var template = element.extend({
  "jsb:onattach": function onattach(element) {
    this.setAttribute(element, "data-repeat", "template");
    
    var min   = this.get(element, "repeatMin");
    var start = this.get(element, "repeatStart");

    var i = 0;
    while (i++ < start) {
      this.addRepetitionBlock(element, null);
    }

    i = this.get(element, "repetitionBlocks").length;
    
    while (i++ < min) {
      this.addRepetitionBlock(element, null);
    }
  },

  "rm:on(added|moved|removed)": function (element, event) {
    return this.fire(element.parentNode, "rm:blocksmodified", {bubbles: false, cancelable: false});
  }
});
