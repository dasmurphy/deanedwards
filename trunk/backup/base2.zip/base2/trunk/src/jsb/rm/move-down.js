
var movedown = move.extend({
  RELATIVE_NODE:  NEXT_SIBLING,
  DIRECTION:      1
});
