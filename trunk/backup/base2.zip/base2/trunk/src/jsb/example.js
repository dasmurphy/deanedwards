
var example = jsb.element.extend({
  "jsb:onattach": function(element) {
    this.classList.add(element, "loaded");
  },

  "jsb:oncontentready": function(element) {
    this.set(element, "textContent", "SUCCESS!!");
  }
});
