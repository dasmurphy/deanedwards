
//@cc_on

var undefined;
var base2    = _.base2;
var forEach  = _.forEach;

var document = window.document;

/*var _PROBABLY_MAYBE = ["probably", "maybe"],
    _MIME_TYPE      = /^(audio|video)\/[\w\-]+$/,
    _MIME_TYPES     = {
      "audio/mp3":         0, // probably
      "audio/ogg":         1, // maybe
      "video/mp4":         0, // probably
      "video/quicktime":   0, // probably
      "video/x-flv":       0, // probably
      "video/ogg":         1  // maybe
};

var _mimeTypes = navigator.mimeTypes;
var _checkMimeType =_mimeTypes &&  _mimeTypes.length ? function(type) {
  var mimeType = _mimeTypes[type];
  return mimeType && mimeType.enabledPlugin;
} : _.False;*/

var SUPPORTS_SILVERLIGHT = false;
try {
  new ActiveXObject('AgControl.AgControl');
  SUPPORTS_SILVERLIGHT = true;
} catch (ex) {}


var USE_QT_PLAYER    = /(aac|mov|mp3|mp4)$/i,
    USE_FLASH_PLAYER = /(aac|flv|mov|mp3|mp4)$/i,
    USE_OGG_PLAYER   = /og[gv]$/i;

var TRIM_URL     = /[\?#].*$/,
    URL_RESOLVER = document.createElement("img");

var QT_PLAYER = '\
<!--[if gt IE 6]>\n\
<object width="{WIDTH}" height="{HEIGHT+15}" classid="clsid:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B"><!\n\
[endif]--><!--[if !IE]><!-->\n\
<object width="{WIDTH}" height="{HEIGHT+15}" type="video/quicktime" data="{SRC}"><!--<![endif]-->\n\
<param name="src" value="{SRC}" />\
<param name="target" value="myself" />\
<param name="controller" value="{CONTROLS}" />\
<param name="enablejavascript" value="true" />\
<param name="autoplay" value="{AUTOPLAY}" />\
<param name="kioskmode" value="false" />\
<param name="volume" value="{VOLUME}" />\
<param name="showlogo" value="false" />\
{FLASH_PLAYER}\
<!--[if gt IE 6]><!-->\n\
</object><!--<![endif]-->';

var OGG_PLAYER = _.format('\
<applet code="com.fluendo.player.Cortado.class" archive="{0}cortado.jar" width="{WIDTH}" height="{HEIGHT}">\
<param name="url" value="{SRC}">\
<param name="autoPlay" value="{AUTOPLAY}" />\
<param name="audio" value="{!MUTED}" />\
<param name="BufferSize" value="4096" />\
<param name="BufferHigh" value="25" />\
<param name="BufferLow" value="5" />\
</applet>',
jsb.host);

var POSTER = '<a href="{SRC}"><img src="{POSTER}" width="{WIDTH}" height="{HEIGHT}" alt="download" /></a>';
