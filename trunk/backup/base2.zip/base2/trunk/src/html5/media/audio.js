
html5.audio = media.extend({
  // TO DO
});
