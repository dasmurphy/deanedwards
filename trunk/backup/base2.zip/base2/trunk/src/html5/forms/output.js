
registerElement("output", {
  "implements": [noValidation],
  
  name: "",
  value: "",
  defaultValue: "",
  
  "jsb:onattach": function(element) {
    this.setUserData(element, "mode", "default");
    element.setAttribute("role", "status");
  },

  get: function(element, propertyName) {
    switch (propertyName) {
      case "type":
        return "output";

      case "value":
        return this.get(element, "textContent");

      case "htmlFor":
        var htmlFor = this.getAttribute(element, "for");
        return htmlFor
          ? this.findAll("#" + htmlFor.match(/[^\s]+/g).join(",#"))
          : new jsb.ExtendedNodeList;
    }
    return this.base(element, propertyName);
  },

  set: function(element, propertyName, value) {
    value = this.base.apply(this, arguments);

    var mode = this.getUserData(element, "mode");

    if (mode == "default" || propertyName == "value") {
      switch (propertyName) {
        case "innerHTML":
          value = this.get(element, "textContent");

        case "textContent":
          this.set(element, "defaultValue", value);
          break;

        case "defaultValue":
          this.set(element, "textContent", value);
          break;

        case "value":
          this.setUserData(element, "mode", "value");
          this.set(element, "textContent", value);
      }
    }
    return value;
  }
}, formitem);
