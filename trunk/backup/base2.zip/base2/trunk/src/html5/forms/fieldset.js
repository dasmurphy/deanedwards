
registerElement("fieldset", {
  "implements": [noValidation],

  get_type: K("fieldset"),

  get_elements: function(element) {
    return this.findAll(element, "button,fieldset,input,output,select,textarea");
  }
});
