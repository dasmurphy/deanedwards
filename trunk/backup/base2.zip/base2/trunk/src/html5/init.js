
registerElement("abbr");

registerElement("article", {
  detect:  "cite",

  display: "block",

  behavior: {
    "jsb:onattach": function(element) {
      element.setAttribute("role", "article");
    }
  }
});

registerElement("aside", {
  display: "block",

  behavior: {
    "jsb:onattach": function(element) {
      element.setAttribute("role", "note");
    }
  }
});

forEach.csv("figcaption,footer,header,hgroup,summary", _.partial(registerElement, undefined, "block"));

registerElement("section", {
  detect:  "cite",

  display: "block",

  behavior: {
    "jsb:onattach": function(element) {
      element.setAttribute("role", "section");
    }
  }
});

registerElement("figure", {
  display: "block",

  style: {
    margin: "1em 40px"
  }
});

registerElement("nav", {
  display: "block",

  behavior: {
    "jsb:onattach": function(element) {
      element.setAttribute("role", "navigation");
    }
  }
});

registerElement("mark", {
  style: {
    background: "yellow"
  }
});

// Can't use registerElement because it is not a flow element.
// It's harmless to just declare default property values.
html5.source = jsb.element.extend({
  src: "",
  type: "",
  codecs: ""
});

registerElement("title", {
  detect: "text",

  behavior: {
    text: "",

    get_text: function(element) {
      return this.get(element, "textContent");
    },

    set_text: function(element, value) {
      return this.set(element, "textContent", value);
    }
  }
});

registerElement("img", {
  detect: "naturalWidth",

  behavior: {
    naturalWidth: 0,
    naturalHeight: 0,

    get_naturalHeight: function(element) {
      var img = new Image;
      img.src = element.src;
      return img.width || 0;
    },

    get_naturalWidth: function(element) {
      var img = new Image;
      img.src = element.src;
      return img.width || 0;
    }
  }
});

registerElement("map", {
  detect: "images",

  behavior: {
    images: null,

    get_images: function(element) {
      var id = element.id;
      return id
        ? this.findAll("img[usemap=#" + id + "],object[type^=image/][usemap=#" + id + "]")
        : new jsb.ExtendedNodeList;
    }
  }
});

// Create stubs for all remaining elements
var _stub = jsb.element.extend();
forEach.csv("\
html,head,base,link,meta,style,script,noscript,body,h1,h2,h3,h4,h5,h6,address,\
p,hr,br,pre,blockquote,ol,ul,li,dl,dt,dd,div,a,em,strong,small,cite,q,dfn,code,\
var,samp,kbd,sub,sup,i,b,ruby,rt,rp,bdo,span,ins,del,iframe,embed,object,param,\
area,table,caption,colgroup,col,tbody,thead,tfoot,tr,td,th,legend,optgroup,option", function(tagName) {
  html5[tagName] = _stub;
});

// Create the style sheet.
jsb.createStyleSheet(styleSheet);

// Create the rules.
html5.rules = new jsb.RuleList(rules);
