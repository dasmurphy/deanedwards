
html5.canvas = jsb.element.extend({
  width: 0,
  height: 0,
  
  "jsb:onattach": function(element) {
    G_vmlCanvasManager.initElement(element);
  },
  
  getContext: function(element, contextId) {
    return element.getContext(contextId);
  },
  
  toDataURL: html5.NOT_SUPPORTED
});
