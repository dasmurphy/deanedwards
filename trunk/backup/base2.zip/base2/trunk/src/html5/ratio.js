
// This is the ancestor of meter/progress.
// Parses max/value from textContent if no attributes are specified.

var PERCENT       = "[%\u066a\ufe6a\uff05\u2030\u2031]",
    PARSE_RATIO   = new RegExp("([\\d.]+" + PERCENT + "?)|([\\d.]+).+([\\d.]+)", "g");
    PERCENT       = new RegExp(PERCENT);

var VALUE = 0, // Indexes to values returned by getRatio().
    MAX   = 1;

var ratio = jsb.element.extend({
  // Default DOM property values.
  max:   0,
  value: 0,

  onmouseover: function(element) {
    if (!element.title) {
      this._untitledElement = element;
      element.title = this.get(element, "textContent");
    }
  },

  onmouseout: function(element) {
    if (element == this._untitledElement) {
      delete this._untitledElement;
      element.removeAttribute("title");
    }
  },

  getRatio: function(element) {
    var max = this.getAttribute(element, "max"),
        value = this.getAttribute(element, "value");
    if (value == null) {
      var parsed = this.parseTextContent(element);
      if (max == null) {
        if (typeof parsed == "number") {
          value = parsed;
          max = 1;
        } else if (typeof parsed == "object") {
          value = parsed[VALUE];
          max = parsed[MAX];
        } else {
          value  = 0;
        }
      } else if (typeof parsed == "number") {
        value = parsed;
      } else {
        value = 0;
      }
    }
    if (isNaN(max) || max == null || max == "") {
      max = 1;
    }
    return [value - 0 || 0, max - 0];
  },

  parseTextContent: function(element) {
    var parsed = this.get(element, "textContent").match(PARSE_RATIO) || [];
    if (parsed[1]) {
      var max = Math.max(parsed[0], parsed[1]);
      var value = Math.min(parsed[0], parsed[1]);
    } else if (PERCENT.test(parsed = parsed[0])) {
      max = parsed.indexOf("\u2031") > 0 ? 10000 : parsed.indexOf("\u2030") > 0 ? 1000 : 100,
      value = Number(parsed.slice(0, -1));
    } else {
      return isNaN(parsed) ? "" : Number(parsed);
    }
    if (!isNaN(max) && !isNaN(value)) {
      return [value, max];
    }
    return "";
  },

  set: function(element, propertyName, value) {
    value = this.base.apply(this, arguments);
    if (typeof this[propertyName] == "number" || propertyName == "innerHTML" || propertyName == "textContent") {
      var ratio = this.getRatio(element);
      this.setAriaAttributes(element, ratio);
      this.layout(element, ratio);
    }
    return value;
  },
  
  setAriaAttributes: _.Undefined
});
