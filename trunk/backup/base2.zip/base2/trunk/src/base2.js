
var base2 = {
  name:      "base2",
  version:   "2.0 (beta1)"
};
