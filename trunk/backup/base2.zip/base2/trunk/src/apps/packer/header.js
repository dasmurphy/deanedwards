
eval(namespace);

var IGNORE = RegGrp.IGNORE;
var REMOVE = "";
var SPACE  = " ";
