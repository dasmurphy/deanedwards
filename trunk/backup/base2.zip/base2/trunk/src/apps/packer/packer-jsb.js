
base2.require("jsb", function(namespace) {
  eval(namespace);

  var packer = new Packer;

  new Rule("form", {
    oncontentready: function(form) {
      form.output.value = "";
      this.ready(form);
    },

    onclick: function(form, event) {
      var target = event.target;
      if (target.tagName == "BUTTON") {
        this[target.id](form);
      }
    },

    clear: function(form) {
      form.input.value = "";
      form.output.value = "";
      this.ready(form);
    },

    decode: function(form) {
      try {
        if (form.output.value) {
          var start = new Date;
          eval("var value=String" + form.output.value.slice(5));
          var stop = new Date;
          form.output.value = value;
          this.update(form, "unpacked in " + (stop - start) + " milliseconds");
        }
      } catch (error) {
        this.error(form, "error decoding script", error);
      } finally {
        form.decode.blur();
        form.decode.disabled = true;
      }
    },

    error: function(form, text, error) {
      this.message(form, text + ": " + error.message, "error");
    },

    message: function(form, text, className) {
      var message = this.querySelector(form, "#message");
      message.innerHTML = text;
      message.className = className || "";
    },

    pack: function(form) {
      form.output.value = "";
      form.clear.disabled = true;
      form.pack.disabled = true;
      var script = form.input.value;
      var REQUIRE = /base2\.require\s*\(\s*(['"])(.+?)\1\s*,\s*function/g;
      var requirements = [], match;
      while ((match = REQUIRE.exec(script))) {
        requirements.push(match[2].replace(/['"]/g, ""));
      }
      var loaded = 0;
      if (requirements.length) {
        var namespaces = [];
        forEach (requirements, function(requirement, i) {
          base2.require(requirement, function(namespace) {
            namespaces[i] = namespace;
            loaded++;
          });
        });
      }
      if (!namespaces && /base2\.(exec|ready)/.test(script)) {
        namespaces = [];
      }
      deferUntil(bind(function() {
        try {
          if (form.input.value) {
            var value = packer.pack(script, form.base62.checked, form.shrink.checked, form.privates.checked, form.strict.checked, namespaces);
            form.output.value = value;
            this.update(form);
          }
        } catch (error) {
          this.error(form, "error packing script", error);
        } finally {
          form.clear.disabled = false;
          form.pack.disabled = false;
          form.decode.disabled = !form.output.value || !form.base62.checked;
        }
      }, this), function() {
        form.clear.disabled = false;
        form.pack.disabled = false;
        return loaded === requirements.length;
      });
    },

    ready: function(form) {
      this.message(form, "ready");
      form.input.focus();
    },

    test1: function(form) {
      new Function(form.input.value)();
    },

    test2: function(form) {
      new Function(form.output.value)();
    },

    update: function(form, message) {
      var length = form.input.value.length;
      if (!/\r/.test(form.input.value)) { // mozilla trims carriage returns
        length += match(form.input.value, /\n/g).length;
      }
      var calc = form.output.value.length + "/" + length;
      var ratio = (form.output.value.length / length).toFixed(3);
      this.message(form, (message ? message + ", " : "") + format("compression ratio: %1=%2", calc, ratio));
    }
  });
});
