

/*_createDictionary: function(script) {
    var CLOSURE = "(function(%1){%2}).apply(null,'%3'.split('|'))";
    var DICTIONARY = /\.(__\w{2,}|[a-zA-Z$]\w{3,})/g;
    var dictionary = new Words(script, DICTIONARY);
    var filtered = dictionary.filter(function(word) {
      var string = word.toString();
      return word.count * string.length > word.count * 4 + string.length + 6;
    });
    dictionary.encode(function(index) {
      return "[@" + (total + index) + "]";
    });
    dictionary[KEYS].length = filtered.length;
    dictionary.toString = function() {
      return this.getValues().join("|").replace(/\./g, "");
    };
    var args = dictionary.pluck("value").join(",").replace(/[\[\].]/g, "");
    script = script.replace(DICTIONARY, function(word) {
      return dictionary.get(word).replacement;
    });
    return format(CLOSURE, args, script, dictionary);
  },*/