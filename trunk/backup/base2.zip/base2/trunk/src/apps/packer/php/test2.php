<?php
$x = array('a','b');
echo($x[-1]);
?>