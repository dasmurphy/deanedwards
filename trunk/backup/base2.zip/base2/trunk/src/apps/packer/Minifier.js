
var Minifier = Base.extend({
  minify: function(script, strictWhitespace, base2Namespaces) {
    // packing with no additional options
    script += "\n";
    script = script.replace(Minifier.CONTINUE, "");
    script = Minifier.comments.parse(script);
    script = Minifier.clean.parse(script);
    script = Minifier[strictWhitespace ? "strictWhitespace" : "whitespace"].parse(script);
    script = Minifier.concat.parse(script);
    
    if (base2Namespaces) {
      base2Namespaces =base2Namespaces.reverse();
      script = script.replace(/(base2\.(require|exec|ready)\((.+?,)?function(?: \w+)?\([\w,]+\)\{)eval\(\w+\);?/g, function(m, fn, type, ns) {
        if (type == "require") {
          ns = base2Namespaces.pop();
        } else if (type == "exec") {
          ns = namespace;
        } else {
          ns = namespace.replace(lang.namespace, "") + base2.dom.namespace + base2.lang.namespace;
        }
        var duplicates = /((var \w+=)[\w.]+;)(.*?)\2[\w.]+;/;
        while (duplicates.test(ns)) ns = ns.replace(duplicates, "$3$1");
        return fn + ns;
      });
    }
    
    return script;
  }
}, {
  CONTINUE: /\\\r?\n/g,
  
  init: function() {
    this.concat = new Parser(this.concat).merge(Packer.data);
    extend(this.concat, "parse", function(script) {
      var parsed = this.base(script);
      while (parsed !== script) {
        script = parsed;
        parsed = this.base(script);
      }
      return parsed;
    });
    forEach.csv("comments,clean", function(name) {
      this[name] = Packer.data.union(new Parser(this[name]));
    }, this);
    this.whitespace = new Parser(this.whitespace);
    this.strictWhitespace = this.whitespace.copy();
    this.strictWhitespace.removeAt(-3);
    this.strictWhitespace.removeAt(-3);
    this.strictWhitespace.removeAt(-3);
    this.conditionalComments = this.comments.copy();
    this.conditionalComments.putAt(-1, " $3");
    this.comments.removeAt(2);
  },

  clean: {
    "\\(\\s*([^;)]*)\\s*;\\s*([^;)]*)\\s*;\\s*([^;)]*)\\)": "($1;$2;$3)", // for (;;) loops
    "throw[^};]+[};]": IGNORE, // a safari 1.3 bug
    ";+\\s*([};])": "$1",
    "\\s*;+\\s*$": REMOVE
  },

  comments: {
    ";;;[^\\n]*\\n": REMOVE,
    "(COMMENT1)\\n\\s*(REGEXP)?": "\n$2",
    "(COMMENT2)\\s*(REGEXP)?": function(match, comment, regexp) {
      if (/^\/\*@/.test(comment) && /@\*\/$/.test(comment)) {
        comment = Minifier.conditionalComments.parse(comment);
      } else {
        comment = "";
      }
      return comment + " " + (regexp || "");
    }
  },

  concat: {
    "(STRING1)\\+(STRING1)([^.])": function(match, a, b, c) {
      return a.slice(0, -1) + b.slice(1) + c;
    },
    "(STRING2)\\+(STRING2)([^.])": function(match, a, b, c) {
      return a.slice(0, -1) + b.slice(1) + c;
    }
  },

  whitespace: {
    "^\\s+": REMOVE,
    "STRING1": IGNORE,
    'STRING2': IGNORE,
    '\\s*(OPERATOR)\\s*(REGEXP)': "$1$2",
    '(return|typeof)\\s*(REGEXP)': "$1$2",
    "\\/\\/@[^\\n]*\\n": IGNORE,
    "@\\s+\\b": "@ ", // protect conditional comments
    "\\b\\s+@": " @",
    "(return|contine|break|throw)\\s*\\n\\s*": "$1;",
    "(POSTFIX)?\\s*\\n\\s*(POSTFIX)": "$1;$2",
    ";\\s*(base2\\.(exec|ready|require)\\()": "\n$1",
    "(\\d)\\s+(\\.\\s*[a-z\\$_\\[(])": "$1 $2", // http://dean.edwards.name/weblog/2007/04/packer3/#comment84066
    "(POSTFIX)\\s+([+-])": "$1 $2", // c = a++ +b;
    "(\\w)\\s+([\u00a1-\ufffe\uffff])": "$1 $2", // http://code.google.com/p/base2/issues/detail?id=78
    "\\b\\s+\\$\\s+\\b": " $ ", // var $ in
    "\\$\\s+\\b": "$ ", // object$ in
    "\\b\\s+\\$": " $", // return $object

    // non-strict
    "\\s+([})\\].])": "$1",
    "\\s*([(\^<=>~,{:;&|!*?\\[+-])\\s*": "$1",
    "\\s*\\n\\s*": "\n",
    
    "\\b\\s+\\b": SPACE,
    "\\s+": REMOVE
  }
});
