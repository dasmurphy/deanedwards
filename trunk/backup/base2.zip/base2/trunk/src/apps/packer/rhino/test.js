
importPackage(java.lang);

load("http://rekky.rosso.name/base2/trunk/src/build.php?src=base2.js");

//base2.host = HOST;

base2.require("io", function(ns) {
  eval(ns);

  var fs = new FileSystem;

  print(fs.path);
});

function print(x) {
  System.out.println(String(x));
};

quit();
