
var Parser = RegGrp.extend({
  put: function(expression, replacement) {
    if (typeOf(expression) == "string") {
      expression = Parser.dictionary.parse(expression);
    }
    this.base(expression, replacement);
  }
}, {
  dictionary: new RegGrp({
    POSTFIX:    /\+\+|\-\-/.source,
    OPERATOR:    /[\[(\^<=>~,{}:;&|!*?+-]/.source,
    CONDITIONAL: /\/\*@\w*|\w*@\*\/|\/\/@\w*|@\w+/.source,
    COMMENT1:    /\/\/[^\n]*/.source,
    COMMENT2:    /\/\*[^*]*\*+(?:[^\/][^*]*\*+)*\//.source,
    //REGEXP:      /\/(\[(\\.|[^\n\]\\])+\]|\\.|[^\/\n\\])+\/[gim]*/.source,
    REGEXP:      /\/(?:\\[\/\\]|[^*\/])(?:\\.|[^\/\n\\])*\/[gim]*/.source,
    STRING1:     /'(?:\\.|[^'\\])*'/.source,
    STRING2:     /"(?:\\.|[^"\\])*"/.source
  })
});
