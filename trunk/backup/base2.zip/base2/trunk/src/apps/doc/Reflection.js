
var Reflection = Base.extend({
  constructor: function(reference) {
    this.reference = reference;
    this.ancestor = Object.prototype;
    
    var type = this.type = typeOf(reference);
    
    switch (type) {
      case "null":
        this.type = "object";
        break;
        
      case "function":
        this.ancestor = Function.prototype;
        if (isBaseClass(reference)) {
          this.ancestor = reference.ancestor || Object;
          if (Trait.ancestorOf(reference)) {
            this.type = "trait";
          } else {
            this.type = "class";
            this.isPseudoClass = isPseudoClass(reference);
          }
        } else if (THIS.test(reference)) {
          this.type = "method";
        }
        break;
        
      case "object":
        this.ancestor = reference.constructor.prototype;
        if (reference == this.ancestor) {
          this.ancestor = (reference.constructor.ancestor || Object).prototype;
        }
        if (reference instanceof Package) {
          this.type = "package";
        }
        break;
    }
  },

  ancestor: null,
  isPseudoClass: false,
  reference: null,
  type: "undefined",

  getClasses: function() {
    return new Members(this, isClass);
  },

  getConstants: function() {
    return new Members(this, isConstant);
  },

  getProperties: function() {
    return new Members(this, function(ref, name) {
      return !(ref instanceof Function) && !(ref instanceof Package && name !== "parent") && !isConstant(ref, name);
    });
  },

  getFunctions: function() {
    if (this.reference instanceof Package) {
      var exports = this.reference.exports;
      return new Members(this, function(ref, name) {
        return ref instanceof Function && name in exports && !isClass(ref) && !Trait.ancestorOf(ref);
      });
    }
    return new Members(this, isFunction);
  },

  getTraits: function() {
    return new Members(this, isTrait);
  },

  getInstanceMethods: function() {
    var reference = this.reference;
    var members = new Reflection(reference.prototype).getMethods();
    if (this.isPseudoClass) {
      var ancestor = global[reference["#name"].slice(6, -1)];
      var _proto = ancestor.prototype;
      for (var name in reference) {
        if (_proto[name] instanceof Function && !members.has(name)) {
          members.put(name, _proto[name], true);
        }
      }
      switch (reference) {
        case Date2:
          forEach.csv(DATE_PROTOTYPE_METHODS, function(name) {
            members.put(name, Date.prototype[name], true);
          });
          break;

        case Function2:
          members.put("apply", _proto.apply, true);
          members.put("call", _proto.call, true);
          break;
      }
      members.sort();
    }
    return members;
  },

  getInstanceProperties: function() {
    var reference = this.reference;
    var members = new Reflection(reference.prototype).getProperties();
    switch (reference) {
      case Array2:
      case Function2:
      case String2:
        members.put("length", 0, true);
        members.sort();
        break;
    }
    return members;
  },

  getMethods: function() {
    var exports = {};
    if (this.reference instanceof Package) {
      exports = this.reference.exports;
    }
    return new Members(this, function(ref, name) {
      return ref instanceof Function && !(name in exports) && !isBaseClass(ref);
    });
  },

  getTraitMethods: function() {
    var traitMethods = this.type == "trait" ? this.reference["#methods"] : {};
    return new Members(this, function(ref, name) {
      return !!traitMethods[name];
    });
  },

  getClassMethods: function() {
    var traitMethods = this.type == "trait" ? this.reference["#methods"] : {};
    var members = new Members(this, function(ref, name) {
      return ref instanceof Function && !traitMethods[name] && !isBaseClass(ref) && ref != Object;
    });
    if (this.reference) {
      var bind = this.reference.bind;
      if (bind != Function.bind) {
        members.put("bind", bind);
        members.sort();
      }
    }
    return members;
  },

  getClassProperties: function() {
    var type = this.type;
    return new Members(this, function(ref, name) {
      return !CONSTANT.test(name) && (typeof ref == "object" || isPrimitive(ref) || isBaseClass(ref) || ref == Object);
    });
  },

  getPackages: function() {
    return new Members(this, isPackage);
  }
});
