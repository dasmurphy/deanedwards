
eval(namespace);

var CONSTANT   = /^[A-Z][\dA-Z_]*$/;
var PRIMITIVE  = /^(boolean|number|string)$/;
var OBJECT     = /^(object|package|class|trait)$/;
var PACKAGE    = /^package$/;
var THIS       = /\bthis\./;
var VALID_NAME = /^[a-z_]/i;

var DATE_PROTOTYPE_METHODS =
"getDate,getDay,getFullYear,getHours,getMilliseconds,getMinutes,getMonth,\
getSeconds,getTime,getTimezoneOffset,getUTCDate,getUTCDay,getUTCFullYear,\
getUTCHours,getUTCMilliseconds,getUTCMinutes,getUTCMonth,getUTCSeconds,\
setDate,setFullYear,setHours,setMilliseconds,setMinutes,setMonth,setSeconds,\
setTime,setUTCDate,setUTCFullYear,setUTCHours,setUTCMilliseconds,setUTCMinutes,\
setUTCMonth,setUTCSeconds,toDateString,toLocaleDateString,toLocaleString,\
toLocaleTimeString,toTimeString,toUTCString";

function isPrimitive(ref) {
  return PRIMITIVE.test(typeOf(ref)) || ref instanceof RegExp;
};

function isConstant(ref, name) {
  return CONSTANT.test(name) && isPrimitive(ref);
};

function isObject(ref) {
  return typeOf(ref) == "object";
};

function isClass(ref) {
  return ref instanceof Function && (isPseudoClass(ref) || (ref.prototype && !Trait.ancestorOf(ref) && (!!ref.prototype.forEach || some(ref.prototype, True))));
};

function isBaseClass(ref) {
  return ref == Base || Base.ancestorOf(ref) || isPseudoClass(ref);
};

function isPseudoClass(ref) {
  return ref == Array2 || ref == Date2 || ref == Function2 || ref == String2;
};

function isTrait(ref) {
  return Trait.ancestorOf(ref);
};

function isPackage(ref, name) {
  return ref instanceof Package && doc.show[name];
};

function isFunction(ref) {
  return ref instanceof Function;
};

function isMethod(ref) {
  return ref instanceof Function && !isClass(ref) && /this\./.test(ref);
};
