
var doc = new Package({
  name:    "doc",
  version: "0.7",
  
  show: {},

  colorize: function(text) {
    // Convert tabs to spaces and then convert spaces to "&nbsp;".
    var indent = text.match(/\n(\s+)\}\s*$/);
    if (indent) {
      text = text.replace(new RegExp("\\n" + indent[1], "g"), "\n");
    }
    text = text.replace(/[ \t]*;;;[^\n]*\n/g, "");
    return colorize.javascript.parse(text);
  },
  
  exports: {
    Reflection: Reflection
  }
});
