
var Members = Collection.extend({
  constructor: function(owner, test) {
    this.base();
    this.owner = owner;
    if (owner instanceof Reflection) {
      var reference = owner.reference
    } else {
      reference = owner;
    }
    forEach (reference, function(member, name) {
      if (VALID_NAME.test(name) && test.apply(null, arguments)) {
        this.put(name, member);
      }
    }, this, typeof reference == "function" ? Function : Object);
    this.sort();
  },
  
  put: function(name, reference, inherited) {
    var member = this.base(name, reference);
    if (arguments.length > 2) member.inherited = !!inherited;
    return member;
  },
  
  owner: null
}, {
  Item: {
    constructor: function(name, reference, members) {
      var owner = members.owner;
      var ancestor = owner.ancestor;
      if (ancestor) {
        if (owner.reference == Trait && name == "forEach") {
          this.inherited = false;
        } else if (base2.jsb && owner.reference == base2.jsb.behavior) {
          this.inherited = name === "base";
        } else if (reference instanceof Package && name == "parent") {
          this.inherited = owner.reference != base2;
        } else if (reference instanceof Function && !(isBaseClass(reference) && name != "ancestor")) {
          this.inherited = name in ancestor;
        } else {
          this.inherited = reference === ancestor[name];
        }
      }
    },

    //name: "",
    inherited: false
  }
});
