
base2["#name"] = "base2";
global["#name"] = "global";

forEach (base2, function(property, name) {
  if (property instanceof Function || property instanceof Package) {
    if (!(this == base2.dom && property._isTraitMethod)) {
      property["#name"] = this["#name"] + "." + name;
    }
    if (property instanceof Package) {
      doc.show[name] = true;
      forEach (property.exports, arguments.callee, property);
      forEach (property, function(klass, name) {
        if (Base.ancestorOf(klass) && !klass["#name"]) {
          klass["#name"] = property["#name"] + "." + name;
        }
      });
    } else if (Trait.ancestorOf(property)) {
      forEach (property["#implements"], function(trait) {
        forEach (trait, function(method, name) {
          if (!Trait[name] && typeOf(method) === "function" && property[name]) {
            property[name]._trait = trait;
            var protoMethod = property.prototype[name];
            if (protoMethod) protoMethod._trait = trait;
          }
        });
      });
    } else if (Collection.ancestorOf(property)) {
      var Item = property.Item;
      if (Item && !Item["#name"]) {
        Item['#name'] = property['#name'] + ".Item";
      }
      if (property == RegGrp) {
        property.Dict['#name'] = property['#name'] + ".Dict";
      }
    }
  }
}, base2);

doc.show.MiniWeb = false;
doc.show.colorize = false;
doc.show.doc = false;
