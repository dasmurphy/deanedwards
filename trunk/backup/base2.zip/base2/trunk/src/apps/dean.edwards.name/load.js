if (!"".replace(/^/, String))
 document.write('<script type="text/javascript" src="http://deanedwards.googlecode.com/svn/trunk/js/my.js"><\/script>');
