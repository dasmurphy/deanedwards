
eval(base2.namespace);
eval(DOM.namespace);
eval(JSB.namespace);

var bindings = new RuleList;
