
onload = function() {
  clearInterval(_timer);  
  if (onload.done) return;
  onload.done = true;
  
  var MSIE     = /*@cc_on!@*/0;
  var JS       = /js/,
      LIST     = /[^\s,]+/g,
      REQUIRED = /required/,
      TEXT     = MSIE ? "innerText" : "textContent";
      
  $("input,textarea", function(element) {
    if (REQUIRED.test(element.className)) {
      updateFlag.call(element);
      element.onmouseup = element.onkeyup = updateFlag;
    }
  });
  
  if (!"".replace(/^/, String)) $("pre", function(element) {
    if (JS.test(element.className)) {
      element.className += " javascript";
    }
    var names = element.className.match(LIST) || "", engine;
    for (var i = 0; engine = names[i]; i++) {
      // use the first class name that matches a highlighter
      var colorizer = Colorizer[engine];
      if (colorizer instanceof Colorizer) {
        element.className += " highlight";
        if (engine == "html-multi") element.className += " html";
        element.innerHTML = colorizer.parse(element[TEXT]);
        break;
      }
    }
  });

  function $(tagNames, behavior) {
    forEach (tagNames.match(LIST), function(tagName) {
      forEach (document.getElementsByTagName(tagName), behavior);
    });
  };
  
  function updateFlag() {
    // update the "required" flag adjacent to an <input> or <textrea>
    this.nextSibling.style.color = this.value ? "#898E79" : "#A03333";
  };
};

/* for Mozilla/Opera9 */
if (document.addEventListener) {
  document.addEventListener("DOMContentLoaded", onload, false);
}

/* for Internet Explorer */
/*@cc_on @*/
/*@if (@_win32)
  document.write("<script id=__ie_onload defer src=javascript:void(0)><\/script>");
  var script = document.getElementById("__ie_onload");
  script.onreadystatechange = function() {
    if (this.readyState == "complete") onload();
  };
/*@end @*/

/* for Safari */
if (/KHTML/i.test(navigator.userAgent)) { // sniff
  var _timer = setInterval(function() {
    if (/loaded|complete/.test(document.readyState)) onload(); 
  }, 50);
}
