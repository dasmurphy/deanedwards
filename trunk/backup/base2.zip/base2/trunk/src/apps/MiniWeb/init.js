
// create page style
document.write("<style>html,body{margin:0;padding:0;height:100%;overflow:hidden}#window{width:100%;height:100%}</style>");

// delegate some methods to the client
forEach.csv ("navigateTo,refresh,reload,submit", function(method) {
  MiniWeb[method] = function() {
    var args = arguments;
    var client = MiniWeb.client;
    // use a timer to jump out of an event
    setTimeout(function() {
      client[method].apply(client, args);
    }, 0);
  };
});

global.onload = function() {
  MiniWeb.readOnly = location.protocol !== "file:" || LocalFile.prototype.open == NOT_SUPPORTED;
  MiniWeb.server = new Server;
  MiniWeb.terminal = new Terminal;
  MiniWeb.client = new Client;
};
