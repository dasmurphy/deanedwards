
eval(namespace);

var _WILD_CARD      = /\*$/,
    _TRIM_PATH      = /[^\/]+$/,
    _SPACE          = /\s+/;

function jsonCopy(data) {
  return JSON.parse(JSON.stringify(data))
};

var INVALID_STATE = "Invalid state.";
