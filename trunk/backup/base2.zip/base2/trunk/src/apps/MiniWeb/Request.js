
// We are basically mimicking the XMLHttpRequest object

var Request = Base.extend({
  constructor: function(method, url, data, headers) {
    this.headers = {};
    this.post = {};
    // allow quick open+send from the constructor if arguments are supplied
    if (arguments.length > 0) {
      this.open(method, url);
      for (var name in headers) {
        this.setRequestHeader(name, headers[name]);
      }
      this.send(data);
    }
  },
  
  headers: null,
  readyState: 0,
  status: 0,
//statusText: "",  // don't bother with this one
  method: "",
  responseText: "",
  post: null,
  url: "",
  
  open: function(method, url) {
    assert(this.readyState === 0, INVALID_STATE);
    this.readyState = 1;
    this.method = method;
    this.url = url;
  },
  
  send: function(data) {
    assert(this.readyState === 1, INVALID_STATE);
    this.readyState = 2;
    MiniWeb.send(this, data);
  },
  
  // there is no distinction between request/response headers at the moment
  
  getResponseHeader: function(header) {
    assert(this.readyState >= 3, INVALID_STATE);
    return this.headers[header];
  },
  
  setRequestHeader: function(header, value) {
    assert(this.readyState === 1, INVALID_STATE);
    this.headers[header] = value;
  }
});
