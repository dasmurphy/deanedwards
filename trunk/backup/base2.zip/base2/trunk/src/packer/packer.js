
packer = new _.Package({
  name:    "packer",
  version: "%%VERSION%%",
  
  pack: function(script, shrink, whitespace, encode62, privates, base2Stuff) {
    script = encoder.encode(script);
    //script += "\n";
    script = clean.parse(script);
    if (whitespace) {
      script = strictWhitespace.parse(script);
    } else {
      script = simpleWhitespace.parse(script);
    }
    if (shrink) script = shrinker.parse(script, whitespace, base2Stuff);
    script = encoder.decode(script);
    if (privates) script = privatesEncoder.encode(script);
    if (encode62) script = base62Encoder.encode(script);
    return script.replace(/^;*\s*/, "").replace(/;*\s*$/, "") + ";";
  },
  
  toString: _.K("/packer/")
});
