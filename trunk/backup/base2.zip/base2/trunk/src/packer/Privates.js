
var Privates = JSEncoder.extend({
  constructor: function(ignoreStrings) {
    var ignore = [];
    if (ignoreStrings) {
      ignore.push(
        /<#STRING>/, IGNORE,
        /(\b(?:return|typeof|instanceof|do))(\s*)<#REGEXP>/, IGNORE,
        /<#CONDITIONAL>/, IGNORE,
        /<#REGEXP>/, IGNORE
      );
    }
    ignore.push(/@_/, IGNORE);
    return this.base(/\b_[\da-zA-Z$][\w$]*\b/g, function(index, word) {
      if (/_\d+/.test(word)) return word;
      return "_" + index;
    }, ignore);
  },

  search: function(script) {
    var words = this.base(script);
    var _private = words.get("_private");
    if (_private) _private.count = 99999;
    return words;
  }
});

var privatesEncoder = new Privates;
