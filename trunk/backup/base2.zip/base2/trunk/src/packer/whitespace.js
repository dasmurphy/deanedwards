
var simpleWhitespace = new Parser([
  /\/\/@[^\n]+\n/, IGNORE,
  /^;*\s+/, REMOVE,
  /\b(return|continue|break|throw|yield)\s*\n\s*/, "$1;",
  /\s+(\x01\d+\x01)\s+/, "$1",
  /(<#POSTFIX>)?\s*\n\s*(<#POSTFIX>)/, "$1;$2",
  /(\d)\s+(\.\s*[a-z$_\[(])/, "$1 $2", // http://dean.edwards.name/weblog/2007/04/packer3/#comment84066
  /\s*([+-]+)\s+([+-])/, "$1 $2", // c = a++ +b;
  "(\\w)\\s+([\u00a1-\ufffe\uffff])", "$1 $2", // http://code.google.com/p/base2/issues/detail?id=78
  /\b\s+\$\s+\b/, " $ ", // var $ in
  /\$\s+\b/, "$ ", // object$ in
  /\b\s+\$/, " $", // return $object

  // non-strict
  /\s+([})\].])/, "$1",
  /\s*([\^+=<>{(\[:;,&|!?*\/%+-])\s*/, "$1",
  /\s*\n\s*/, "\n",

  /@\s+\b/, "@ ",
  /\b\s+\b/, SPACE,
  /\s+/, REMOVE
]);

var strictWhitespace = simpleWhitespace.clone();
strictWhitespace.removeAt(-4);
strictWhitespace.removeAt(-4);
strictWhitespace.removeAt(-4);

var base2Whitespace = new Parser([
  /;\s*(base2\.(exec|ready|require)\()/, ";\n$1"
]);
