
var license = new Parser([
  /^(\s*<#CONDITIONAL>\s*)+/, REMOVE,

  /^(\s*<#COMMENT>\s*)+/, IGNORE,

  /<#CONDITIONAL>/, REMOVE,

  /<#COMMENT>/, REMOVE,

  /<#OP_WORD>/, REMOVE,

  /<#DIVISION>/, REMOVE,

  /<#REGEXP>/, REMOVE,

  /<#STRING>/, REMOVE,

  ".", REMOVE
]);
