
base2.require("jsb,packer", function(_, jsb, packer) {
  var URL = window.URL || window.webkitURL || window.mozURL || window;
  var Blob = window.Blob || window.WebKitBlob || window.MozBlob;
  var BlobBuilder = window.BlobBuilder || window.WebKitBlobBuilder || window.MozBlobBuilder;
  
  var SUPPORTS_DOWNLOAD = URL && (Blob || BlobBuilder) && _.detect("(<a>.download)");

  jsb.Rule("#packer", {
    "jsb:oncontentready": function(form) {
      form.output.value = "";
      if (typeof FileReader == "function" && form.local.files) {
        form.load.disabled = false;
      }
      this.ready(form);
    },

    ":onclick": {
      "#clear": function(form) {
        form.input.value = "";
        form.output.value = "";
        form.decode.disabled = true;
        form.save.disabled = true;
        this.ready(form);
      },

      "#load": function(form) {
        form.local.click();
      },

      "#pack": function(form) {
        form.output.value = "packing...";
        this.setTimeout(function() { // allow the form to become interactive
          var script = form.input.value;
          form.output.value = "";
          form.clear.disabled = true;
          form.pack.disabled = true;
          try {
            if (script) {
              var value = packer.pack(script, form.shrink.checked, form.whitespace.checked, form.encode62.checked, form.privates.checked, form.imports.checked);
              form.output.value = value;
              this.showDetails(form);
            }
          } catch (error) {
            this.showError(form, "error packing script", error);
          } finally {
            form.clear.disabled = false;
            form.pack.disabled = false;
            form.decode.disabled = !form.output.value || !form.encode62.checked;
            if (SUPPORTS_DOWNLOAD) {
              form.save.disabled = !form.output.value;
            }
          }
        });
      },

      "#decode": function(form) {
        try {
          if (form.output.value) {
            var start = new Date;
            var value = Function("return String" + form.output.value.slice(4))();
            var stop = new Date;
            form.output.value = value;
            this.showDetails(form, "unpacked in " + (stop - start) + " milliseconds");
          }
        } catch (error) {
          this.showError(form, "error decoding script", error);
        } finally {
          form.decode.blur();
          form.decode.disabled = true;
        }
      },

      "#save": function(form) {
        var file = form.local.files[0];
        var name = file ? file.name.replace(/(\.packed)?\.js$/, ".packed.js") : "packed.js";

        if (Blob) {
          var blob = new Blob([form.output.value], {"type" : "text/plain"});
        } else {
          var bb = new BlobBuilder();
          bb.append(form.output.value);
          blob = bb.getBlob("text/plain");
        }

        var downloader = this.find(form, "#downloader");
  			downloader.href = URL.createObjectURL(blob);
  			downloader.download = name;

        this.fire(downloader, "click");
      }
    },

    ":ondragover": function(form, event) {
      event.preventDefault();
    },

    ":ondrop": function(form, event) {
      event.preventDefault();
      this.load(form, event.dataTransfer.files[0]);
    },

    ":onchange": {
      "#local": function(form) {
        _.forEach (form.local.files, function(file) {
          this.load(form, file);
        }, this);
      }
    },

    load: function(form, file) {
      var reader = new FileReader;

      reader.onload = function(event) {
        form.input.value += event.target.result + "\n\n\n";
      };

      reader.onerror = function(event) {
        alert("Could not load file.");
      };

      reader.readAsText(file, "utf-8");
    },

    ready: function(form) {
      this.showMessage(form, "ready");
      form.input.focus();
    },

    showDetails: function(form, message) {
      var length = form.input.value.length;
      if (!/\r/.test(form.input.value)) { // mozilla trims carriage returns
        length += (form.input.value.match(/\n/g) || "").length;
      }
      var calc = form.output.value.length + "/" + length;
      var ratio = (form.output.value.length / length).toFixed(3);
      this.showMessage(form, (message ? message + ", " : "") + _.format("compression ratio: {0}={1}", calc, ratio));
    },

    showError: function(form, text, error) {
      this.showMessage(form, text + ": " + error.message, "error");
    },

    showMessage: function(form, text, className) {
      var message = this.find(form, "#message");
      this.set(message, "textContent", text);
      message.className = className || "";
    }
  });
});
