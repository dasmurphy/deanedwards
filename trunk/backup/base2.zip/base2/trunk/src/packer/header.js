
var IGNORE  = _.RegGrp.IGNORE;
var REMOVE  = "";
var SPACE   = " ";

var K       = _.K;
var forEach = _.forEach;

// Windows Scripting Host cannot do regexp.test() on global regexps.
function globalize(regexp) {
  // This function creates a global version of the passed regexp.
  return new RegExp(regexp.source, "g");
};

function encode52(c) {
  // Base52 encoding (a-Z)
  function encode(c) {
    return (c < 52 ? '' : encode(parseInt(c / 52))) +
      ((c = c % 52) > 25 ? String.fromCharCode(c + 39) : String.fromCharCode(c + 97));
  };
  var encoded = encode(c);
  if (/^(do|if|in|let|try)$/.test(encoded)) encoded += 0;
  return encoded;
};
