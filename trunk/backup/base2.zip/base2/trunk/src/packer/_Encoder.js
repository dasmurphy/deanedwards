
var Encoder = _.Base.extend({
  constructor: function(pattern, encoder, ignore) {
    this.parser = new Parser(ignore);
    if (pattern) this.parser.set(pattern, "");
    this.encoder = encoder;
  },

  parser: null,
  encoder: _.Undefined,

  search: function(script) {
    var words = new Words;
    this.parser.setAt(-1, function(word) {
      words.add(word);
    });
    this.parser.parse(script);
    return words;
  },

  encode: function(script) {
    var words = this.search(script);
    if (words.size() > 52) {
      words.sort();
    }
    var index = 0;
    forEach (words, function(word) {
      word.encoded = this.encoder(index++, word);
    }, this);
    this.parser.setAt(-1, function(word) {
      return words.get(word).encoded;
    });
    return this.parser.parse(script);
  }
});
