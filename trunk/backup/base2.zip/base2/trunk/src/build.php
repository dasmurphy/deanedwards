<?php

# PHP5 required

header('Content-Type: application/x-javascript');
header('Expires: ' . gmdate('D, d M Y H:i:s') . ' GMT');
header('Cache-Control: no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$REG_XML = '/\\w+\\.xml$/';
$SRC     = isset($_GET['src']) ? $_GET['src'] : '';
$HBASE   = dirname(realpath("build.php"));
$PBASE   = '';

if ($SRC) {
  print_header();
	$load = explode(" ", preg_replace('/\.js$/', '', $SRC));
  foreach ($load as $index => $name) {
    $p = '~/';
    if ($index > 0) {
      $p .= 'base2/';
    }
    $p = path_resolve($p.$name.'/package.xml', $PBASE);
    if (file_exists($p)) {
      load_package($p, true);
    } else {
      print_script($SRC);
    }
  }
} else {
  $PACKAGE = $_GET["package"];

  if (!file_exists($PACKAGE)) {
  	print("\nPackage '".$PACKAGE."' does not exist or is not supplied.");
  	print("\n\n");
  	print("Use the 'src' parameter to identify a package:\n\n");
  	print("   build.php?src=path/to/package.js\n\n");
  	print("Here are some examples:\n\n");
  	print("   build.php?src=base2.js\n");
  	print("   build.php?src=base2/dom.js\n");
  	print("   build.php?src=base2+dom.js\n");
  	print("\n\n");
  	print("An alterntaive syntax is to us the 'package' parameter.\n");
  	print("This gives more fine-grained control for specific builds:\n\n");
  	print("   build.php?package=path/to/package.xml\n");
  	print("\n");
  	print("Path is relative to build.php.\nPaths within the package.xml file are relative to package.xml.\n");
  	print("To make a path relative to build.php, use ~/ at the start of the path.\n");
  	print("\n");
  	print("To include all dependencies, add 'full' to the query string:\n\n");
  	print("   build.php?package=path/to/package.xml&full\n");
  	exit;
  }
  
  $PBASE = dirname($PACKAGE);

  print_header();

  $dom = new DomDocument;
  $p = path_resolve($PACKAGE, $HBASE);
  $dom->load($p);
  $package =  $dom->documentElement;

  if (preg_match('/(^|\&)(amp;)?full($|\=|\&)/i',$_SERVER['QUERY_STRING'])) {
  	if ($package->getAttribute('name') != 'base2') {
  		load_package(path_resolve('~/base2/package.xml',$PBASE), true);
  	}
  	$require = explode(',', $package->getAttribute('require'));
    foreach ($require as $name) {
    	if ($name) load_package(path_resolve('~/base2/'.$name.'/package.xml',$PBASE), true);
    }
  }

  print_package($package, $PBASE, true);
}

function print_script($src) {
  print_banner($src);
  readfile($src);
}

function print_header() {
  readfile(path_resolve('~/header.txt'));
  print("\r\n// timestamp: ".gmdate('D, d M Y H:i:s')."\r\n");
}

function print_banner($message) {
	print("\r\n// =========================================================================\r\n");
	print('// '.$message);
	print("\r\n// =========================================================================\r\n");
}

// Paths are resolved relative to the current package.xml,
// bootstrapped with path of build.php
// Home directory notation (~/) is relative to build.php
// Absolute path's are relative to the root
function path_resolve($path, $package = '') {
	global $HBASE;
	if (substr($path, 0, 2) == '~/') return $HBASE.substr($path, 1);
	if (substr($path, 0, 1) != '/') return $package."/".$path;
	return $path;
}

function load_package($path, $closure) {
	$dom = new DomDocument;
	$dom->load($path);
	print_package($dom->documentElement, dirname($path), $closure);
}

function print_package($package, $pbase, $closure) {
	global $REG_XML, $BASE;
	
	$isCore = $package->getAttribute('name') == 'base2';

	$name = $package->getAttribute('name');
	
	$header = $package->getAttribute('header');
	if ($header) {
    readfile(path_resolve($header, $pbase));
  }
	
	if ($closure) {
    if ($isCore) {
      print("\r\n(function(global) { // begin: package\r\n");
    } else {
      $require = $package->getAttribute('require');
      if ($require == '') {
        print("\r\nbase2.exec(function(namespace) { // begin: package\r\n");
      } else {
        print("\r\nbase2.require(\"$require\", function(namespace) { // begin: package\r\n");
      }
    }
  }
	$includes = $package->getElementsByTagName('include');
	foreach ($includes as $include) {
		$src = path_resolve($include->getAttribute('src'), $pbase);

		if (preg_match($REG_XML, $src)) {
			load_package($src, false);
		} else {
			print_banner(preg_replace('/^\//', '', preg_replace('/[\w\-]+\/\.\./', '', $name.'/'.$include->getAttribute('src'))));
      readfile($src);
		}
	}	
	if ($closure) {
    if ($isCore) {
      if (!preg_match('/(^|\&)build/i',$_SERVER['QUERY_STRING'])) {
        print("\r\n;;; base2.host = \"http://".$_SERVER['SERVER_NAME']."/base2/trunk/src/build.php?src=\";\r\n");
      }
      print("\r\n})(this); // end: package\r\n");
    } else {
      print("\r\n}); // end: package\r\n");
    }
  }
}
?>
