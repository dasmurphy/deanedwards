<?php

# PHP5 required

error_reporting(E_ERROR | E_PARSE);

$loaded = Array(
  "Date" => true,
  "JSON" => true,
  "XMLHttpRequest" => true,
  "window" => true,
  "document" => true
);
$STRICT = FALSE;
$HEADER = FALSE;
$REG_JSON = '/\\w+\\.json$/';
$PACKAGE = isset($_GET['package']) ? $_GET['package'] : '';
$fullBuild = isset($_GET['full']);
$docBuild = isset($_GET['doc']);
if (isset($_REQUEST['src'])) {
  $SRC = $_REQUEST['src'];
  $tag = '';
  if (preg_match('/\-a\.js$/', $SRC)) {
    $tag = '-a';
    $SRC = preg_replace('/\-a\.js/', '.js', $SRC);
  }
  if ($SRC == 'base2.js') {
    $PACKAGE = 'base2/package'.$tag.'.json';
  } else if ($SRC == 'base2-dom.js') {
    $PACKAGE = 'base2/dom/package'.$tag.'.json';
    $fullBuild = true;
  } else if ($SRC == 'base2-jsb.js') {
    $PACKAGE = 'jsb/package'.$tag.'.json';
    $fullBuild = true;
  }
} else {
  $SRC = '';
}
$HBASE = dirname(realpath("./header.txt"));
$PBASE = '';

if (!$PACKAGE && !$SRC) {
?>
<!doctype html>
<html>
<title>base2 build tool</title>
<style>
body {padding:0 20px;}
ul {padding:0; margin:0 1em;}
dd {margin:0 1em;}
dd p {margin:1ex 0;}
</style>

<h1>Build</h1>
<p>Use the <i>src</i> parameter to identify a package:</p>
<pre>    build.php?src=path/to/package.js</pre>
<p>Here are some examples:</p>
<dl>
<dt><a href="build.php?src=base2.js">build.php?src=base2.js</a>
<dd><p>just base2
<dt><a href="build.php?src=base2/dom.js">build.php?src=base2/dom.js</a>
<dd><p>just base2.dom
<dt><a href="build.php?src=base2-dom.js">build.php?src=base2-dom.js</a>
<dd><p>base2.dom and <em>all</em> dependencies
</dl>
<p>An alterntaive syntax is to use the <i>package</i> parameter.</p>
<p>This gives more fine-grained control for specific builds:</p>
<pre>
    ?package=path/to/package.json
</pre>
<p><i>path</i> is relative to <code>trunk/src</code>. Paths within the <code>package.json</code> file are relative to <code>package.json</code>.</p>
<p>To make a path relative to <code>trunk/src</code>, use "~/" at the start of the path.</p>
<p>To include all dependencies, add 'full' to the query string:</p>
<pre>    build.php?package=path/to/package.json&amp;full</pre>
<?php
	exit;
}

header('Content-Type: application/x-javascript');
header('Expires: ' . gmdate('D, d M Y H:i:s') . ' GMT');
header('Cache-Control: no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

//print("var s = new Date;\n\n");

if ($PACKAGE) {
  $PBASE = dirname($PACKAGE);

  $p = path_resolve($PACKAGE, $HBASE);
  $json = json_decode(file_get_contents($p), true);
  $package =  $json['_build'];
  $package['name'] = $json['name'];
  $package['version'] = $json['version'];

  if ($fullBuild) {
    $gradeA = $package['grade'] == 'a';
  	if ($package['name'] != 'base2') {
      if ($gradeA) {
  		  load_package(path_resolve('~/base2/package-a.json',$PBASE), true);
      } else {
  		  load_package(path_resolve('~/base2/package.json',$PBASE), true);
      }
  	}
  }

  print_package($package, $PBASE, true);
} else {
	$load = explode(" ", preg_replace('/\.js$/', '', $SRC));
  foreach ($load as $index => $name) {
    $p = '~/';
    if ($index > 0) {
      $p .= 'base2/';
    }
    $p = path_resolve($p.$name.'/package.json', $PBASE);
    if (file_exists($p)) {
      load_package($p, true);
    } else {
      print_script($SRC);
    }
  }
}

#print("alert(new Date - s);\n\n");

function format_script($text) {
  global $docBuild;
  $text = preg_replace('/[\040\t]+\n/', "\n", $text);
  if (!$docBuild) {
    $text = preg_replace('/([\040\t]*;doc;[^\n]*\n)+\r?\n?/', '', $text);
  }
  return $text;
}

function print_script($src) {
  global $HBASE;
  print_banner($src);
  $src = path_resolve($src, $HBASE);
  $text = file_get_contents($src);
  $text = format_script($text);
  print($text);
}

function print_strict() {
  global $STRICT;
  if (!$STRICT) print("\r\n\"use strict\";\r\n");
  $STRICT = TRUE;
}

function print_header($package) {
  global $HBASE, $HEADER;
  if (!$HEADER) {
    $HEADER = TRUE;
    $text = file_get_contents(path_resolve('~/header.txt', $HBASE));
    $text = preg_replace('/%%VERSION%%/', $package['version'], $text);
    $text = preg_replace('/%%NAME%%/', $package['name'], $text);
    $text = preg_replace('/%%TIMESTAMP%%/', gmdate('c'), $text);
    $text = preg_replace('/%%YEAR%%/', gmdate('Y'), $text);
    print($text."\r\n");
  }
}

function print_banner($message) {
	print("\r\n// =========================================================================\r\n");
	print('// '.$message);
	print("\r\n// =========================================================================\r\n");
}

// Paths are resolved relative to the current package.json,
// bootstrapped with path of build.php
// Home directory notation (~/) is relative to build.php
// Absolute path's are relative to the root
function path_resolve($path, $package = '') {
	global $HBASE;
	if (substr($path, 0, 2) == '~/') return $HBASE.substr($path, 1);
	if (substr($path, 0, 1) != '/') return $package."/".$path;
	return $path;
}

function load_package($path, $closure) {
  $json = json_decode(file_get_contents($path), true);
  $package =  $json['_build'];
  $package['name'] = $json['name'];
  $package['version'] = $json['version'];
	print_package($package, dirname($path), $closure);
}

function print_package($package, $pbase, $closure) {
	global $REG_JSON, $PBASE, $BASE, $fullBuild, $loaded, $gradeA;

  print_header($package);

	$name = $package['name'];
  $version = $package['version'];
	$isCore = $name == 'base2';
  $require = $package['require'];
  $showBanner = !isset($package['headers']) || $package['headers'] == TRUE;

  if ($fullBuild && !$isCore) {
  	if ($require) {
    	$requirements = explode(',', $require);
      foreach ($requirements as $name) {
	      $name = preg_replace('/\:\w+/', '', $name);
        if (!isset($loaded[$name])) {
          $loaded[$name] = true;
	        $name = preg_replace('/\./', '/', $name);
          $jsFile = '~/'.$name.'.js';
          if (file_exists(path_resolve($jsFile))) {
            print_script($jsFile, true);
          } else {
            if ($gradeA && ($name == 'base2/dom' || $name == 'jsb')) {
              load_package(path_resolve('~/'.$name.'/package-a.json', $PBASE), true);
            } else {
              $jsonFile = path_resolve('~/'.$name.'/package.json', $PBASE);
              if (file_exists($jsonFile)) {
                load_package($jsonFile, true);
              }
            }
          }
        }
      }
    }
  }

	$name = $package['name'];
	
	$header = $package['header'];
	if ($header) {
    readfile(path_resolve($header, $pbase));
  }

	$declare = $package['declare'];
  if ($declare) {
    print("\r\n".$declare."\r\n");
  }

  $globals = 'base2,Object,Array,Date,Function,RegExp,String,Error,RangeError,ReferenceError,SyntaxError,TypeError';
  
	if ($closure) {
    if ($isCore) {
      print("\r\nvar base2 = (function(global,".$globals.") { // begin: closure\r\n");
      print_strict();
    } else {
      if ($require == '') {
        print("\r\nbase2.exec(function(_) { // begin: closure\r\n");
        print_strict();
      } else {
	      $requires = preg_replace('/[^,#]*#|@[^,]*|(\w+\.)+/', '', $require);
        $requires = implode(', ', explode(',', $requires));
	      $require = preg_replace('/\:\w+/', '', $require);
        print("\r\nbase2.require(\"$require\", function(_, ".$requires.") { // begin: closure\r\n");
        print_strict();
      }
    }
  } else if ($package['closure']) {
    print("\r\n(function() { // begin: closure\r\n");
    print_strict();
  }
  
	$includes = $package['files'];
	foreach ($includes as $src) {
		$fileName = path_resolve($src, $pbase);
		if (preg_match($REG_JSON, $src)) {
      if ($showBanner) print_banner(preg_replace('/\./', '/', $name).'/'.preg_replace('/\w+\.json/', '', $src));
			load_package($fileName, false);
		} else {
			if ($src != 'header.js' && $src != 'footer.js') {
        $title = preg_replace('/^\//', '', preg_replace('/[\w\-]+\/\.\./', '', preg_replace('/\./', '/', $name).'/'.$src));
        $title = preg_replace('/^[^~]+~\//', '', $title);
        if ($showBanner) print_banner($title);
      }
      $text = file_get_contents($fileName);
      $text = preg_replace('/%%VERSION%%/', $version, $text);
      $text = format_script($text);
      echo($text);
		}
	}
	if ($closure) {
    if ($isCore) {
      print("\r\nreturn base2;\r\n\r\n})(this,".$globals."); // end: closure\r\n");
    } else {
      print("\r\n}); // end: closure\r\n");
    }
  } else if ($package['closure']) {
    print("\r\n})(); // end: closure\r\n");
  }

	$footer = $package['footer'];
	if ($footer) {
    readfile(path_resolve($footer, $pbase));
  }
}
?>
