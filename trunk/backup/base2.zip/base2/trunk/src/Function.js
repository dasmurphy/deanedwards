
// Some browsers don't define this.
Function.prototype.prototype = {};
