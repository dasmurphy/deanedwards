
var Colorizer = base2.exec(function(_) { // begin: closure

var forEach = _.forEach;

var IGNORE = _.RegGrp.IGNORE;

var TAB  = /\t/g;
var TABS = /\n([\t \xa0]*)/g;

// Use a string to create the CHAR pattern.
// This protects against a bug in Safari 2.
// Finally, we need to separate the \uffff char (this is for Opera).
var CHAR = "\\w\u00a1-\ufffe\uffff";

var BLOCK_COMMENT = /\/\*[^*]*\*+([^\/][^*]*\*+)*\//;
var LINE_COMMENT  = /\/\/[^\r\n]*/;
var NUMBER        = /\b\-?(\d+\.\d+|\.\d+|\d+\.|\d+)([eE][-+]?\d+)?\b/;
var STRING1       = /'(\\\r?\n|\\.|[^'\\])*'/;
var STRING2       = /"(\\\r?\n|\\.|[^"\\])*"/;
var EMAIL         = /(mailto:)?([<#CHAR>.+-]+@[<#CHAR>.-]+\.[<#CHAR>]+)/;
var URL           = /https?:\/\/+[<#CHAR>\/\-%&#=.,?+$]+/;

var escape = new _.RegGrp([
  "<",       "\x01",
  ">",       "\x02",
  "&",       "\x03"
]);

var unescape = new _.RegGrp([
  "\x01",    "&lt;",
  "\x02",    "&gt;",
  "\x03",    "&amp;"
]);

var Dictionary = _.RegGrp.Dict.extend({
  parse: function(phrase) {
    return escape.parse(this.base(phrase));
  }
});

var schemes = {};

function addScheme(name, dictionary, items, options) {
  if (arguments.length == 2 && arguments[1] instanceof Colorizer) {
    var scheme = arguments[1];
  } else {
    scheme = new Colorizer(dictionary, items, options);
  }

  /*var RULE = "pre:not(.colorized).colorize-";
  if (typeof jsb != "undefined") {
    jsb.Rule(RULE + name, {
      "jsb:oncontentready": function(element) {
        var textContent = this.get(element, "textContent");
        element.innerHTML = scheme.parse(textContent);
        this.classList.add(element, "colorized");
      }
    });
  } else if (typeof jQuery != "undefined") {
    jQuery(function($) {
      $(RULE + name).each(function() {
        var textContent = $(this).text();
        this.innerHTML = scheme.parse(textContent);
        $(this).addClass("colorized");
      });
    });
  }*/
  schemes[name] = scheme;
  return scheme;
}

function getScheme(name) {
  return schemes[name] || null;
}

Colorizer = _.RegGrp.extend({
  constructor: function(dictionary, items, options) {
    _.extend(this, options);
    this.dictionary = new Colorizer.Dict(dictionary);
    this.base(items);
  },

  escapeChar: "",
  parseUrls: true,
  tabStop: 4,

  parse: function(text, tabSize) {
    var preParsed = !!arguments[2]; // Not a secondary parse of the text (e.g. CSS within an HTML sample).
    text = escape.parse(text);
    if (!preParsed && this.before) {
      text = this.before(text);
    }
    text = this.base(text);
    if (!preParsed) {
      // Convert tabs to spaces and then convert spaces to "&nbsp;".
      if (tabSize) {
        var tab = Array(tabSize + 1).join(" ");
        text = text.replace(TABS, tab);
      }
      if (this.parseUrls) text = urls.parse(text);
    }
    if (!preParsed && this.after) {
      text = this.after(text);
    }
    return unescape.parse(text);
  },
  
  set: function(pattern, replacement) {
    if (/^colorize\-/.test(replacement)) {
      replacement = '<span class="' + replacement + '">$1</span>';
    }
    return this.base(pattern, replacement);
  },

  "@MSIE[67]": {
    parse: function(text, tabSize) {
      return this.base.apply(this, arguments).replace(/\r?\n\r?\n/g, "<br>&nbsp;<br>");
    }
  },

  "@MSIE": {
    parse: function(text, tabSize) {
      return this.base.apply(this, arguments).replace(/[ \xa0]{2}/g, "&nbsp;&nbsp;").replace(/\r?\n/g, "<br>");
    }
  }
});

Colorizer.version       = "%%VERSION%%";
Colorizer.CHAR          = CHAR;
Colorizer.BLOCK_COMMENT = BLOCK_COMMENT;
Colorizer.LINE_COMMENT  = LINE_COMMENT;
Colorizer.NUMBER        = NUMBER;
Colorizer.STRING1       = STRING1;
Colorizer.STRING2       = STRING2;
Colorizer.Dict          = Dictionary;
Colorizer.addScheme     = addSceme;
Colorizer.getScheme     = getScheme;

// ------------------------------------------------------
// URL parser.
// ------------------------------------------------------

var urls = new _.RegGrp({
  CHAR:   CHAR,
  EMAIL:  EMAIL,
  URL:    URL
}, {
  '<#EMAIL>': '<a href="mailto:$2">$1$2</a>',
  '(<#URL>)': '<a href="$1">$1</a>'
});

// ------------------------------------------------------
// JavaScript parser.
// ------------------------------------------------------

var js = addScheme("js", [
  "OPERATOR",      /[\[({\^<=>,:;&|!*?+-]/,
  "BLOCK_COMMENT", BLOCK_COMMENT,
  "LINE_COMMENT",  LINE_COMMENT,
  "COMMENT",       /<#BLOCK_COMMENT>|<#LINE_COMMENT>/,
  "NUMBER",        NUMBER,
  "STRING1",       STRING1,
  "STRING2",       STRING2,
  "STRING",        /<#STRING1>|<#STRING2>/,
  "CONDITIONAL",   /\/\*@if\s*\([^\)]*\)|@else[\s\w]*@\*\/|\/\*@[^\n]+@\*\/|\/[\/\*]@[^\n]*|\S+[^\n@]*@\*\/|@\*\//, // conditional comments
  "GLOBAL",        /\b(__defineGetter__|__defineSetter__|__lookupGetter__|__lookupSetter__|clearInterval|clearTimeout|confirm|constructor|document|escape|hasOwnProperty|Infinity|isNaN|isPrototypeOf|NaN|parseFloat|parseInt|prompt|propertyIsArrayLike|prototype|setInterval|setTimeout|toString|toLocaleString|unescape|valueOf|window)\b/,
  "KEYWORD",       /\b(arguments|break|case|const|continue|default|delete|do|else|false|for|function|get|if|in|instanceof|let|new|null|return|set|switch|this|true|typeof|var|void|while|with|undefined|yield)\b/,
  "REGEXP",        /\/(\[(\\.|[^\n\]\\])+\]|\\.|[^\/\n\\])+\/[gim]*/,
  "SPECIAL",       /\b(assert\w*|alert|catch|console|debugger|eval|finally|throw|try)\b/
], [
  /\+\+|\-\-/, IGNORE,

  '(0[xX][\\dA-Fa-f]*)',
    'colorize-number',

  '(<#NUMBER>)',
    'colorize-number',

  "(<#OPERATOR>)(\\s*)(<#CONDITIONAL>)",
    '$1$2<span class="colorize-conditional-comment">$3</span>',

  "(<#OPERATOR>)(\\s*)(<#COMMENT>)",
    '$1$2<span class="colorize-comment">$3</span>',
    
  "(<#OPERATOR>)(\\s*)(<#REGEXP>)",
    '$1$2<span class="colorize-regexp">$3</span>',
    
  "\\b(return|typeof|instanceof|do)(\\s*)(<#REGEXP>)",
    '<span class="colorize-keyword">$1</span>$2<span class="colorize-regexp">$3</span>',

  '(<#CONDITIONAL>)',
    'colorize-conditional-comment',

  '(<#COMMENT>)',
    'colorize-comment',
    
  '(<#STRING>)',
    'colorize-string',
    
  '(<#GLOBAL>)',
    'colorize-global',
    
  '(<#KEYWORD>)',
    'colorize-keyword',
    
  '(<#SPECIAL>)',
    'colorize-special'
]);

// ------------------------------------------------------
// CSS parser.
// ------------------------------------------------------

var css = addScheme("css", {
  CHAR:              CHAR,
  AT_RULE:           /@\w[^;{]+/,
  BRACKETED:         /\([^'\x22)]*\)/,
  COMMENT:           BLOCK_COMMENT,
  PROPERTY:          /(\w[\w\-]*\s*):([^;}]+)/,
  VENDOR_SPECIFIC:   /(\-[\w\-]+\s*):([^;}]+)/,
  SELECTOR:          /([<#CHAR>:\[.#-](\\.|[^{\\])*)\{/
}, {
  '(<#AT_RULE>)':       'colorize-at_rule',
  '<#BRACKETED>':       IGNORE,
  '(<#COMMENT>)':       'colorize-comment',
  '<#PROPERTY>':        '<span class="colorize-property-name">$1</span>:<span class="colorize-property-value">$2</span>',
  '<#VENDOR_SPECIFIC>': '<span class="colorize-vendor-specific"><span class="colorize-property-name">$1</span>:<span class="colorize-property-value">$2</span></span>',
  '<#SELECTOR>':        '<span class="colorize-selector">$1</span>{'
}, {
  ignoreCase: true
});

// ------------------------------------------------------
// XML parser.
// ------------------------------------------------------

var xml = addScheme("xml", {
  CHAR:      CHAR,
  PI:        /<\?[^>]+>/,
  COMMENT:   /<!\s*(--([^-]|[\r\n]|-[^-])*--\s*)>/,
  CDATA:     /<!\[CDATA\[([^\]]|\][^\]]|\]\][^>])*\]\]>/,
  ENTITY:    /&(#\d+|\w+);/,
  TAG:       /(<\/?)([<#CHAR>\-]+(?:\:[<#CHAR>\-]+)?\s*)((?:\/[^>]|[^/>])*)(\/?>)/
}, {
  '(<#PI>)':      'colorize-processing-instruction',
  '(<#COMMENT>)': 'colorize-comment',
  '(<#CDATA>)':   'colorize-cdata',
  '(<#ENTITY>)':  'colorize-entity',
  
  '<#TAG>': function(match, openTag, tagName, attributes, closeTag) {
    return openTag + '<span class="colorize-tag">' + tagName + '</span>' + attr.parse(attributes) + closeTag;
  }
}, {
  ignoreCase: true,
  tabStop: 1
});

var attr = new _.RegGrp([
  "CHAR",      CHAR,
  "STRING1",   STRING1,
  "STRING2",   STRING2,
  "STRING",    /<#STRING1>|<#STRING2>/
], [
  '([<#CHAR>-]+)(?:(\\s*=\\s*)(<#STRING>))?', '<span class="colorize-attribute-name">$1</span>$2<span class="colorize-attribute-value">$3</span>'
]);

// ------------------------------------------------------
// HTML parser.
// ------------------------------------------------------

var html = xml.clone();

html.dictionary.merge({
  DOCTYPE:     /<!doctype[^>]+>/,
  CONDITIONAL: /<!(--)?\[[^\]]*\]>|<!\[endif\](--)?>/, // conditional comments
  BLOCK:       /(<)(script|style)([^>]*)(>)([^<]*)<\/\2>/
});

// Parse a script or style block.
html.insertAt(-1, "<#BLOCK>", parseBlock);

html.merge([
  '(<#DOCTYPE>)',     'colorize-doctype',
  '(<#CONDITIONAL>)', 'colorize-conditional-comment'
]);

function parseBlock(match, openTag, tagName, attributes, closeTag, cdata) {
  return openTag + '<span class="colorize-tag">' + tagName + '</span>' + attr.parse(attributes) + closeTag +
    cdata + openTag + '/<span class="colorize-tag">' + tagName + '</span>' + closeTag;
};

addScheme("html", html);

// ------------------------------------------------------
// HTML+CSS+JS parser.
// ------------------------------------------------------

addScheme("html_multi", html.union({
  '<#BLOCK>': function(match, openTag, tagName, attributes, closeTag, cdata) {
    var type = /style/i.test(tagName) ? "css" : "js";
    cdata = '<span class="colorize-' + type + ' colorize-block">' + colorize[type].parse(cdata, 0, true) + '</span>';
    return parseBlock(match, openTag, tagName, attributes, closeTag, cdata);
  }
}));

}); // end: closure
