/*
  base2 - Copyright 2007-2010, Dean Edwards
    http://code.google.com/p/base2/

  License:
    http://www.opensource.org/licenses/mit-license.php

  Contributors:
    Doeke Zanstra
*/

// timestamp: Sun, 08 Aug 2010 20:14:40

base2.exec(function(namespace) { // begin: package

// =========================================================================
// doc/header.js
// =========================================================================

eval(namespace);

var CONSTANT   = /^[A-Z][\dA-Z_]*$/;
var PRIMITIVE  = /^(boolean|number|string)$/;
var OBJECT     = /^(object|package|class|trait)$/;
var PACKAGE    = /^package$/;
var THIS       = /\bthis\./;
var VALID_NAME = /^[a-z_]/i;

var DATE_PROTOTYPE_METHODS =
"getDate,getDay,getFullYear,getHours,getMilliseconds,getMinutes,getMonth,\
getSeconds,getTime,getTimezoneOffset,getUTCDate,getUTCDay,getUTCFullYear,\
getUTCHours,getUTCMilliseconds,getUTCMinutes,getUTCMonth,getUTCSeconds,\
setDate,setFullYear,setHours,setMilliseconds,setMinutes,setMonth,setSeconds,\
setTime,setUTCDate,setUTCFullYear,setUTCHours,setUTCMilliseconds,setUTCMinutes,\
setUTCMonth,setUTCSeconds,toDateString,toLocaleDateString,toLocaleString,\
toLocaleTimeString,toTimeString,toUTCString";

function isPrimitive(ref) {
  return PRIMITIVE.test(typeOf(ref)) || ref instanceof RegExp;
};

function isConstant(ref, name) {
  return CONSTANT.test(name) && isPrimitive(ref);
};

function isObject(ref) {
  return typeOf(ref) == "object";
};

function isClass(ref) {
  return ref instanceof Function && (isPseudoClass(ref) || (ref.prototype && !Trait.ancestorOf(ref) && (!!ref.prototype.forEach || some(ref.prototype, True))));
};

function isBaseClass(ref) {
  return ref == Base || Base.ancestorOf(ref) || isPseudoClass(ref);
};

function isPseudoClass(ref) {
  return ref == Array2 || ref == Date2 || ref == Function2 || ref == String2;
};

function isTrait(ref) {
  return Trait.ancestorOf(ref);
};

function isPackage(ref, name) {
  return ref instanceof Package && doc.show[name];
};

function isFunction(ref) {
  return ref instanceof Function;
};

function isMethod(ref) {
  return ref instanceof Function && !isClass(ref) && /this\./.test(ref);
};

// =========================================================================
// doc/Members.js
// =========================================================================

var Members = Collection.extend({
  constructor: function(owner, test) {
    this.base();
    this.owner = owner;
    if (owner instanceof Reflection) {
      var reference = owner.reference
    } else {
      reference = owner;
    }
    forEach (reference, function(member, name) {
      if (VALID_NAME.test(name) && test.apply(null, arguments)) {
        this.put(name, member);
      }
    }, this, typeof reference == "function" ? Function : Object);
    this.sort();
  },
  
  put: function(name, reference, inherited) {
    var member = this.base(name, reference);
    if (arguments.length > 2) member.inherited = !!inherited;
    return member;
  },
  
  owner: null
}, {
  Item: {
    constructor: function(name, reference, members) {
      var owner = members.owner;
      var ancestor = owner.ancestor;
      if (ancestor) {
        if (owner.reference == Trait && name == "forEach") {
          this.inherited = false;
        } else if (base2.jsb && owner.reference == base2.jsb.behavior) {
          this.inherited = name === "base";
        } else if (reference instanceof Package && name == "parent") {
          this.inherited = owner.reference != base2;
        } else if (reference instanceof Function && !(isBaseClass(reference) && name != "ancestor")) {
          this.inherited = name in ancestor;
        } else {
          this.inherited = reference === ancestor[name];
        }
      }
    },

    //name: "",
    inherited: false
  }
});

// =========================================================================
// doc/Reflection.js
// =========================================================================

var Reflection = Base.extend({
  constructor: function(reference) {
    this.reference = reference;
    this.ancestor = Object.prototype;
    
    var type = this.type = typeOf(reference);
    
    switch (type) {
      case "null":
        this.type = "object";
        break;
        
      case "function":
        this.ancestor = Function.prototype;
        if (isBaseClass(reference)) {
          this.ancestor = reference.ancestor || Object;
          if (Trait.ancestorOf(reference)) {
            this.type = "trait";
          } else {
            this.type = "class";
            this.isPseudoClass = isPseudoClass(reference);
          }
        } else if (THIS.test(reference)) {
          this.type = "method";
        }
        break;
        
      case "object":
        this.ancestor = reference.constructor.prototype;
        if (reference == this.ancestor) {
          this.ancestor = (reference.constructor.ancestor || Object).prototype;
        }
        if (reference instanceof Package) {
          this.type = "package";
        }
        break;
    }
  },

  ancestor: null,
  isPseudoClass: false,
  reference: null,
  type: "undefined",

  getClasses: function() {
    return new Members(this, isClass);
  },

  getConstants: function() {
    return new Members(this, isConstant);
  },

  getProperties: function() {
    return new Members(this, function(ref, name) {
      return !(ref instanceof Function) && !(ref instanceof Package && name !== "parent") && !isConstant(ref, name);
    });
  },

  getFunctions: function() {
    if (this.reference instanceof Package) {
      var exports = this.reference.exports;
      return new Members(this, function(ref, name) {
        return ref instanceof Function && name in exports && !isClass(ref) && !Trait.ancestorOf(ref);
      });
    }
    return new Members(this, isFunction);
  },

  getTraits: function() {
    return new Members(this, isTrait);
  },

  getInstanceMethods: function() {
    var reference = this.reference;
    var members = new Reflection(reference.prototype).getMethods();
    if (this.isPseudoClass) {
      var ancestor = global[reference["#name"].slice(6, -1)];
      var _proto = ancestor.prototype;
      for (var name in reference) {
        if (_proto[name] instanceof Function && !members.has(name)) {
          members.put(name, _proto[name], true);
        }
      }
      switch (reference) {
        case Date2:
          forEach.csv(DATE_PROTOTYPE_METHODS, function(name) {
            members.put(name, Date.prototype[name], true);
          });
          break;

        case Function2:
          members.put("apply", _proto.apply, true);
          members.put("call", _proto.call, true);
          break;
      }
      members.sort();
    }
    return members;
  },

  getInstanceProperties: function() {
    var reference = this.reference;
    var members = new Reflection(reference.prototype).getProperties();
    switch (reference) {
      case Array2:
      case Function2:
      case String2:
        members.put("length", 0, true);
        members.sort();
        break;
    }
    return members;
  },

  getMethods: function() {
    var exports = {};
    if (this.reference instanceof Package) {
      exports = this.reference.exports;
    }
    return new Members(this, function(ref, name) {
      return ref instanceof Function && !(name in exports) && !isBaseClass(ref);
    });
  },

  getTraitMethods: function() {
    var traitMethods = this.type == "trait" ? this.reference["#methods"] : {};
    return new Members(this, function(ref, name) {
      return !!traitMethods[name];
    });
  },

  getClassMethods: function() {
    var traitMethods = this.type == "trait" ? this.reference["#methods"] : {};
    var members = new Members(this, function(ref, name) {
      return ref instanceof Function && !traitMethods[name] && !isBaseClass(ref) && ref != Object;
    });
    if (this.reference) {
      var bind = this.reference.bind;
      if (bind != Function.bind) {
        members.put("bind", bind);
        members.sort();
      }
    }
    return members;
  },

  getClassProperties: function() {
    var type = this.type;
    return new Members(this, function(ref, name) {
      return !CONSTANT.test(name) && (typeof ref == "object" || isPrimitive(ref) || isBaseClass(ref) || ref == Object);
    });
  },

  getPackages: function() {
    return new Members(this, isPackage);
  }
});

// =========================================================================
// doc/package.js
// =========================================================================

var doc = new Package({
  name:    "doc",
  version: "0.7",
  
  show: {},

  colorize: function(text) {
    // Convert tabs to spaces and then convert spaces to "&nbsp;".
    var indent = text.match(/\n(\s+)\}\s*$/);
    if (indent) {
      text = text.replace(new RegExp("\\n" + indent[1], "g"), "\n");
    }
    text = text.replace(/[ \t]*;;;[^\n]*\n/g, "");
    return colorize.javascript.parse(text);
  },
  
  exports: {
    Reflection: Reflection
  }
});

// =========================================================================
// doc/data.js
// =========================================================================

doc.data = {
  PATH: "/data/doc/entries/",
  
  exists: function(objectID, entry) {
    return MiniWeb.server.io.exists(this.makepath(objectID, entry));
  },

  makepath: function(objectID, entry) {
    return this.PATH + String(objectID).replace(/::/, ".prototype.").split(".").join("/") + "/#" + entry;
  },

  read: function(objectID, entry) {
    return MiniWeb.server.io.read(this.makepath(objectID, entry));
  },

  remove: function(objectID, entry) {
    return MiniWeb.server.io.remove(this.makepath(objectID, entry));
  },
  
  write: function(objectID, entry, value) {
    var io = MiniWeb.server.io;
    var names = objectID.replace(/::/, ".prototype.").split(".");
    for (var i = 1; i <= names.length; i++) {
      var path = this.PATH + names.slice(0, i).join("/");
      if (!io.isDirectory(path)) {
        io.mkdir(path);
      }
    }
    io.write(path + "/#" + entry, value);
  }
};

// =========================================================================
// doc/~/base2/code/colorize.js
// =========================================================================

base2.exec(function(namespace) { // begin: closure

  eval(namespace); // import
  
  var IGNORE = RegGrp.IGNORE;

  var TAB  = /\t/g;
  var TABS = /\n([\t \xa0]*)/g;

  // Use a srting to create the CHAR pattern.
  // This protects against a bug in Safari 2.
  // Finally, we need to separate the \uffff char (this is for Opera).
  var CHAR = "\\w\u00a1-\ufffe\uffff";
  
  var BLOCK_COMMENT = /\/\*[^*]*\*+([^\/][^*]*\*+)*\//;
  var LINE_COMMENT  = /\/\/[^\r\n]*/;
  var NUMBER        = /\b\-?(0|[1-9]\d*)(\.\d+)?([eE][-+]?\d+)?\b/;
  var STRING1       = /'(\\.|[^'\\])*'/;
  var STRING2       = /"(\\.|[^"\\])*"/;
  var EMAIL         = /(mailto:)?([<#CHAR>.+-]+@[<#CHAR>.-]+\.[<#CHAR>]+)/;
  var URL           = /https?:\/\/+[<#CHAR>\/\-%&#=.,?+$]+/;

  var escape = new RegGrp({
    "<":       "\x01",
    ">":       "\x02",
    "&":       "\x03"
  });

  var unescape = new RegGrp({
    "\x01":    "&lt;",
    "\x02":    "&gt;",
    "\x03":    "&amp;"
  });

  var Colorizer = RegGrp.extend({
    constructor: function(dictionary, values, options) {
      extend(this, options);
      this.dictionary = new Colorizer.Dict(dictionary);
      this.base(values);
    },

    escapeChar: "",
    parseUrls: true,
    tabStop: 4,

    parse: function(text, preParsed) {
      text = escape.parse(text);
      if (!preParsed && this.before) {
        text = this.before(text);
      }
      text = this.base(text);
      if (!preParsed) { // Not a secondary parse of the text (e.g. CSS within an HTML sample).
        text = this.parseWhiteSpace(text);
        if (this.parseUrls) text = urls.parse(text);
      }
      if (!preParsed && this.after) {
        text = this.after(text);
      }
      return unescape.parse(text);
    },
    
    put: function(pattern, replacement) {
      if (/^colorize\-/.test(replacement)) {
        replacement = '<span class="' + replacement + '">$1</span>';
      }
      return this.base(pattern, replacement);
    },

    parseWhiteSpace: function(text) {
      // Convert tabs to spaces and then convert spaces to "&nbsp;".
      var tabStop = this.tabStop;
      if (tabStop > 0) {
        var tab = Array(tabStop + 1).join(" ");
        return text.replace(TABS, function(match) {
          match = match.replace(TAB, tab);
          if (tabStop > 1) {
            var padding = (match.length - 1) % tabStop;
            if (padding) match = match.slice(0, padding);
          }
          return match.replace(/ /g, "&nbsp;");
        });
      }
      return text;
    },

    "@MSIE": {
      parseWhiteSpace: function(text) {
        return this.base(text).replace(/\r?\n/g, "<br>");
      }
    }
  });

  Colorizer.Dict = RegGrp.Dict.extend({
    parse: function(phrase) {
      return escape.parse(this.base(phrase));
    }
  });

  // ------------------------------------------------------
  // Package.
  // ------------------------------------------------------

  var colorize = new Package({
    name:    "colorize",
    version: "0.9",
    //parent:  tools?, // -@DRE

    exports: {
      CHAR:          CHAR,
      BLOCK_COMMENT: BLOCK_COMMENT,
      LINE_COMMENT:  LINE_COMMENT,
      NUMBER:        NUMBER,
      STRING1:       STRING1,
      STRING2:       STRING2,
      
      Colorizer:     Colorizer,
      
      addScheme:     addScheme
    }
  });
  
  global.colorize = colorize; // -@DRE

  var RULE = "pre:not(.colorized).colorize-";

  function addScheme(name, dictionary, values, options) {
    if (arguments.length == 2 && arguments[1] instanceof Colorizer) {
      var scheme = arguments[1];
    } else {
      scheme = new Colorizer(dictionary, values, options);
    }
    if (base2.jsb) {
      new jsb.Rule(RULE + name, {
        oncontentready: function(element) {
          var textContent = this.get(element, "textContent");
          element.innerHTML = scheme.parse(textContent);
          this.classList.add(element, "colorized");
        }
      });
    } else if (global.jQuery) {
      jQuery(function($) {
        $(RULE + name).each(function() {
          var textContent = $(this).text();
          this.innerHTML = scheme.parse(textContent);
          $(this).addClass("colorized");
        });
      });
    }
    return colorize.addName(name, scheme);
  };

  // ------------------------------------------------------
  // URL parser.
  // ------------------------------------------------------

  var urls = new RegGrp({
    CHAR:   CHAR,
    EMAIL:  EMAIL,
    URL:    URL
  }, {
    '<#EMAIL>': '<a href="mailto:$2">$1$2</a>',
    '(<#URL>)':   '<a href="$1">$1</a>'
  });

  // ------------------------------------------------------
  // JavaScript parser.
  // ------------------------------------------------------

  var javascript = addScheme("javascript", {
    OPERATOR:      /[\[(\^=,:;&|!*?]/,
    BLOCK_COMMENT: BLOCK_COMMENT,
    LINE_COMMENT:  LINE_COMMENT,
    COMMENT:       /<#BLOCK_COMMENT>|<#LINE_COMMENT>/,
    NUMBER:        NUMBER,
    STRING1:       STRING1,
    STRING2:       STRING2,
    STRING:        /<#STRING1>|<#STRING2>/,
    CONDITIONAL:   /\/\*@if\s*\([^\)]*\)|\/\*@[\s\w]*|@\*\/|\/\/@\w+|@else[\s\w]*/, // conditional comments
    GLOBAL:        /\b(clearInterval|clearTimeout|confirm|constructor|document|escape|hasOwnProperty|Infinity|isNaN|isPrototypeOf|NaN|parseFloat|parseInt|prompt|propertyIsEnumerable|prototype|setInterval|setTimeout|toString|toLocaleString|unescape|valueOf|window)\b/,
    KEYWORD:       /\b(&&|\|\||arguments|break|case|continue|default|delete|do|else|false|for|function|if|in|instanceof|new|null|return|switch|this|true|typeof|var|void|while|with|undefined)\b/,
    REGEXP:        /\/(\[(\\.|[^\n\]\\])+\]|\\.|[^\/\n\\])+\/[gim]*/,
    SPECIAL:       /\b(assert\w*|alert|catch|console|debug|debugger|eval|finally|throw|try)\b/
  }, {
    "(<#LINE_COMMENT>)(\\n\\s*)(<#REGEXP>)?": '<span class="colorize-comment">$1</span>$2<span class="colorize-regexp">$3</span>',
    "(<#BLOCK_COMMENT)(\\s*)(<#REGEXP>)?": '<span class="colorize-comment">$1</span>$2<span class="colorize-regexp">$3</span>',
    "(<#OPERATOR>)(\\s*)(<#REGEXP>)": '$1$2<span class="colorize-regexp">$3</span>',
    "(return|typeof)(\\s*)(<#REGEXP>)": '<span class="colorize-keyword">$1</span>$2<span class="colorize-regexp">$3</span>',
    '(<#COMMENT>)':       'colorize-comment',
    '(<#STRING>)':        'colorize-string',
    '(<#NUMBER>)':        'colorize-number',
    '(<#CONDITIONAL>)':   'colorize-conditional-comment',
    '(<#GLOBAL>)':        'colorize-global',
    '(<#KEYWORD>)':       'colorize-keyword',
    '(<#SPECIAL>)':       'colorize-special'
  });

  // ------------------------------------------------------
  // CSS parser.
  // ------------------------------------------------------
  
  var css = addScheme("css", {
    CHAR:              CHAR,
    AT_RULE:           /@\w[^;{]+/,
    BRACKETED:         /\([^'\x22)]*\)/,
    COMMENT:           BLOCK_COMMENT,
    PROPERTY:          /(\w[\w-]*\s*):([^;}]+)/,
    VENDOR_SPECIFIC:   /(\-[\w-]+\s*):([^;}]+)/,
    SELECTOR:          /([<#CHAR>:\[.#-](\\.|[^{\\])*)\{/
  }, {
    '(<#AT_RULE>)':       'colorize-at_rule',
    '<#BRACKETED>':       IGNORE,
    '(<#COMMENT>)':       'colorize-comment',
    '<#PROPERTY>':        '<span class="colorize-property-name">$1</span>:<span class="colorize-property-value">$2</span>',
    '<#VENDOR_SPECIFIC>': '<span class="colorize-vendor-specific"><span class="colorize-property-name">$1</span>:<span class="colorize-property-value">$2</span></span>',
    '<#SELECTOR>':        '<span class="colorize-selector">$1</span>{'
  }, {
    ignoreCase: true
  });

  // ------------------------------------------------------
  // XML parser.
  // ------------------------------------------------------

  var xml = addScheme("xml", {
    CHAR:      CHAR,
    PI:        /<\?[^>]+>/,
    COMMENT:   /<!\s*(--([^-]|[\r\n]|-[^-])*--\s*)>/,
    CDATA:     /<!\[CDATA\[([^\]]|\][^\]]|\]\][^>])*\]\]>/,
    ENTITY:    /&(#\d+|\w+);/,
    TAG:       /(<\/?)([<#CHAR>\-]+(?:\:[<#CHAR>\-]+)?\s*)((?:\/[^>]|[^/>])*)(\/?>)/
  }, {
    '(<#PI>)':      'colorize-processing-instruction',
    '(<#COMMENT>)': 'colorize-comment',
    '(<#CDATA>)':   'colorize-cdata',
    '(<#ENTITY>)':  'colorize-entity',
    
    '<#TAG>': function(match, openTag, tagName, attributes, closeTag) {
      return openTag + '<span class="colorize-tag">' + tagName + '</span>' + attr.parse(attributes) + closeTag;
    }
  }, {
    ignoreCase: true,
    tabStop: 1
  });

  var attr = new RegGrp({
    CHAR:      CHAR,
    STRING1:   STRING1,
    STRING2:   STRING2,
    STRING:    /<#STRING1>|<#STRING2>/
  }, {
    '([<#CHAR>-]+)(?:(\\s*=\\s*)(<#STRING>))?': '<span class="colorize-attribute-name">$1</span>$2<span class="colorize-attribute-value">$3</span>'
  });

  // ------------------------------------------------------
  // HTML parser.
  // ------------------------------------------------------

  var html = xml.copy();

  html.dictionary.merge({
    DOCTYPE:     /<!doctype[^>]+>/,
    CONDITIONAL: /<!(--)?\[[^\]]*\]>|<!\[endif\](--)?>/, // conditional comments
    BLOCK:       /(<)(script|style)([^>]*)(>)([^<]*)<\/\2>/
  });

  // Parse a script or style block.
  html.insertAt(-1, "<#BLOCK>", parseBlock);

  html.merge({
    '(<#DOCTYPE>)':     'colorize-doctype',
    '(<#CONDITIONAL>)': 'colorize-conditional-comment'
  });

  function parseBlock(match, openTag, tagName, attributes, closeTag, cdata) {
    return openTag + '<span class="colorize-tag">' + tagName + '</span>' + attr.parse(attributes) + closeTag +
      cdata + openTag + '/<span class="colorize-tag">' + tagName + '</span>' + closeTag;
  };

  addScheme("html", html);

  // ------------------------------------------------------
  // HTML+CSS+JS parser.
  // ------------------------------------------------------

  addScheme("html_multi", html.union({
    '<#BLOCK>': function(match, openTag, tagName, attributes, closeTag, cdata) {
      var type = /style/i.test(tagName) ? "css" : "javascript";
      cdata = '<span class="colorize-' + type + ' colorize-block">' + colorize[type].parse(cdata, true) + '</span>';
      return parseBlock(match, openTag, tagName, attributes, closeTag, cdata);
    }
  }));
  
}); // end: closure

// =========================================================================
// doc/~/base2/code/colorize/base2.js
// =========================================================================

base2.exec(function(namespace) {
  eval(namespace);
  var javascript = colorize.javascript;
  javascript.add("\\b(" + ([extractNames(base2),extractNames(lang),extractNames(Function2),extractNames(Enumerable)].join(",") + ",base,base2,implement").match(/[^\s,]+/g).join("|") + ")\\b", '<span class="base2">$1</span>');
  javascript.insertAt(0, /("@[^"]+"):/, '<span class="colorize-special">$1</span>:');
  javascript.tabStop = 2;
  function extractNames(object) {
    return Array2.map(object.namespace.match(/var \w+/g), function(match) {
      return match.slice(4);
    }).join(",");
  };
});

// =========================================================================
// doc/init.js
// =========================================================================

base2["#name"] = "base2";
global["#name"] = "global";

forEach (base2, function(property, name) {
  if (property instanceof Function || property instanceof Package) {
    if (!(this == base2.dom && property._isTraitMethod)) {
      property["#name"] = this["#name"] + "." + name;
    }
    if (property instanceof Package) {
      doc.show[name] = true;
      forEach (property.exports, arguments.callee, property);
      forEach (property, function(klass, name) {
        if (Base.ancestorOf(klass) && !klass["#name"]) {
          klass["#name"] = property["#name"] + "." + name;
        }
      });
    } else if (Trait.ancestorOf(property)) {
      forEach (property["#implements"], function(trait) {
        forEach (trait, function(method, name) {
          if (!Trait[name] && typeOf(method) === "function" && property[name]) {
            property[name]._trait = trait;
            var protoMethod = property.prototype[name];
            if (protoMethod) protoMethod._trait = trait;
          }
        });
      });
    } else if (Collection.ancestorOf(property)) {
      var Item = property.Item;
      if (Item && !Item["#name"]) {
        Item['#name'] = property['#name'] + ".Item";
      }
      if (property == RegGrp) {
        property.Dict['#name'] = property['#name'] + ".Dict";
      }
    }
  }
}, base2);

doc.show.MiniWeb = false;
doc.show.colorize = false;
doc.show.doc = false;

}); // end: package
