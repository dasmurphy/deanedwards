/*
  base2.js (c) 2007-2012, Dean Edwards
  Home: http://code.google.com/p/base2/
  License: http://mit-license.org/
*/

// timestamp: Wed, 31 Oct 2012 01:00:52

base2.require("Date,base2.dom", function(_, Date, dom) { // begin: closure

"use strict";

var forEach = _.forEach;

//base2.exec("es5-shim");

var CONSTANT   = /^[A-Z][\dA-Z_]*$/;
var PRIMITIVE  = /^(boolean|number|string)$/;
var OBJECT     = /^(object|package|class|trait)$/;
var PACKAGE    = /^package$/;
var THIS       = /\bthis\./;
var VALID_NAME = /^[a-z]/i;

var mimeTypes = {
  js: "text/javascript",
  css: "text/css",
  html: "text/html",
  xml: "text/xml"
};

var OBJECT = /^(Object|Null|Undefined)$/;

var Object__toString = {}.toString;

var DATE_PROTOTYPE_METHODS =
"getDate,getDay,getFullYear,getHours,getMilliseconds,getMinutes,getMonth,\
getSeconds,getTime,getTimezoneOffset,getUTCDate,getUTCDay,getUTCFullYear,\
getUTCHours,getUTCMilliseconds,getUTCMinutes,getUTCMonth,getUTCSeconds,\
setDate,setFullYear,setHours,setMilliseconds,setMinutes,setMonth,setSeconds,\
setTime,setUTCDate,setUTCFullYear,setUTCHours,setUTCMilliseconds,setUTCMinutes,\
setUTCMonth,setUTCSeconds,toDateString,toLocaleDateString,\
toLocaleTimeString,toTimeString,toUTCString";

function isPrimitive(ref) {
  return PRIMITIVE.test(typeof ref) || ref instanceof RegExp;
}

function isConstant(ref, name) {
  return CONSTANT.test(name) && (ref === null || isPrimitive(ref));
}

function isObject(ref) {
  return typeof ref == "object" || typeof ref == "null";
}

function isClass(ref) {
  if (typeof ref != "function") return false;
  if (ref == window.Date || ref == window.XMLHttpRequest) return true;
  for (var i in ref.prototype) return true;
  if (ref == _.Base || _.Base.ancestorOf(ref)) return true;
  return /\s*function\s+[A-Z][^\[]+\[native code/.test(String(ref));
}

function isBaseClass(ref) {
  return typeof ref == "function" && (ref == base2.Base || base2.Base.ancestorOf(ref));
}

function isTrait(ref) {
  return typeof ref == "function" && base2.Trait.ancestorOf(ref);
}

function isPackage(ref, name) {
  return ref instanceof base2.Package && doc.show[name] !== false;
}

function isFunction(ref) {
  return _.isFunction(ref) && !isClass(ref);
}

function isMethod(ref) {
  return isFunction(ref) && /\bthis\./.test(ref);
}

// =========================================================================
// MiniWeb/doc/Members.js
// =========================================================================

var Member = _.Base.extend({
  constructor: function Member__constructor(name, reference, owner) {
    this.inherited = owner.ancestor && owner.ancestor[name] === reference;
  },

  inherited: false
});

var Members = _.Collection.extend({
  constructor: function Members__constructor(owner, test) {
    this.base();
    this.owner = owner;
    if (owner instanceof Reflection) {
      var reference = owner.reference
    } else {
      reference = owner;
    }
    forEach (reference, function _eacher(member, name) {
      if (VALID_NAME.test(name) && (!test || test.apply(undefined, arguments))) {
        this.set(name, member);
      }
    }, this, (typeof reference == "function" ? Function : Object).prototype);
    this.sort();
  },

  createItem: function Members__createItem(name, reference, inherited) {
    var member = this.base(name, reference, this.owner);
    if (arguments.length > 2) member.inherited = !!inherited;
    return member;
  },
  
  owner: null
}, {
  Item: Member
});

// =========================================================================
// MiniWeb/doc/Reflection.js
// =========================================================================

var Reflection = _.Base.extend({
  constructor: function Reflection__constructor(reference) {
    this.reference = reference;
    this.ancestor = Object.prototype;
    
    this.type = typeof reference;
    
    if (this.type === "null") this.type = "object";
    
    if (reference != null) {
      if (this.type === "function") {
        this.ancestor = Function.prototype;
        if (isClass(reference)) {
          this.ancestor = reference.ancestor || Object;
          if (typeof reference == "function" && _.Trait.ancestorOf(reference)) {
            this.type = "trait";
          } else {
            this.type = "class";
          }
        } else if (reference.prototype) {
          var typeString = Object__toString.call(reference.prototype).slice(8, -1);
          if (!OBJECT.test(typeString)) {
            this.type = "class";
          }
        }
      } else if (this.type === "object") {
        if (jsb.element == reference || jsb.element.ancestorOf(reference)) {
          this.ancestor = reference.ancestor;
          this.type = "behavior";
        } else {
          this.ancestor = reference.constructor.prototype;
          if (reference == this.ancestor || String(this.ancestor) == "[xpconnect wrapped native prototype]") {
            this.ancestor = (reference.constructor.ancestor || Object).prototype;
          }
          if (reference instanceof Namespace) {
            this.type = "namespace";
          } else if (reference instanceof _.Package) {
            this.type = "package";
          }
        }
      }
    }
  },

  ancestor: Object.prototype,
  reference: null,
  type: "undefined",

  getClasses: function Reflection__getClasses() {
    var members = new Members(this, function(ref) {
      return isClass(ref) && !isTrait(ref);
    });
    if (this.reference == window && _.detect("Gecko")) {
      for (var name in Components.interfaces) {
        name = name.slice(3);
        if (name in window) {
          members.set(name, window[name]);
        } else {
          name = name.slice(3);
          if (name in window) {
            members.set(name, window[name]);
          }
        }
      }
    }
    members.sort();
    return members;
  },

  getClassMethods: function Reflection__getClassMethods() {
    var traitMethods = this.type == "trait" ? this.reference.prototype : {};
    var members = new Members(this, function(ref, name) {
      return ref instanceof Function && !traitMethods[name] && !isBaseClass(ref) && ref != Object;
    });
    if (this.reference == Date) {
      members.set("UTC", Date.UTC, true);
      members.set("now", Date.now, false);
      members.set("parse", Date.parse, false);
    }
    if (!traitMethods.bind) {
      var bind = this.reference.bind;
      if (bind != Function.bind) {
        members.set("bind", bind);
      }
    }
    members.set("toString", this.reference.toString, true);
    members.sort();
    return members;
  },

  getClassProperties: function Reflection__getClassProperties() {
    var type = this.type;
    return new Members(this, function(ref, name) {
      return !CONSTANT.test(name) && (typeof ref == "null" || typeof ref == "object" || isPrimitive(ref) || isBaseClass(ref) || ref == Object);
    });
  },

  getConstants: function Reflection__getConstants() {
    return new Members(this, isConstant);
  },

  getEvents: function Reflection__getEvents() {
    return new Members(this, function(ref, name) {
      return ref === null && /^(\w+:)?on[a-z]+$/.test(name);
    });
  },

  getInstanceMethods: function Reflection__getInstanceMethods() {
    var reference = this.reference;
    if (reference == Date) {
      var proto = new Date;
      var members = new Reflection(proto).getMethods();
      forEach.csv(DATE_PROTOTYPE_METHODS, function(name) {
        members.set(name, proto[name], true);
      });
      members.set("toISOString", proto.toISOString, false);
      members.sort();
    } else {
      members = new Reflection(reference.prototype).getMethods();
    }
    return members;
  },

  getInstanceProperties: function Reflection__getInstanceProperties() {
    var reference = this.reference;
    if (reference == Date) {
      var members = new Reflection(new Date).getProperties();
    } else {
      members = new Reflection(reference.prototype).getProperties();
    }
    return members;
  },

  getMembers: function Reflection__getMembers() {
    var members = new Members(this);
    members.sort();
    return members;
  },

  getMethods: function Reflection__getMethods() {
    var reference = this.reference;
    var members = new Members(this, isFunction);
    if (reference == JSON) {
      members.set("parse", JSON.parse, true);
      members.set("stringify", JSON.stringify, true);
    }
    if (jsb.element.ancestorOf(reference)) {
      forEach.csv("attach,detach,get,modify,setCapture", function(name) {
        var member = members.get(name);
        member.inherited = String(jsb.element[name]) === String(reference[name]);
      });
    }
    try {
      members.set("toString", reference.toString, true);
    } catch(e){}
    members.sort();
    return members;
  },

  getPackages: function Reflection__getPackages() {
    return new Members(this, isPackage);
  },

  getProperties: function Reflection__getProperties() {
    return new Members(this, function(ref, name) {
      return typeof ref != "function" && !isConstant(ref, name) && !(ref instanceof _.Package) && !(ref === null && /^(\w+:)?on[a-z]+$/.test(name));
    });
  },

  getTraits: function Reflection__getTraits() {
    return new Members(this, isTrait);
  },

  getTraitMethods: function Reflection__getTraitMethods() {
    var traitMethods = this.type == "trait" ? this.reference.prototype : {};
    var members = new Members(this, function(ref, name) {
      return !!traitMethods[name] && name != "base";
    });
    if (traitMethods.bind) {
      members.set("bind", this.reference.bind);
      members.sort();
    }
    return members;
  }
});

// =========================================================================
// MiniWeb/doc/package.js
// =========================================================================

var doc = MiniWeb.doc = new _.Package({
  name:    "MiniWeb.doc",
  version: "1.0(beta1)",

  show: {},

  getObject: function(objectID) {
    if (objectID === "namespace") return namespace;

    var refId = String(objectID).replace(/::/, '.prototype.');
    refId = refId.split('.');
    if (refId.length > 1) {
      refId[refId.length - 2] += '["' + refId.pop() + '"]';
    }
    refId = refId.join('.');
    return new Function("try{return " + refId + "}catch(e){}")();
  },

  beautify: function(source) {
    source = String(source).replace(/([\x20\t]*;(;|doc);[^\n]+\n)+\r?\n?/g, "");
    var indent = source.match(/\n(\s+)\}\s*$/);
    if (indent) {
      source = source.replace(new RegExp("\\n" + indent[1], "g"), "\n");
    }
    return source;
  },

  "@Gecko": {
    beautify: function(source) {
      source = String(source).replace(/\s+doc;\r?\n/g, "");
      source = source.replace(/[\x20\t]*['"]use strict['"];[^\n]*\n/g, "");
      source = js_beautify(source, {indent_size: 2, keep_array_indentation: true});
      return source.replace(/{(\[native code\])/, "{\n  $1");
    }
  },

  beginEdit: function(textarea, type, width, height) {
    var body = textarea.ownerDocument.body;
    var scrollTop = body.scrollTop;
    var scrollHeight = body.scrollHeight;
    var editor = CodeMirror.fromTextArea(textarea, {
      mode: mimeTypes[type] || "text/html",
      tabMode: "indent",
      tabSize: 2,
      autofocus: true,
      lineWrapping: true,
      onFocus: function() {
        dom.classList.add(element, "mw-focus");
      },
      onBlur: function() {
        dom.classList.remove(element, "mw-focus");
      }
    });
    var element = editor.getWrapperElement();
    dom.classList.add(element, "mw-editor");
    editor.setSize(width, height);
    textarea.className = "mw-offscreen";
    setTimeout(function() {
      console.log([body.scrollTop, scrollTop])
      if (body.scrollTop > scrollTop) {
        //body.scrollTop = scrollTop;
      }
    }, 0);
    this._editor = editor;
    return editor;
  },

  stopEdit: function() {
    this._editor.toTextArea();
    delete this._editor;
  },

  colorize: function(pre) {
    var type = pre.className.split(/\s+/)[0];
    if (!mimeTypes[type]) return;

    var value = dom.get(pre, 'textContent');

    CodeMirror.runMode(_.trim(value), mimeTypes[type], pre, {
      tabMode: "indent",
      tabSize: 2,
      lineWrapping: true
    });
  },

  Members: Members,
  Reflection: Reflection
});

// =========================================================================
// MiniWeb/doc/data.js
// =========================================================================

doc.data = {
  PATH: "/data/doc/entries/",

  exists: function(objectID, entry) {
    return MiniWeb.server.io.exists(this.makepath(objectID, entry));
  },

  makepath: function(objectID, entry) {
    return this.PATH + String(objectID).replace(/::/, ".prototype.").split(".").join("/") + "/#" + entry;
  },

  read: function(objectID, entry) {
    return MiniWeb.server.io.read(this.makepath(objectID, entry));
  },

  remove: function(objectID, entry) {
    return MiniWeb.server.io.remove(this.makepath(objectID, entry));
  },

  write: function(objectID, entry, value) {
    var io = MiniWeb.server.io;
    var names = objectID.replace(/::/, ".prototype.").split(".");
    for (var i = 1; i <= names.length; i++) {
      var path = this.PATH + names.slice(0, i).join("/");
      if (!io.isDirectory(path)) {
        io.mkdir(path);
      }
    }
    io.write(path + "/#" + entry, value);
  }
};

// =========================================================================
// MiniWeb/doc/init.js
// =========================================================================

var behavior = jsb.element.constructor.prototype;
var dummy = jsb.element.extend();
for (var i in dummy) {
  if (!/^(constructor|ancestor)$/.test(i) && dummy[i] !== behavior[i]) {
    behavior[i] = dummy[i];
  }
}

base2["#name"] = "base2";
jsb["#name"] = "jsb";
MiniWeb["#name"] = "MiniWeb";
MiniWeb.doc["#name"] = "MiniWeb.doc";
base2.Base["#name"] = "base2.Base";
window["#name"] = "window";
FormData["#name"] = "FormData";
XMLHttpRequest2["#name"] = "XMLHttpRequest";
window.XMLHttpRequest = XMLHttpRequest2;
jsb.element["#name"] = "jsb.element";
jsb.form.element["#name"] = "jsb.form.element";

forEach.csv("Command,Terminal", function(className) {
  var klass = MiniWeb[className];
  var instance = new klass;
  (klass.prototype.exec = _.K()).toString = _.K(String(instance.exec));
});

var namespace = base2.exec(_.I);
var Namespace = namespace.constructor;

function createKey(key) {
  return key + "";
}
createKey.toString = _.K(String(String));

base2.Collection.prototype.createKey = createKey;

process(base2, "base2");
process(jsb, "jsb");
process(MiniWeb, "MiniWeb");
forEach (base2, process);
forEach (jsb, process);
forEach (MiniWeb, process);

function process(property, name) {
  if (property instanceof base2.Package) {
    property["#name"] = property.name;
    doc.show[name] = true;
    forEach (property, function(object, name) {
      if ((typeof object == "function" || jsb.element.ancestorOf(object)) && !object["#name"]) {
        object["#name"] = property["#name"] + "." + name;
      } else {
        process(object, name);
      }
    });
  } else if (typeof property == "function" && base2.Trait.ancestorOf(property)) {
    forEach (property["#implements"], function(trait) {
      forEach (trait, function(method, name) {
        if (!base2.Trait[name] && typeof method == "function" && property[name]) {
          property[name]._trait = trait;
          var protoMethod = property.prototype[name];
          if (protoMethod) protoMethod._trait = trait;
        }
      });
    });
  } else if (typeof property == "function" && base2.Collection.ancestorOf(property)) {
    var Item = property.Item;
    if (Item && !Item["#name"]) {
      Item['#name'] = property['#name'] + ".Item";
    }
    if (property == base2.RegGrp) {
      property.Dict['#name'] = property['#name'] + ".Dict";
    }
  }
}

doc.show.io = false;
doc.show.jst = false;

var events = (
  "mousedown|mouseup|mousemove|mouseenter|mouseleave|mouseover|mouseout|mousewheel|click|dblclick|" +
  "touchstart|touchmove|touchend|touchcancel|" +
  "keydown|keyup|input|" +
  "change|reset|submit|" +
  "focus|blur|scroll|select|" +
  "transitionend"
).split("|").sort();

forEach (events, function(name) {
  behavior["on" + name] = null;
});

events = "attach|contentready|documentready|losecapture".split("|");

forEach (events, function(name) {
  behavior["jsb:on" + name] = null;
});

//jsb.element["capture:onblur"] = null;
//jsb.element["capture:onfocus"] = null;
behavior["window:onresize"] = null;

}); // end: closure
