
base2.exec(function(_) {
  var Package = base2.Package;

  describe('Package::constructor', {
    "Should construct": function() {
      var pkg = new Package();
      value_of(pkg instanceof Package).should_be(true);
    },

    "Should construct from object": function() {
      var pkg = new Package({
        name: "sample",
        version: "1.0"
      });
      value_of(pkg instanceof Package).should_be(true);
      value_of(pkg.name).should_be("sample");
    },

    "Should export names": function() {
      var MyClass = _.Base.extend();

      var pkg = new Package({
        name: "sample",
        version: "1.0",
        MyClass: MyClass
      });

      value_of(pkg instanceof Package).should_be(true);
      value_of(pkg.name).should_be("sample");

      value_of(pkg.MyClass).should_be(MyClass);
    },

    "Should prettify class and object names": function() {
      var MyClass = _.Base.extend();

      var pkg = new Package({
        name: "sample",
        version: "1.0",
        MyClass: MyClass
      });

      value_of(pkg.MyClass.toString()).should_be("[sample.MyClass]");
      value_of(new pkg.MyClass().toString()).should_be("[object sample.MyClass]");
    }
  });
});
