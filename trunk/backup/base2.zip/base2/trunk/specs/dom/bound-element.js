
base2.require("dom", function(namespace) {
  eval(namespace);

  var button = document.createElement("button");
  var element = document.createElement("div");
  element.style.width = "100px";
  
  var clickCount = 0;
  
  function listen(event) {
    clickCount++;
  };

  describe('base2.dom.bind(element)', {

    "Should support compareDocumentPosition": function() {
      document.body.appendChild(element);
      var position = element.compareDocumentPosition(document.body);
      value_of(position).should_be(10);
    },

    "Should support get/setUserData": function() {
      element.setUserData("example", 55, null);
      value_of(element.getUserData("example")).should_be(55);
    },

    "Should support addEventListener": function() {
      document.body.appendChild(button);
      button.addEventListener("click", listen, false);
      button.click();
      value_of(clickCount).should_be(1);
    },

    "Should support dispatchEvent": function() {
      var event = document.createEvent("UIEvents");
      event.initEvent("click", true, true);
      button.dispatchEvent(event);
      value_of(clickCount).should_be(2);
    },

    "Should support removeEventListener": function() {
      button.removeEventListener("click", listen, false);
      button.click();
      value_of(clickCount).should_be(2);
      document.body.removeChild(button);
    },

    "Should support getBoundingClientRect": function() {
      var rect = element.getBoundingClientRect();
      value_of(rect.right - rect.left).should_be(100);
    },

    "Should support classList.contains": function() {
      element.className = "test1";
      value_of(element.classList.contains("test")).should_be(false);
      value_of(element.classList.contains("test1")).should_be(true);
    },

    "Should support classList.add": function() {
      element.classList.add("test2");
      value_of(element.className).should_be("test1 test2");
    },

    "Should support classList.remove": function() {
      element.classList.remove("test2");
      value_of(element.className).should_be("test1");
    },

    "Should support classList.toggle": function() {
      element.classList.toggle("test1");
      value_of(element.className).should_be("");
      element.classList.toggle("test1");
      value_of(element.className).should_be("test1");
    },

    "Should support hasAttribute": function() {
      value_of(element.hasAttribute("id")).should_be(false);
    },

    "Should support getAttribute": function() {
      value_of(element.getAttribute("id")).should_be(null);
    },

    "Should support setAttribute": function() {
      element.setAttribute("id", "example");
      value_of(element.id).should_be("example");
    },

    "Should support removeAttribute": function() {
      element.removeAttribute("id");
      value_of(element.id).should_be("");
    },

    "Should support querySelector": function() {
      element.innerHTML = "<p>Hello.</p><p>Hello.</p><p>Hello.</p>";
      value_of(element.querySelector("p")).should_be(element.firstChild);
    },

    "Should support querySelectorAll": function() {
      element.removeAttribute("id");
      value_of(element.querySelectorAll("p").length).should_be(3);
    },

    "Should support matchesSelector": function() {
      value_of(element.matchesSelector("div")).should_be(true);
      document.body.removeChild(element);
    }

  });

});
