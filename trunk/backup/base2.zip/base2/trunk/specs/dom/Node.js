
base2.require("base2.dom", function(_, dom) {
});
