
base2.require("base2.dom", function(_, dom) {
  describe('base2.dom.getAttribute', {
    "Should return a string": function() {
      var element = document.createElement("input");
      value_of(dom.getAttribute(element, "style")).should_be(null);
      element.style.color = "red";
      element.readOnly = true;
      value_of(typeof dom.getAttribute(element, "style")).should_be("string");
      value_of(typeof dom.getAttribute(element, "readonly")).should_be("string");
    },

    "Should return null for unspecified attributes": function() {
      var element = document.createElement("div");
      element.id = "example";
      value_of(dom.getAttribute(element, "example")).should_be(null);
      value_of(dom.getAttribute(element, "id")).should_not_be(null);
    }

  });

  describe('base2.dom.hasAttribute', {
    "Should return a boolean": function() {
      var element = document.createElement("input");
      element.style.color = "red";
      value_of(typeof dom.hasAttribute(element, "style")).should_be("boolean");
      value_of(typeof dom.hasAttribute(element, "readonly")).should_be("boolean");
    },

    "Should return false for unspecified attributes": function() {
      var element = document.createElement("input");
      value_of(dom.hasAttribute(element, "example")).should_be(false);
      value_of(dom.hasAttribute(element, "value")).should_be(false);
    },

    "Should return true for specified attributes": function() {
      var element = document.createElement("div");
      element.innerHTML = "<input readonly>";
      element.id = "example";
      value_of(dom.hasAttribute(element, "id")).should_be(true);
      value_of(dom.hasAttribute(element.firstChild, "readonly")).should_be(true);
    },

    "Should return false for removed boolean attributes": function() {
      var element = document.createElement("div");
      element.innerHTML = "<input readonly>";
      dom.removeAttribute(element.firstChild, "readonly")
      value_of(dom.hasAttribute(element.firstChild, "readonly")).should_be(false);
    }

  });

  describe('base2.dom.removeAttribute', {
    "Should remove an attribute": function() {
      var element = document.createElement("div");
      element.innerHTML = "<input id='example'>";
      dom.removeAttribute(element.firstChild, "id");
      value_of(dom.hasAttribute(element, "id")).should_be(false);
    },

    "Should set boolean properties to false when the attribute is removed": function() {
      var element = document.createElement("div");
      element.innerHTML = "<input readonly>";
      dom.removeAttribute(element.firstChild, "readonly");
      value_of(element.firstChild.readOnly).should_be(false);
    }

  });

  describe('base2.dom.setAttribute', {

  });
});
