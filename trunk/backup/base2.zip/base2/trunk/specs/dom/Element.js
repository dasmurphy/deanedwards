
base2.require("dom", function(namespace) {
  eval(namespace);

  describe('Element.getAttribute', {

    "Should return a string": function() {
      var element = document.createElement("input");
      value_of(getAttribute(element, "style")).should_be(null);
      element.style.color = "red";
      element.readOnly = true;
      value_of(typeof getAttribute(element, "style")).should_be("string");
      value_of(typeof getAttribute(element, "readonly")).should_be("string");
    },

    "Should return null for unspecified attributes": function() {
      var element = document.createElement("div");
      element.id = "example";
      value_of(getAttribute(element, "example")).should_be(null);
      value_of(getAttribute(element, "id")).should_not_be(null);
    }

  });

  describe('Element.hasAttribute', {

    "Should return a boolean": function() {
      var element = document.createElement("input");
      element.style.color = "red";
      value_of(typeof hasAttribute(element, "style")).should_be("boolean");
      value_of(typeof hasAttribute(element, "readonly")).should_be("boolean");
    },

    "Should return false for unspecified attributes": function() {
      var element = document.createElement("input");
      value_of(hasAttribute(element, "example")).should_be(false);
      value_of(hasAttribute(element, "value")).should_be(false);
    },

    "Should return true for specified attributes": function() {
      var element = document.createElement("div");
      element.innerHTML = "<input readonly>";
      element.id = "example";
      value_of(hasAttribute(element, "id")).should_be(true);
      value_of(hasAttribute(element.firstChild, "readonly")).should_be(true);
    },

    "Should return false for removed boolean attributes": function() {
      var element = document.createElement("div");
      element.innerHTML = "<input readonly>";
      removeAttribute(element.firstChild, "readonly")
      value_of(hasAttribute(element.firstChild, "readonly")).should_be(false);
    }

  });

  describe('Element.removeAttribute', {

    "Should remove an attribute": function() {
      var element = document.createElement("div");
      element.innerHTML = "<input id='example'>";
      removeAttribute(element.firstChild, "id");
      value_of(hasAttribute(element, "id")).should_be(false);
    },

    "Should set boolean properties to false when the attribute is removed": function() {
      var element = document.createElement("div");
      element.innerHTML = "<input readonly>";
      removeAttribute(element.firstChild, "readonly");
      value_of(element.firstChild.readOnly).should_be(false);
    }

  });

  describe('Element.setAttribute', {

  });

  describe('Element.matchesSelector', {

  });

});
