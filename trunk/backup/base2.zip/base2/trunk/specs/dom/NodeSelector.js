
base2.require("dom", function(namespace) {
  eval(namespace);

  describe('NodeSelector.querySelector', {

    "Should find element by tag name": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span id="a"></span><span id="b"></span><span id="c"></span>';

      value_of(querySelector(element, "span")).should_be(element.firstChild);
      value_of(querySelector(element, "SPAN")).should_be(element.firstChild);
      value_of(querySelector(element, "span span")).should_be(element.firstChild.firstChild);
      value_of(querySelector(element, "img")).should_be(null);

      element.appendChild(document.createElement("section"));
      value_of(querySelector(element, "span+section")).should_be(element.lastChild);
    },

    "Should find element by ID": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span id="a"></span><span id="b"></span><span id="c"></span>';

      value_of(querySelector(element, "#a")).should_be(element.firstChild);
      value_of(querySelector(document, "#b")).should_be(null);
      value_of(querySelector(element, "#d")).should_be(null);
    },

    /*"Should respect upper case IDs": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span id="EXAMPLE"></span>';
      value_of(querySelector(element, "#EXAMPLE")).should_be(element.firstChild);

      element.innerHTML = '<span id="eXample"></span>';
      value_of(querySelector(element, "#eXample")).should_be(element.firstChild);

      element.innerHTML = '<span id="�xamplE"></span>';
      value_of(querySelector(element, "#�xamplE")).should_be(element.firstChild);

      element.innerHTML = '<span id="�xample"></span>';
      value_of(querySelector(element, "#�xample")).should_be(element.firstChild);
    },*/

    "Should find element by class name": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span id="a" class="another example"></span><span id="b"></span><span id="c"></span>';

      value_of(querySelector(element, ".example")).should_be(element.firstChild);
      value_of(querySelector(element, ".another.example")).should_be(element.firstChild);
      value_of(querySelector(element, ".example2")).should_be(null);
    },

    "Should find element by attribute ([att])": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span title="this is an example"></span><span></span><span></span>';

      value_of(querySelector(element, "[title]")).should_be(element.firstChild);
      value_of(querySelector(element, "[class]")).should_be(null);
    },

    "Should find element by attribute ([att=value])": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span title="this is an example"></span><span></span><span></span>';

      value_of(querySelector(element, "[title='this is an example']")).should_be(element.firstChild);
      value_of(querySelector(element, "[title='THIS IS AN EXAMPLE']")).should_be(null);
    },

    "Should find element by attribute ([att^=value])": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span title="this is an example"></span><span></span><span></span>';

      value_of(querySelector(element, "[title^='this']")).should_be(element.firstChild);
      value_of(querySelector(element, "[title^='this is']")).should_be(element.firstChild);
      value_of(querySelector(element, "[title^='is']")).should_be(null);
      value_of(querySelector(element, "[title^='']")).should_be(null);
    },

    "Should find element by attribute ([att*=value])": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span title="this is an example"></span><span></span><span></span>';

      value_of(querySelector(element, "[title*='this']")).should_be(element.firstChild);
      value_of(querySelector(element, "[title*='is an']")).should_be(element.firstChild);
      value_of(querySelector(element, "[title*='example']")).should_be(element.firstChild);
      value_of(querySelector(element, "[title*='']")).should_be(null);
    },

    "Should find element by attribute ([att~=value])": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span title="this is an example"></span><span></span><span></span>';

      value_of(querySelector(element, "[title~='this']")).should_be(element.firstChild);
      value_of(querySelector(element, "[title~='an']")).should_be(element.firstChild);
      value_of(querySelector(element, "[title~='example']")).should_be(element.firstChild);
      value_of(querySelector(element, "[title~='is an']")).should_be(null);
      value_of(querySelector(element, "[title~='']")).should_be(null);
    },

    "Should find element by attribute ([att|=value])": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span title="this-is-an-example"></span><span></span><span></span>';

      value_of(querySelector(element, "[title|='this']")).should_be(element.firstChild);
      value_of(querySelector(element, "[title|='this-']")).should_be(null);
      value_of(querySelector(element, "[title|='this-is']")).should_be(element.firstChild);
      value_of(querySelector(element, "[title|='an']")).should_be(null);
      value_of(querySelector(element, "[title|='this-is-an-example']")).should_be(element.firstChild);
      value_of(querySelector(element, "[title|='']")).should_be(null);
    },

    "Should find element by attribute ([att$=value])": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span title="this is an example"></span><span></span><span></span>';

      value_of(querySelector(element, "[title$='example']")).should_be(element.firstChild);
      value_of(querySelector(element, "[title$='example']")).should_be(element.firstChild);
      value_of(querySelector(element, "[title$='']")).should_be(null);
    },

    "Should find element by first-child pseudo class": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span></span><span></span><span></span>';

      value_of(querySelector(element, "span:first-child")).should_be(element.firstChild);
      value_of(querySelector(element, ":first-child")).should_be(element.firstChild);
      value_of(querySelector(element, "img:first-child")).should_be(null);
    },

    "Should find element by last-child pseudo class": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span></span><span></span><span></span>';


      value_of(querySelector(element, "span:last-child")).should_be(element.lastChild);
      value_of(querySelector(element, ":last-child")).should_be(element.lastChild);
      value_of(querySelector(element, "img:last-child")).should_be(null);
    },

    "Should find element by only-child pseudo class": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span><span></span></span>';


      value_of(querySelector(element, "span:only-child")).should_be(element.firstChild);
      value_of(querySelector(element, ":only-child")).should_be(element.firstChild);
      value_of(querySelector(element, "img:only-child")).should_be(null);
    },

    "Should find element by nth-child pseudo class": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span id="a"></span><span id="b"></span><span id="c"></span>';

      value_of(querySelector(element, "span:nth-child(1)")).should_be(element.firstChild);
      value_of(querySelector(element, "span:nth-child(odd)")).should_be(element.firstChild);
      value_of(querySelector(element, "span:nth-child(even)")).should_be(element.firstChild.nextSibling);
      value_of(querySelector(element, "span:nth-child(3n)")).should_be(element.lastChild);
      value_of(querySelector(element, "img:nth-child(1)")).should_be(null);
    },

    "Should find element by nth-last-child pseudo class": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span id="a"></span><span id="b"></span><span id="c"></span>';

      value_of(querySelector(element, "span:nth-last-child(1)")).should_be(element.lastChild);
      value_of(querySelector(element, "span:nth-last-child(odd)")).should_be(element.firstChild);
      value_of(querySelector(element, "span:nth-last-child(even)")).should_be(element.firstChild.nextSibling);
      value_of(querySelector(element, "span:nth-last-child(3n)")).should_be(element.firstChild);
      value_of(querySelector(element, "img:nth-last-child(1)")).should_be(null);
    }

  });

  describe('NodeSelector.querySelectorAll', {

    "Should find elements by tag name": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span><span></span><span></span></span>';

      value_of(querySelectorAll(element, "SPAN").length).should_be(3);
      value_of(querySelectorAll(element, "span").length).should_be(3);
      value_of(querySelectorAll(element, "span span").length).should_be(2);
      value_of(querySelectorAll(element, "span span span").length).should_be(0);
      value_of(querySelectorAll(element, "img").length).should_be(0);
    },

    /*"Should find elements by ID": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span id="example"></span><span></span><span></span>';

      value_of(querySelectorAll(element, "#example").length).should_be(1);
      value_of(querySelectorAll(element, "#example")[0]).should_be(element.firstChild);
    },

    "Should respect upper case IDs": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span id="EXAMPLE"></span><span></span><span></span>';

      value_of(querySelectorAll(element, "#EXAMPLE").length).should_be(1);
    },*/

    "Should find elements by class name": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span class="example"></span><span class="another example"></span><span class="another example"></span>';

      value_of(querySelectorAll(element, ".example").length).should_be(3);
      value_of(querySelectorAll(element, ".another.example").length).should_be(2);
      value_of(querySelectorAll(element, ".example2").length).should_be(0);
    },

    "Should find elements by attribute ([att])": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span title="this is an example"></span><span title="this is an example"></span><span></span>';

      value_of(querySelectorAll(element, "[title]").length).should_be(2);
      value_of(querySelectorAll(element, "[class]").length).should_be(0);
    },

    "Should find elements by attribute ([att=value])": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span title="this is an example"></span><span title="this is an example"></span><span></span>';

      value_of(querySelectorAll(element, "[title='this is an example']").length).should_be(2);
      value_of(querySelectorAll(element, "[title='THIS IS AN EXAMPLE']").length).should_be(0);
    },

    "Should find elements by attribute ([att^=value])": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span title="this is an example"></span><span title="this is an example"></span><span></span>';

      value_of(querySelectorAll(element, "[title^='this']").length).should_be(2);
      value_of(querySelectorAll(element, "[title^='this is']").length).should_be(2);
      value_of(querySelectorAll(element, "[title^='is']").length).should_be(0);
      value_of(querySelectorAll(element, "[title^='']").length).should_be(0);
    },

    "Should find elements by attribute ([att*=value])": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span title="this is an example"></span><span title="this is an example"></span><span></span>';

      value_of(querySelectorAll(element, "[title*='this']").length).should_be(2);
      value_of(querySelectorAll(element, "[title*='is an']").length).should_be(2);
      value_of(querySelectorAll(element, "[title*='example']").length).should_be(2);
    },

    "Should find elements by attribute ([att~=value])": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span title="this is an example"></span><span title="this is an example"></span><span></span>';

      value_of(querySelectorAll(element, "[title~='this']").length).should_be(2);
      value_of(querySelectorAll(element, "[title~='an']").length).should_be(2);
      value_of(querySelectorAll(element, "[title~='example']").length).should_be(2);
      value_of(querySelectorAll(element, "[title~='is an']").length).should_be(0);
    },

    "Should find elements by attribute ([att|=value])": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span title="this-is-an-example"></span><span title="this-is-an-example"></span><span></span>';

      value_of(querySelectorAll(element, "[title|='this']").length).should_be(2);
      value_of(querySelectorAll(element, "[title|='this-']").length).should_be(0);
      value_of(querySelectorAll(element, "[title|='this-is']").length).should_be(2);
      value_of(querySelectorAll(element, "[title|='an']").length).should_be(0);
      value_of(querySelectorAll(element, "[title|='this-is-an-example']").length).should_be(2);
    },

    "Should find elements by attribute ([att$=value])": function() {
      var element = document.createElement("div");
      element.innerHTML = '<span title="this is an example"></span><span title="this is an example"></span><span></span>';

      value_of(querySelectorAll(element, "[title$='example']").length).should_be(2);
      value_of(querySelectorAll(element, "[title$='example']").length).should_be(2);
    }

  });

});