
base2.require("dom", function(namespace) {
  eval(namespace);
  
  var element = document.createElement("div");
  element.innerHTML = '<ul><li id="a">a<li id="b" class="bb">b<li id="c">c</ul>';
  var snl = querySelectorAll(element, "li");

  describe('StaticNodeList', {

    "Should construct from NodeList": function() {
      var snl = new base2.dom.StaticNodeList(element.getElementsByTagName("*"));
      value_of(snl.length).should_be(4);
    },

    "Should return from querySelectorAll()": function() {
      value_of(typeof snl.forEach).should_be("function");
      value_of(snl.length).should_be(3);
    },

    "Should support forEach()": function() {
      var text = "";
      snl.forEach(function(node) {
        text += node.id;
      });
      value_of(text).should_be("abc");
    },

    "Should support map()": function() {
      var text = snl.map(function(node) {
        return node.id;
      }).join("");
      value_of(text).should_be("abc");
    },

    "Should support filter() by function": function() {
      var result = snl.filter(function(node) {
        return node.id != "b";
      });
      value_of(result.length).should_be(2);
    },

    "Should support filter() by selector": function() {
      var result = snl.filter(":not([id=b])");
      value_of(result.length).should_be(2);
    },

    "Should support not() by function": function() {
      var result = snl.not(function(node) {
        return node.id == "b";
      });
      value_of(result.length).should_be(2);
    },

    "Should support not() by selector": function() {
      var result = snl.not("[id=b]");
      value_of(result.length).should_be(2);
    },

    "Should support item()": function() {
      value_of(snl.item(-1)).should_be(snl[snl.length - 1]);
    },

    "Should support indexOf()": function() {
      value_of(snl.indexOf(snl[2])).should_be(2);
    },

    "Should support slice()": function() {
      var result = snl.slice(1);
      value_of(pluck(result, "id").join("")).should_be("bc");
      result = snl.slice(0, -1);
      value_of(pluck(result, "id").join("")).should_be("ab");
    },

    "Should support every()": function() {
      value_of(snl.every("[id]")).should_be(true);
      value_of(snl.every("[class]")).should_be(false);
    },

    "Should support some()": function() {
      value_of(snl.some("[class]")).should_be(true);
      value_of(snl.some("[href]")).should_be(false);
    }

  });

});