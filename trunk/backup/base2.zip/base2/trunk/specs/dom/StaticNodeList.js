
base2.require("base2.dom", function(_, dom) {
  var element = document.createElement("div");
  element.innerHTML = '<ul><li id="a">a</li><li id="b" class="bb">b</li><li id="c">c</li></ul>';
  
  var nodes = dom.querySelectorAll(element, "li");

  describe('StaticNodeList', {
    "Should construct from NodeList": function() {
      var nodeList = element.getElementsByTagName("*");
      var nodes = new dom.StaticNodeList(nodeList);
      value_of(nodes.length).should_be(nodeList.length);
    },

    "Should return from querySelectorAll()": function() {
      value_of(typeof nodes).should_be("object");
    },

    "Should have a length property": function() {
      value_of(typeof nodes.length).should_be("number");
    },

    "Should support item()": function() {
      value_of(nodes.item(1)).should_be(nodes[1]);
    }
  });
});
