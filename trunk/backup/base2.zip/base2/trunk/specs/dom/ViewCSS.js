
base2.require("base2.dom", function(_, dom) {
  describe('base2.dom.getComputedStyle', {
    "should return metrics in pixels": function() {
      var element = document.createElement("div");
      element.style.cssText = "width:1em;padding:0;margin:1PX;left:1ex;position:absolute";
      document.body.appendChild(element);
      var cs = dom.getComputedStyle(element, null);
      value_of(cs.width).should_match(/px$/);
      value_of(cs.paddingLeft).should_match(/px$/);
      value_of(cs.marginLeft).should_match(/px$/);
      value_of(cs.left).should_match(/px$/);
      document.body.removeChild(element);
    },

    "should return colors in rgb": function() {
      var element = document.createElement("div");
      element.style.cssText = "color: #65C400; background-color: #227700";
      document.body.appendChild(element);
      var cs = dom.getComputedStyle(element, null);
      value_of(cs.color).should_be('rgb(101, 196, 0)');
      value_of(cs.backgroundColor).should_be('rgb(34, 119, 0)');

      element.style.cssText = 'color: white; background-color: black';
      var cs = dom.getComputedStyle(element, null);
      value_of(cs.color).should_be('rgb(255, 255, 255)');
      value_of(cs.backgroundColor).should_be('rgb(0, 0, 0)');
      document.body.removeChild(element);
    },

    "should return background position": function() {
      var element = document.createElement("div");
      element.style.cssText = 'color: white; background-position: 1px 1px';
      document.body.appendChild(element);
      var cs = dom.getComputedStyle(element, null);
      value_of(cs.backgroundPosition).should_be('1px 1px');
      document.body.removeChild(element);
    },

    "should return float": function() {
      var element = document.createElement("div");
      element.style.cssText = 'color: white; float: left';
      document.body.appendChild(element);
      var cs = dom.getComputedStyle(element, null);
      value_of(cs.cssFloat).should_be('left');
      document.body.removeChild(element);
    }
  });
});
