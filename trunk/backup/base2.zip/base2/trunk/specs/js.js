
describe('base2.Date2', {
  'Should construct from date': function() {
    var now = new Date;
    value_of(new base2.Date2(now).valueOf()).should_be(now.valueOf());
  },
  
  'Should construct from number': function() {
    var now = new Date;
    value_of(new base2.Date2(now.valueOf()).valueOf()).should_be(now.valueOf());
  },

  'Should construct from ISO string': function() {
    value_of(new base2.Date2("1999-01-01").valueOf()).should_be(Date.UTC(1999, 0, 1));
  },

  'Should construct with 3 or more arguments': function() {
    value_of(new base2.Date2(1999, 0, 1).valueOf()).should_be(new Date(1999, 0, 1).valueOf());
    value_of(new base2.Date2(1999, 0, 1, 1).valueOf()).should_be(new Date(1999, 0, 1, 1).valueOf());
  },

  'Should cast date': function() {
    value_of(typeof base2.Date2(new Date).toISOString).should_be("function");
  }
});

describe('base2.Date2.parse', {
  'Should parse ISO string to number (milliseconds since the epoch (1st Jan 1970))': function() {
    value_of(base2.Date2.parse("1999-01-01")).should_be(Date.UTC(1999,0,1));
  }
});

describe('base2.Date2.now', {
  'Should return current elapsed time in milliseconds since the epoch (1st Jan 1970)': function() {
    value_of(base2.Date2.now()).should_be(new Date().valueOf());
  }
});

describe('base2.Date2.toISOString', {
  'Should convert a date to ISO string': function() {
    value_of(base2.Date2.toISOString(new Date(Date.UTC(2001, 0, 1)))).should_be("2001-01-01T00:00:00.000Z");
  }
});

describe('base2.Date2::toISOString', {
  'Should convert to ISO string': function() {
    value_of(new base2.Date2(Date.UTC(2001, 0, 1)).toISOString()).should_be("2001-01-01T00:00:00.000Z");
  }
});

describe('base2.Function2', {
  'Should define constants (I, II, K)': function() {
    value_of(base2.Function2.K).should_not_be(undefined);
    value_of(base2.Function2.I).should_not_be(undefined);
    value_of(base2.Function2.II).should_not_be(undefined);
  },
  
  'Should construct from null': function() {
    value_of(new base2.Function2(null).toString()).should_be(new Function(null).toString());
  },

  'Should construct from string': function() {
    value_of(new base2.Function2("return x").toString()).should_be(new Function("return x").toString());
    value_of(new base2.Function2("x,y,z", "return x").toString()).should_be(new Function("x,y,z", "return x").toString());
  },

  'Should cast existing function': function() {
    value_of(typeof base2.Function2(new Function).partial).should_be("function");
  }
});

describe('base2.Function2.bind', {
  'Should bind anonymous function': function() {
    value_of(base2.Function2.bind(function(){return this.a}, {a:1})()).should_be(1);
    value_of(base2.Function2.bind(function(){return this.b}, {b:2})()).should_be(2);
    value_of(base2.Function2(function(){return this.c}).bind({c:3})()).should_be(3);
  }
});

describe('base2.Function2.bind', {
  'Should bind to object': function() {
    value_of(base2.Function2.bind(function(){return this.a}, {a:1})()).should_be(1);
    value_of(base2.Function2.bind(function(){return this.b}, {b:2})()).should_be(2);
    value_of(base2.Function2(function(){return this.c}).bind({c:3})()).should_be(3);
  }
});
