
describe('jsb', {
  'Should be defined': function() {
    value_of(typeof jsb).should_be("object");
  }
});

describe('jsb.createStyleSheet', {
  'Should create style sheet from cssText': function() {
  },

  'Should create style sheet from object': function() {
  }
});

describe('jsb.Rule', {
  'Should create Rule': function() {
  },
  
  'Should refresh a Rule': function() {
  }
});

describe('jsb.RuleList', {
  'Should create RuleList': function() {
  },
  
  'Should inherit from base2.Collection': function() {
  }
});

describe('jsb.behavior', {
});
