
base2.exec(function(_) {
  describe('Functional', {
    'Should not cast null': function() {
      var err = false;
      try {
        _.Functional(null);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },
    
    'Should cast functions': function() {
      var fn = _.Functional(function(){});
      value_of(typeof fn.partial).should_be("function");
    },

    'Should not cast objects': function() {
      var err = false;
      try {
        _.Functional({});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    }
  });
  
  describe('Functional.bind', {
    'Should throw if first argument is not a function': function() {
      var err = false;
      try {
        var fn = _.bind();
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should bind a function to an object': function() {
      var obj = {
        a: 99,
        test: function() {
          return this.a;
        }
      }
      var fn = _.bind(obj.test, obj);
      value_of(fn()).should_be(99);
    },

    'Should pass supplied arguments': function() {
      var obj = {
        a: 1,
        test: function(a, b, c) {
          return _.slice(arguments).join("");
        }
      }
      var fn = _.bind(obj.test, obj, 1, 2, 3);
      value_of(fn()).should_be("123");
    },

    'Should pass all additional arguments': function() {
      var obj = {
        a: 1,
        test: function(a, b, c) {
          return _.slice(arguments).join("");
        }
      }
      var fn = _.bind(obj.test, obj, 1, 2);
      value_of(fn(3)).should_be("123");
    }
  });

  describe('Functional.compose', {
    'Should throw if first argument is not a function': function() {
      var err = false;
      try {
        var fn = _.compose();
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Composed functions must be functionally equivalent': function() {
      // compose(a, b, c)() === a(b(c()))
      function addWorld(word) {
        return word + " World!";
      }
      function reverse(word) {
        return word.split("").reverse().join("");
      }
      function toUpperCase(word) {
        return word.toUpperCase();
      }
      var composed = _.compose(toUpperCase, addWorld, reverse);
      value_of(composed("olleH")).should_be(toUpperCase(addWorld(reverse("olleH"))));
    }
  });

  describe('Functional.memoize', {
    'Should throw if first argument is not a function': function() {
      var err = false;
      try {
        var fn = _.memoize();
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should retrieve value from cache': function() {
      var count = 0;
      var add1 = _.memoize(function(v) {
        count++;
        return v + 1;
      });
      var a = add1(1);
      var b = add1(2);
      var c = add1(2);
      var d = add1(99);
      value_of(a).should_be(2);
      value_of(b).should_be(c);
      value_of(d).should_be(100);
      value_of(count).should_be(3);
    },

    'Should expose cache': function() {
      var add1 = _.memoize(function(v) {
        return v + 1;
      });
      var d = add1(99);
      value_of(add1.cache[99]).should_be(100);
    },

    'Should memoize multiple arguments': function() {
      var count = 0;
      var add = _.memoize(function(a, b) {
        count++;
        return a + b;
      });
      var a = add(5, 6);
      var b = add(8, 3);
      var c = add(8, 3);
      value_of(a).should_be(11);
      value_of(b).should_be(c);
      value_of(count).should_be(2);
    },

    'Should use keyFunction': function() {
      var keyCount = 0;
      var keyFunction = function(a, b) {
        keyCount++;
        return a + "." + b;
      };
      var callCount = 0;
      var add = _.memoize(function(a, b) {
        callCount++;
        return a + b;
      }, keyFunction);

      var a = add(5, 6);
      var b = add(8, 3);
      var c = add(8, 3);
      value_of(a).should_be(11);
      value_of(b).should_be(c);
      value_of(keyCount).should_be(3);
      value_of(callCount).should_be(2);
    }
  });
  
  describe('Functional.once', {
    'Should throw if first argument is not a function': function() {
      var err = false;
      try {
        var fn = _.once();
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },
    
    'Should only execute once': function() {
      var count = 0;
      var add = _.once(function() {
        count++;
      });
      add();
      add();
      add();
      value_of(count).should_be(1);
    }
  });

  describe('Functional.partial', {
    'Should throw if first argument is not a function': function() {
      var err = false;
      try {
        var fn = _.partial();
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should partially evaluate a function': function() {
      var test = function(a, b, c) {
        return _.slice(arguments).join("");
      };
      var test_a1 = _.partial(test, 1);
      value_of(test_a1(2,3)).should_be("123");
    },

    'Should use undefined as a placeholder': function() {
      var test = function(a, b, c) {
        return _.slice(arguments).join("");
      };
      var test_b2 = _.partial(test, undefined, 2);
      value_of(test_b2(1,3)).should_be("123");
    },

    'Should allow repeated partial evaulations': function() {
      var test = function(a, b, c) {
        return _.slice(arguments).join("");
      };
      
      var test_b2 = _.partial(test, undefined, 2);
      var test_b2c3 = _.partial(test_b2, undefined, 3);
      value_of(test_b2c3(1)).should_be("123");
    }
  });

  describe('Functional.unbind', {
    'Should throw if first argument is not a function': function() {
      var err = false;
      try {
        var fn = _.unbind();
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should unbind a method from an object': function() {
      var slice = _.unbind([].slice);
      var test = function() {
        return slice(arguments, 1, -1).join("");
      };
      value_of(test(1,2,3,4,5)).should_be("234");
    }
  });
});
