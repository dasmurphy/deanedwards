
base2.exec(function(_) {
  var K = _.K;
  var I = _.I;

  describe('lang.assert', {
    'Should throw if condition fails': function() {
      var err = false;
      try {
        _.assert(false);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should use provided error message': function() {
      var err = false;
      try {
        _.assert(false, "This is an error");
      } catch (ex) {
        err = ex.message == "This is an error";
      }
      value_of(err).should_be(true);
    },

    'Should use provided error class': function() {
      var err = false;
      try {
        _.assert(false, "This is an error", SyntaxError);
      } catch (ex) {
        err = ex instanceof SyntaxError;
      }
      value_of(err).should_be(true);
    }
  });

  describe('lang.assertArity', {
    'Should throw if condition fails': function() {
      var err = false;
      try {
        _.assertArity(arguments, 0);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(false);
      try {
        _.assertArity(arguments, 99);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    }
  });

  describe('lang.assertType', {
    'Should use typeof when type is string': function() {
      var err = false;
      try {
        _.assertType(new Function, "function");
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(false);
      try {
        _.assertType({}, "function");
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should use instanceof when type is function': function() {
      var err = false;
      try {
        _.assertType(new Function, Function);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(false);
      try {
        _.assertType({}, Function);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should use provided error message': function() {
      var err = false;
      try {
        _.assertType({}, Function, "This is an error");
      } catch (ex) {
        err = ex.message == "This is an error";
      }
      value_of(err).should_be(true);
    }
  });

  describe('lang.extend', {
    'Should throw if first argument is null/undefined': function() {
      var err = false;
      try {
        var fn = _.extend(null, {});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should extend objects': function() {
      value_of(_.extend({}, {a:1}).a).should_be(1);
    },

    'Should support inheritance': function() {
      value_of(_.extend({a: K(2)}, {a:function(){return this.base()}}, true).a()).should_be(2);
      value_of(_.extend({a: I}, {a:function(a){return this.base(a)}}, true).a(3)).should_be(3);
    }
  });

  describe('lang.forEach', {
    'Should NOT throw if first argument is null/undefined': function() {
      var err = false;
      try {
        var fn = _.forEach(null, function(){});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(false);
    },
    
    'Should throw if second argument is not a function': function() {
      var err = false;
      try {
        var fn = _.forEach([]);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should enumerate arrays': function() {
      var e = [1,2,3];
      
      var count = 0;
      _.forEach (e, function(v, k, o) {
        count += v;
      });
      value_of(count).should_be(6);

      var keys = "";
      _.forEach (e, function(v, k, o) {
        keys += k;
      });
      value_of(keys).should_be("012");

      var r = null;
      _.forEach (e, function(v, k, o) {
        r = o;
      });
      value_of(r).should_be(e);
    },

    'Should enumerate objects': function() {
      var e = {a:1,b:2,c:3};
      
      var count = 0;
      _.forEach (e, function(v, k, o) {
        count += v;
      });
      value_of(count).should_be(6);

      var keys = "";
      _.forEach (e, function(v, k, o) {
        keys += k;
      });
      value_of(keys).should_be("abc");
    },

    'Should enumerate collections': function() {
      var e = new _.Collection({a:1,b:2,c:3});
      
      var count = 0;
      _.forEach (e, function(v, k, o) {
        count += v;
      });
      value_of(count).should_be(6);

      var keys = "";
      _.forEach (e, function(v, k, o) {
        keys += k;
      });
      value_of(keys).should_be("abc");

      var r = null;
      _.forEach (e, function(v, k, o) {
        r = o;
      });
      value_of(r).should_be(e);
    },

    'Should enumerate node lists': function() {
      var e = document.childNodes;
      
      var count = 0;
      _.forEach (e, function(v, k, o) {
        if ("nodeType" in v) {
          count++;
        }
      });
      value_of(count).should_be(e.length);

      var r = null;
      _.forEach (e, function(v, k, o) {
        r = o;
      });
      value_of(r).should_be(e);
    },

    'Should NOT enumerate strings': function() {
      var string = "string";
      var count = 0;
      _.forEach (string, function() {
        count++;
      });
      value_of(count).should_be(0);
    },

    'Should NOT enumerate numbers': function() {
      var count = 0;
      _.forEach (6, function() {
        count++;
      });
      value_of(count).should_be(0);
    }
  });

  describe('lang.format', {
    'Should format from arguments': function() {
      value_of(_.format("{0} {1}{2} {1}a {0}{2}", "she", "se", "lls")).should_be("she sells sea shells");
    },

    'Should format from array': function() {
      value_of(_.format("{0} {1}{2} {1}a {0}{2}", ["she", "se", "lls"])).should_be("she sells sea shells");
    },

    'Should format from object': function() {
      value_of(_.format("{a} {b}{c} {b}a {a}{c}", {a:"she", b:"se", c:"lls"})).should_be("she sells sea shells");
    },

    'Should ignore missing lookups': function() {
      value_of(_.format("{a}{b}{c}", {a:"A", c:"C"})).should_be("A{b}C");
      var replacement = [];
      replacement[0] = "A";
      replacement[2] = "C";
      value_of(_.format("{0}{1}{2}", replacement)).should_be("A{1}C");
    }
  });

  describe('lang.isArray', {
    'Should detect identify Arrays': function() {
      value_of(_.isArray([])).should_be(true);
      value_of(_.isArray({length: 0})).should_be(false);
      value_of(_.isArray(null)).should_be(false);
    }
  });

  describe('lang.isFunction', {
    'Should detect identify Arrays': function() {
      value_of(_.isFunction(null)).should_be(false);
      value_of(_.isFunction({length: 0})).should_be(false);
      value_of(_.isFunction(new Function)).should_be(true);
    }
  });

  describe('lang.now', {
    'Should return the time in milliseconds': function() {
      value_of(typeof _.now()).should_be("number");
      value_of(_.now() > 0).should_be(true);
    }
  });

  describe('lang.trim', {
    'Should trim a string': function() {
      value_of(_.trim("1 ")).should_be("1");
      value_of(_.trim(" 2 ")).should_be("2");
      value_of(_.trim(" 3")).should_be("3");
    },

    'Should trim a number': function() {
      value_of(_.trim(1)).should_be("1");
    },

    'Should throw if string is null': function() {
      var err = false;
      try {
        var result = _.trim(null);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    }
  });
});
