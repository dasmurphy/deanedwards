
base2.exec(function(namespace) {

  eval(namespace);

  describe('base2.lang.bind', {
    'Should bind anonymous functions': function() {
      value_of(bind(function(){return this.a}, {a:1})()).should_be(1);
    }
  });

  describe('base2.lang.copy', {
    'Should copy objects': function() {
      var object = {a: 1};
      value_of(copy(object).a).should_be(1);
      value_of(copy(object)===object).should_not_be(true);
    }
  });

  describe('base2.lang.extend', {
    'Should extend objects': function() {
      value_of(extend({}, {a:1}).a).should_be(1);
    },

    'Should support inheritance': function() {
      value_of(extend({a: K(2)}, {a:function(){return this.base()}}).a()).should_be(2);
      value_of(extend({a: I}, {a:function(a){return this.base(a)}}).a(3)).should_be(3);
    }
  });

  describe('base2.lang.forEach', {
    'Should enumerate arrays': function() {
      var count = 0;
      forEach ([1,2,3], function() {
        count++;
      });
      value_of(count).should_be(3);
    },

    'Should enumerate objects': function() {
      var count = 0;
      forEach ({a:1,b:2,c:3}, function() {
        count++;
      });
      value_of(count).should_be(3);
    },

    'Should enumerate node lists': function() {
      var count = 0;
      forEach (document.childNodes, function() {
        count++;
      });
      value_of(count).should_be(document.childNodes.length);
    },

    'Should enumerate null': function() {
      var count = 0;
      forEach (null, function() {
        count++;
      });
      value_of(count).should_be(0);
    },

    'Should enumerate strings': function() {
      var string = "string";
      var count = 0;
      forEach (string, function() {
        count++;
      });
      value_of(count).should_be(string.length);
    }
  });

  describe('base2.lang.format', {
    'Should format strings': function() {
      value_of(format("%1 %2%3 %2a %1%3", "she", "se", "lls")).should_be("she sells sea shells");
    }
  });

  describe('base2.lang.instanceOf', {
    'Should detect instances of Function': function() {
      value_of(instanceOf("", Function)).should_be(false);
      value_of(instanceOf(Function, Function)).should_be(true);
    },

    'Should detect instances of String': function() {
      value_of(instanceOf(1, String)).should_be(false);
      value_of(instanceOf("", String)).should_be(false);
      value_of(instanceOf(new String("1"), String)).should_be(true);
    },

    'Should detect instances of Number': function() {
      value_of(instanceOf("", Number)).should_be(false);
      value_of(instanceOf(6, Number)).should_be(false);
      value_of(instanceOf(new Number(6), Number)).should_be(true);
    },

    'Should detect instances of RegExp': function() {
      value_of(instanceOf("", RegExp)).should_be(false);
      value_of(instanceOf(/./, RegExp)).should_be(true);
    },

    'Should detect instances of Object': function() {
      value_of(instanceOf(null, Object)).should_be(false);
      value_of(instanceOf({}, Object)).should_be(true);
    },

    'Should detect instances of Base': function() {
      value_of(instanceOf({}, base2.Base)).should_be(false);
      value_of(instanceOf(new base2.Base, base2.Base)).should_be(true);
      value_of(instanceOf(base2.Base.prototype, base2.Base)).should_be(false);
      value_of(instanceOf(base2, base2.Base)).should_be(true);
    },

    'Should detect instances of Array': function() {
      value_of(instanceOf(document, Array)).should_be(false);
      value_of(instanceOf(document.childNodes, Array)).should_be(false);
      value_of(instanceOf([], Array)).should_be(true);
    }
  });

  describe('base2.lang.pcopy', {
    'Should make a copy of an object by using the object as its prototype': function() {
      var object = {a: 1};
      value_of(pcopy(object).a).should_be(1);
      value_of(pcopy(object) === object).should_not_be(true);
      var object2 = pcopy(object);
      object.a = 2;
      object.b = 3;
      value_of(object2.a).should_be(2);
      value_of(object2.b).should_be(3);
    }
  });

  describe('base2.lang.rescape', {
    'Should escape a string': function() {
      value_of(rescape("[{.}]")).should_be("\\[\\{\\.\\}\\]");
    },

    'Should escape null': function() {
      value_of(rescape(null)).should_be("null");
    }
  });

  describe('base2.lang.trim', {
    'Should trim a string': function() {
      value_of(trim("1 ")).should_be("1");
      value_of(trim(" 2 ")).should_be("2");
      value_of(trim(" 3")).should_be("3");
    },

    'Should trim a number': function() {
      value_of(trim(1)).should_be("1");
    },

    'Should trim null': function() {
      value_of(trim(null)).should_be("null");
    }
  });

  describe('base2.lang.typeOf', {
    'Should detect "undefined"': function() {
      value_of(typeOf(undefined)).should_be("undefined");
      value_of(typeOf()).should_be("undefined");
    },

    'Should detect "boolean"': function() {
      value_of(typeOf(new Boolean)).should_be("boolean");
      value_of(typeOf(true)).should_be("boolean");
      value_of(typeOf(false)).should_be("boolean");
    },

    'Should detect "string"': function() {
      value_of(typeOf("")).should_be("string");
      value_of(typeOf(new String)).should_be("string");
    },

    'Should detect "number"': function() {
      value_of(typeOf(new Number)).should_be("number");
      value_of(typeOf(0)).should_be("number");
      value_of(typeOf(6)).should_be("number");
      value_of(typeOf(NaN)).should_be("number");
      value_of(typeOf(Infinity)).should_be("number");
    },

    'Should detect "null"': function() {
      value_of(typeOf(null)).should_be("null");
    },

    'Should detect "object"': function() {
      value_of(typeOf({})).should_be("object");
      value_of(typeOf(/./)).should_be("object");
      value_of(typeOf([])).should_be("object");
      value_of(typeOf(new Date)).should_be("object");
      value_of(typeOf(document)).should_be("object");
    },

    'Should detect "function"': function() {
      value_of(typeOf(Function)).should_be("function");
      value_of(typeOf(new Function)).should_be("function");
      value_of(typeOf(isNaN)).should_be("function");
      value_of(typeOf(document.createElement)).should_be("function");
    }
  });

});