
describe('base2', {
  'Should be defined ;)': function() {
    value_of(typeof base2).should_be("object");
  },

  'Should have "lang" package': function() {
    value_of(base2.lang).should_not_be(undefined);
  },

  'Should have a "namespace" property': function() {
    value_of(typeof base2.namespace).should_be("string");
    value_of(typeof Base).should_not_be("function");
    eval(base2.namespace);
    value_of(typeof Base).should_be("function");
  }
});

describe('base2.assignID', {

  'Should assign "base2ID" to objects': function() {
    var object = {};
    base2.assignID(object);
    value_of(object.base2ID).should_not_be(undefined);
  },

  'Should assign "uniqueID" to elements': function() {
    var element = document.createElement("span");
    base2.assignID(element);
    value_of(element.uniqueID).should_not_be(undefined);
  },

  'IDs should be unique': function() {
    value_of(base2.assignID({})).should_not_be(base2.assignID({}));
  },

  'Should allow named IDs': function() {
    var object = {};
    base2.assignID(object, "myID");
    value_of(object.myID).should_not_be(undefined);
  }
  
});

describe('base2.detect', {
  'Should detect objects': function() {
    value_of(base2.detect("(Array)")).should_be(true);
    value_of(base2.detect("(DOES_NOT_EXIST)")).should_be(false);
    value_of(base2.detect("(document)")).should_be(true);
    value_of(base2.detect("(element)")).should_be(true);
    value_of(base2.detect("(element.className)")).should_be(true);
    value_of(base2.detect("(element.DOES_NOT_EXIST)")).should_be(false);
    value_of(base2.detect("(style)")).should_be(true);
    value_of(base2.detect("(style.color)")).should_be(true);
    value_of(base2.detect("(style.DOES_NOT_EXIST)")).should_be(false);
  },

  'Should detect browser platforms': function() {
    value_of(base2.detect("Win|Mac|Linux")).should_be(true);
  }
});
