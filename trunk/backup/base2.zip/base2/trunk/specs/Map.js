
base2.exec(function(namespace) {
  eval(namespace);
  
  var map;

  describe('Map', {

    "Should construct from object": function() {
      map = new Map({
        a: {name: "a", value: 1},
        b: {name: "b", value: 2},
        c: {name: "c", value: 3},
        d: {name: "d", value: 4}
      });
      value_of(map instanceof Map).should_be(true);
    },

    "Should support has()": function() {
      value_of(map.has("a")).should_be(true);
      value_of(map.has("e")).should_be(false);
    },

    "Should support get()": function() {
      value_of(map.get("a").value).should_be(1);
      value_of(typeof map.get("e")).should_be("undefined");
    },

    "Should support put()": function() {
      map.put("e", {name: "e", value: 5});
      value_of(map.has("e")).should_be(true);
    },

    "Should support remove()": function() {
      map.remove("e");
      value_of(map.has("e")).should_be(false);
    },

    "Should support size()": function() {
      value_of(map.size()).should_be(4);
    },

    "Should support getKeys()": function() {
      var keys = map.getKeys();
      value_of(keys instanceof Array).should_be(true);
      value_of(keys.join("")).should_be("abcd");
    },

    "Should support getValues()": function() {
      var values = map.getValues();
      value_of(values instanceof Array).should_be(true);
      value_of(values[1].name).should_be("b");
    },

    "Should support forEach()": function() {
      var text = "";
      map.forEach(function(item) {
        text += item.name;
      });
      value_of(text).should_be("abcd");
    },

    "Should support map()": function() {
      var result = map.map(function(item) {
        return item.name;
      });
      value_of(result instanceof Map).should_be(true);
      var text = result.getValues().join("");
      value_of(text).should_be("abcd");
    },

    "Should support filter()": function() {
      var result = map.filter(function(item) {
        return item.name != "b";
      });
      value_of(result instanceof Map).should_be(true);
      value_of(result.size()).should_be(3);
    },

    "Should support pluck()": function() {
      var text = map.pluck("name").join("");
      value_of(text).should_be("abcd");
    },

    "Should support every()": function() {
      value_of(map.every(function(item) {
        return typeof item.value == "number";
      })).should_be(true);

      value_of(map.every(function(item) {
        return item.value % 2 == 0;
      })).should_be(false);
    },

    "Should support some()": function() {
      value_of(map.some(function(item) {
        return item.value % 2 == 0;
      })).should_be(true);

      value_of(map.some(function(item) {
        return typeof item.value == "string";
      })).should_be(false);
    }

  });

});