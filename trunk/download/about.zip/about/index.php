<?php
header('Expires: ' . gmdate('D, d M Y H:i:s') . ' GMT');
header('Cache-Control: no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$phrases = array(
    "is left to wonder",
    "is pondering",
    "wants to know",
    "is curious to find out"
);

// write the question to a separate HTML file
$question = stripslashes($_POST["question"]);
if ($question == "?") $question = "";
if ($question) {
    $author = ($_POST["name"]) ? $_POST["name"] : "Curious Coward";
    $filename = "questions.html";
    // build the message
    if ($questions = fopen($filename, "a+t")) {
    	$QA = fread($questions, filesize($filename));
    	$id = preg_match_all("/class=\"qa\"/", $QA, $match) + 1;
        // add the entry
        $cite = "<cite>".$author."</cite>";
        if ($_POST["url"]) $cite = "<a href=\"".$_POST["url"]."\">".$cite."</a>";
        $html =
            "<li class=\"qa\" id=\"q".$id."\">\n".
            " <p class=\"author\">".$cite." ".$phrases[time() % count($phrases)].":</p>\n".
            " <p class=\"question\">".htmlspecialchars($question)."</p>\n".
            " <p class=\"answer\"></p>\n".
            "</li>\n";
        fwrite($questions, $html);
        fclose($questions);
    }
    // send yourself an email
    $contents = "Question: ".$question."\n";
    if ($_POST["email"]) $contents .= "From: ".$author." <".$_POST["email"].">\n";
    if ($_POST["url"]) $contents .= "Web Site: ".stripslashes($_POST["url"])."\n";
    @mail("self@example.com", "New question on 'About' page", $contents, "From: about@example.com");
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
 <title>About Me</title>
 <meta name="description" content="About Me. Questions and answers."/>
 <style type="text/css">
  cite {color: black; font-style: normal;}
  #questions {list-style-type: none; padding: 0; margin: 0;}
  li.qa {margin: 2em 0;}
  p.author {font-size: 0.67em; color: #898E79; margin: 1em 0 0.33em 0;}
  p.author :link cite {color: #0000EE;}
  p.author :visited cite {color: #551A86;}
  p.question {font-size: 1em; font-weight: bold; margin: 0;}
  p.answer {margin: 0.5em 1em;}
  p.alert {color: red;}
 </style>
</head>

<body id="about-page">
<?php if ($question) { ?>
 <p>Thanks for your question. I&#8217;ll answer it as soon I can.</p>
<?php } else if (count($_POST)) { ?>
 <p class="alert">You did not ask anything.</p>
<?php } else { ?>
<p>If you want to know something about me then you can <a href="#ask">ask a question</a>.</p>
<?php } ?>
<hr class="short"/>
<ol id="questions">
<?php include("questions.html"); ?>
</ol>
<h2 id="ask">Feeling Nosy?</h2>
<form action="index.php" method="post">
 <fieldset class="input">
  <p class="input"><label for="question">Question:</label>
   <input class="required" id="question" type="text" name="question" value="?"/><sup>required</sup></p>
  <p class="input"><label for="name">Name:</label>
   <input id="name" type="text" name="name"/></p>
  <p class="input"><label for="email">Email:</label>
   <input id="email" type="text" name="email"/></p>
  <p class="input"><label for="url"><abbr title="Uniform Resource Identifier">URI</abbr>:</label>
   <input id="url" type="text" name="url"/></p>
 </fieldset>
 <fieldset class="buttons">
  <input type="submit" value="Submit"/>
  <input type="reset" value="Reset"/>
 </fieldset>
</form>
</body>
</html>
