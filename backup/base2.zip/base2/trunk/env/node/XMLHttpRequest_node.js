
var URL = require("url");
var http = require("http");
var http2 = require("https");

function XMLHttpRequest() {
};

XMLHttpRequest.prototype = {
  readyState: 0,
  responseText: "",
  responseXML: null,
  status: 0,

  open: function open(method, url, async, user, password) {
    url = URL.parse(url);

    this._isSSL = url.protocol == "https";
    
    this._requestHeaders = {
  		"User-Agent": "node.js",
  		"Accept": "*/*",
    };
    this._options = {
      host: url.hostname,
      port: url.port || (this._isSSL ? 443 : 80),
      path: url.pathname + url.search,
      method: method,
      headers: this._requestHeaders
    };

    this.readyState = 1;
    this.onreadystatechange();
  },

  setRequestHeader: function setRequestHeader(header, value) {
    this._requestHeaders[header] = value;
  },

  send: function send(data) {
    var self = this;
    
    var protocol = this._isSSL ? https ? http;

    this._request = protocol.request(this._options, function(response) {
      self.readyState = 2;
      self.status = response.statusCode;
      self._responseHeaders = response.headers;

      response.on("data", function(chunk) {
        self.responseText += chunk;
        if (self.readyState === 2) {
          self.readyState = 3;
          self.onreadystatechange();
        }
      });

      response.on("end", function() {
        self.readyState = 4;
        self.onreadystatechange();
      });

      self.onreadystatechange();
    });

    this._request.on("error", function(error) {
      self.onerror(error);
    });

		if (data) {
			this._request.write(data);
		}

    this._request.end();
  },

  abort: function abort() {
    if (this._request) {
      this._request.end();
    }
		this.readyState = 0;
		this.responseText = "";
		this.responseXML = null;
  },

  getResponseHeader: function getResponseHeader(header) {
    header = header.toLowerCase();
    return header in this._responseHeaders ? this._responseHeaders[header] : null;
  },

  getAllResponseHeaders: function getAllResponseHeaders() {
		var headers = [];
		for (var header in this._responseHeaders) {
			headers.push(header + ": " + this._responseHeaders[header]);
		}
		return headers.join("\r\n");
  },

  onerror: function(error){},
  onreadystatechange: function(){}
};

exports.XMLHttpRequest = XMLHttpRequest;
