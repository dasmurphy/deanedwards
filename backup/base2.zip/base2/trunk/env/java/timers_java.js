
// setTimeout etc for java

(function(global) {
  global.clearInterval = function clearInterval(id) {
  	destroyTimer(id);
  };

  global.clearTimeout = function clearTimeout(id) {
  	destroyTimer(id);
  };

  global.setInterval = function setInterval(fn, interval) {
    if (arguments.length > 2) {
      fn = fn.bind(undefined, [].slice.call(arguments, 2));
    }
  	return createTimer(fn, interval, true);
  };

  global.setTimeout = function setTimeout(fn, interval) {
    if (arguments.length > 2) {
      fn = fn.bind(undefined, [].slice.call(arguments, 2));
    }
  	return createTimer(fn, interval);
  };

  var timers = {}
  var timer_id = 1337;

  function destroyTimer(id) {
  	if (timers[id]) {
  		timers[id].stop();
  		delete timers[id];
  	}
  };

  function createTimer(fn, interval, repeat) {
    var id = timer_id++;
  	var timer = new java.lang.Thread(new java.lang.Runnable({
  		run: function() {
  			do {
  				java.lang.Thread.currentThread().sleep(interval);
  				if (timers[id]) fn();
  				if (!repeat) destroyTimer(id);
  			} while (timers[id]);
  		}
  	}));
  	timers[id] = timer;
    timer.start();
  	return id;
  };
})((function(){return this||(1,eval)("this")})());
