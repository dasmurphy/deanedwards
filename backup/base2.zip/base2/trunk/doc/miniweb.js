/*
  base2.js (c) 2007-2012, Dean Edwards
  Home: http://code.google.com/p/base2/
  License: http://mit-license.org/
*/

// timestamp: Mon, 22 Oct 2012 02:36:33

var MiniWeb;

base2.require("base2.dom,base2.jst,base2.io,JSON,base2.EventTarget", function(_, dom, jst, io, JSON, EventTarget) { // begin: closure

"use strict";

var _private = _._;
var forEach  = _.forEach;

var WILD_CARD      = /\*$/;
var TRIM_PATH      = /[^\/]+$/;
var SPACE          = /\s+/;

var DOCTYPE = '<!doctype html>';

var INTERNAL_SCRIPT = '<script>\n{0}\n<\/script>';
var EXTERNAL_SCRIPT = '<script src="{0}"><\/script>';

var HTML_ESCAPE = new _.RegGrp([
  "&", "&amp;",
  "<", "&lt;",
  ">", "&gt;"
]);

var INVALID_STATE = "Invalid state.";

var URL = _private.get(window, "URL");
var Blob = _private.get(window, "Blob");

var SUPPORTS_DOWNLOAD = URL && Blob && _.detect("(<a>.download)");

function flatten(array) {
  var i = 0;
  var flattener = function _flattener(result, item) {
    if (_.isArray(item)) {
      _.reduce(item, flattener, result);
    } else {
      result[i++] = item;
    }
    return result;
  };
  return _.reduce(array, flattener, []);
}

function jsonCopy(data) {
  return JSON.parse(JSON.stringify(data))
}

function download(html, name) {
  var defaultName = MiniWeb.doc ? "base2.html" : "miniweb.html";
  var pathname = location.pathname.slice(location.pathname.lastIndexOf("/") + 1);
  var blob = new Blob([html], {"type" : "text/plain"});
  var fragment = document.createDocumentFragment();
  var downloader = document.createElement("a");
	downloader.href = URL.createObjectURL(blob);
	downloader.download = name || pathname || defaultName;
  fragment.appendChild(downloader);
	downloader.click();
}

// =========================================================================
// MiniWeb/Client.js
// =========================================================================

// The client object wraps an <iframe> that contains the rendered page

var Client = _.Base.extend({
  constructor: function() {
    var client = this;

    this.history = new History(function() { // callback
      var address = location.hash.slice(1);
      client.send("GET", address);
      client.address = address;
      client.refresh();
    });
    
    // the url of the hosting page
    this.host = location.href.slice(0, -location.hash.length);
    
    this.view = document.createElement("iframe");
    this.view.style.display = "none";
    document.body.appendChild(this.view);

    var client = this;
    MiniWeb.addEventListener("saved", function() {
      var saveButtons = dom.findAll(client.window.document, ".mw-dirty");
      _.forEach(saveButtons, function(saveButton) {
        dom.classList.remove(saveButton, "mw-dirty");
      });
      this.dirty = false;
    });
  },
  
  address: "",
  history: null,
  host: "",
  response: null,
  view: null,
  window: null,
  
  fixForm: function(form) {
    // intercept form submissions
    form.onsubmit = Client.onsubmit;
  },

  fixLinks: function(document) {
    forEach (document.links, this.fixLink, this);
  },
  
  fixLink: function(link) {
    // stylise links - add classes for visited etc
    var href = link.getAttribute("href");
    // extract the hash portion and create a path
    href = String(href || "").replace(this.host, "");
    if (/^#[^\/]/.test(href)) {
      var hash = location.hash.replace(/^#(.*!)?/, "");
      href = "#" + hash.replace(/[^\/]+$/, "") + href.slice(1);
    }
    if (/^#/.test(href)) {
      link.setAttribute("href", href);
      if (this.history.visited[href] && !/(^|\s)mw\-visited(\s|$)/.test(link.className)) {
        link.className += " mw-visited";
      }
      link.onclick = Client.onclick;
    }
    if (!/^javascript/i.test(href)) {
      link.target = "_parent";
    }
  },
  
  fixStyle: function(style) {
    style.textContent = style.textContent.replace(/:(visited)/g, ".mw-$1");
  },
  
  navigateTo: function(url) {
    // load a new page
    var hash = /^#/.test(url) ? url.slice(1) : url;
    if (this.address !== hash) {
      var request = new Request("HEAD", hash);
      if (request.status == 301) {
        hash = request.getResponseHeader("Location");
      }
      this.history.add("#" + hash);
    }
  },

  refresh: function() {
    // refresh the current page from the last response
    
    // insert a script
    var script = "parent.MiniWeb.register(this);";
    script = _.format(INTERNAL_SCRIPT, script);
    var html = this.response.replace(/(<head[^>]*>)/i, function(match) {
      return match + script;
    });
    // create an iframe to display the page
    var iframe = document.createElement(Client.$IFRAME);
    iframe.frameBorder = "0";
    iframe.id = "window";
    document.body.replaceChild(iframe, this.view);
    document.body.scrollTop = 0;
    this.view = iframe;
    
    var client = this;
    // write the html
    var doc = iframe.contentDocument || iframe.contentWindow.document;
    doc.open();
    doc.write(html);
    doc.close();

    // fix the page
    client.fixLinks(doc);
    forEach (doc.getElementsByTagName("style"), client.fixStyle, client);
    forEach (doc.forms, client.fixForm, client);

    // keep the browser title in sync
    var title = doc.title;
    if (!title) {
      var h1 = doc.getElementsByTagName("h1")[0];
      if (h1) title = dom.get(h1, "textContent");
    }
    document.title = title || "MiniWeb";
  },
  
  register: function(window) {
    this.window = window;
    window.base2 = base2;
    window.MiniWeb = MiniWeb;
    window.doc = MiniWeb.doc;
    base2.require("base2.dom", function(_, dom) {
      for (var i in _) if (/^([a-z]\w+)$/i.test(i) && i !== "getComputedStyle") window[i] = _[i]; // -@DRE
      window.dom = dom;
    });
  },
  
  reload: function() {
    // reload the current page
    this.send("GET", this.address);
    this.refresh();
  },
  
  send: function(method, url, data, headers) {
    this.response = new Request(method, url, data, headers).responseText;
  },
  
  submit: function(form) {
    // post form data
    var successful = _.filter(form.elements, function(element) {
      if (!element.name || element.disabled) return false;
      
      switch (element.type) {
        case "radio":
        case "checkbox":
          return element.checked;

        case "button":
        case "reset":
          return false;
          
        case "image":
        case "submit":
          return element = form.ownerDocument.activeElement;

        default:
          return true;
      }
    });

    var data = _.map(successful, function(element) {
      return element.name + "=" + encodeURIComponent(element.value);
    }).join("&");
    
    this.send("POST", form.action || this.address, data);
    this.refresh();
  },

  "@MSIE[678]": {
    fixStyle: function(style) {
      style = style.styleSheet;
      style.cssText = style.cssText.replace(/:visited/g, ".mw-visited");
    },
    
    "@MSIE[67]": {
      refresh: function() {
        // IE needs a kick up the butt
        //  this will cause the unload event to fire in the iframe
        this.view.contentWindow.document.write();
        this.base();
      }
    }
  }
}, {
  $IFRAME: "iframe",

  onclick: function() {
    var href = this.getAttribute("href", 2);
    if (href && !/^\w+:/.test(href) ) {
      if (!/current/.test(this.className)) {
        MiniWeb.navigateTo(href);
      }
      return false;
    }
    return true;
  },
  
  onsubmit: function() {
    MiniWeb.submit(this);
    return false;
  },

  "@MSIE[678]": {
    $IFRAME: "<iframe scrolling=yes>"
  }
});

// =========================================================================
// MiniWeb/History.js
// =========================================================================

// Manage back/forward buttons

var History = _.Base.extend({
  constructor: function(callback) {
    this.visited = {};

    var hash;
    if ("onhashchange" in window && !_.detect("MSIE7")) {
      window.onhashchange = onhashchange;
      setTimeout(onhashchange, 20); // kick-start
    } else {
      this.timer = setInterval(onhashchange, 20);
    }

    function onhashchange() {
      if (hash !== location.hash) {
        hash = location.hash;
        callback();
      }
    };

    this.add(location.hash || ("#" + (document.title.slice(9) || "/")));
  },

  timer: 0,
  visited: null,

  add: function(hash) {
    if (location.hash !== hash) {
      location.hash = hash;
    }
    this.visited[hash] = true;
  }
});

// the hash portion of the location needs to be set for history to work properly
// -- we need to do it before the page has loaded
if (!location.hash) location.replace("#" + (document.title.slice(9) || "/"));

if (_.detect("MSIE[67]")) {
  document.write("<iframe style=display:none></iframe>");
  writeHistoryToIFrame(location.hash.slice(1)); // make sure it's unique the first time
  _.extend(History.prototype, "add", function(hash) {
    writeHistoryToIFrame(hash);
    this.base(hash);
  });
}

function writeHistoryToIFrame(hash) {
  if (hash !== location.hash) {
    var document = frames[0].document;
    document.open();
    document.write("<script>parent.location.hash='" + hash + "'<\/script>");
    document.close();
  }
}

// =========================================================================
// MiniWeb/Server.js
// =========================================================================

// The Server object responds to client requests

var Server = _.Base.extend({
  constructor: function() {
    this.io = new FileSystem;
  },

  io: null,

  interpret: function(request) {
    var interpreter = new Interpreter(request);
    //try {
      return interpreter.interpret();
    //} catch (error) {
    //  request.command = jsonCopy(interpreter);
    //  throw error;
    //}
  },

  respond: function(request, data) {
    // repsond to a client request
    //try {
      request.status = 202; // Accepted
      request.readyState = 3; // Receiving
      request.headers["Server"] = String(MiniWeb);
      if (typeof Server[request.method] == "function") {
        // use static methods to resolve the request method
        Server[request.method](this, request, data);
      } else {
        request.status = 405; // Method Not Allowed
      }
    //} catch (error) {
    //  request.error = error;
    //  request.status = 500; // Internal Server Error
    //} finally {
      if (request.method !== "HEAD" && request.status > 299) { // return an error page
        request.responseText = this.interpret(request);
      }
      request.readyState = 4; // Loaded
    //}
  }
}, {
  GET: function(server, request) {
    // get header info, really just makes sure the file exists
    this.HEAD(server, request);
    if (request.status == 200) { // file exists
      switch (request.headers["Content-Type"]) {
        case "text/plain":
          request.responseText = server.io.read(request.url);
          break;
        default:
          request.responseText = server.interpret(request);
      }
    }
  },

  HEAD: function(server, request) {
    var url = request.url.replace(/!.*$/, "");
    if (server.io.exists(url)) {
      var DIR = /\/$/;
      if (server.io.isDirectory(url) && !DIR.test(url)) {
        request.headers["Location"] = url + "/";
        request.status = 301; // Moved Permanently
      } else {
        request.status = 200; // OK
      }
    } else {
      request.status = 404; // Not Found
    }
  },

  OPTIONS: function(server, request) {
    request.headers["Allow"] = "OPTIONS,HEAD,GET,POST,PUT,DELETE";
    request.status = 200; // OK
  },

  PUT: function(server, request, data) {
    request.responseText = server.io.write(request.url, data);
    // not sure what to return here
    request.status = 200; // OK
  },

  DELETE: function(server, request) {
    this.HEAD(server, request);
    // not sure what to return here
    if (request.status == 200) {
      request.reponseText = server.io.remove(request.url);
    }
  },

  POST: function(server, request, data) {
    // build a simple object containing post data
    forEach (data.split("&"), function(data) {
      data = data.split("=");
      request.post[data[0]] = decodeURIComponent(data[1]);
    });
    // same as GET apart from post data
    this.GET(server, request);
  }
});

// =========================================================================
// MiniWeb/Request.js
// =========================================================================

// We are basically mimicking the XMLHttpRequest object

var Request = _.Base.extend({
  constructor: function(method, url, data, headers) {
    this.headers = {};
    this.post = {};
    // allow quick open+send from the constructor if arguments are supplied
    if (arguments.length > 0) {
      this.open(method, url);
      for (var name in headers) {
        this.setRequestHeader(name, headers[name]);
      }
      this.send(data);
    }
  },

  headers: null,
  readyState: 0,
  status: 0,
//statusText: "",  // don't bother with this one
  method: "",
  responseText: "",
  post: null,
  url: "",

  open: function(method, url) {
    _.assert(this.readyState === 0, INVALID_STATE);
    this.readyState = 1;
    this.method = method;
    this.url = url;
  },

  send: function(data) {
    _.assert(this.readyState === 1, INVALID_STATE);
    this.readyState = 2;
    MiniWeb.send(this, data);
  },

  // there is no distinction between request/response headers at the moment

  getResponseHeader: function(header) {
    _.assert(this.readyState >= 3, INVALID_STATE);
    return this.headers[header];
  },

  setRequestHeader: function(header, value) {
    _.assert(this.readyState === 1, INVALID_STATE);
    this.headers[header] = value;
  }
});

// =========================================================================
// MiniWeb/JSONFileSystem.js
// =========================================================================

var CR = /\r/g;
var FETCH = "";

var JSONFileSystem = io.FileSystem.extend({
  constructor: function JSONFileSystem__constructor(data) {
    this[FETCH] = function(path) {
      // fetch data from the JSON object, regardless of type
      path = this.makepath(path);
      return _.reduce(path.split("/"), function(file, name) {
        if (file && name) file = name in file ? file[name] : undefined; // code looks silly but stops warnings being generated in Firebug
        return file;
      }, data);
    };
  },
  
  exists: function JSONFileSystem__exists(path) {
    return typeof this[FETCH](path) != "undefined";
  },
  
  isFile: function JSONFileSystem__isFile(path) {
    return typeof this[FETCH](path) == "string";
  },
  
  isDirectory: function JSONFileSystem__isDirectory(path) {
    return typeof this[FETCH](path) == "object";
  },

  copy: function JSONFileSystem__copy(path1, path2) {
    var data = this[FETCH](path1);
    this.write(path2, JSON.parse(JSON.stringify(data)));
  },
  
  mkdir: function JSONFileSystem__mkdir(path) {
    // Create a directory.
    this.write(path, {});
  },
  
  move: function JSONFileSystem__move(path1, path2) {
    var data = this[FETCH](path1);
    this.write(path2, data);
    this.remove(path1);
  },

  read: function JSONFileSystem__read(path) {
    // Read text from the JSON object.
    var file = this[FETCH](path);
    return typeof file == "object" ? new JSONDirectory(file) : file || ""; // make read safe
  },
  
  remove: function JSONFileSystem__remove(path) {
    // Remove data from the JSON object.
    path = path.replace(/\/$/, "").split("/");
    var filename = path.splice(path.length - 1, 1);
    var directory = this[FETCH](path.join("/"));
    if (directory) delete directory[filename];
  },

  write: function JSONFileSystem__write(path, data) {
    // Write data to the JSON object.
    path = path.split("/");
    var filename = path.splice(path.length - 1, 1);
    var directory = this[FETCH](path.join("/"));
    if (!directory) {
      throw new ReferenceError("Directory not found.");
    }
    if (typeof data == "string") {
      data = data.replace(CR, "")
    }
    return directory[filename] = data || "";
  }
});

// =========================================================================
// MiniWeb/JSONDirectory.js
// =========================================================================

var JSONDirectory = io.Directory.extend({
  createKey: function JSONDirectory__createKey(name) {
    return _.trim(name);
  },

  set: function JSONDirectory__set(name, item) {
    name = this.createKey(name);
    if (name !== "" && name !== JSONDirectory.HIDDEN) {
      this.base(name, item);
    }
  }
}, {
  HIDDEN: "__JSONDirectory_hidden_file__",

  Item: {
    constructor: function JSONDirectory_Item__constructor(name, item) {
      this.name = String(name);
      this.isDirectory = typeof item == "object";
      this.size = this.isDirectory ? 0 : item.length || 0;
    }
  }
});

// =========================================================================
// MiniWeb/FileSystem.js
// =========================================================================

// This class wraps the various file retrieval systems.
// So far they are:
//   JSON (json:)
//   Local file system (file:)

var FileSystem = JSONFileSystem.extend({
  constructor: function() {
    this.base(MiniWeb.$$);
  },

  remove: function(path) {
    MiniWeb.dirty = true;
    return this.base(path);
  },

  write: function(path, data) {
    MiniWeb.dirty = true;
    return this.base(path, data);
  },

  protocol: "json:"
});

// =========================================================================
// MiniWeb/Command.js
// =========================================================================

// This is the base command object for the MiniWeb interpreter.
//  This object effectively defines the templating language.
//  It extends FileSystem so has inherent commands for IO.

var STDIN    = 0;
var STDOUT   = 1;
var STDERR   = 2;
var INCLUDES = 3;

var Command = FileSystem.extend({
  constructor: function() {
    this.base();
    var command = this;
    var interpreter = new jst.Interpreter(this);
    this[INCLUDES] = {};
    this.exec = function(template, target) {
      var result = "";
      var dir = template.replace(TRIM_PATH, "");
      if (command.isDirectory(dir)) {
        if (!command.top) {
          command.top =
          command.parent = this.makepath(template);
        } else {
          command.parent = command.self;
        }
        var path = command.path;
        var restore = command.target;
        command.self = this.makepath(template);
        command.chdir(dir);
        command.target = target || "";
        result = interpreter.interpret(this.read(template));
        command.target = restore;
        command.path = path;
        command.self = command.parent;
      }
      return result;
    };
  },

  parent: "",
  self: "",
  target: "",
  top: "",

  args: function(names) {
    // define template arguments in the current scope
    var args = this.target.split(SPACE);
    forEach.csv(names, function(name, index) {
      if (name) this[name] = args[index];
    }, this);
    return args;
  },

  escapeHTML: function(string) {
    return HTML_ESCAPE.parse(string);
  },

  exec: _.Undefined, // defined in the constructor function

  include: function(template) {
    this.echo(this.exec(template, this.target));
  },

  include_once: function(template) {
    var path = this.makepath(template);
    if (!this[INCLUDES][path]) {
      this[INCLUDES][path] = true;
      this.include(template);
    }
  },

  process: function(template, target) {
    if (WILD_CARD.test(target)) { // process everything in the current directory
      var path = target.replace(WILD_CARD, "") || this.path;
      var directory = this.read(path);
      forEach (directory, function(item, target) {
        if (!item.isDirectory) {
          this.process(template, target);
        }
      }, this);
    } else {
      this.echo(this.exec(template, target));
    }
    // process remaining arguments
    forEach (_.slice(arguments, 2), function(target) {
      this.process(template, target);
    }, this);
  }
});

// =========================================================================
// MiniWeb/Interpreter.js
// =========================================================================

// This object gets between the server and the file system to manage the
//  returned content.
// The interpreter also provides access to to a copy of the request object
//  and its post data.

var Interpreter = Command.extend({
  constructor: function(request) {
    this.base();
    this.request = _private.pcopy(request);
  },

  query: "",
  request: null,

  include_script: function(template) {
    var path = this.makepath(template);
    if (!this[INCLUDES][path] && !Interpreter.SYSTEM.test(this.top)) {
      this.echo("<script>\n");
      this.include_once(template);
      this.echo("\n<\/script>\n");
    }
  },

  include_style: function(template) {
    var path = this.makepath(template);
    if (!this[INCLUDES][path] && !Interpreter.SYSTEM.test(this.top)) {
      this.echo("<style>\n");
      this.include_once(template);
      this.echo("\n<\/style>\n");
    }
  },

  interpret: function() {
    var url = this.request.url;
    var template = Interpreter.VIEW;
    var status = this.request.status;

    if (status > 299) { // return an error page
      target = Interpreter.ERROR + (Interpreter.ERROR_PAGES[status] || Interpreter.DEFAULT);
    } else {
      if (url.indexOf("!") !== -1) { // it's a query
        var parts = url.split("!");
        url = parts[0];
        this.query = parts[1];
      }
      var target = url;
      // find a template
      var path = url.split("/");
      do {
        path.pop();
        template = path.join("/") + Interpreter.VIEW;
      } while (path.length && !this.exists(template));
      if (this.isDirectory(target) && this.exists(target + Interpreter.DEFAULT)) {
        target += Interpreter.DEFAULT;
      }
    }
    return this.exec(template, target);
  }
}, {
  DEFAULT:   "default",
  SYSTEM:    /^\/system\/(create|edit|view)$/,
  VIEW:      "/system/view",
  ERROR:     "/system/Error/",
  ERROR_PAGES: {
    "301": "Moved_Permanently",
    "404": "Not_Found",
    "405": "Method_Not_Allowed",
    "500": "Internal_Server_Error"
  }
});

// =========================================================================
// MiniWeb/Terminal.js
// =========================================================================

// It didn't start off that way but this is becoming more like the UNIX shell
//  (which I know very little about)

var STATE = 0;

var Terminal = Command.extend({
  constructor: function() {
    this.base();
    _.extend(this, "exec", function() {
      try {
        return this.base.apply(this, arguments);
      } catch (error) {
        return String(error.message || error);
      }
    });
    this[STATE] = {
     commands: [],
     output:   "<pre>MiniWeb 0.8.1</pre><br>",
     path:     "/",
     position: 0,
     protocol: "json:"
    };
  },

  path: "/",
  protocol: "json:"
});

// =========================================================================
// MiniWeb/package.js
// =========================================================================
/*
  MiniWeb - copyright 2007-2011, Dean Edwards
  License: http://mit-license.org/
*/

// An active document thing

window.MiniWeb = new _.Package({
  name:    "MiniWeb",
  version: "0.8.1",
  
  $$: {data: {}},
  
  client: null,
  dirty: false,
  readOnly: true,
  server: null,
  terminal: null,
  
  register: function(window) {
    this.client.register(window);
  },
  
  resolve: function(path, filename) {
    return io.FileSystem.resolve(path, filename);
  },
  
  save: function(name) {
    if (this.readOnly && !SUPPORTS_DOWNLOAD) {
      alert(
        location.protocol == "file:"
        ?
          "Your browser does not support local file access.\n" +
          "Use Internet Explorer or Firefox instead."
        :
          "You cannot save your changes over HTTP.\n" +
          "Instead, save this page to your hard disk.\n" +
          "If you edit the local version you will then\n" +
          "be able to save your changes."
      );
      return false;
    }

    // update the revision number of the document
    var REVISION = "/system/About/revision";
    var io = this.server.io;
    var revision = parseInt(io.read(REVISION), 10);
    io.write(REVISION, String(++revision));

    // collect external scripts
    var scripts = [];
    forEach (document.getElementsByTagName("script"), function(script) {
      if (script.src) {
        scripts.push(_.format(EXTERNAL_SCRIPT, HTML_ESCAPE.parse(script.getAttribute("src", 2))));
      }
    });

    forEach (this.$$, function(value, name) {
      if (name !== "data") {
        var entry = "MiniWeb.$$." + name + "=" + JSON.stringify(value).replace(/<\//g, "<\\/");
        scripts.push(_.format(INTERNAL_SCRIPT, entry));
      }
    }, this);
    
    var data = [];
    forEach (this.$$.data, function(value, name) {
      var entry = "MiniWeb.$$.data." + name + "=" + JSON.stringify(value).replace(/<\//g, "<\\/");
      data.push(_.format(INTERNAL_SCRIPT, entry));
    }, this);
    
    // it's mostly script :-)
    var html = flatten([
      DOCTYPE,
      '<meta charset="utf-8">',
      "<title>MiniWeb: " + this.client.address + "<\/title>",
      scripts,
      "<body>",
      data,
      ""
    ]).join("\r\n");

    if (_.LocalFileSystem.supported) {
      var path = name || decodeURI(location.pathname);
      var fs = new _.LocalFileSystem;
      if (!name) fs.backup(path);
      fs.write(path, html);
    } else if (SUPPORTS_DOWNLOAD) {
      download(html, name);
    }

    this.dispatchEvent("saved");

    return true;
  },
  
  send: function(request, data) {
    if (this.client) {
      request.referer = this.client.address;
    }
    this.server.respond(request, data);
  },
  
  Client: Client,
  Server: Server,
  JSONFileSystem: JSONFileSystem,
  JSONDirectory: JSONDirectory,
  FileSystem: FileSystem,
  Command: Command,
  Interpreter: Interpreter,
  Terminal: Terminal,
  Request: Request,
  History: History
});

MiniWeb.toString = _.K("MiniWeb");

EventTarget(MiniWeb);

// =========================================================================
// MiniWeb/init.js
// =========================================================================

// create page style
document.write("<style>\
html{overflow:hidden}\
html,body{margin:0;padding:0}\
body{position:absolute;left:0;top:0;right:0;bottom:0}\
#window{position:absolute;left:0;top:0;border:0;height:100%;width:100%;background:white;}\
</style>");

// delegate some methods to the client
forEach.csv ("navigateTo,refresh,reload,submit", function(method) {
  MiniWeb[method] = function() {
    var args = _.slice(arguments);
    var client = MiniWeb.client;
    // use a timer to jump out of an event
    setTimeout(function() {
      client[method].apply(client, args);
    }, 0);
  };
});

window.onload = function() {
  MiniWeb.readOnly = location.protocol !== "file:" || !io.LocalFileSystem.supported;
  MiniWeb.server = new Server;
  MiniWeb.terminal = new Terminal;
  MiniWeb.client = new Client;
};

}); // end: closure
