/*
  base2.js (c) 2007-2012, Dean Edwards
  Home: http://code.google.com/p/base2/
  License: http://mit-license.org/
*/

// timestamp: Mon, 22 Oct 2012 02:36:34

base2.require("Date,base2.dom", function(_, Date, dom) { // begin: closure

"use strict";

var forEach = _.forEach;

base2.exec("es5-shim");

var CONSTANT   = /^[A-Z][\dA-Z_]*$/;
var PRIMITIVE  = /^(boolean|number|string)$/;
var OBJECT     = /^(object|package|class|trait)$/;
var PACKAGE    = /^package$/;
var THIS       = /\bthis\./;
var VALID_NAME = /^[a-z]/i;

var OBJECT = /^(Object|Null|Undefined)$/;

var Object__toString = {}.toString;

var DATE_PROTOTYPE_METHODS =
"getDate,getDay,getFullYear,getHours,getMilliseconds,getMinutes,getMonth,\
getSeconds,getTime,getTimezoneOffset,getUTCDate,getUTCDay,getUTCFullYear,\
getUTCHours,getUTCMilliseconds,getUTCMinutes,getUTCMonth,getUTCSeconds,\
setDate,setFullYear,setHours,setMilliseconds,setMinutes,setMonth,setSeconds,\
setTime,setUTCDate,setUTCFullYear,setUTCHours,setUTCMilliseconds,setUTCMinutes,\
setUTCMonth,setUTCSeconds,toDateString,toLocaleDateString,\
toLocaleTimeString,toTimeString,toUTCString";

function isPrimitive(ref) {
  return PRIMITIVE.test(typeof ref) || ref instanceof RegExp;
}

function isConstant(ref, name) {
  return CONSTANT.test(name) && (ref === null || isPrimitive(ref));
}

function isObject(ref) {
  return typeof ref == "object" || typeof ref == "null";
}

function isClass(ref) {
  if (typeof ref != "function") return false;
  if (ref == window.Date || ref == window.XMLHttpRequest) return true;
  for (var i in ref.prototype) return true;
  return /\s*function\s+[A-Z][^\[]+\[native code/.test(String(ref));
  return false;
}

function isBaseClass(ref) {
  return typeof ref == "function" && (ref == base2.Base || base2.Base.ancestorOf(ref));
}

function isTrait(ref) {
  return typeof ref == "function" && base2.Trait.ancestorOf(ref);
}

function isPackage(ref, name) {
  return ref instanceof base2.Package && doc.show[name] !== false;
}

function isFunction(ref) {
  return _.isFunction(ref) && !isClass(ref);
}

function isMethod(ref) {
  return isFunction(ref) && /\bthis\./.test(ref);
}

//alert(new Counter)

// =========================================================================
// MiniWeb/doc/Members.js
// =========================================================================

var Member = _.Base.extend({
  constructor: function Member__constructor(name, reference, owner) {
    this.inherited = owner.ancestor[name] === reference;
  },

  inherited: false
});

var Members = _.Collection.extend({
  constructor: function Members__constructor(owner, test) {
    this.base();
    this.owner = owner;
    if (owner instanceof Reflection) {
      var reference = owner.reference
    } else {
      reference = owner;
    }
    forEach (reference, function(member, name) {
      if (VALID_NAME.test(name) && (!test || test.apply(undefined, arguments))) {
        this.set(name, member);
      }
    }, this, (typeof reference == "function" ? Function : Object).prototype);
    this.sort();
  },

  createItem: function Members__createItem(name, reference, inherited) {
    var member = this.base(name, reference, this.owner);
    if (arguments.length > 2) member.inherited = !!inherited;
    return member;
  },
  
  owner: null
}, {
  Item: Member
});

// =========================================================================
// MiniWeb/doc/Reflection.js
// =========================================================================

var Reflection = _.Base.extend({
  constructor: function(reference) {
    this.reference = reference;
    this.ancestor = Object.prototype;
    
    this.type = typeof reference;
    
    if (this.type === "null") this.type = "object";
    
    if (reference != null) {
      if (this.type === "function") {
        this.ancestor = Function.prototype;
        if (isClass(reference)) {
          this.ancestor = reference.ancestor || Object;
          if (typeof reference == "function" && _.Trait.ancestorOf(reference)) {
            this.type = "trait";
          } else {
            this.type = "class";
          }
        } else if (reference.prototype) {
          var typeString = Object__toString.call(reference.prototype).slice(8, -1);
          if (!OBJECT.test(typeString)) {
            this.type = "class";
          }
        }
      } else if (this.type === "object") {
        if (jsb.element.ancestorOf(reference)) {
          this.ancestor = reference.ancestor;
          this.type = "behavior";
        } else {
          this.ancestor = reference.constructor.prototype;
          if (reference == this.ancestor || String(this.ancestor) == "[xpconnect wrapped native prototype]") {
            this.ancestor = (reference.constructor.ancestor || Object).prototype;
          }
          if (reference instanceof Namespace) {
            this.type = "namespace";
          } else if (reference instanceof _.Package) {
            this.type = "package";
          }
        }
      }
    }
  },

  ancestor: Object.prototype,
  reference: null,
  type: "undefined",

  getClasses: function() {
    var members = new Members(this, function(ref) {
      return isClass(ref) && !isTrait(ref);
    });
    if (this.reference == window && _.detect("Gecko")) {
      for (var name in Components.interfaces) {
        name = name.slice(3);
        if (name in window) {
          members.set(name, window[name]);
        } else {
          name = name.slice(3);
          if (name in window) {
            members.set(name, window[name]);
          }
        }
      }
    }
    members.sort();
    return members;
  },

  getClassMethods: function() {
    var traitMethods = this.type == "trait" ? this.reference.prototype : {};
    var members = new Members(this, function(ref, name) {
      return ref instanceof Function && !traitMethods[name] && !isBaseClass(ref) && ref != Object;
    });
    if (this.reference == Date) {
      members.set("UTC", Date.UTC, true);
      members.set("now", Date.now, false);
      members.set("parse", Date.parse, false);
    }
    if (!traitMethods.bind) {
      var bind = this.reference.bind;
      if (bind != Function.bind) {
        members.set("bind", bind);
      }
    }
    members.set("toString", this.reference.toString, true);
    members.sort();
    return members;
  },

  getClassProperties: function() {
    var type = this.type;
    return new Members(this, function(ref, name) {
      return !CONSTANT.test(name) && (typeof ref == "null" || typeof ref == "object" || isPrimitive(ref) || isBaseClass(ref) || ref == Object);
    });
  },

  getConstants: function() {
    return new Members(this, isConstant);
  },

  getEvents: function() {
    return new Members(this, function(ref, name) {
      return ref === null && /^(\w+:)?on[a-z]+$/.test(name);
    });
  },

  getInstanceMethods: function() {
    var reference = this.reference;
    if (reference == Date) {
      var proto = new Date;
      var members = new Reflection(proto).getMethods();
      forEach.csv(DATE_PROTOTYPE_METHODS, function(name) {
        members.set(name, proto[name], true);
      });
      members.set("toISOString", proto.toISOString, false);
      members.sort();
    } else {
      members = new Reflection(reference.prototype).getMethods();
    }
    return members;
  },

  getInstanceProperties: function() {
    var reference = this.reference;
    if (reference == Date) {
      var members = new Reflection(new Date).getProperties();
    } else {
      members = new Reflection(reference.prototype).getProperties();
    }
    return members;
  },

  getMembers: function() {
    var members = new Members(this);
    members.sort();
    return members;
  },

  getMethods: function() {
    var members = new Members(this, isFunction);
    if (this.reference == JSON) {
      members.set("parse", JSON.parse, false);
      members.set("stringify", JSON.stringify, false);
    }
    try {
      members.set("toString", this.reference.toString, true);
    } catch(e){}
    members.sort();
    return members;
  },

  getPackages: function() {
    return new Members(this, isPackage);
  },

  getProperties: function() {
    return new Members(this, function(ref, name) {
      return typeof ref != "function" && !isConstant(ref, name) && !(ref instanceof _.Package) && !(ref === null && /^(\w+:)?on[a-z]+$/.test(name));
    });
  },

  getTraits: function() {
    return new Members(this, isTrait);
  },

  getTraitMethods: function() {
    var traitMethods = this.type == "trait" ? this.reference.prototype : {};
    var members = new Members(this, function(ref, name) {
      return !!traitMethods[name] && name != "base";
    });
    if (traitMethods.bind) {
      members.set("bind", this.reference.bind);
      members.sort();
    }
    return members;
  }
});

// =========================================================================
// MiniWeb/doc/package.js
// =========================================================================

var doc = MiniWeb.doc = new _.Package({
  name:    "MiniWeb.doc",
  version: "1.0(beta1)",

  show: {},

  getObject: function(objectID) {
    if (objectID === "namespace") return namespace;

    var refId = String(objectID).replace(/::/, '.prototype.');
    refId = refId.split('.');
    if (refId.length > 1) {
      refId[refId.length - 2] += '["' + refId.pop() + '"]';
    }
    refId = refId.join('.');
    return new Function("try{return " + refId + "}catch(e){}")();
  },

  beautify: String,

  "@Gecko": {
    beautify: function(source) {
      source = String(source).replace(/\s+doc;\r?\n[^\n]+\n/g, "");
      source = source.replace(/[\x20\t]*['"]use strict['"];[^\n]*\n/g, "");
      source = js_beautify(source, {indent_size: 2, keep_array_indentation: true});
      source = source.replace(/{(\[native code\])/, "{\n  $1");
      return source;
    }
  },

  colorize: function(pre) {
    var className = pre.className;
    var colorizer = colorize[className];

    if (colorizer) {
      colorizer.parseUrls = false;

      var textContent = dom.get(pre, 'textContent');

      // Convert tabs to spaces and then convert spaces to "&nbsp;".
      var indent = textContent.match(/\n(\s+)\}\s*$/);
      if (indent) {
        textContent = textContent.replace(new RegExp("\\n" + indent[1], "g"), "\n");
      }

      textContent = textContent.replace(/([\x20\t]*;(;|doc);[^\n]+\n)+\r?\n?/g, "");

      dom.classList.add(pre, "colorized");
      dom.classList.add(pre, "colorize-" + className);

      pre.innerHTML = colorizer.parse(textContent);
    }
  },

  Members: Members,
  Reflection: Reflection
});

// =========================================================================
// MiniWeb/doc/data.js
// =========================================================================

doc.data = {
  PATH: "/data/doc/entries/",

  exists: function(objectID, entry) {
    return MiniWeb.server.io.exists(this.makepath(objectID, entry));
  },

  makepath: function(objectID, entry) {
    return this.PATH + String(objectID).replace(/::/, ".prototype.").split(".").join("/") + "/#" + entry;
  },

  read: function(objectID, entry) {
    return MiniWeb.server.io.read(this.makepath(objectID, entry));
  },

  remove: function(objectID, entry) {
    return MiniWeb.server.io.remove(this.makepath(objectID, entry));
  },

  write: function(objectID, entry, value) {
    var io = MiniWeb.server.io;
    var names = objectID.replace(/::/, ".prototype.").split(".");
    for (var i = 1; i <= names.length; i++) {
      var path = this.PATH + names.slice(0, i).join("/");
      if (!io.isDirectory(path)) {
        io.mkdir(path);
      }
    }
    io.write(path + "/#" + entry, value);
  }
};

// =========================================================================
// colorize/colorize.js
// =========================================================================

base2.exec(function(_) { // begin: closure

var forEach = _.forEach;

var IGNORE = _.RegGrp.IGNORE;

var TAB  = /\t/g;
var TABS = /\n([\t \xa0]*)/g;

// Use a string to create the CHAR pattern.
// This protects against a bug in Safari 2.
// Finally, we need to separate the \uffff char (this is for Opera).
var CHAR = "\\w\u00a1-\ufffe\uffff";

var BLOCK_COMMENT = /\/\*[^*]*\*+([^\/][^*]*\*+)*\//;
var LINE_COMMENT  = /\/\/[^\r\n]*/;
var NUMBER        = /\b\-?(\d+\.\d+|\.\d+|\d+\.|\d+)([eE][-+]?\d+)?\b/;
var STRING1       = /'(\\\r?\n|\\.|[^'\\])*'/;
var STRING2       = /"(\\\r?\n|\\.|[^"\\])*"/;
var EMAIL         = /(mailto:)?([<#CHAR>.+-]+@[<#CHAR>.-]+\.[<#CHAR>]+)/;
var URL           = /https?:\/\/+[<#CHAR>\/\-%&#=.,?+$]+/;

var escape = new _.RegGrp([
  "<",       "\x01",
  ">",       "\x02",
  "&",       "\x03"
]);

var unescape = new _.RegGrp([
  "\x01",    "&lt;",
  "\x02",    "&gt;",
  "\x03",    "&amp;"
]);

var Colorizer = _.RegGrp.extend({
  constructor: function(dictionary, items, options) {
    _.extend(this, options);
    this.dictionary = new Colorizer.Dict(dictionary);
    this.base(items);
  },

  escapeChar: "",
  parseUrls: true,
  tabStop: 4,

  parse: function(text, tabSize) {
    var preParsed = !!arguments[2]; // Not a secondary parse of the text (e.g. CSS within an HTML sample).
    text = escape.parse(text);
    if (!preParsed && this.before) {
      text = this.before(text);
    }
    text = this.base(text);
    if (!preParsed) {
      // Convert tabs to spaces and then convert spaces to "&nbsp;".
      if (tabSize) {
        var tab = Array(tabSize + 1).join(" ");
        text = text.replace(TABS, tab);
      }
      if (this.parseUrls) text = urls.parse(text);
    }
    if (!preParsed && this.after) {
      text = this.after(text);
    }
    return unescape.parse(text);
  },
  
  set: function(pattern, replacement) {
    if (/^colorize\-/.test(replacement)) {
      replacement = '<span class="' + replacement + '">$1</span>';
    }
    return this.base(pattern, replacement);
  },

  "@MSIE[67]": {
    parse: function(text, tabSize) {
      return this.base.apply(this, arguments).replace(/\r?\n\r?\n/g, "<br>&nbsp;<br>");
    }
  },

  "@MSIE": {
    parse: function(text, tabSize) {
      return this.base.apply(this, arguments).replace(/[ \xa0]{2}/g, "&nbsp;&nbsp;").replace(/\r?\n/g, "<br>");
    }
  }
});

Colorizer.Dict = _.RegGrp.Dict.extend({
  parse: function(phrase) {
    return escape.parse(this.base(phrase));
  }
});

// ------------------------------------------------------
// Package.
// ------------------------------------------------------

var colorize = new _.Package({
  name:    "colorize",
  version: "1.0(beta1)"
}, {
  CHAR:          CHAR,
  BLOCK_COMMENT: BLOCK_COMMENT,
  LINE_COMMENT:  LINE_COMMENT,
  NUMBER:        NUMBER,
  STRING1:       STRING1,
  STRING2:       STRING2,
  
  Colorizer:     Colorizer,
  
  addScheme:     addScheme
});

window.colorize = colorize; // -@DRE

var RULE = "pre:not(.colorized).colorize-";

function addScheme(name, dictionary, items, options) {
  if (arguments.length == 2 && arguments[1] instanceof Colorizer) {
    var scheme = arguments[1];
  } else {
    scheme = new Colorizer(dictionary, items, options);
  }
  if (typeof jsb != "undefined") {
    jsb.Rule(RULE + name, {
      "jsb:oncontentready": function(element) {
        var textContent = this.get(element, "textContent");
        element.innerHTML = scheme.parse(textContent);
        this.classList.add(element, "colorized");
      }
    });
  } else if (typeof jQuery != "undefined") {
    jQuery(function($) {
      $(RULE + name).each(function() {
        var textContent = $(this).text();
        this.innerHTML = scheme.parse(textContent);
        $(this).addClass("colorized");
      });
    });
  }
  colorize[name] = scheme;
  return scheme;
}

// ------------------------------------------------------
// URL parser.
// ------------------------------------------------------

var urls = new _.RegGrp({
  CHAR:   CHAR,
  EMAIL:  EMAIL,
  URL:    URL
}, {
  '<#EMAIL>': '<a href="mailto:$2">$1$2</a>',
  '(<#URL>)': '<a href="$1">$1</a>'
});

// ------------------------------------------------------
// JavaScript parser.
// ------------------------------------------------------

var js = addScheme("js", [
  "OPERATOR",      /[\[({\^<=>,:;&|!*?+-]/,
  "BLOCK_COMMENT", BLOCK_COMMENT,
  "LINE_COMMENT",  LINE_COMMENT,
  "COMMENT",       /<#BLOCK_COMMENT>|<#LINE_COMMENT>/,
  "NUMBER",        NUMBER,
  "STRING1",       STRING1,
  "STRING2",       STRING2,
  "STRING",        /<#STRING1>|<#STRING2>/,
  "CONDITIONAL",   /\/\*@if\s*\([^\)]*\)|@else[\s\w]*@\*\/|\/\*@[^\n]+@\*\/|\/[\/\*]@[^\n]*|\S+[^\n@]*@\*\/|@\*\//, // conditional comments
  "GLOBAL",        /\b(__defineGetter__|__defineSetter__|__lookupGetter__|__lookupSetter__|clearInterval|clearTimeout|confirm|constructor|document|escape|hasOwnProperty|Infinity|isNaN|isPrototypeOf|NaN|parseFloat|parseInt|prompt|propertyIsArrayLike|prototype|setInterval|setTimeout|toString|toLocaleString|unescape|valueOf|window)\b/,
  "KEYWORD",       /\b(arguments|break|case|const|continue|default|delete|do|else|false|for|function|get|if|in|instanceof|let|new|null|return|set|switch|this|true|typeof|var|void|while|with|undefined|yield)\b/,
  "REGEXP",        /\/(\[(\\.|[^\n\]\\])+\]|\\.|[^\/\n\\])+\/[gim]*/,
  "SPECIAL",       /\b(assert\w*|alert|catch|console|debugger|eval|finally|throw|try)\b/
], [
  /\+\+|\-\-/, IGNORE,

  '(0[xX][\\dA-Fa-f]*)',
    'colorize-number',

  '(<#NUMBER>)',
    'colorize-number',

  "(<#OPERATOR>)(\\s*)(<#CONDITIONAL>)",
    '$1$2<span class="colorize-conditional-comment">$3</span>',

  "(<#OPERATOR>)(\\s*)(<#COMMENT>)",
    '$1$2<span class="colorize-comment">$3</span>',
    
  "(<#OPERATOR>)(\\s*)(<#REGEXP>)",
    '$1$2<span class="colorize-regexp">$3</span>',
    
  "\\b(return|typeof|instanceof|do)(\\s*)(<#REGEXP>)",
    '<span class="colorize-keyword">$1</span>$2<span class="colorize-regexp">$3</span>',

  '(<#CONDITIONAL>)',
    'colorize-conditional-comment',

  '(<#COMMENT>)',
    'colorize-comment',
    
  '(<#STRING>)',
    'colorize-string',
    
  '(<#GLOBAL>)',
    'colorize-global',
    
  '(<#KEYWORD>)',
    'colorize-keyword',
    
  '(<#SPECIAL>)',
    'colorize-special'
]);

// ------------------------------------------------------
// CSS parser.
// ------------------------------------------------------

var css = addScheme("css", {
  CHAR:              CHAR,
  AT_RULE:           /@\w[^;{]+/,
  BRACKETED:         /\([^'\x22)]*\)/,
  COMMENT:           BLOCK_COMMENT,
  PROPERTY:          /(\w[\w\-]*\s*):([^;}]+)/,
  VENDOR_SPECIFIC:   /(\-[\w\-]+\s*):([^;}]+)/,
  SELECTOR:          /([<#CHAR>:\[.#-](\\.|[^{\\])*)\{/
}, {
  '(<#AT_RULE>)':       'colorize-at_rule',
  '<#BRACKETED>':       IGNORE,
  '(<#COMMENT>)':       'colorize-comment',
  '<#PROPERTY>':        '<span class="colorize-property-name">$1</span>:<span class="colorize-property-value">$2</span>',
  '<#VENDOR_SPECIFIC>': '<span class="colorize-vendor-specific"><span class="colorize-property-name">$1</span>:<span class="colorize-property-value">$2</span></span>',
  '<#SELECTOR>':        '<span class="colorize-selector">$1</span>{'
}, {
  ignoreCase: true
});

// ------------------------------------------------------
// XML parser.
// ------------------------------------------------------

var xml = addScheme("xml", {
  CHAR:      CHAR,
  PI:        /<\?[^>]+>/,
  COMMENT:   /<!\s*(--([^-]|[\r\n]|-[^-])*--\s*)>/,
  CDATA:     /<!\[CDATA\[([^\]]|\][^\]]|\]\][^>])*\]\]>/,
  ENTITY:    /&(#\d+|\w+);/,
  TAG:       /(<\/?)([<#CHAR>\-]+(?:\:[<#CHAR>\-]+)?\s*)((?:\/[^>]|[^/>])*)(\/?>)/
}, {
  '(<#PI>)':      'colorize-processing-instruction',
  '(<#COMMENT>)': 'colorize-comment',
  '(<#CDATA>)':   'colorize-cdata',
  '(<#ENTITY>)':  'colorize-entity',
  
  '<#TAG>': function(match, openTag, tagName, attributes, closeTag) {
    return openTag + '<span class="colorize-tag">' + tagName + '</span>' + attr.parse(attributes) + closeTag;
  }
}, {
  ignoreCase: true,
  tabStop: 1
});

var attr = new _.RegGrp([
  "CHAR",      CHAR,
  "STRING1",   STRING1,
  "STRING2",   STRING2,
  "STRING",    /<#STRING1>|<#STRING2>/
], [
  '([<#CHAR>-]+)(?:(\\s*=\\s*)(<#STRING>))?', '<span class="colorize-attribute-name">$1</span>$2<span class="colorize-attribute-value">$3</span>'
]);

// ------------------------------------------------------
// HTML parser.
// ------------------------------------------------------

var html = xml.clone();

html.dictionary.merge({
  DOCTYPE:     /<!doctype[^>]+>/,
  CONDITIONAL: /<!(--)?\[[^\]]*\]>|<!\[endif\](--)?>/, // conditional comments
  BLOCK:       /(<)(script|style)([^>]*)(>)([^<]*)<\/\2>/
});

// Parse a script or style block.
html.insertAt(-1, "<#BLOCK>", parseBlock);

html.merge([
  '(<#DOCTYPE>)',     'colorize-doctype',
  '(<#CONDITIONAL>)', 'colorize-conditional-comment'
]);

function parseBlock(match, openTag, tagName, attributes, closeTag, cdata) {
  return openTag + '<span class="colorize-tag">' + tagName + '</span>' + attr.parse(attributes) + closeTag +
    cdata + openTag + '/<span class="colorize-tag">' + tagName + '</span>' + closeTag;
};

addScheme("html", html);

// ------------------------------------------------------
// HTML+CSS+JS parser.
// ------------------------------------------------------

addScheme("html_multi", html.union({
  '<#BLOCK>': function(match, openTag, tagName, attributes, closeTag, cdata) {
    var type = /style/i.test(tagName) ? "css" : "js";
    cdata = '<span class="colorize-' + type + ' colorize-block">' + colorize[type].parse(cdata, 0, true) + '</span>';
    return parseBlock(match, openTag, tagName, attributes, closeTag, cdata);
  }
}));

}); // end: closure

// =========================================================================
// colorize/base2.js
// =========================================================================

base2.exec(function(_) {
  var names = "base,implement".split(",");
  _.forEach(_, function(value, name) {
    if (name != "_") names.push(name);
  }, {});
  names = "\\b(" + names.join("|") + ")\\b";
  var js = colorize.js;
  js.add(names, '<span class="base2">$1</span>');
  js.add("\\b(behavior)\\b", '<span class="jsb-behavior">$1</span>');
  js.insertAt(0, /("@[^"]+"):/, '<span class="colorize-conditional-comment colorize-string">$1</span>:');
  js.tabStop = 2;
});

// =========================================================================
// MiniWeb/doc/jsbeautify.js
// =========================================================================
/*
 JS Beautifier
---------------

  Written by Einar Lielmanis, <einar@jsbeautifier.org>
      http://jsbeautifier.org/

  Originally converted to javascript by Vital, <vital76@gmail.com>
  "End braces on own line" added by Chris J. Shull, <chrisjshull@gmail.com>

  You are free to use this in any way you want, in case you find this useful or working for you.
*/
function js_beautify(z,m){var f,i,n,d,g,F,w,a,S,A,T,U,G,b,D,bg,s,V,W,x,y,u,K='';m=m?m:{};var r;if(m.space_after_anon_function!==undefined&&m.jslint_happy===undefined){m.jslint_happy=m.space_after_anon_function}if(m.braces_on_own_line!==undefined){r=m.braces_on_own_line?"expand":"collapse"}r=m.brace_style?m.brace_style:(r?r:"collapse");var bh=m.indent_size?m.indent_size:4,bo=m.indent_char?m.indent_char:' ',Z=typeof m.preserve_newlines==='undefined'?true:m.preserve_newlines,bp=typeof m.break_chained_methods==='undefined'?false:m.break_chained_methods,bi=typeof m.max_preserve_newlines==='undefined'?false:m.max_preserve_newlines,bq=m.jslint_happy==='undefined'?false:m.jslint_happy,t=typeof m.keep_array_indentation==='undefined'?false:m.keep_array_indentation,br=typeof m.space_before_conditional==='undefined'?true:m.space_before_conditional,bs=typeof m.unescape_strings==='undefined'?false:m.unescape_strings;y=false;var p=z.length;function H(e){e=typeof e==='undefined'?false:e;while(i.length&&(i[i.length-1]===' '||i[i.length-1]===A||i[i.length-1]===K||(e&&(i[i.length-1]==='\n'||i[i.length-1]==='\r')))){i.pop()}}function ba(e){return e.replace(/^\s\s*|\s\s*$/,'')}function bt(e){e=e.replace(/\x0d/g,'');var j=[],c=e.indexOf("\n");while(c!==-1){j.push(e.substring(0,c));e=e.substring(c+1);c=e.indexOf("\n")}if(e.length){j.push(e)}return j}function bu(){var e=t;t=false;h();t=e}function h(e,j){a.eat_next_space=false;if(t&&L(a.mode)){return}e=typeof e==='undefined'?true:e;j=typeof j==='undefined'?true:j;if(j){a.if_line=false;a.chain_extra_indentation=0}H();if(!i.length){return}if(i[i.length-1]!=="\n"||!e){y=true;i.push("\n")}if(K){i.push(K)}for(var c=0;c<a.indentation_level+a.chain_extra_indentation;c+=1){i.push(A)}if(a.var_line&&a.var_line_reindented){i.push(A)}}function k(){if(d==='TK_COMMENT'){return h()}if(a.eat_next_space){a.eat_next_space=false;return}var e=' ';if(i.length){e=i[i.length-1]}if(e!==' '&&e!=='\n'&&e!==A){i.push(' ')}}function l(){y=false;a.eat_next_space=false;i.push(n)}function M(){a.indentation_level+=1}function bb(){if(i.length&&i[i.length-1]===A){i.pop()}}function v(e){if(a){S.push(a)}a={previous_mode:a?a.mode:'BLOCK',mode:e,var_line:false,var_line_tainted:false,var_line_reindented:false,in_html_comment:false,if_line:false,chain_extra_indentation:0,in_case_statement:false,in_case:false,case_body:false,eat_next_space:false,indentation_baseline:-1,indentation_level:(a?a.indentation_level+((a.var_line&&a.var_line_reindented)?1:0):0),ternary_depth:0}}function L(e){return e==='[EXPRESSION]'||e==='[INDENTED-EXPRESSION]'}function N(e){return o(e,['[EXPRESSION]','(EXPRESSION)','(FOR-EXPRESSION)','(COND-EXPRESSION)'])}function X(){W=a.mode==='DO_BLOCK';if(S.length>0){var e=a.mode;a=S.pop();a.previous_mode=e}}function bv(e,j){for(var c=0;c<e.length;c++){var bc=ba(e[c]);if(bc.charAt(0)!==j){return false}}return true}function O(e){return o(e,['case','return','do','if','throw','else'])}function o(e,j){for(var c=0;c<j.length;c+=1){if(j[c]===e){return true}}return false}function bj(e){var j=b,c=f.charAt(j);while(o(c,T)&&c!==e){j++;if(j>=p){return 0}c=f.charAt(j)}return c}function bd(){var e,j;u=0;if(b>=p){return['','TK_EOF']}x=false;var c=f.charAt(b);b+=1;var bc=t&&L(a.mode);if(bc){var P=0;while(o(c,T)){if(c==="\n"){H();i.push("\n");y=true;P=0}else{if(c==='\t'){P+=4}else if(c==='\r'){}else{P+=1}}if(b>=p){return['','TK_EOF']}c=f.charAt(b);b+=1}if(a.indentation_baseline===-1){a.indentation_baseline=P}if(y){for(e=0;e<a.indentation_level+1;e+=1){i.push(A)}if(a.indentation_baseline!==-1){for(e=0;e<P-a.indentation_baseline;e++){i.push(' ')}}}}else{while(o(c,T)){if(c==="\n"){u+=((bi)?(u<=bi)?1:0:1)}if(b>=p){return['','TK_EOF']}c=f.charAt(b);b+=1}if(Z){if(u>1){for(e=0;e<u;e+=1){h(e===0);y=true}}}x=u>0}if(o(c,U)){if(b<p){while(o(f.charAt(b),U)){c+=f.charAt(b);b+=1;if(b===p){break}}}if(b!==p&&c.match(/^[0-9]+[Ee]$/)&&(f.charAt(b)==='-'||f.charAt(b)==='+')){var bw=f.charAt(b);b+=1;var bx=bd();c+=bw+bx[0];return[c,'TK_WORD']}if(c==='in'){return[c,'TK_OPERATOR']}if(x&&d!=='TK_OPERATOR'&&d!=='TK_EQUALS'&&!a.if_line&&(Z||g!=='var')){h()}return[c,'TK_WORD']}if(c==='('||c==='['){return[c,'TK_START_EXPR']}if(c===')'||c===']'){return[c,'TK_END_EXPR']}if(c==='{'){return[c,'TK_START_BLOCK']}if(c==='}'){return[c,'TK_END_BLOCK']}if(c===';'){return[c,'TK_SEMICOLON']}if(c==='/'){var I='',bk=true;if(f.charAt(b)==='*'){b+=1;if(b<p){while(b<p&&!(f.charAt(b)==='*'&&f.charAt(b+1)&&f.charAt(b+1)==='/')){c=f.charAt(b);I+=c;if(c==="\n"||c==="\r"){bk=false}b+=1;if(b>=p){break}}}b+=2;if(bk&&u===0){return['/*'+I+'*/','TK_INLINE_COMMENT']}else{return['/*'+I+'*/','TK_BLOCK_COMMENT']}}if(f.charAt(b)==='/'){I=c;while(f.charAt(b)!=='\r'&&f.charAt(b)!=='\n'){I+=f.charAt(b);b+=1;if(b>=p){break}}if(x){h()}return[I,'TK_COMMENT']}}if(c==="'"||c==='"'||(c==='/'&&((d==='TK_WORD'&&O(g))||(g===')'&&o(a.previous_mode,['(COND-EXPRESSION)','(FOR-EXPRESSION)']))||(d==='TK_COMMA'||d==='TK_COMMENT'||d==='TK_START_EXPR'||d==='TK_START_BLOCK'||d==='TK_END_BLOCK'||d==='TK_OPERATOR'||d==='TK_EQUALS'||d==='TK_EOF'||d==='TK_SEMICOLON')))){var J=c,B=false,q=0,Q=0;j=c;if(b<p){if(J==='/'){var be=false;while(B||be||f.charAt(b)!==J){j+=f.charAt(b);if(!B){B=f.charAt(b)==='\\';if(f.charAt(b)==='['){be=true}else if(f.charAt(b)===']'){be=false}}else{B=false}b+=1;if(b>=p){return[j,'TK_STRING']}}}else{while(B||f.charAt(b)!==J){j+=f.charAt(b);if(q&&q>=Q){q=parseInt(j.substr(-Q),16);if(q&&q>=0x20&&q<=0x7e){q=String.fromCharCode(q);j=j.substr(0,j.length-Q-2)+(((q===J)||(q==='\\'))?'\\':'')+q}q=0}if(q){q++}else if(!B){B=f.charAt(b)==='\\'}else{B=false;if(bs){if(f.charAt(b)==='x'){q++;Q=2}else if(f.charAt(b)==='u'){q++;Q=4}}}b+=1;if(b>=p){return[j,'TK_STRING']}}}}b+=1;j+=J;if(J==='/'){while(b<p&&o(f.charAt(b),U)){j+=f.charAt(b);b+=1}}return[j,'TK_STRING']}if(c==='#'){if(i.length===0&&f.charAt(b)==='!'){j=c;while(b<p&&c!=='\n'){c=f.charAt(b);j+=c;b+=1}i.push(ba(j)+'\n');h();return bd()}var Y='#';if(b<p&&o(f.charAt(b),bg)){do{c=f.charAt(b);Y+=c;b+=1}while(b<p&&c!=='#'&&c!=='=');if(c==='#'){}else if(f.charAt(b)==='['&&f.charAt(b+1)===']'){Y+='[]';b+=2}else if(f.charAt(b)==='{'&&f.charAt(b+1)==='}'){Y+='{}';b+=2}return[Y,'TK_WORD']}}if(c==='<'&&f.substring(b-1,b+3)==='<!--'){b+=3;c='<!--';while(f.charAt(b)!=='\n'&&b<p){c+=f.charAt(b);b++}a.in_html_comment=true;return[c,'TK_COMMENT']}if(c==='-'&&a.in_html_comment&&f.substring(b-1,b+2)==='-->'){a.in_html_comment=false;b+=2;if(x){h()}return['-->','TK_COMMENT']}if(c==='.'){return[c,'TK_DOT']}if(o(c,G)){while(b<p&&o(c+f.charAt(b),G)){c+=f.charAt(b);b+=1;if(b>=p){break}}if(c===','){return[c,'TK_COMMA']}else if(c==='='){return[c,'TK_EQUALS']}else{return[c,'TK_OPERATOR']}}return[c,'TK_UNKNOWN']}A='';while(bh>0){A+=bo;bh-=1}while(z&&(z.charAt(0)===' '||z.charAt(0)==='\t')){K+=z.charAt(0);z=z.substring(1)}f=z;w='';d='TK_START_EXPR';g='';F='';i=[];W=false;T="\n\r\t ".split('');U='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_$'.split('');bg='0123456789'.split('');G='+ - * / % & ++ -- = += -= *= /= %= == === != !== > < >= <= >> << >>> >>>= >>= <<= && &= | || ! !! , : ? ^ ^= |= ::';G+=' <%= <% %> <?= <? ?>';G=G.split(' ');D='continue,try,throw,return,var,if,switch,case,default,for,while,break,function'.split(',');S=[];v('BLOCK');b=0;while(true){var bl=bd();n=bl[0];V=bl[1];if(V==='TK_EOF'){break}switch(V){case'TK_START_EXPR':if(n==='['){if(d==='TK_WORD'||g===')'){if(o(g,D)){k()}v('(EXPRESSION)');l();break}if(a.mode==='[EXPRESSION]'||a.mode==='[INDENTED-EXPRESSION]'){if(F===']'&&g===','){if(a.mode==='[EXPRESSION]'){a.mode='[INDENTED-EXPRESSION]';if(!t){M()}}v('[EXPRESSION]');if(!t){h()}}else if(g==='['){if(a.mode==='[EXPRESSION]'){a.mode='[INDENTED-EXPRESSION]';if(!t){M()}}v('[EXPRESSION]');if(!t){h()}}else{v('[EXPRESSION]')}}else{v('[EXPRESSION]')}}else{if(w==='for'){v('(FOR-EXPRESSION)')}else if(o(w,['if','while'])){v('(COND-EXPRESSION)')}else{v('(EXPRESSION)')}}if(g===';'||d==='TK_START_BLOCK'){h()}else if(d==='TK_END_EXPR'||d==='TK_START_EXPR'||d==='TK_END_BLOCK'||g==='.'){if(x){h()}}else if(d!=='TK_WORD'&&d!=='TK_OPERATOR'){k()}else if(w==='function'||w==='typeof'){if(bq){k()}}else if(o(g,D)||g==='catch'){if(br){k()}}l();break;case'TK_DOT':if(O(g)){k()}else if(g===')'){if(bp||x){a.chain_extra_indentation=1;h(true,false)}}l();break;case'TK_END_EXPR':if(n===']'){if(t){if(g==='}'){bb();l();X();break}}else{if(a.mode==='[INDENTED-EXPRESSION]'){if(g===']'){X();h();l();break}}}}X();l();break;case'TK_START_BLOCK':if(w==='do'){v('DO_BLOCK')}else{v('BLOCK')}if(r==="expand"||r==="expand-strict"){var bf=false;if(r==="expand-strict"){bf=(bj()==='}');if(!bf){h(true)}}else{if(d!=='TK_OPERATOR'){if(g==='='||(O(g)&&g!=='else')){k()}else{h(true)}}}l();if(!bf){M()}}else{if(d!=='TK_OPERATOR'&&d!=='TK_START_EXPR'){if(d==='TK_START_BLOCK'){h()}else{k()}}else{if(L(a.previous_mode)&&g===','){if(F==='}'){k()}else{h()}}}M();l()}break;case'TK_END_BLOCK':X();if(r==="expand"||r==="expand-strict"){if(g!=='{'){h()}l()}else{if(d==='TK_START_BLOCK'){if(y){bb()}else{H()}}else{if(L(a.mode)&&t){t=false;h();t=true}else{h()}}l()}break;case'TK_WORD':if(W){k();l();k();W=false;break}s='NONE';if(n==='function'){if(a.var_line&&d!=='TK_EQUALS'){a.var_line_reindented=true}if((y||g===';')&&g!=='{'&&d!=='TK_BLOCK_COMMENT'&&d!=='TK_COMMENT'){u=y?u:0;if(!Z){u=1}for(var bm=0;bm<2-u;bm++){h(false)}}if(d==='TK_WORD'){if(g==='get'||g==='set'||g==='new'||g==='return'){k()}else{h()}}else if(d==='TK_OPERATOR'||g==='='){k()}else if(N(a.mode)){}else{h()}l();w=n;break}if(n==='case'||(n==='default'&&a.in_case_statement)){h();if(a.case_body){a.indentation_level--;a.case_body=false;bb()}l();a.in_case=true;a.in_case_statement=true;break}if(d==='TK_END_BLOCK'){if(!o(n.toLowerCase(),['else','catch','finally'])){s='NEWLINE'}else{if(r==="expand"||r==="end-expand"||r==="expand-strict"){s='NEWLINE'}else{s='SPACE';k()}}}else if(d==='TK_SEMICOLON'&&(a.mode==='BLOCK'||a.mode==='DO_BLOCK')){s='NEWLINE'}else if(d==='TK_SEMICOLON'&&N(a.mode)){s='SPACE'}else if(d==='TK_STRING'){s='NEWLINE'}else if(d==='TK_WORD'){if(g==='else'){H(true)}s='SPACE'}else if(d==='TK_START_BLOCK'){s='NEWLINE'}else if(d==='TK_END_EXPR'){k();s='NEWLINE'}if(o(n,D)&&g!==')'){if(g==='else'){s='SPACE'}else{s='NEWLINE'}}if(a.if_line&&d==='TK_END_EXPR'){a.if_line=false}if(o(n.toLowerCase(),['else','catch','finally'])){if(d!=='TK_END_BLOCK'||r==="expand"||r==="end-expand"||r==="expand-strict"){h()}else{H(true);k()}}else if(s==='NEWLINE'){if(O(g)){k()}else if(d!=='TK_END_EXPR'){if((d!=='TK_START_EXPR'||n!=='var')&&g!==':'){if(n==='if'&&w==='else'&&g!=='{'){k()}else{a.var_line=false;a.var_line_reindented=false;h()}}}else if(o(n,D)&&g!==')'){a.var_line=false;a.var_line_reindented=false;h()}}else if(L(a.mode)&&g===','&&F==='}'){h()}else if(s==='SPACE'){k()}l();w=n;if(n==='var'){a.var_line=true;a.var_line_reindented=false;a.var_line_tainted=false}if(n==='if'){a.if_line=true}if(n==='else'){a.if_line=false}break;case'TK_SEMICOLON':l();a.var_line=false;a.var_line_reindented=false;if(a.mode==='OBJECT'){a.mode='BLOCK'}break;case'TK_STRING':if(d==='TK_END_EXPR'&&o(a.previous_mode,['(COND-EXPRESSION)','(FOR-EXPRESSION)'])){k()}else if(d==='TK_COMMENT'||d==='TK_STRING'||d==='TK_START_BLOCK'||d==='TK_END_BLOCK'||d==='TK_SEMICOLON'){h()}else if(d==='TK_WORD'){k()}l();break;case'TK_EQUALS':if(a.var_line){a.var_line_tainted=true}k();l();k();break;case'TK_COMMA':if(a.var_line){if(N(a.mode)||d==='TK_END_BLOCK'){a.var_line_tainted=false}if(a.var_line_tainted){l();a.var_line_reindented=true;a.var_line_tainted=false;h();break}else{a.var_line_tainted=false}l();k();break}if(d==='TK_COMMENT'){h()}if(d==='TK_END_BLOCK'&&a.mode!=="(EXPRESSION)"){l();if(a.mode==='OBJECT'&&g==='}'){h()}else{k()}}else{if(a.mode==='OBJECT'){l();h()}else{l();k()}}break;case'TK_OPERATOR':var R=true,bn=true;if(O(g)){k();l();break}if(n==='*'&&d==='TK_DOT'&&!F.match(/^\d+$/)){l();break}if(n===':'&&a.in_case){a.case_body=true;M();l();h();a.in_case=false;break}if(n==='::'){l();break}if(o(n,['--','++','!'])||(o(n,['-','+'])&&(o(d,['TK_START_BLOCK','TK_START_EXPR','TK_EQUALS','TK_OPERATOR'])||o(g,D)))){R=false;bn=false;if(g===';'&&N(a.mode)){R=true}if(d==='TK_WORD'&&o(g,D)){R=true}if(a.mode==='BLOCK'&&(g==='{'||g===';')){h()}}else if(n===':'){if(a.ternary_depth===0){if(a.mode==='BLOCK'){a.mode='OBJECT'}R=false}else{a.ternary_depth-=1}}else if(n==='?'){a.ternary_depth+=1}if(R){k()}l();if(bn){k()}break;case'TK_BLOCK_COMMENT':var E=bt(n),C;if(bv(E.slice(1),'*')){h();i.push(E[0]);for(C=1;C<E.length;C++){h();i.push(' ');i.push(ba(E[C]))}}else{if(E.length>1){h()}else{if(d==='TK_END_BLOCK'){h()}else{k()}}for(C=0;C<E.length;C++){i.push(E[C]);i.push("\n")}}if(bj('\n')!=='\n'){h()}break;case'TK_INLINE_COMMENT':k();l();if(N(a.mode)){k()}else{bu()}break;case'TK_COMMENT':if(g===','&&!x){H(true)}if(d!=='TK_COMMENT'){if(x){h()}else{k()}}l();h();break;case'TK_UNKNOWN':l();break}F=g;d=V;g=n}var by=K+i.join('').replace(/[\r\n ]+$/,'');return by};

// =========================================================================
// MiniWeb/doc/init.js
// =========================================================================

var behavior = jsb.element.constructor.prototype;
var dummy = jsb.element.extend();
for (var i in dummy) {
  if (i !== "ancestor" && jsb.element[i] != dummy[i]) {
    behavior[i] != dummy[i];
  }
}

base2["#name"] = "base2";
jsb["#name"] = "jsb";
base2.Base["#name"] = "base2.Base";
window["#name"] = "window";
FormData["#name"] = "FormData";
XMLHttpRequest2["#name"] = "XMLHttpRequest";
window.XMLHttpRequest = XMLHttpRequest2;
jsb.form.element["#name"] = "jsb.form.element";

var namespace = base2.exec(_.I);
var Namespace = namespace.constructor;

function createKey(key) {
  return key + "";
}
createKey.toString = _.K(String(String));

base2.Collection.prototype.createKey = createKey;

process(base2, "base2");
process(jsb, "jsb");
forEach (base2, process);
forEach (jsb, process);

function process(property, name) {
  if (!doc.show[name] && property instanceof base2.Package) {
    property["#name"] = property.name;
    doc.show[name] = true;
    forEach (property, function(object, name) {
      if ((typeof object == "function" || jsb.element.ancestorOf(object)) && !object["#name"]) {
        object["#name"] = property["#name"] + "." + name;
      } else {
        process(object, name);
      }
    });
  } else if (typeof property == "function" && base2.Trait.ancestorOf(property)) {
    forEach (property["#implements"], function(trait) {
      forEach (trait, function(method, name) {
        if (!base2.Trait[name] && typeof method == "function" && property[name]) {
          property[name]._trait = trait;
          var protoMethod = property.prototype[name];
          if (protoMethod) protoMethod._trait = trait;
        }
      });
    });
  } else if (typeof property == "function" && base2.Collection.ancestorOf(property)) {
    var Item = property.Item;
    if (Item && !Item["#name"]) {
      Item['#name'] = property['#name'] + ".Item";
    }
    if (property == base2.RegGrp) {
      property.Dict['#name'] = property['#name'] + ".Dict";
    }
  }
}

doc.show.io = false;
doc.show.jst = false;

var events = (
  "mousedown|mouseup|mousemove|mouseenter|mouseleave|mouseover|mouseout|mousewheel|click|dblclick|" +
  "touchstart|touchmove|touchend|touchcancel|" +
  "keydown|keyup|input|" +
  "change|reset|submit|" +
  "focus|blur|scroll|select|" +
  "transitionend"
).split("|").sort();

forEach (events, function(name) {
  behavior["on" + name] = null;
});

events = "attach|contentready|documentready|losecapture".split("|");

forEach (events, function(name) {
  behavior["jsb:on" + name] = null;
});

//jsb.element["capture:onblur"] = null;
//jsb.element["capture:onfocus"] = null;
behavior["window:onresize"] = null;

}); // end: closure
