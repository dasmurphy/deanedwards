/*
  base2.js (c) 2007-2012, Dean Edwards
  Home: http://code.google.com/p/base2/
  License: http://mit-license.org/
*/

// timestamp: Tue, 31 Jan 2012 22:49:31

base2.require("Date,base2.dom", function(_, Date, dom) { // begin: closure

"use strict";

var forEach = _.forEach;

base2.exec("es5-shim");

var CONSTANT   = /^[A-Z][\dA-Z_]*$/;
var PRIMITIVE  = /^(boolean|number|string)$/;
var OBJECT     = /^(object|package|class|trait)$/;
var PACKAGE    = /^package$/;
var THIS       = /\bthis\./;
var VALID_NAME = /^[a-z_]/i;

var OBJECT = /^(Object|Null|Undefined)$/;

var Object__toString = {}.toString;

var DATE_PROTOTYPE_METHODS =
"getDate,getDay,getFullYear,getHours,getMilliseconds,getMinutes,getMonth,\
getSeconds,getTime,getTimezoneOffset,getUTCDate,getUTCDay,getUTCFullYear,\
getUTCHours,getUTCMilliseconds,getUTCMinutes,getUTCMonth,getUTCSeconds,\
setDate,setFullYear,setHours,setMilliseconds,setMinutes,setMonth,setSeconds,\
setTime,setUTCDate,setUTCFullYear,setUTCHours,setUTCMilliseconds,setUTCMinutes,\
setUTCMonth,setUTCSeconds,toDateString,toLocaleDateString,\
toLocaleTimeString,toTimeString,toUTCString";

function isPrimitive(ref) {
  return PRIMITIVE.test(typeof ref) || ref instanceof RegExp;
}

function isConstant(ref, name) {
  return CONSTANT.test(name) && (ref === null || isPrimitive(ref));
}

function isObject(ref) {
  return typeof ref == "object" || typeof ref == "null";
}

function isClass(ref) {
  if (typeof ref != "function" || typeof ref.prototype != "object") return false;
  if (ref == window.Date || ref == window.XMLHttpRequest) return true;
  for (var i in ref.prototype) return true;
  return false;
}

function isBaseClass(ref) {
  return typeof ref == "function" && (ref == base2.Base || base2.Base.ancestorOf(ref));
}

function isTrait(ref) {
  return typeof ref == "function" && base2.Trait.ancestorOf(ref);
}

function isPackage(ref, name) {
  return ref instanceof base2.Package && doc.show[name] !== false;
}

function isFunction(ref) {
  return _.isFunction(ref) && !isClass(ref);
}

function isMethod(ref) {
  return isFunction(ref) && /\bthis\./.test(ref);
}

// =========================================================================
// MiniWeb/doc/Members.js
// =========================================================================

var Members = base2.Collection.extend({
  constructor: function(owner, test) {
    this.base();
    this.owner = owner;
    if (owner instanceof Reflection) {
      var reference = owner.reference
    } else {
      reference = owner;
    }
    forEach (reference, function(member, name) {
      if (VALID_NAME.test(name) && (!test || test.apply(undefined, arguments))) {
        this.set(name, member);
      }
    }, this, (typeof reference == "function" ? Function : Object).prototype);
    this.sort();
  },
  
  set: function(name, reference, inherited) {
    var member = this.base(name, reference, this.owner);
    if (arguments.length > 2) member.inherited = !!inherited;
    return member;
  },
  
  owner: null
}, {
  Item: {
    constructor: function(name, reference, owner) {
      var ancestor = owner.ancestor;
      if (ancestor) {
        if ((owner.reference == base2.Trait && name === "forEach") || (owner.reference == base2.Functional && name === "bind")) {
          this.inherited = false;
        } else if (typeof jsb == "object" && owner.reference == jsb.element) {
          this.inherited = name === "base";
        } else if (reference instanceof Function && !(isBaseClass(reference) && name !== "ancestor")) {
          this.inherited = name in ancestor;
        } else {
          this.inherited = typeof ancestor[name] != "undefined";
        }
      }
    },

    //name: "",
    inherited: false
  }
});

// =========================================================================
// MiniWeb/doc/Reflection.js
// =========================================================================

var Reflection = _.Base.extend({
  constructor: function(reference) {
    this.reference = reference;
    this.ancestor = Object.prototype;
    
    this.type = typeof reference;
    
    if (this.type === "null") this.type = "object";
    
    if (reference != null) {
      if (this.type === "function") {
        this.ancestor = Function.prototype;
        if (isClass(reference)) {
          this.ancestor = reference.ancestor || Object;
          if (typeof reference == "function" && _.Trait.ancestorOf(reference)) {
            this.type = "trait";
          } else {
            this.type = "class";
          }
        } else if (reference.prototype) {
          var typeString = Object__toString.call(reference.prototype).slice(8, -1);
          if (!OBJECT.test(typeString)) {
            this.type = "class";
          }
        }
      } else if (this.type === "object") {
        this.ancestor = reference.constructor.prototype;
        if (reference == this.ancestor) {
          this.ancestor = (reference.constructor.ancestor || Object).prototype;
        }
        if (reference == window["namespace"]) {
          this.type = "namespace";
        } else if (reference instanceof _.Package) {
          this.type = "package";
        }
      }
    }
  },

  ancestor: null,
  reference: null,
  type: "undefined",

  getClasses: function() {
    return new Members(this, function(ref) {
      return isClass(ref) && !isTrait(ref);
    });
  },

  getClassMethods: function() {
    var traitMethods = this.type == "trait" ? this.reference.prototype : {};
    var members = new Members(this, function(ref, name) {
      return ref instanceof Function && !traitMethods[name] && !isBaseClass(ref) && ref != Object;
    });
    if (this.reference == Date) {
      members.set("UTC", Date.UTC, true);
      members.set("now", Date.now, false);
      members.set("parse", Date.parse, false);
    }
    if (!traitMethods.bind) {
      var bind = this.reference.bind;
      if (bind != Function.bind) {
        members.set("bind", bind);
      }
    }
    members.set("toString", this.reference.toString, true);
    members.sort();
    return members;
  },

  getClassProperties: function() {
    var type = this.type;
    return new Members(this, function(ref, name) {
      return !CONSTANT.test(name) && (typeof ref == "null" || typeof ref == "object" || isPrimitive(ref) || isBaseClass(ref) || ref == Object);
    });
  },

  getConstants: function() {
    return new Members(this, isConstant);
  },

  getEvents: function() {
    return new Members(this, function(ref, name) {
      return ref === null && /^(\w+:)?on[a-z]+$/.test(name);
    });
  },

  getInstanceMethods: function() {
    var reference = this.reference;
    if (reference == Date) {
      var proto = new Date;
      var members = new Reflection(proto).getMethods();
      forEach.csv(DATE_PROTOTYPE_METHODS, function(name) {
        members.set(name, proto[name], true);
      });
      members.set("toISOString", proto.toISOString, false);
      members.sort();
    } else {
      members = new Reflection(reference.prototype).getMethods();
    }
    return members;
  },

  getInstanceProperties: function() {
    var reference = this.reference;
    if (reference == Date) {
      var members = new Reflection(new Date).getProperties();
    } else {
      members = new Reflection(reference.prototype).getProperties();
    }
    return members;
  },

  getMembers: function() {
    var members = new Members(this);
    members.sort();
    return members;
  },

  getMethods: function() {
    var members = new Members(this, isFunction);
    if (this.type == "object" && this.reference == JSON) {
      members.set("parse", JSON.parse, false);
      members.set("stringify", JSON.stringify, false);
    }
    try {
      members.set("toString", this.reference.toString, true);
    } catch(e){}
    members.sort();
    return members;
  },

  getPackages: function() {
    return new Members(this, isPackage);
  },

  getProperties: function() {
    return new Members(this, function(ref, name) {
      return !(ref instanceof Function) && !(ref instanceof _.Package && name !== "parent") && !isConstant(ref, name) && !(ref === null && /^(\w+:)?on[a-z]+$/.test(name));
    });
  },

  getTraits: function() {
    return new Members(this, isTrait);
  },

  getTraitMethods: function() {
    var traitMethods = this.type == "trait" ? this.reference.prototype : {};
    var members = new Members(this, function(ref, name) {
      return !!traitMethods[name] && name != "base";
    });
    if (traitMethods.bind) {
      members.set("bind", this.reference.bind);
      members.sort();
    }
    return members;
  }
});

// =========================================================================
// MiniWeb/doc/package.js
// =========================================================================

var doc = MiniWeb.doc = new _.Package({
  name:    "MiniWeb.doc",
  version: "1.0(beta1)",
  
  show: {},
  
  getObject: function(objectID) {
    try {
      var refId = 'arguments[1]=' + String(objectID).replace(/::/, '.prototype.');
      refId = refId.split('.');
      if (refId.length > 1) {
        refId[refId.length - 2] += '["' + refId.pop() + '"]';
      }
      refId = refId.join('.');
      eval(refId);
    } catch (e){}
    return arguments[1];
  },

  colorize: function(pre) {
    var className = pre.className;
    if (className == "js") className = "javascript";
    var colorizer = colorize[className];
    
    if (colorizer) {
      colorizer.parseUrls = false;
      
      var textContent = dom.get(pre, 'textContent');

      // Convert tabs to spaces and then convert spaces to "&nbsp;".
      var indent = textContent.match(/\n(\s+)\}\s*$/);
      if (indent) {
        textContent = textContent.replace(new RegExp("\\n" + indent[1], "g"), "\n");
      }
      textContent = textContent.replace(/[ \t]*;;;[^\n]*\n/g, "");

      dom.classList.add(pre, "colorized");
      dom.classList.add(pre, "colorize-" + className);
      
      pre.innerHTML = colorizer.parse(textContent);
    }
  },
  
  Members: Members,
  Reflection: Reflection
});

// =========================================================================
// MiniWeb/doc/data.js
// =========================================================================

doc.data = {
  PATH: "/data/doc/entries/",
  
  exists: function(objectID, entry) {
    return MiniWeb.server.io.exists(this.makepath(objectID, entry));
  },

  makepath: function(objectID, entry) {
    return this.PATH + String(objectID).replace(/::/, ".prototype.").split(".").join("/") + "/#" + entry;
  },

  read: function(objectID, entry) {
    return MiniWeb.server.io.read(this.makepath(objectID, entry));
  },

  remove: function(objectID, entry) {
    return MiniWeb.server.io.remove(this.makepath(objectID, entry));
  },
  
  write: function(objectID, entry, value) {
    var io = MiniWeb.server.io;
    var names = objectID.replace(/::/, ".prototype.").split(".");
    for (var i = 1; i <= names.length; i++) {
      var path = this.PATH + names.slice(0, i).join("/");
      if (!io.isDirectory(path)) {
        io.mkdir(path);
      }
    }
    io.write(path + "/#" + entry, value);
  }
};

// =========================================================================
// colorize/colorize.js
// =========================================================================

base2.exec(function(_) { // begin: closure

var forEach = _.forEach;

var IGNORE = _.RegGrp.IGNORE;

var TAB  = /\t/g;
var TABS = /\n([\t \xa0]*)/g;

// Use a string to create the CHAR pattern.
// This protects against a bug in Safari 2.
// Finally, we need to separate the \uffff char (this is for Opera).
var CHAR = "\\w\u00a1-\ufffe\uffff";

var BLOCK_COMMENT = /\/\*[^*]*\*+([^\/][^*]*\*+)*\//;
var LINE_COMMENT  = /\/\/[^\r\n]*/;
var NUMBER        = /\b\-?(\d+\.\d+|\.\d+|\d+\.|\d+)([eE][-+]?\d+)?\b/;
var STRING1       = /'(\\\r?\n|\\.|[^'\\])*'/;
var STRING2       = /"(\\\r?\n|\\.|[^"\\])*"/;
var EMAIL         = /(mailto:)?([<#CHAR>.+-]+@[<#CHAR>.-]+\.[<#CHAR>]+)/;
var URL           = /https?:\/\/+[<#CHAR>\/\-%&#=.,?+$]+/;

var escape = new _.RegGrp([
  "<",       "\x01",
  ">",       "\x02",
  "&",       "\x03"
]);

var unescape = new _.RegGrp([
  "\x01",    "&lt;",
  "\x02",    "&gt;",
  "\x03",    "&amp;"
]);

var Colorizer = _.RegGrp.extend({
  constructor: function(dictionary, values, options) {
    _.extend(this, options);
    this.dictionary = new Colorizer.Dict(dictionary);
    this.base(values);
  },

  escapeChar: "",
  parseUrls: true,
  tabStop: 4,

  parse: function(text, tabSize) {
    var preParsed = !!arguments[2]; // Not a secondary parse of the text (e.g. CSS within an HTML sample).
    text = escape.parse(text);
    if (!preParsed && this.before) {
      text = this.before(text);
    }
    text = this.base(text);
    if (!preParsed) {
      // Convert tabs to spaces and then convert spaces to "&nbsp;".
      if (tabSize) {
        var tab = Array(tabSize + 1).join(" ");
        text = text.replace(TABS, tab);
      }
      if (this.parseUrls) text = urls.parse(text);
    }
    if (!preParsed && this.after) {
      text = this.after(text);
    }
    return unescape.parse(text);
  },
  
  set: function(pattern, replacement) {
    if (/^colorize\-/.test(replacement)) {
      replacement = '<span class="' + replacement + '">$1</span>';
    }
    return this.base(pattern, replacement);
  },

  "@MSIE[67]": {
    parse: function(text, tabSize) {
      return this.base.apply(this, arguments).replace(/\r?\n\r?\n/g, "<br>&nbsp;<br>");
    }
  },

  "@MSIE": {
    parse: function(text, tabSize) {
      return this.base.apply(this, arguments).replace(/[ \xa0]{2}/g, "&nbsp;&nbsp;").replace(/\r?\n/g, "<br>");
    }
  }
});

Colorizer.Dict = _.RegGrp.Dict.extend({
  parse: function(phrase) {
    return escape.parse(this.base(phrase));
  }
});

// ------------------------------------------------------
// Package.
// ------------------------------------------------------

var colorize = new _.Package({
  name:    "colorize",
  version: "1.0(beta1)"
}, {
  CHAR:          CHAR,
  BLOCK_COMMENT: BLOCK_COMMENT,
  LINE_COMMENT:  LINE_COMMENT,
  NUMBER:        NUMBER,
  STRING1:       STRING1,
  STRING2:       STRING2,
  
  Colorizer:     Colorizer,
  
  addScheme:     addScheme
});

window.colorize = colorize; // -@DRE

var RULE = "pre:not(.colorized).colorize-";

function addScheme(name, dictionary, values, options) {
  if (arguments.length == 2 && arguments[1] instanceof Colorizer) {
    var scheme = arguments[1];
  } else {
    scheme = new Colorizer(dictionary, values, options);
  }
  if (typeof jsb != "undefined") {
    new jsb.Rule(RULE + name, {
      "jsb:oncontentready": function(element) {
        var textContent = this.get(element, "textContent");
        element.innerHTML = scheme.parse(textContent);
        this.classList.add(element, "colorized");
      }
    });
  } else if (typeof jQuery != "undefined") {
    jQuery(function($) {
      $(RULE + name).each(function() {
        var textContent = $(this).text();
        this.innerHTML = scheme.parse(textContent);
        $(this).addClass("colorized");
      });
    });
  }
  colorize[name] = scheme;
  return scheme;
}

// ------------------------------------------------------
// URL parser.
// ------------------------------------------------------

var urls = new _.RegGrp({
  CHAR:   CHAR,
  EMAIL:  EMAIL,
  URL:    URL
}, {
  '<#EMAIL>': '<a href="mailto:$2">$1$2</a>',
  '(<#URL>)': '<a href="$1">$1</a>'
});

// ------------------------------------------------------
// JavaScript parser.
// ------------------------------------------------------

var javascript = addScheme("javascript", [
  "OPERATOR",      /[\[({\^<=>,:;&|!*?+-]/,
  "BLOCK_COMMENT", BLOCK_COMMENT,
  "LINE_COMMENT",  LINE_COMMENT,
  "COMMENT",       /<#BLOCK_COMMENT>|<#LINE_COMMENT>/,
  "NUMBER",        NUMBER,
  "STRING1",       STRING1,
  "STRING2",       STRING2,
  "STRING",        /<#STRING1>|<#STRING2>/,
  "CONDITIONAL",   /\/\*@if\s*\([^\)]*\)|\/\*@[^\r\n]*|@\*\/|@else[\s\w]*/, // conditional comments
  "GLOBAL",        /\b(__defineGetter__|__defineSetter__|__lookupGetter__|__lookupSetter__|clearInterval|clearTimeout|confirm|constructor|document|escape|hasOwnProperty|Infinity|isNaN|isPrototypeOf|NaN|parseFloat|parseInt|prompt|propertyIsArrayLike|prototype|setInterval|setTimeout|toString|toLocaleString|unescape|valueOf|window)\b/,
  "KEYWORD",       /\b(arguments|break|case|const|continue|default|delete|do|else|false|for|function|get|if|in|instanceof|let|new|null|return|set|switch|this|true|typeof|var|void|while|with|undefined|yield)\b/,
  "REGEXP",        /\/(\[(\\.|[^\n\]\\])+\]|\\.|[^\/\n\\])+\/[gim]*/,
  "SPECIAL",       /\b(assert\w*|alert|catch|console|debugger|eval|finally|throw|try)\b/
], [
  /\+\+|\-\-/, IGNORE,

  '(0[xX][\\dA-Fa-f]*)',
    'colorize-number',

  '(<#NUMBER>)',
    'colorize-number',

  "(<#OPERATOR>)(\\s*)(<#CONDITIONAL>)",
    '$1$2<span class="colorize-conditional-comment">$3</span>',

  "(<#OPERATOR>)(\\s*)(<#COMMENT>)",
    '$1$2<span class="colorize-comment">$3</span>',
    
  "(<#OPERATOR>)(\\s*)(<#REGEXP>)",
    '$1$2<span class="colorize-regexp">$3</span>',
    
  "\\b(return|typeof|instanceof|do)(\\s*)(<#REGEXP>)",
    '<span class="colorize-keyword">$1</span>$2<span class="colorize-regexp">$3</span>',

  '(<#CONDITIONAL>)',
    'colorize-conditional-comment',

  '(<#COMMENT>)',
    'colorize-comment',
    
  '(<#STRING>)',
    'colorize-string',
    
  '(<#GLOBAL>)',
    'colorize-global',
    
  '(<#KEYWORD>)',
    'colorize-keyword',
    
  '(<#SPECIAL>)',
    'colorize-special'
]);

// ------------------------------------------------------
// CSS parser.
// ------------------------------------------------------

var css = addScheme("css", {
  CHAR:              CHAR,
  AT_RULE:           /@\w[^;{]+/,
  BRACKETED:         /\([^'\x22)]*\)/,
  COMMENT:           BLOCK_COMMENT,
  PROPERTY:          /(\w[\w\-]*\s*):([^;}]+)/,
  VENDOR_SPECIFIC:   /(\-[\w\-]+\s*):([^;}]+)/,
  SELECTOR:          /([<#CHAR>:\[.#-](\\.|[^{\\])*)\{/
}, {
  '(<#AT_RULE>)':       'colorize-at_rule',
  '<#BRACKETED>':       IGNORE,
  '(<#COMMENT>)':       'colorize-comment',
  '<#PROPERTY>':        '<span class="colorize-property-name">$1</span>:<span class="colorize-property-value">$2</span>',
  '<#VENDOR_SPECIFIC>': '<span class="colorize-vendor-specific"><span class="colorize-property-name">$1</span>:<span class="colorize-property-value">$2</span></span>',
  '<#SELECTOR>':        '<span class="colorize-selector">$1</span>{'
}, {
  ignoreCase: true
});

// ------------------------------------------------------
// XML parser.
// ------------------------------------------------------

var xml = addScheme("xml", {
  CHAR:      CHAR,
  PI:        /<\?[^>]+>/,
  COMMENT:   /<!\s*(--([^-]|[\r\n]|-[^-])*--\s*)>/,
  CDATA:     /<!\[CDATA\[([^\]]|\][^\]]|\]\][^>])*\]\]>/,
  ENTITY:    /&(#\d+|\w+);/,
  TAG:       /(<\/?)([<#CHAR>\-]+(?:\:[<#CHAR>\-]+)?\s*)((?:\/[^>]|[^/>])*)(\/?>)/
}, {
  '(<#PI>)':      'colorize-processing-instruction',
  '(<#COMMENT>)': 'colorize-comment',
  '(<#CDATA>)':   'colorize-cdata',
  '(<#ENTITY>)':  'colorize-entity',
  
  '<#TAG>': function(match, openTag, tagName, attributes, closeTag) {
    return openTag + '<span class="colorize-tag">' + tagName + '</span>' + attr.parse(attributes) + closeTag;
  }
}, {
  ignoreCase: true,
  tabStop: 1
});

var attr = new _.RegGrp([
  "CHAR",      CHAR,
  "STRING1",   STRING1,
  "STRING2",   STRING2,
  "STRING",    /<#STRING1>|<#STRING2>/
], [
  '([<#CHAR>-]+)(?:(\\s*=\\s*)(<#STRING>))?', '<span class="colorize-attribute-name">$1</span>$2<span class="colorize-attribute-value">$3</span>'
]);

// ------------------------------------------------------
// HTML parser.
// ------------------------------------------------------

var html = xml.clone();

html.dictionary.merge({
  DOCTYPE:     /<!doctype[^>]+>/,
  CONDITIONAL: /<!(--)?\[[^\]]*\]>|<!\[endif\](--)?>/, // conditional comments
  BLOCK:       /(<)(script|style)([^>]*)(>)([^<]*)<\/\2>/
});

// Parse a script or style block.
html.insertAt(-1, "<#BLOCK>", parseBlock);

html.merge([
  '(<#DOCTYPE>)',     'colorize-doctype',
  '(<#CONDITIONAL>)', 'colorize-conditional-comment'
]);

function parseBlock(match, openTag, tagName, attributes, closeTag, cdata) {
  return openTag + '<span class="colorize-tag">' + tagName + '</span>' + attr.parse(attributes) + closeTag +
    cdata + openTag + '/<span class="colorize-tag">' + tagName + '</span>' + closeTag;
};

addScheme("html", html);

// ------------------------------------------------------
// HTML+CSS+JS parser.
// ------------------------------------------------------

addScheme("html_multi", html.union({
  '<#BLOCK>': function(match, openTag, tagName, attributes, closeTag, cdata) {
    var type = /style/i.test(tagName) ? "css" : "javascript";
    cdata = '<span class="colorize-' + type + ' colorize-block">' + colorize[type].parse(cdata, 0, true) + '</span>';
    return parseBlock(match, openTag, tagName, attributes, closeTag, cdata);
  }
}));

}); // end: closure

// =========================================================================
// colorize/base2.js
// =========================================================================

base2.exec(function(_) {
  var names = "base,implement".split(",");
  _.forEach(_, function(value, name) {
    if (name != "_") names.push(name);
  });
  names = "\\b(" + names.join("|") + ")\\b";
  var javascript = colorize.javascript;
  javascript.add(names, '<span class="base2">$1</span>');
  javascript.add("\\b(behavior)\\b", '<span class="jsb-behavior">$1</span>');
  javascript.insertAt(0, /("@[^"]+"):/, '<span class="colorize-special">$1</span>:');
  javascript.tabStop = 2;
});

// =========================================================================
// MiniWeb/doc/init.js
// =========================================================================

jsb.element = jsb.element.extend();

base2["#name"] = "base2";
//jsb["#name"] = "jsb";
base2.Base["#name"] = "base2.Base";
window["#name"] = "window";
FormData["#name"] = "FormData";
XMLHttpRequest2["#name"] = "XMLHttpRequest2";

window["namespace"] = base2.exec(function(_) {
  var ns = {};
  for (var i in _) ns[i] = _[i];
  delete ns._;
  ns.toString = _.toString;
  return ns;
});

process(base2, "base2");
process(jsb, "jsb");
forEach (base2, process);
forEach (jsb, process);

function process(property, name) {
  if (property instanceof Function || (!doc.show[name] && property instanceof base2.Package)) {
    if (property instanceof base2.Package) {
      property["#name"] = property.name;
      doc.show[name] = true;
      forEach (property, function(object, name) {
        if (typeof object == "function" && !object["#name"]) {
          object["#name"] = property["#name"] + "." + name;
        } else {
          process(object, name);
        }
      });
    } else if (typeof property == "function" && base2.Trait.ancestorOf(property)) {
      forEach (property["#implements"], function(trait) {
        forEach (trait, function(method, name) {
          if (!base2.Trait[name] && typeof method == "function" && property[name]) {
            property[name]._trait = trait;
            var protoMethod = property.prototype[name];
            if (protoMethod) protoMethod._trait = trait;
          }
        });
      });
    } else if (typeof property == "function" && base2.Collection.ancestorOf(property)) {
      var Item = property.Item;
      if (Item && !Item["#name"]) {
        Item['#name'] = property['#name'] + ".Item";
      }
      if (property == base2.RegGrp) {
        property.Dict['#name'] = property['#name'] + ".Dict";
      }
    }
  }
}

doc.show.io = false;
doc.show.jst = false;

var events = (
  "mousedown|mouseup|mousemove|mouseenter|mouseleave|mouseover|mouseout|mousewheel|click|dblclick|" +
  "touchstart|touchmove|touchend|touchcancel|" +
  "keydown|keyup|input|" +
  "change|reset|submit|" +
  "focus|blur|scroll|select"
).split("|").sort();

forEach (events, function(name) {
  jsb.element["on" + name] = null;
});

events = "attach|contentready|documentready|losecapture|transitionend".split("|");

forEach (events, function(name) {
  jsb.element["jsb:on" + name] = null;
});

//jsb.element["capture:onblur"] = null;
//jsb.element["capture:onfocus"] = null;
jsb.element["window:onresize"] = null;

}); // end: closure
