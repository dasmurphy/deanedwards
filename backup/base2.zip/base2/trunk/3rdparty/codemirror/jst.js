
CodeMirror.defineMode("jst-js", function(config) {
  return CodeMirror.multiplexingMode(
    CodeMirror.getMode(config, "javascript"), {
      open: "<%=",
      close: "%>",
      mode: CodeMirror.getMode(config, "javascript"),
      delimStyle: "jst-view"
    }, {
      open: "<%",
      close: "%>",
      mode: CodeMirror.getMode(config, "javascript"),
      delimStyle: "jst-view"
    }, {
      open: '/*@',
      close: "@*/",
      mode: CodeMirror.getMode(config, "javascript"),
      delimStyle: "js-conditional"
    });
});

CodeMirror.defineMode("jst-css", function(config) {
  return CodeMirror.multiplexingMode(
    CodeMirror.getMode(config, "css"), {
      open: "<%=",
      close: "%>",
      mode: CodeMirror.getMode(config, "javascript"),
      delimStyle: "jst-view"
    }, {
      open: "<%",
      close: "%>",
      mode: CodeMirror.getMode(config, "javascript"),
      delimStyle: "jst-view"
    });
});

CodeMirror.defineMode("jst-html", function(config) {
  return CodeMirror.multiplexingMode(
    CodeMirror.getMode(config, "htmlmixed"), {
      open: "<%=",
      close: "%>",
      mode: CodeMirror.getMode(config, "javascript"),
      delimStyle: "jst-view"
    }, {
      open: "<%",
      close: "%>",
      mode: CodeMirror.getMode(config, "javascript"),
      delimStyle: "jst-view"
    }, {
      open: '<pre class="css">',
      close: "</pre>",
      mode: CodeMirror.getMode(config, "css"),
      delimStyle: "html-view"
    }, {
      open: "<pre class=css>",
      close: "</pre>",
      mode: CodeMirror.getMode(config, "css"),
      delimStyle: "html-view"
    }, {
      open: '<pre class="js">',
      close: "</pre>",
      mode: CodeMirror.getMode(config, "javascript"),
      delimStyle: "html-view"
    }, {
      open: "<pre class=js>",
      close: "</pre>",
      mode: CodeMirror.getMode(config, "javascript"),
      delimStyle: "html-view"
    }, {
      open: '<pre class="html">',
      close: "</pre>",
      mode: CodeMirror.getMode(config, "xml"),
      delimStyle: "html-view"
    }, {
      open: "<pre class=html>",
      close: "</pre>",
      mode: CodeMirror.getMode(config, "xml"),
      htmlMode: true,
      delimStyle: "html-view"
    }, {
      open: '<pre class="xml">',
      close: "</pre>",
      mode: CodeMirror.getMode(config, "xml"),
      htmlMode: true,
      delimStyle: "html-view"
    }, {
      open: "<pre class=xml>",
      close: "</pre>",
      mode: CodeMirror.getMode(config, "xml"),
      delimStyle: "html-view"
    });
});

CodeMirror.defineMIME("text/javascript", "jst-js");
CodeMirror.defineMIME("text/css", "jst-css");
CodeMirror.defineMIME("text/html", "jst-html");
