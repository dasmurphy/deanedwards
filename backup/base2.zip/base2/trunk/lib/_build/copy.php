<?php

$HOST = 'http://rekky.rosso.name/base2/trunk/src/build.php?';
$SRC  = $HOST.'src=';
$PKG  = $HOST.'package=';

$PACKAGES = Array(
	'base2.js',
	'base2-dom.js',
	'base2-jsb.js',
	
	'base2/dom.js',
	'base2/EventTarget.js',
	'base2/io.js',
	'base2/jst.js',

	'XMLHttpRequest2.js',

	'jsb.js',
	'jsb/chrome.js',
	'jsb/rm.js'
);

file_put_contents('../../doc/miniweb.js', file_get_contents($SRC.'MiniWeb.js&build=true'));
file_put_contents('../../doc/doc.js', file_get_contents($SRC.'MiniWeb/doc.js&build=true'));
foreach ($PACKAGES as $package) {
	file_put_contents('../src/'.$package, file_get_contents($SRC.$package.'&build=true'));
}
file_put_contents('../src/lite/base2.js', file_get_contents($PKG.'base2/lite.json&build=true'));
file_put_contents('../src/lite/base2-dom.js', file_get_contents($PKG.'base2/dom/lite.json&full=true&build=true'));
file_put_contents('../src/lite/base2-jsb.js', file_get_contents($PKG.'jsb/lite.json&full=true&build=true'));

?>
