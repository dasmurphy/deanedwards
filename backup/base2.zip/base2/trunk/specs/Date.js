
var NativeDate = Date;

base2.require("Date", function(_, Date) {
  describe('Date', {
    'Should construct from date': function() {
      var today = new NativeDate;
      value_of(new Date(today).valueOf()).should_be(today.valueOf());
    },

    'Should construct from number': function() {
      var today = new NativeDate;
      value_of(new Date(today.valueOf()).valueOf()).should_be(today.valueOf());
    },

    'Should construct from ISO string': function() {
      value_of(new Date("1999-01-01T00:00:00.000Z").valueOf()).should_be(NativeDate.UTC(1999, 0, 1));
    },

    'Should construct with 3 or more arguments': function() {
      value_of(new Date(1999, 0, 1).valueOf()).should_be(new NativeDate(1999, 0, 1).valueOf());
      value_of(new Date(1999, 0, 1, 1).valueOf()).should_be(new NativeDate(1999, 0, 1, 1).valueOf());
    },

    'Should return string date when not used as a constructor': function() {
      value_of(typeof Date(new NativeDate)).should_be("string");
    }
  });

  describe('Date.parse', {
    'Should parse ISO string to number (milliseconds since the epoch (1st Jan 1970))': function() {
      value_of(Date.parse("1999-01-01T00:00:00.000Z")).should_be(NativeDate.UTC(1999,0,1));
    }
  });

  describe('Date.now', {
    'Should return current elapsed time in milliseconds since the epoch (1st Jan 1970)': function() {
      var now1 = Date.now();
      var now2 = new NativeDate().valueOf()
      value_of(now1).should_be(now2);
    }
  });

  describe('Date::toISOString', {
    'Should convert to ISO string': function() {
      value_of(new Date(NativeDate.UTC(2001, 0, 1)).toISOString()).should_be("2001-01-01T00:00:00.000Z");
    }
  });
});