
base2.require("base2.dom", function(_, dom) {
  dom.bind(document);
  
  var button = document.createElement("button");
  var element = document.createElement("div");
  element.style.width = "100px";
  
  describe('bound element', {
    "Should support contains": function() {
      document.body.appendChild(element);
      value_of(document.body.contains(element)).should_be(true);
      value_of(element.contains(document.body)).should_be(false);
    },

    "Should support addEventListener": function() {
      document.body.appendChild(button);
      var clickCount = 0;
      var listen = function(event) {
        clickCount++;
      };
      button.addEventListener("click", listen, false);
      button.click();
      value_of(clickCount).should_be(1);
    },

    "Should support dispatchEvent": function() {
      var clickCount = 0;
      var listen = function(event) {
        clickCount++;
      };
      button.addEventListener("click", listen, false);
      var event = document.createEvent("MouseEvent");
      event.initMouseEvent("click", true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
      button.dispatchEvent(event);
      value_of(clickCount).should_be(1);
    },

    "Should support removeEventListener": function() {
      var clickCount = 0;
      var listen = function(event) {
        clickCount++;
      };
      
      button.addEventListener("click", listen, false);
      button.click();
      
      button.removeEventListener("click", listen, false);
      button.click();
      
      value_of(clickCount).should_be(1);
      
      document.body.removeChild(button);
    },

    "Should support getBoundingClientRect": function() {
      var rect = element.getBoundingClientRect();
      value_of(rect.right - rect.left).should_be(100);
    },

    "Should support classList.contains": function() {
      element.className = "test1";
      value_of(element.classList.contains("test")).should_be(false);
      value_of(element.classList.contains("test1")).should_be(true);
    },

    "Should support classList.add": function() {
      element.classList.add("test2");
      value_of(element.className).should_be("test1 test2");
    },

    "Should support classList.remove": function() {
      element.classList.remove("test2");
      value_of(element.className).should_be("test1");
    },

    "Should support classList.toggle": function() {
      element.classList.toggle("test1");
      value_of(element.className).should_be("");
      element.classList.toggle("test1");
      value_of(element.className).should_be("test1");
    },

    "classList object should be preserved": function() {
      var classList = element.classList;
      value_of(element.classList).should_be(classList);
    },

    "Should support hasAttribute": function() {
      value_of(element.hasAttribute("id")).should_be(false);
    },

    "Should support getAttribute": function() {
      value_of(element.getAttribute("id")).should_be(null);
    },

    "Should support setAttribute": function() {
      element.setAttribute("id", "example");
      value_of(element.id).should_be("example");
    },

    "Should support removeAttribute": function() {
      element.id = "test";
      element.removeAttribute("id");
      value_of(element.id).should_be("");
    },

    "Should support querySelector": function() {
      element.innerHTML = "<p>Hello.</p><p>Hello.</p><p>Hello.</p>";
      value_of(element.querySelector("p")).should_be(element.firstChild);
    },

    "Should support querySelectorAll": function() {
      value_of(element.querySelectorAll("p").length).should_be(3);
    },

    "Should support matchesSelector": function() {
      value_of(element.matchesSelector("div")).should_be(true);
      document.body.removeChild(element);
    }

  });

});
