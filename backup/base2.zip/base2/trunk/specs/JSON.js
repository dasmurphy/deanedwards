
base2.require("JSON", function(_, JSON) {
  describe('JSON.stringify', {
    'Should stringify booleans': function() {
      value_of(JSON.stringify(true)).should_be("true");
      value_of(JSON.stringify(false)).should_be("false");
    },

    'Should stringify numbers': function() {
      value_of(JSON.stringify(0)).should_be("0");
      value_of(JSON.stringify(1)).should_be("1");
      value_of(JSON.stringify(0.0)).should_be("0");
      value_of(JSON.stringify(-1)).should_be("-1");
      value_of(JSON.stringify(12345)).should_be("12345");
      value_of(JSON.stringify(-12345)).should_be("-12345");
      value_of(JSON.stringify(1.2345)).should_be("1.2345");
      value_of(JSON.stringify(-1.2345)).should_be("-1.2345");
      //can't be sure which power of ten the js-engine chooses
      value_of(parseFloat(JSON.stringify(12.34567e89))).should_be(12.34567e89);
      value_of(parseFloat(JSON.stringify(-12.34567e-89))).should_be(-12.34567e-89);
      value_of(JSON.stringify(1/0)).should_be("null");
      value_of(JSON.stringify(-1/0)).should_be("null");
      value_of(JSON.stringify(Number.NEGATIVE_INFINITY)).should_be("null");
      value_of(JSON.stringify(Number.POSITIVE_INFINITY)).should_be("null");
      value_of(JSON.stringify(Number.NaN)).should_be("null");
    },

    'Should stringify strings': function() {
      function quote(s) { return '"'+s+'"'; } //we test agains double quotes
      value_of(JSON.stringify("")).should_be(quote(""));
      value_of(JSON.stringify("test")).should_be(quote("test"));
      value_of(JSON.stringify("I said: 'quiet'!")).should_be(quote("I said: 'quiet'!"));
      value_of(JSON.stringify("I said: \"quiet\"!")).should_be(quote('I said: \\"quiet\\"!'));
      try {
        value_of(JSON.stringify("Line1\nLine2\nLine3")).should_be(quote("Line1\\u000aLine2\\u000aLine3"));
        value_of(JSON.stringify("Line1\rLine2\rLine3")).should_be(quote("Line1\\u000dLine2\\u000dLine3"));
        value_of(JSON.stringify("Line1\n\rLine2\r\nLine3")).should_be(quote("Line1\\u000a\\u000dLine2\\u000d\\u000aLine3"));
        value_of(JSON.stringify("Column1\tColumn2")).should_be(quote("Column1\\u0009Column2"));
        value_of(JSON.stringify("Form1\fForm2")).should_be(quote("Form1\\u000cForm2"));
        value_of(JSON.stringify("Delete\b\b\b\b\b\bBackspace")).should_be(quote("Delete\\u0008\\u0008\\u0008\\u0008\\u0008\\u0008Backspace"));
        value_of(JSON.stringify("\x08")).should_be(quote("\\u0008"));
        value_of(JSON.stringify("\x09")).should_be(quote("\\u0009"));
        value_of(JSON.stringify("\x0a")).should_be(quote("\\u000a"));
        value_of(JSON.stringify("\x0c")).should_be(quote("\\u000c"));
        value_of(JSON.stringify("\x0d")).should_be(quote("\\u000d"));
      } catch (x) {
        value_of(JSON.stringify("Line1\nLine2\nLine3")).should_be(quote("Line1\\nLine2\\nLine3"));
        value_of(JSON.stringify("Line1\rLine2\rLine3")).should_be(quote("Line1\\rLine2\\rLine3"));
        value_of(JSON.stringify("Line1\n\rLine2\r\nLine3")).should_be(quote("Line1\\n\\rLine2\\r\\nLine3"));
        value_of(JSON.stringify("Column1\tColumn2")).should_be(quote("Column1\\tColumn2"));
        value_of(JSON.stringify("Form1\fForm2")).should_be(quote("Form1\\fForm2"));
        value_of(JSON.stringify("Delete\b\b\b\b\b\bBackspace"), quote("Delete\\b\\b\\b\\b\\b\\bBackspace"));
        value_of(JSON.stringify("\x08")).should_be(quote("\\b"));
        value_of(JSON.stringify("\x09")).should_be(quote("\\t"));
        value_of(JSON.stringify("\x0a")).should_be(quote("\\n"));
        value_of(JSON.stringify("\x0c")).should_be(quote("\\f"));
        value_of(JSON.stringify("\x0d")).should_be(quote("\\r"));
      }
      value_of(JSON.stringify("\x00")).should_be(quote("\\u0000"));
      value_of(JSON.stringify("\x01")).should_be(quote("\\u0001"));
      value_of(JSON.stringify("\x02")).should_be(quote("\\u0002"));
      value_of(JSON.stringify("\x03")).should_be(quote("\\u0003"));
      value_of(JSON.stringify("\x04")).should_be(quote("\\u0004"));
      value_of(JSON.stringify("\x05")).should_be(quote("\\u0005"));
      value_of(JSON.stringify("\x06")).should_be(quote("\\u0006"));
      value_of(JSON.stringify("\x07")).should_be(quote("\\u0007"));
      //Hexadecimal unicode test depends on Number.toString(16) is in lowercase
      value_of(JSON.stringify("\x0b")).should_be(quote("\\u000b"));
      value_of(JSON.stringify("\x0e")).should_be(quote("\\u000e"));
      value_of(JSON.stringify("\x0f")).should_be(quote("\\u000f"));
      value_of(JSON.stringify("\x10")).should_be(quote("\\u0010"));
      value_of(JSON.stringify("\x11")).should_be(quote("\\u0011"));
      value_of(JSON.stringify("\x12")).should_be(quote("\\u0012"));
      value_of(JSON.stringify("\x13")).should_be(quote("\\u0013"));
      value_of(JSON.stringify("\x14")).should_be(quote("\\u0014"));
      value_of(JSON.stringify("\x15")).should_be(quote("\\u0015"));
      value_of(JSON.stringify("\x16")).should_be(quote("\\u0016"));
      value_of(JSON.stringify("\x17")).should_be(quote("\\u0017"));
      value_of(JSON.stringify("\x18")).should_be(quote("\\u0018"));
      value_of(JSON.stringify("\x19")).should_be(quote("\\u0019"));
      value_of(JSON.stringify("\x1a")).should_be(quote("\\u001a"));
      value_of(JSON.stringify("\x1b")).should_be(quote("\\u001b"));
      value_of(JSON.stringify("\x1c")).should_be(quote("\\u001c"));
      value_of(JSON.stringify("\x1d")).should_be(quote("\\u001d"));
      value_of(JSON.stringify("\x1e")).should_be(quote("\\u001e"));
      value_of(JSON.stringify("\x1f")).should_be(quote("\\u001f"));
    },

    'Should stringify dates': function() {
      function d() { return new Date(Date.UTC.apply(this, arguments)); }
      function quote(s) { return '"'+s+'"'; }
      value_of(JSON.stringify(d(1972,11-1,14))).should_be(quote("1972-11-14T00:00:00.000Z"));
      value_of(JSON.stringify(d(2007,07-1,28,0,28,10))).should_be(quote("2007-07-28T00:28:10.000Z"));
    },

    'Should stringify arrays': function() {
      value_of(JSON.stringify([]), "[]");
      value_of(JSON.stringify([1,2,3,4])).should_be("[1,2,3,4]");
      value_of(JSON.stringify(new Array(2))).should_be("[null,null]");
      value_of(JSON.stringify([void 0,1,undefined,2,void true])).should_be("[null,1,null,2,null]");
      value_of(JSON.stringify(new Array(0,1,2,3))).should_be("[0,1,2,3]");
      value_of(JSON.stringify([[1,2,[3]],[3,[2],1]])).should_be('[[1,2,[3]],[3,[2],1]]');
      value_of(JSON.stringify([[[[[[true]]]]]])).should_be('[[[[[[true]]]]]]');
    },

    'Should stringify objects': function() {
      value_of(JSON.stringify({})).should_be("{}");
      value_of(JSON.stringify({a:1})).should_be('{"a":1}');
      value_of(JSON.stringify({a:1,b:2,c:3})).should_be('{"a":1,"b":2,"c":3}');
      value_of(JSON.stringify({'while':1,'wend':void 0})).should_be('{"while":1}');
      value_of(JSON.stringify({'while':1,'wend':2,loop:3})).should_be('{"while":1,"wend":2,"loop":3}');
      value_of(JSON.stringify({"§±!@#$%^&*()_+=-[]}{:\"|';,./?><~`™}":1})).should_be("{\"§±!@#$%^&*()_+=-[]}{:\\\"|';,./?><~`™}\":1}");
      value_of(JSON.stringify({a:{b:{c:{d:{e:{f:true}}}}}})).should_be('{"a":{"b":{"c":{"d":{"e":{"f":true}}}}}}');
    },

    'Should stringify null but not undefined': function() {
      value_of(JSON.stringify(null)).should_be("null");
      value_of(JSON.stringify(void 0)).should_be(undefined);
    }
  });
});