
base2.exec(function(_) {
  describe('Functional', {
    'Should NOT cast null': function() {
      var err = false;
      try {
        _.Functional(null);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },
    
    'Should cast functions': function() {
      var fn = _.Functional(function(){});
      value_of(typeof fn.partial).should_be("function");
    },

    'Should NOT cast objects': function() {
      var err = false;
      try {
        _.Functional({});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    }
  });
  
  describe('Functional.bind', {
    'Should throw if first argument is not a function': function() {
      var err = false;
      try {
        var fn = _.bind();
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should bind a function to an object': function() {
      var obj = {
        a: 99,
        test: function() {
          return this.a;
        }
      }
      var fn = _.bind(obj.test, obj);
      value_of(fn()).should_be(99);
    },

    'Should pass supplied arguments': function() {
      var obj = {
        a: 1,
        test: function(a, b, c) {
          return _.slice(arguments).join("");
        }
      }
      var fn = _.bind(obj.test, obj, 1, 2, 3);
      value_of(fn()).should_be("123");
    },

    'Should pass all additional arguments': function() {
      var obj = {
        a: 1,
        test: function(a, b, c) {
          return _.slice(arguments).join("");
        }
      }
      var fn = _.bind(obj.test, obj, 1, 2);
      value_of(fn(3)).should_be("123");
    }
  });

  /*
  describe('Functional.compose', {
    'Should throw if first argument is not a function': function() {
      var err = false;
      try {
        var fn = _.compose();
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'All arguments should be functions': function() {
      var err = false;
      try {
        var fn = _.compose(function(){}, 1);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Composed functions must be functionally equivalent': function() {
      // compose(a, b, c)() === c(b(a()))
      function addWorld(word) {
        return word + " World!";
      }
      function reverse(word) {
        return word.split("").reverse().join("");
      }
      function toUpperCase(word) {
        return word.toUpperCase();
      }
      var composed = _.compose(reverse, addWorld, toUpperCase);
      value_of(composed("olleH")).should_be(toUpperCase(addWorld(reverse("olleH"))));
    }
  });
  */
  
  describe('Functional.flip', {
    'Should throw if first argument is not a function': function() {
      var err = false;
      try {
        var fn = _.flip();
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },
    
    'Should swap first two arguments': function() {
      var flipped = _.flip(function() {
        return _.slice(arguments).join("");
      });
      
      value_of(flipped(1,2,3)).should_be("213");
    }
  });

  describe('Functional.not', {
    'Should throw if first argument is not a function': function() {
      var err = false;
      try {
        var fn = _.not();
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should negate the return value of a function': function() {
      value_of(_.not(_.False)()).should_be(true);
      value_of(_.not(_.True)()).should_be(false);
    }
  });

  describe('Functional.partial', {
    'Should throw if first argument is not a function': function() {
      var err = false;
      try {
        var fn = _.partial();
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should partially evaluate a function': function() {
      var test = function(a, b, c) {
        return _.slice(arguments).join("");
      };
      var test_a1 = _.partial(test, 1);
      value_of(test_a1(2,3)).should_be("123");
    },

    'Should use undefined as a placeholder': function() {
      var test = function(a, b, c) {
        return _.slice(arguments).join("");
      };
      var test_b2 = _.partial(test, undefined, 2);
      value_of(test_b2(1,3)).should_be("123");
    },

    'Should allow repeated partial evaulations': function() {
      var test = function(a, b, c) {
        return _.slice(arguments).join("");
      };
      
      var test_b2 = _.partial(test, undefined, 2);
      var test_b2c3 = _.partial(test_b2, undefined, 3);
      value_of(test_b2c3(1)).should_be("123");
    }
  });

  describe('Functional.unbind', {
    'Should throw if first argument is not a function': function() {
      var err = false;
      try {
        var fn = _.unbind();
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should unbind a method from an object': function() {
      var slice = _.unbind([].slice);
      var test = function() {
        return slice(arguments, 1, -1).join("");
      };
      value_of(test(1,2,3,4,5)).should_be("234");
    }
  });
});