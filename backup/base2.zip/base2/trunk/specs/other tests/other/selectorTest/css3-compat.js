/*
 * NWMatcher test for CSS3 3 Selectors
 * Copyright (C) 2010 Diego Perini
 * All rights reserved
 */

(function(global, engines) {

  var version = '0.1',

  // document reference
  d = global.document,

  // root element reference
  root = d.documentElement,

  // default engine to be used
  defaultEngine = engines ? engines[0] || null : null,

  // global variables shared by methods
  param, select,

  getQueryParam =
    function(key, defaultValue) {
      var pattern = new RegExp('[?&]' + key + '=([^&#]+)');
      return (global.location.href.match(pattern) || [0, defaultValue])[1];
    },

  refresh =
    function() {
      var loc = global.location;
      loc.href = loc.protocol + '//' + loc.hostname + loc.pathname +
        '?engine=' + select.options[select.selectedIndex].text;
    },

  change =
    function(options, value) {
      var i = -1, option;
      while ((option = options[++i])) {
        if (option.text == value) {
          options[0].parentNode.selectedIndex = i;
          break;
        }
      }
    },

  // transform (p)roperty name to hyphenated format (font-size, line-height)
  hyphenate =
    function(p) {
      return p.replace(/([A-Z])/g,
        function(m, c) {
          return '-'+c.toLowerCase();
        });
    },

  // transform (p)roperty name to camelized format (fontSize, lineHeight)
  camelize =
    function(p) {
      return p.replace(/-([a-z])/g,
        function(m, c) {
          return c.toUpperCase();
        });
    },

  // get computed style (p)roperty value for (o)bject,
  // may be an element or style rule declaration
  getStyle = root.style.Property ?
    function(o, p) {
      return (o.ownerDocument || o.document).
        defaultView.getComputedStyle(o, '').
        getPropertyValue(hyphenate(p));
    } :
    function(o, p) {
      return o.style[camelize(p)];
    },

  // set properties values on the element
  addStyle =
    function(element, style) {
      var i = 0, items = style.match(/([a-zA-Z][^;]+)/g), length = items.length, parts;
      for (; length > i; ++i) {
        parts = items[i].match(/\s*(.*)\s*:\s*(.*)\s*/);
        setStyle(element, parts[1], parts[2]);
      }
    },

  // set computed style property value for object,
  // may be an element or style rule declaration
  // (o)bject, (p)roperty, (v)alue, [priorit(y)]
  setStyle = root.style.setProperty ?
    function(o, p, v, y) {
      p = p.replace(/^\s+|\s+$/g, '');
      return o.style.setProperty(hyphenate(p), v.replace(/^\s+|\s+$/g, ''), y || '');
    } :
    function(o, p, v, y) {
      p = p.replace(/^\s+|\s+$/g, '');
      if (p == 'float') p = 'styleFloat';
      return o.style[camelize(p)] = v.replace(/^\s+|\s+$/g, '');
    },

  setStyleRule =
    function(selectorText, cssText, engine) {

      var j, elements = [ ];

      // some engine will throw errors and stop processing
      // so we added a try/catch block around those failing
      switch(engine) {
        case 'querySelectorAll':
          try { elements = d.querySelectorAll(selectorText); } catch(e) { }
          break;
        case 'nwmatcher':
          elements = NW.Dom.select(selectorText);
          break;
        case 'sizzle':
          try { elements = jQuery(selectorText); } catch(e) { }
          break;
        case 'base2':
          try { elements = base2.dom.querySelectorAll(document, selectorText); } catch(e) { }
          break;
        case 'slick':
          try { elements = Slick(document, selectorText); } catch(e) { }
          break;
        case 'mylib':
          try { elements = API.getEBCS(selectorText); } catch(e) { }
          break;
        case 'dojo':
          elements = dojo.query(selectorText);
          break;
        case 'ext':
          try { elements = Ext.DomQuery.select(selectorText); } catch(e) { }
          break;
        case 'yui':
          elements = YAHOO.util.Selector.query(selectorText);
          break;
        default:
          break;
      }

      for (j = 0; elements.length > j; j++) {
        addStyle(elements[j], cssText);
      }

    };

  cleanDOM =
    function(node) {
      var next, val;
      while (node) {
        next = node.nextSibling;
        if (node.nodeType == 1 && node.firstChild) {
          cleanDOM(node.firstChild);
        } else if (node.nodeType == 3) {
          val = node.nodeValue.replace(/\s+/g, ' ');
          if (val == ' ' && node != node.parentNode.childNodes[0]) {
            node.parentNode.removeChild(node);
          }
        } else if (node.nodeName.charCodeAt(0) < 65) {
          node.parentNode.removeChild(node);
        }
        node = next;
      }
    },

  addSelectBox =
    function() {
      var i, select = d.createElement('select');

      for (i = 0; engines.length > i; i++) {
        select.appendChild(d.createElement('option')).
          appendChild(d.createTextNode(engines[i]));
      }

      d.body.insertBefore(select, d.body.firstChild);
      d.body.insertBefore(d.createElement('b'), d.body.firstChild).
        appendChild(d.createTextNode('Choose selector engine\xa0'));

      param = getQueryParam('engine', defaultEngine);
      change(select.options, param);
      select.onchange = refresh;

      return select;
    },

  global.onload =
    function() {

      // fix empty/comments test
      cleanDOM(root);

      // add engines select box
      select = addSelectBox();

      location.hash = "target";

      var style = (d.getElementById("teststyle")||d.getElementsByTagName("style")[0]).innerHTML,
          i, items, rules = style.match(/\s*(.*)\s*\{\s*(.*)\s*\}/g),
          length = rules.length;

      if (param == 'querySelectorAll' && typeof d.querySelectorAll == 'undefined') {
        alert('This browser do not support Query Selectors API !!!\n' +
          'The stylesheet will be loaded from an external css file.');
        var head, link;
        head = d.getElementsByTagName('head')[0] || root;
        link = d.createElement('link');
        link.href = 'css3-compat.css';
        link.rel = 'stylesheet';
        link.type = 'text/css';
        head.appendChild(link);
      } else {
        for (i = 0; length > i; i++) {
          items = rules[i].match(/\s*(.*)\s*{\s*(.*)\s*}/);
          setStyleRule(items[1] , items[2], param);
        }
      }

    };

})(this, ['querySelectorAll', 'nwmatcher', 'sizzle', 'base2', 'slick', 'mylib', 'dojo', 'ext', 'yui']);
