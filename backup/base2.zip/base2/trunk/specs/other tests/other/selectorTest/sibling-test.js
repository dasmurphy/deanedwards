/*
 * NWMatcher test for CSS3 3 Selectors
 * Copyright (C) 2010 Diego Perini
 * All rights reserved
 */

var CDN = 'http://ajax.googleapis.com/ajax/libs/',

// order is:
//  * working CSS3 engines
//  * CDN hosted frameworks
//  * other selector engines
engines = {
  'querySelectorAll': [ 'document.querySelectorAll(s)',    '' ],
  'nwmatcher':        [ 'NW.Dom.select(s)',                'lib/nwmatcher.js' ],
  'base2':            [ 'base2.dom.querySelectorAll(c,s)', '/base2/trunk/src/base2-dom.js' ],
  'domassistant':     [ '$(s)',                            'lib/domass.js' ],
  'dojo':             [ 'dojo.query(s)',                   CDN + 'dojo/1.4.1/dojo/dojo.xd.js' ],
  'ext':              [ 'Ext.DomQuery.select(s)',          CDN + 'ext-core/3.1.0/ext-core.js' ],
  'jquery':           [ '$(s)',                            CDN + 'jquery/1.4.2/jquery.min.js' ],
  'mootools':         [ '$$(s)',                           CDN + 'mootools/1.2.4/mootools.js' ],
  'prototype':        [ '$$(s)',                           CDN + 'prototype/1.6.1.0/prototype.js' ],
  'mylib':            [ 'API.getEBCS(s)',                  'lib/mylib-qsa-min.js' ],
  'yass':             [ '_(s)',                            'lib/yass.0.3.9.js' ],
  'slick':            [ 'Slick.search(c,s)',               'lib/slick.js' ],
  'yui':              [ 'Y.Selector.query(s)',             'lib/yui3.js' ],
  'sly':              [ 'Sly.search(s)',                   'lib/sly.js' ]
};

(function(global, engines) {

  var version = '0.1',

  // document reference
  doc = global.document,

  // root element reference
  root = doc.documentElement,

  // head element reference to add scripts
  head = doc.getElementsByTagName('head')[0] || root,

  // default selector engine to use on page load
  // and common global variables shared by methods
  defaultEngine = 'querySelectorAll', engine, script, select,

  // get URL parameters from query string
  getQueryParam =
    function(key, defaultValue) {
      var pattern = new RegExp('[?&]' + key + '=([^&#]+)');
      return (global.location.href.match(pattern) || [0, defaultValue])[1];
    },

  // refresh replacing current history entry
  refresh =
    function() {
      var loc = global.location;
      loc.replace(loc.protocol + '//' + loc.hostname + loc.pathname +
        '?engine=' + select.options[select.selectedIndex].text);
    },

  // trap change event on engines select box
  change =
    function(options, value) {
      var i = 0, option;
      while ((option = options[i])) {
        if (option.text == value) {
          options[0].parentNode.selectedIndex = i;
          break;
        }
        ++i;
      }
    },

  // add engine selection box atop the page
  addSelectBox =
    function() {
      var i, select = doc.createElement('select');

      for (i in engines) {
        select.appendChild(doc.createElement('option')).
          appendChild(doc.createTextNode(i));
      }

      if (doc.body) {
        doc.body.insertBefore(select, doc.body.firstChild);
        doc.body.insertBefore(doc.createElement('b'), doc.body.firstChild).
          appendChild(doc.createTextNode('Choose selector engine\xa0'));

        param = getQueryParam('engine', defaultEngine);
        change(select.options, param);
        select.onchange = refresh;
      }

      return select;
    };

  // CSS3 Selectors Tests
  startTest =
    function() {
      if (startTest.alreadyRun) return;
      startTest.alreadyRun = true;

      var i = 1, j = 1, l, resolver,
      elements, items, selector, types,
	  operators = { '+': ' >+~', '~': ' >+~' };

      if (engine == 'querySelectorAll' &&
        typeof doc.querySelectorAll == 'undefined') {
        return;
      }

      for (types in operators) {
        items = operators[types].split('');
        for (i = 1, l = items.length; l >= i; ++i, ++j) {
          selector = '#test' + j + ' ' + types + ' div ' + items[i - 1] + ' *';
          resolver = new Function('c,s', 'return ' + engines[engine][0]);
          elements = resolver(doc, selector);
          test(elements, j, i % 5 == 1 ? 3 : 1);
        }
      }

      function test(n, t, e) {
        var i = 0, l = n.length, out;
        for (; l > i; ++i) {
          // fix for ExtJS returning text nodes
          if (n[i].nodeName > '@') {
            n[i].style.color = "#060";
          }
        }
        if (e !== i) {
          out = '(expected ' + e + ', <span style="color: #f00;">found ' + i + ') - FAIL</span>';
        } else {
          out = '(expected ' + e + ', <span style="color: #060;">found ' + i + ') - PASS</span>';
        }
        document.getElementById('output' + t).innerHTML = out;
      }

    };

  // get 'engine' parameter value from query string
  engine = getQueryParam('engine', defaultEngine);

  global.onload =
    function() {
      // add engines select box
      select = addSelectBox();

      if (engine && engines[engine][1]) {
        // inject a script loading the selected framework/library
        script = head.insertBefore(doc.createElement('script'), head.firstChild);
        script.type = 'text/javascript';
        script.src = engines[engine][1];
        // setup script load handlers
        script.onload = startTest;
        // need a small IE inference :(
        // to avoid problems with Opera
        // doesn't this make sense :?)
        if (doc.createEventObject) {
          script.onreadystatechange =
            function() {
              if (/loaded/.test(script.readyState)) {
                startTest();
              }
            };
        }
      } else {
        // no need to load a framework
        engine = 'querySelectorAll';
        startTest();
      }
    };

})(this, engines);
