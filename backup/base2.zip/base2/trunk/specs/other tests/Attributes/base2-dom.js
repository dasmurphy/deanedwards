/*
  base2 - Copyright 2007-2011, Dean Edwards
    http://code.google.com/p/base2/

  License:
    http://www.opensource.org/licenses/mit-license.php

  Contributors:
    Doeke Zanstra
*/

// timestamp: Tue, 11 Oct 2011 15:26:37

var base2 = (function(base2,Object,Array,Date,Function,RegExp,String,Error,RangeError,ReferenceError,SyntaxError,TypeError) { // begin: closure

var info = {VERSION: "2.0(beta1)"};

/*@cc_on @*/

var oldBase2 = base2 || {};
if (info.VERSION === oldBase2.version) return oldBase2;

base2 = {}; // placeholder

var undefined, document;

var NOT_ENOUGH_ARGUMENTS_ERR = "Not enough arguments.";
var FUNCTION_REQUIRED_ERR    = "Function required.";
var OBJECT_REQUIRED_ERR      = "Object required.";

var Object__toString       = {}.toString,
    Array_prototype        = Array.prototype,
    Array__concat          = Array_prototype.concat,
    Array__indexOf         = Array_prototype.indexOf,
    Array__forEach         = Array_prototype.forEach,
    Array__slice           = Array_prototype.slice,
    Function_prototype     = Function.prototype,
    Function__call         = Function_prototype.call;

var Object_protected       = {base: 1};
var Function_protected     = K();
Function_protected.bind    = 1;
Function_protected.base    = 1;

var Undefined = K(),
    Null      = K(null),
    False     = K(false),
    True      = K(true);

True.contains = True.has = True.test = True;
False.contains = False.has = False.test = False;

Trait = Collection = Undefined; // initialise

var commands = {"es5-shim": Undefined};

var base2_shims = {};

var counter = 0;

var assignID = oldBase2.assignID || function assignID(object, ID) {
  // Assign a unique ID to an object.
  var id = "b2_" + counter++;
  if (object == null) return id;
  if (!ID) ID = object.nodeType === 1 ? "uniqueID" : "base2ID";
  if (!object[ID]) object[ID] = id;
  return object[ID];
};

var isArray = Array.isArray;
var now = Date.now;

var String__trim = "".trim;

var trim = function trim(string) {
  if (string == null) throw new TypeError(OBJECT_REQUIRED_ERR);
  return String__trim.call(string);
};

var isBrowser = detect("(<script>)");

// =========================================================================
// base2/_private.js
// =========================================================================

function deferUntil(fn, test, interval, timeout, ontimeout) {
  var startTime = now();
  var tick = function tick() {
    if (test()) {
      fn();
    } else if (!timeout || (now() - startTime < timeout)) {
      setTimeout(tick, interval || 25);
    } else if (ontimeout) {
      ontimeout();
    }
  };
  tick();
}

function copy(object) {
  var result = {};
  for (var i in object) result[i] = object[i];
  return result;
}

function Dummy(){}

function pcopy(object, properties) {
  Dummy.prototype = object;
  var result = new Dummy;
  for (var i in properties) result[i] = properties[i];
  return result;
}

var _private = {
  shims: base2_shims,

  deferUntil: deferUntil,
  
  copy: copy,
  pcopy: pcopy
};

// =========================================================================
// base2/Base.js
// =========================================================================

var BASE_CALL = /return/.test(K) ? /\.base[.(]/ : True; // some platforms don't allow decompilation

var __prototyping__ = false;

function Base(properties) {
  if (properties && this instanceof Base) {
    extend(this, properties);
  }
}

;;; Base["#implements"] = [];
;;; Base["#implemented_by"] = [];

Base.prototype.toString = function toString() {
  return "[object " + getClassName(this.constructor, "base2.Base") + "]";
};

Base.prototype.base = base;

var Base_static = {
  ancestor: null,
  
  ancestorOf: function Base_ancestorOf(klass) {
    return klass && klass.prototype instanceof this;
  },

  base: base,

  extend: function Base_extend(_instance, _static) {
    // Build the prototype.
    var proto = pcopy(this.prototype);
    if (_instance) {
      __prototyping__ = true;
      extend(proto, _instance);
      __prototyping__ = false;
    }
    proto.base = base;
    var subclass = proto.constructor;
    if (subclass == this) {
      subclass = proto.constructor = _inheritConstructor(this);
    }
    subclass.prototype = proto;

    // Build the static interface.
    for (var i in Base_static) subclass[i] = this[i];
    if (_static) extend(subclass, _static);
    subclass.ancestor = this;

    ;;; // introspection (removed when packed)
    ;;; delete subclass._underlyingFunction;
    ;;; subclass["#implements"] = [];
    ;;; subclass["#implemented_by"] = [];

    return subclass;
  },

  implement: function Base_implement(properties) {
    if (typeof properties == "function") {
      ;;; // introspection (removed when packed)
      ;;; if (properties.prototype instanceof Base) {
      ;;;   this["#implements"].push(properties);
      ;;;   properties["#implemented_by"].push(this);
      ;;; }
      if (Trait.ancestorOf(properties) && !properties.test(this.prototype)) {
        throw new TraitError(TRAIT_INVALID_TARGET_ERR, properties);
      }
      properties = properties.prototype;
    }
    // Add the interface using the extend() function.
    if (typeof properties == "object") {
      extend(this.prototype, properties);
    }
    return this;
  }
};

for (var name in Base_static) Base[name] = Base_static[name];

function base() {
  // call this method from any other method to invoke that method's ancestor
}

// help

function _inheritConstructor(superClass) {
  var subClass = function _Faux__constructor() {
    arguments.length === 0 ? superClass.call(this) : superClass.apply(this, arguments);
    return this;
  };
  ;;; subClass.toString = K(String(superClass));
  return subClass;
}

function getClassName(klass, defaultName) {
  while (klass) {
    if (klass.toString._pretty) return klass.toString().slice(1, -1);
    klass = klass.ancestor;
  }
  return defaultName || "base2.Base";
}

// =========================================================================
// base2/Trait.js
// =========================================================================

var TRAIT_INSTANTIATION_ERR              = "{trait} cannot be instantiated.";
var TRAIT_INVALID_TARGET_ERR             = "Invalid target for {trait} methods.";
var TRAIT_INVALID_TARGET_FOR_METHOD_ERR  = "Invalid target for {trait}.{method}().";

var Trait = Base.extend({
  constructor: function Trait__constructor() {
    if (this instanceof Trait) {
      throw new TraitError(TRAIT_INSTANTIATION_ERR);
    }
  }
}, {
  extend: function Trait_extend(_instance, _static) {
    // Extend a Trait to create a new Trait.
    if (!_instance) _instance = {};
    _instance.constructor = function _Trait__constructor(object) {
      if (this instanceof Trait) {
        // Attempt to instantiate a Trait.
        throw new TraitError(TRAIT_INSTANTIATION_ERR, trait);
      } else {
        if (!trait.test(object)) {
          throw new TraitError(TRAIT_INVALID_TARGET_ERR, trait);
        }
        return extend(object, trait.prototype);
      }
    };
    var trait = this.base(_instance);
    _Trait_createStaticMethods(trait, _Trait_createStaticMethod);
    trait.test = this.test;
    if (_static) extend(trait, _static);
    return trait;
  },

  implement: function Trait_implement(methods) {
    if (methods == null) throw new TraitError(OBJECT_REQUIRED_ERR);

    this.base(methods);
    _Trait_createStaticMethods(this, _Trait_createStaticMethod);
    return this;
  },

  test: False
});

// help

var Trait_reserved = pcopy(Base_static, {test: 1});

function _Trait_createStaticMethods(trait, methodCreater) {
  forEach (trait.prototype, methodCreater, trait, Object_protected);
}

function _Trait_createStaticMethod(protoMethod, methodName) {
  var trait = this;

  if (!isFunction(protoMethod)) throw new TraitError(FUNCTION_REQUIRED_ERR); // only methods are allowed
  if (Trait_reserved[methodName]) throw new TraitError("'{method}' is reserved.", trait, methodName);

  // Convert an instance method to a static method
  trait[methodName] = function _Trait_method(object) {
    // Throw an error if the supplied object is not a suitable target for this Trait.
    if (!trait.test(object)) {
      throw new TraitError(TRAIT_INVALID_TARGET_FOR_METHOD_ERR, trait, methodName);
    }
    // Traits are "soft", so if the object already implements the method then use that.
    var method = object[methodName];
    if (typeof method != "function") method = protoMethod;
    return Function__call.apply(method, arguments);
  };
  ;;; trait[methodName]._underlyingFunction = protoMethod._underlyingFunction || protoMethod;
}

function TraitError(message, trait, method) {
  if (message) this.message = format(message, {trait: getClassName(trait, "Trait").split(".").pop(), method: method});
}
TraitError.prototype = new TypeError;

// =========================================================================
// base2/Functional.js
// =========================================================================

function isFunction(object) {
  return typeof object == "function" && typeof object.call == "function";
}

function I(i) { // identity
  return i; // returns first argument
}

function II(i, ii) {
  return ii; // returns second argument
}

function K(value) { // returns a constant function that always returns 'value'
  return function() {
    return value;
  };
}

var Function__bind = preferNativeMethod(Function_prototype, "bind", function bind(context /*, arg1, arg2, .. , argN */) {
  // This solution does not fix the length property of the resulting function.
  
  var fn = this;

  if (typeof fn != "function" || typeof fn.call != "function") throw new TypeError(FUNCTION_REQUIRED_ERR);

  var initialArguments = arguments.length > 1 ? Array__slice.call(arguments, 1) : null;

  var boundFunction = function _boundFunction() {
    var instance = this instanceof boundFunction ? pcopy(fn.prototype) : null;
    var callContext = instance || context;
    var hasArguments = arguments.length > 0;

    var result = initialArguments
      ? fn.apply(callContext, hasArguments ? Array__concat.apply(initialArguments, arguments) : initialArguments)
      : hasArguments ? fn.apply(callContext, arguments) : fn.call(callContext);

    if (instance && result !== Object(result)) result = instance;

    return result;
  };
  boundFunction.prototype = fn.prototype; // wrong, but the best alternative
  return boundFunction;
});

var Functional_instance = {
  bind: Function__bind,
  
  compose: function compose(fn1 /*, fn2, fn3, .. , fnN */) {
    var fn = this;
    
    var fns = [];

    var length = arguments.length;
    for (var i = 0; i < length; i++) {
      fns[i] = arguments[i];
      if (typeof fns[i] != "function") throw new TypeError(FUNCTION_REQUIRED_ERR);
    }

    var composedFunction = function _composedFunction() {
      var result = arguments.length === 0 ? fn.call(this) : fn.apply(this, arguments);
      for (var i = 0; i < length; i++) {
        result = fns[i].call(this, result);
      }
      return result;
    };
    ;;; composedFunction._underlyingFunction = fn._underlyingFunction || fn;
    return composedFunction;
  },
  
  flip: function flip() {
    var fn = this;

    // Swap the first two arguments in a function.
    var flippedFunction = function _flippedFunction() {
      var temp = arguments[0];
      arguments[0] = arguments[1];
      arguments[1] = temp;
      return fn.apply(this, arguments);
    };
    ;;; flippedFunction._underlyingFunction = fn._underlyingFunction || fn;
    return flippedFunction;
  },
  
  not: function not() {
    var fn = this;

    // Negate the return value of a function.
    var notFunction = function _notFunction() {
      return arguments.length === 0 ? !fn.call(this) : !fn.apply(this, arguments);
    };
    ;;; notFunction._underlyingFunction = fn._underlyingFunction || fn;
    return notFunction;
  },
  
  partial: function partial(/*, arg1/undefined, arg2/undefined, .. , argN */) {
    var fn = this;

    // Partial evaluation.
    var args = Array__slice.call(arguments);
    var partialFunction = function _partialFunction() {
      var specialised = args.concat();
      var length = arguments.length;
      var i = 0, j = 0;
      while (i < args.length && j < length) {
        if (typeof specialised[i] == "undefined") {
          specialised[i] = arguments[j++];
        }
        i++;
      }
      while (j < length) {
        specialised[i++] = arguments[j++];
      }
      while (i--) {
        if (typeof specialised[i] == "undefined") {
          return partial.apply(fn, specialised);
        }
      }
      return fn.apply(this, specialised);
    };
    ;;; partialFunction._underlyingFunction = fn._underlyingFunction || fn;
    return partialFunction;
  },
  
  unbind: function unbind() {
    var fn = this;

    // Unbind a method from an object.
    // Returns a function that has as its first parameter the object that would have been the "this" object.
    //
    // var slice = unbind([].slice);
    // var args = slice(arguments); // cast to Array

    var unboundFunction = function _unboundFunction(object) {
      if (object == null) throw new TypeError(OBJECT_REQUIRED_ERR);
      return Function__call.apply(fn, arguments);
    };
    ;;; unboundFunction._underlyingFunction = fn._underlyingFunction || fn;
    return unboundFunction;
  }
};

var Functional_static = {
  I: I,
  II: II,
  K: K,
  Null: Null,
  False: False,
  True: True,
  Undefined: Undefined
};

var Functional = Trait.extend(null, Functional_static);

Functional.test = isFunction;

extend(Functional.prototype, Functional_instance);

;;; for (var name in Functional_static) {
;;;   if (/^(Null|False|True|Undefined)$/.test(name)) {
;;;     Functional[name].toString = K("function " + name + "() {\n  return " + name.toLowerCase() + ";\n}");
;;;   }
;;; }

// =========================================================================
// base2/ArrayLike.js
// =========================================================================

var REDUCE_ERR = "Nothing to reduce.";

var Array_enumerable = {
  every: function every(test, context) {
    if (!isFunction(test)) throw new TypeError(FUNCTION_REQUIRED_ERR);

    var array = Object(this);
    var length = array.length >>> 0;

    for (var i = 0; i < length; i++) if (i in array) {
      if (!test.call(context, array[i], i, array)) return false;
    }

    return true;
  },

  filter: function filter(test, context) {
    if (!isFunction(test)) throw new TypeError(FUNCTION_REQUIRED_ERR);

    var array = Object(this);
    var length = array.length >>> 0;
    var result = [];

    for (var i = 0, j = 0, value; i < length; i++) if (i in array) {
      value = array[i];
      if (test.call(context, value, i, array)) {
        result[j++] = value;
      }
    }

    return result;
  },

  forEach: function forEach(eacher, context) {
    if (!isFunction(eacher)) throw new TypeError(FUNCTION_REQUIRED_ERR);

    var array = Object(this);
    var length = array.length >>> 0;

    for (var i = 0; i < length; i++) if (i in array) {
      eacher.call(context, array[i], i, array);
    }
  },

  map: function map(mapper, context) {
    if (!isFunction(mapper)) throw new TypeError(FUNCTION_REQUIRED_ERR);

    var array = Object(this);
    var length = array.length >>> 0;
    var result = new Array(length);

    for (var i = 0; i < length; i++) if (i in array) {
      result[i] = mapper.call(context, array[i], i, array);
    }

    return result;
  },

  reduce: function reduce(reducer, initialValue) {
    if (!isFunction(reducer)) throw new TypeError(FUNCTION_REQUIRED_ERR);

    var array = Object(this);
    var length = array.length >>> 0;
    var result = initialValue;
    var initialised = arguments.length > 1;

    for (var i = 0; i < length; i++) if (i in array) {
      var value = array[i];
      result = initialised ? reducer.call(undefined, result, value, i, array) : value;
      initialised = true;
    }

    if (!initialised) throw new TypeError(REDUCE_ERR);

    return result;
  },

  reduceRight: function reduceRight(reducer, initialValue) {
    if (!isFunction(reducer)) throw new TypeError(FUNCTION_REQUIRED_ERR);

    var array = Object(this);
    var length = array.length >>> 0;
    var result = initialValue;
    var initialised = arguments.length > 1;

    for (var i = length - 1; i >= 0; i--) if (i in array) {
      var value = array[i];
      result = initialised ? reducer.call(undefined, result, value, i, array) : value;
      initialised = true;
    }

    if (!initialised) throw new TypeError(REDUCE_ERR);

    return result;
  },

  some: function some(test, context) {
    if (!isFunction(test)) throw new TypeError(FUNCTION_REQUIRED_ERR);

    var array = Object(this);
    var length = array.length >>> 0;

    for (var i = 0; i < length; i++) if (i in array) {
      if (test.call(context, array[i], i, array)) return true;
    }

    return false;
  }
};

var Array_extras = extend({
  indexOf: function indexOf(item, fromIndex) {
    var length = this.length >>> 0;
    
    if (fromIndex == null) {
      fromIndex = 0;
    } else {
      fromIndex = ~~+fromIndex;
      if (fromIndex < 0) {
        fromIndex = length + fromIndex;
        if (fromIndex < 0) fromIndex = 0;
      }
    }
    for (var i = fromIndex; i < length; i++) {
      if (item === this[i]) return i;
    }
    
    return -1;
  },

  lastIndexOf: function lastIndexOf(item, fromIndex) {
    var length = this.length >>> 0;
    
    if (fromIndex == null) {
      fromIndex = length - 1;
    } else {
      fromIndex = ~~+fromIndex;
      if (fromIndex < 0) {
        fromIndex = length + fromIndex;
        if (fromIndex < 0) fromIndex = 0;
      }
    }
    for (var i = fromIndex; i >= 0; i--) {
      if (item === this[i]) return i;
    }
    
    return -1;
  },

  slice: function slice(start, end) { // You should only see this code in MSIE6-8.
    if (this.valueOf) { // not a COM object
      return Array__slice.apply(this, arguments);
    }

    var length = this.length >>> 0;
    var result = [];
    
    if (length > 0) {
      start = _clamp(start, length);
      end = isNaN(end) ? length : _clamp(end, length);

      for (var i = start, j = 0; i < end; i++) {
        result[j++] = this[i];
      }
    }
    
    return result;
  }
}, Array_enumerable);

// derived

var ArrayLike_instance = {
  invoke: function invoke(method /*, arg1, arg2, .. , argN */) {
    // Apply a method to each item in the enumerated object.
    var args = arguments.length > 1 ? Array__slice.call(arguments, 1) : null;

    switch (typeof method) {
      case "function":
        var invoker = args ? function _invoker(item) {
          return item == null ? undefined : method.apply(item, args);
        } : function _invoker(item) {
          return item == null ? undefined : method.call(item);
        };
        break;

      case "string":
        invoker = args ? function _invoker(item) {
          return item == null ? undefined : item[method].apply(item, args);
        } : function _invoker(item) {
          return item == null ? undefined : item[method]();
        };
        break;

      default:
        throw new TypeError(FUNCTION_REQUIRED_ERR);
    }

    return _.map(this, invoker);
  },
  
  plant: function plant(propertyName, value) {
    forEach (this, function _planter(item) {
      if (item != null) item[propertyName] = value;
    });
  },
  
  pluck: function pluck(propertyName) {
    return _.map(this, function _plucker(item) {
      return item == null ? undefined : item[propertyName];
    });
  }
};

for (var name in Array_extras) ArrayLike_instance[name] = Array_extras[name];
delete Array_extras.slice;

var Array_extensions = {};
for (name in []) Array_extensions[name] = 1;
for (name in Array_extras) {
  if (Array_prototype[name] && !Array_extensions[name]) {
    ArrayLike_instance[name] = Array_prototype[name];
    delete Array_extras[name];
  } else {
    delete Array_enumerable[name];
  }
}

Array__forEach = Array_extras.forEach || Array__forEach;
Array__indexOf = Array_extras.indexOf || Array__indexOf;

try {
  if (!isBrowser || Array__slice.call(document.childNodes) instanceof Array) {
    ArrayLike_instance.slice = Array__slice;
  }
} catch (ex) {}

var ArrayLike = Trait.extend();

ArrayLike.test = function ArrayLike_test(object) {
  if (object == null) return false;

  switch (typeof object) {
    case "function": if (object.call) return false;
      // fall through to catch Safari NodeLists

    case "object":
      if (typeof object.length == "number") {
         // strings not supported
        return !(object.charAt && Object__toString.call(object) === "[object String]");
      }
      // avoid using instanceof on COM objects
      return object.imap && (object instanceof Collection || object == Collection.prototype);
  }

  return false;
};

extend(ArrayLike.prototype, ArrayLike_instance);

// help

function _clamp(value, length) {
  value = ~~+value;
  if (value < 0) value += length;
  return value < 0 ? 0 : value > length ? length : value;
}

// =========================================================================
// base2/Collection.js
// =========================================================================

// Collection classes have a special (optional) property: Item
// The Item property points to a constructor function.
// Members of the collection must be an instance of Item.

var DUPLICATE_KEY_ERR        = "Duplicate key: ";
var INDEX_OUT_OF_BOUNDS_ERR  = "Index out of bounds.";

var CONST_HASH  = "#";
var CONST_ITEMS =  0;
var CONST_KEYS  =  1;

var Collection = Base.extend({
  constructor: function Collection__constructor(items) {
    this[CONST_ITEMS] = {};
    this[CONST_KEYS] = [];
    if (items) this.merge(items);
  },

  add: function Collection__add(key, item) {
    // Duplicates are not allowed using add().
    // You can still overwrite entries using put().
    if (CONST_HASH + key in this[CONST_ITEMS]) {
      throw new ReferenceError(DUPLICATE_KEY_ERR + key);
    }
    
    return this.put.apply(this, arguments);
  },

  clear: function Collection__clear() {
    this[CONST_KEYS] = [];
    this[CONST_ITEMS] = {};
    
    return this;
  },

  clone: function Collection__clone() {
    var result = pcopy(this.constructor.prototype, this);
    result[CONST_ITEMS] = copy(this[CONST_ITEMS]);
    result[CONST_KEYS] = this[CONST_KEYS].slice();
    
    return result;
  },
  
  every: function Collection__every(test, context) {
    if (!isFunction(test)) throw new TypeError(FUNCTION_REQUIRED_ERR);

    var keys = this[CONST_KEYS], key;
    var items = this[CONST_ITEMS];
    var size = keys.length;
    
    for (var i = 0; i < size; i++) {
      if (!test.call(context, items[CONST_HASH + (key = keys[i])], key, this)) {
        return false;
      }
    }
    
    return true;
  },
  
  filter: function Collection__filter(test, context) {
    if (!isFunction(test)) throw new TypeError(FUNCTION_REQUIRED_ERR);

    var result = pcopy(this.constructor.prototype, this);
    
    var resultKeys = result[CONST_KEYS] = [];
    var resultItems = result[CONST_ITEMS] = {};
    
    var keys = this[CONST_KEYS];
    var items = this[CONST_ITEMS];
    var size = keys.length;
    
    for (var i = 0, j = 0, key, HASH_key, item; i < size; i++) {
      item = items[HASH_key = CONST_HASH + (key = keys[i])];
      if (test.call(context, item, key, this)) {
        resultKeys[j++] = key;
        resultItems[HASH_key] = item;
      }
    }
    
    return result; // Returns a clone of the current object with its members filtered by "test"
  },
  
  forEach: function Collection__forEach(eacher, context) {
    if (!isFunction(eacher)) throw new TypeError(FUNCTION_REQUIRED_ERR);

    var keys = this[CONST_KEYS], key;
    var items = this[CONST_ITEMS];
    var size = keys.length;
    
    for (var i = 0; i < size; i++) {
      eacher.call(context, items[CONST_HASH + (key = keys[i])], key, this);
    }
  },

  get: function Collection__get(key) {
    var item = this[CONST_ITEMS][CONST_HASH + key];
    return item;
  },

  getAt: function Collection__getAt(index) {
    var key = this.keyAt(index);
    return key == null ? undefined : this[CONST_ITEMS][CONST_HASH + key];
  },

  has: function Collection__has(key) {
    return CONST_HASH + key in this[CONST_ITEMS];
  },

  imap: function Collection__imap(mapper, context) {
    if (!isFunction(mapper)) throw new TypeError(FUNCTION_REQUIRED_ERR);
    
    // the same as _.map(this.values(), ..) but faster.
    
    var result = [];
    
    var keys = this[CONST_KEYS];
    var items = this[CONST_ITEMS];
    var size = keys.length;
    
    for (var i = 0; i < size; i++) {
      result[i] = mapper.call(context, items[CONST_HASH + keys[i]], i, this);
    }
    
    return result; // returns an Array
  },

  indexOf: Collection__indexOf,

  insertAt: function Collection__insertAt(index, key, item) {
    var keys = this[CONST_KEYS];
    var items = this[CONST_ITEMS];
    var HASH_key = CONST_HASH + key;
    
    if (HASH_key in items) throw new ReferenceError(DUPLICATE_KEY_ERR + key);
    if (this.keyAt(index) == null) throw new RangeError(INDEX_OUT_OF_BOUNDS_ERR);
    
    keys.splice(index, 0, String(key));
    items[HASH_key] = undefined;
    
    return this.put.apply(this, Array__slice.call(arguments, 1));
  },

  join: function Collection__join(separator) {
    return this.values().join(separator);
  },

  keyAt: function Collection__keyAt(index) { // Allow negative indexes.
    index = +index;
    var keys = this[CONST_KEYS];
    if (index < 0) index = index + keys.length;
    var key = keys[index];
    return key;
  },

  keys: function Collection__keys() {
    return this[CONST_KEYS].concat(); // returns an Array
  },

  lastIndexOf: Collection__indexOf, // polymorphic with ArrayLike

  map: function Collection__map(mapper, context) {
    if (!isFunction(mapper)) throw new TypeError(FUNCTION_REQUIRED_ERR);
    
    // Returns a new Collection containing the mapped items.
    var result = new Collection;
    var resultItems = result[CONST_ITEMS];
    
    var keys = this[CONST_KEYS], key, HASH_key;
    var items = this[CONST_ITEMS];
    var size = keys.length;
    
    result[CONST_KEYS] = keys.concat();
    
    for (var i = 0; i < size; i++) {
      resultItems[HASH_key = CONST_HASH + (key = keys[i])] = mapper.call(context, items[HASH_key], key, this);
    }
    
    return result; // returns a Collection
  },

  merge: function Collection__merge(source /*, source1, source2, .. , sourceN */) {
    // For speed, try to avoid calling the put() method.
    var optimised = !this.constructor.Item && this.put == Collection.prototype.put;

    var keys = this[CONST_KEYS], key, HASH_key;
    var items = this[CONST_ITEMS], item;
    var size = keys.length;
    
    for (var i = 0; i < arguments.length; i++) {
      source = arguments[i];
      if (source && typeof source == "object" && source != this) {
        if (source.imap && source instanceof Collection) {
          var sourceItems = source[CONST_ITEMS];
          var sourceKeys = source[CONST_KEYS];
          var length = sourceKeys.length;
          for (var j = 0; j < length; j++) {
            key = sourceKeys[j];
            HASH_key = CONST_HASH + key;
            item = sourceItems[HASH_key];
            if (optimised) {
              if (!(HASH_key in items)) keys[size++] = key;
              items[HASH_key] = item;
            } else {
              this.put(key, item);
            }
          }
        } else if (isArray(source)) { // An array of key/value pairs.
          length = source.length;
          for (j = 0; j < length; j++) {
            key = source[j++];
            item = source[j];
            if (optimised) {
              HASH_key = CONST_HASH + key;
              if (!(HASH_key in items)) keys[size++] = String(key);
              items[HASH_key] = item;
            } else {
              this.put(key, item);
            }
          }
        } else { // An object literal.
          for (key in source) if (!(key in Object_protected)) {
            item = source[key];
            if (optimised) {
              HASH_key = CONST_HASH + key;
              if (!(HASH_key in items)) keys[size++] = key;
              items[HASH_key] = item;
            } else {
              this.put(key, item);
            }
          }
        }
      }
    }
    return this;
  },

  put: function Collection__put(key, item) {
    var argsLength = arguments.length;
    if (argsLength < 2) item = key;
    key = String(key);
    
    var items = this[CONST_ITEMS];

    // Make sure it's an instance of Item.
    var Item = this.constructor.Item;
    if (Item && !(item && item.valueOf && item instanceof Item)) {
      var args = argsLength < 3 ? [key, item] : Array__slice.call(arguments);
      item = pcopy(Item.prototype);
      Item.apply(item, args);
    }

    // Update the keys array.
    var HASH_key = CONST_HASH + key;
    if (!(HASH_key in items)) {
      this[CONST_KEYS].push(key);
    }

    // Write the new item.
    items[HASH_key] = item;

    return item;
  },

  putAt: function Collection__putAt(index, item) {
    var key = this.keyAt(index); // Allow negative indexes.
    if (key == null) throw new RangeError(INDEX_OUT_OF_BOUNDS_ERR);
    var args = Array__slice.call(arguments);
    args[0] = key;
    return this.put.apply(this, args);
  },

  reduce: function Collection__reduce(reducer, result) {
    if (!isFunction(reducer)) throw new TypeError(FUNCTION_REQUIRED_ERR);

    var initialised = arguments.length > 1;
    var keys = this[CONST_KEYS], key;
    var items = this[CONST_ITEMS], item;
    var size = keys.length;
    
    if (size > 0) {
      var start = 0;
      if (!initialised) {
        result = items[CONST_HASH + keys[start++]];
        initialised = true;
      }
      for (var i = start; i < size; i++) {
        result = reducer.call(undefined, result, items[CONST_HASH + (key = keys[i])], key, this);
      }
    }
    
    if (!initialised) throw new TypeError(REDUCE_ERR);
    
    return result;
  },

  reduceRight: function Collection__reduceRight(reducer, result) {
    if (!isFunction(reducer)) throw new TypeError(FUNCTION_REQUIRED_ERR);

    var initialised = arguments.length > 1;
    var keys = this[CONST_KEYS], key;
    var items = this[CONST_ITEMS], item;
    var size = keys.length;
    
    if (size > 0) {
      var start = size - 1;
      if (!initialised) {
        result = items[CONST_HASH + keys[start--]];
        initialised = true;
      }
      for (var i = start; i >= 0; i--) {
        result = reducer.call(undefined, result, items[CONST_HASH + (key = keys[i])], key, this);
      }
    }
    
    if (!initialised) throw new TypeError(REDUCE_ERR);
    
    return result;
  },

  remove: function Collection__remove(key) {
    var items = this[CONST_ITEMS];
    var HASH_key = CONST_HASH + key;

    // The remove() method can be slow so check if the key exists first.
    if (HASH_key in items) {
      delete items[HASH_key];
      var keys = this[CONST_KEYS];
      var index = Array__indexOf.call(keys, String(key));
      keys.splice(index, 1);
    }
  },

  removeAt: function Collection__removeAt(index) {
    var removed = this[CONST_KEYS].splice(index, 1);
    if (removed.length === 1) {
      delete this[CONST_ITEMS][CONST_HASH + removed[0]];
    }
  },

  reverse: function Collection__reverse() {
    this[CONST_KEYS].reverse();
    return this;
  },

  size: function Collection__size() {
    return this[CONST_KEYS].length;
  },

  slice: function Collection__slice(start, end) {
    var result = this.clone();
    
    if (arguments.length > 0) {
      var removed = result[CONST_KEYS];
      var size = removed.length;
      start = _clamp(start, size);
      end = isNaN(end) ? size : _clamp(end, size);
      var keys = removed.splice(start, end - start);
      var i = removed.length;
      var resultItems = result[CONST_ITEMS];
      while (i--) delete resultItems[CONST_HASH + removed[i]];
      result[CONST_KEYS] = keys;
    }
    
    return result;
  },
  
  some: function Collection__some(test, context) {
    if (!isFunction(test)) throw new TypeError(FUNCTION_REQUIRED_ERR);

    var keys = this[CONST_KEYS], key;
    var items = this[CONST_ITEMS];
    var size = keys.length;
    
    for (var i = 0; i < size; i++) {
      if (test.call(context, items[CONST_HASH + (key = keys[i])], key, this)) {
        return true;
      }
    }
    
    return false;
  },

  sort: function Collection__sort(compare) {
    if (compare) {
      var items = this[CONST_ITEMS];
      this[CONST_KEYS].sort(function _sorter(key1, key2) {
        return compare(items[CONST_HASH + key1], items[CONST_HASH + key2], key1, key2);
      });
    } else {
      this[CONST_KEYS].sort();
    }
    
    return this;
  },

  toString: function Collection__toString() {
    return "(" + (this[CONST_KEYS] || "") + ")";
  },

  union: function Collection__union(source /*, source1, source2, .. , sourceN */) {
    return this.merge.apply(this.clone(), arguments);
  },

  values: function Collection__values() {
    var result = [];

    var keys = this[CONST_KEYS];
    var items = this[CONST_ITEMS];
    var i = keys.length;

    while (i--) {
      result[i] = items[CONST_HASH + keys[i]];
    }
    
    return result; // returns an Array
  }
}, {
  Item: null, // If specified, all members of the collection must be instances of Item.

  extend: function Collection_extend(_instance, _static) {
    var klass = this.base(_instance);
    if (_static) extend(klass, _static);
    if (!klass.Item) {
      klass.Item = this.Item;
    } else if (typeof klass.Item != "function") {
      klass.Item = (this.Item || Base).extend(klass.Item);
    }
    
    return klass;
  }
});

Collection.implement(ArrayLike);

// help

function Collection__indexOf(key) {
  return CONST_HASH + key in this[CONST_ITEMS]
    ? Array__indexOf.call(this[CONST_KEYS], String(key))
    : -1;
}

// =========================================================================
// base2/RegGrp.js
// =========================================================================

// A collection of regular expressions and their associated replacement values.
// A Base class for creating parsers.

var CONST_COMPILED = 3;
var CONST_PATTERNS = 1; // CONST_KEYS;

// I Can't feature detect this as it crashes Konqueror 3.x
// This browser is not actually supported but it is still poor form to crash it. :)
var REGGRP_ALWAYS_RECOMPILE = detect("Konqueror");

var REGGRP_BACK_REF         = /\\(\d+)/g,
    REGGRP_ESCAPE_COUNT     = /\[(\\.|[^\]\\])+\]|\\.|\(\?/g,
    REGGRP_PAREN            = /\(/g,
    REGGRP_LOOKUP           = /\$(\d+)/,
    REGGRP_LOOKUP_SIMPLE    = /^\$\d+$/,
    REGGRP_DICT_ENTRY       = /^<#\w+>$/,
    REGGRP_DICT_ENTRIES     = /<#(\w+)>/g;

var RegGrp = Collection.extend({
  constructor: function RegGrp__constructor(dictionary, values) {
    if (arguments.length === 1) {
      values = dictionary;
      dictionary = null;
    }
    if (dictionary) {
      this.dictionary = new RegGrp_Dict(dictionary);
    }
    this.base(values);
  },
  
  dictionary: null,
  ignoreCase: false,

  clear: _RegGrp_recompile,

  exec: function RegGrp__exec(string, fn /* optional */) { // This method needs a lot more work -@DRE
    var group = this;
    var patterns = group[CONST_PATTERNS];
    var items = group[CONST_ITEMS], item;
    group[CONST_COMPILED] = new RegExp(group[CONST_COMPILED] ? group[CONST_COMPILED].source : group, group.ignoreCase ? "gi" : "g");
    var result = group[CONST_COMPILED].exec(string);
    if (result) {
      // Loop through the RegGrp items.
      var i = 0, offset = 1;
      while ((item = items[CONST_HASH + patterns[i++]])) {
        var next = offset + item.length + 1;
        if (result[offset]) {
          if (item.replacement === 0) {
            return group.exec(string);
          } else {
            var args = result.slice(offset, next);
            var j = args.length;
            while (--j) args[j] = args[j] || ""; // some platforms return null/undefined for non-matching sub-expressions
            args[0] = {match: args[0], item: item};
            return isFunction(fn) ? fn.call(args) : args;
          }
        }
        offset = next;
      }
    }
    return null;
  },

  parse: function RegGrp__parse(string) {
    string = String(string);
    var _replacement = arguments[1]; // optional argument (deprecated)
    var group = this;
    var patterns = group[CONST_PATTERNS];
    var items = group[CONST_ITEMS];
    var regexp = group[CONST_COMPILED];
    if (!patterns.length) return string;
    if (REGGRP_ALWAYS_RECOMPILE || !regexp || regexp.ignoreCase !== !!group.ignoreCase) {
      regexp = group[CONST_COMPILED] = new RegExp(regexp ? regexp.source : group, group.ignoreCase ? "gi" : "g");
    }
    return string.replace(regexp, function _RegGrp_parser(match) {
      var args = [], item, offset = 1, i = arguments.length;
      while (--i) args[i] = arguments[i] || ""; // some platforms return null/undefined for non-matching sub-expressions
      // Loop through the RegGrp items.
      while ((item = items[CONST_HASH + patterns[i++]])) {
        var next = offset + item.length + 1;
        if (args[offset]) { // do we have a result?
          var replacement = _replacement == null ? item.replacement : _replacement;
          switch (typeof replacement) {
            case "function":
              return replacement.apply(group, args.slice(offset, next));
              
            case "number":
              return args[offset + replacement];
              
            case "object":
              if (replacement instanceof RegGrp) {
                return replacement.parse(args[offset]);
              }
              
            default:
              return String(replacement);
          }
        }
        offset = next;
      }
      return match;
    });
  },

  removeAt: _RegGrp_recompile,
  reverse:  _RegGrp_recompile,
  sort:     _RegGrp_recompile,

  test: function RegGrp__test(string) { // The slow way to do it. Hopefully, this isn't called too often. :)
    return this.parse(string) != string;
  },
  
  toString: function RegGrp__toString() {
    var patterns = this[CONST_PATTERNS];
    if (!patterns) return "()";
    var string = patterns.join(")|(");
    if (this.dictionary || /\\\d/.test(string)) { // back refs
      var offset = 1;
      var keys = patterns;
      var items = this[CONST_ITEMS], item;
      patterns = [];
      for (var i = 0; item = items[CONST_HASH + keys[i]]; i++) {
        patterns[i] = item.source.replace(REGGRP_BACK_REF, function(match, index) {
          return "\\" + (offset + ~~index);
        });
        offset += item.length + 1;
      }
      string = patterns.join(")|(");
    }
    return "(" + string + ")";
  }
}, {
  IGNORE: null, // a null replacement value means that there is no replacement and the pattern is ignored

  count: RegGrp_count
});

// init

forEach ("add,get,has,indexOf,insertAt,put,remove".split(","), function(name) {
  var index = name === "insertAt" ? 1 : 0;
  var recompile = name === "put" || name === "remove";
  ;;; var underlyingFunction = this[name];
  this[name] = _override(this[name], function _RegGrp_recompile() {
    var args = Array__slice.call(arguments);
    if (args[index] instanceof RegExp) {
      args[index] = args[index].source;
    }
    if (recompile) {
      delete this[CONST_COMPILED];
      if (name === "put" && this.dictionary) {
        if (args.length < 2) args[1] = args[0];
        args[2] = this.dictionary;
      }
    }
    return this.base.apply(this, args);
  });
  ;;; this[name]._underlyingFunction = underlyingFunction;
}, RegGrp.prototype);

// help

function RegGrp_count(expression) {
  return (String(expression).replace(REGGRP_ESCAPE_COUNT, "").match(REGGRP_PAREN) || "").length;
}

function _RegGrp_recompile() {
  delete this[CONST_COMPILED];
  return this.base.apply(this, arguments);
}

// =========================================================================
// base2/RegGrp.Item.js
// =========================================================================

RegGrp.Item = Base.extend({
  constructor: function RegGrp_Item__constructor(source, replacement, dictionary) {
    var length = source.indexOf("(") === -1 ? 0 : RegGrp_count(source);
    
    if (dictionary && source.indexOf("<#") !== -1) {
      if (REGGRP_DICT_ENTRY.test(source)) {
        var entry = dictionary[CONST_ITEMS][CONST_HASH + source.slice(2, -1)];
        source = entry.replacement;
        length = entry._length;
      } else {
        source = dictionary.parse(source);
      }
    }
    
    if (replacement == null) {
      replacement = 0;
    } else if (replacement.replacement != null) {
      replacement = replacement.replacement;
    } else if (typeof replacement == "number") {
      replacement = String(replacement);
    }

    // Does the expression use sub-expression lookups?
    if (typeof replacement == "string" && REGGRP_LOOKUP.test(replacement)) {
      if (REGGRP_LOOKUP_SIMPLE.test(replacement)) { // A simple lookup? (e.g. "$2").
        // Store the index (used for fast retrieval of matched strings).
        var index = +replacement.slice(1);
        if (index && index <= length) replacement = index;
      } else {
        // A complicated lookup (e.g. "Hello $2 $1.").
        var lookup = replacement, regexp;
        replacement = function(match) {
          if (!regexp || regexp.ignoreCase !== this.ignoreCase) {
            regexp = new RegExp(source, this.ignoreCase ? "gi": "g");
          }
          return match.replace(regexp, lookup);
        };
      }
    }

    this.length = length;
    this.source = String(source);
    this.replacement = replacement;
  },

  length: 0,
  source: "",
  replacement: ""
});

// =========================================================================
// base2/RegGrp.Dict.js
// =========================================================================

var REGGRP_DICT_NON_CAPTURING = /(\[(\\.|[^\]\\])+\]|\\.|\(\?)|\(/g;
    
var RegGrp_Dict = RegGrp.extend({
  parse: function RegGrp_Dict__parse(phrase) {
    // Prevent sub-expressions in dictionary entries from capturing.
    var entries = this[CONST_ITEMS];
    return phrase.replace(REGGRP_DICT_ENTRIES, function(match, entry) {
      entry = entries[CONST_HASH + entry];
      return entry ? entry._nonCapturing : match;
    });
  },

  put: function RegGrp_Dict__put(expression, replacement, dictionary) {
    // Get the underlying replacement value.
    if (replacement instanceof RegGrp.Item) {
      replacement = replacement.replacement;
    } else if (replacement instanceof RegExp) {
      replacement = replacement.source;
    }
    if (typeof replacement == "string") { // Don't translate functions.
      // Translate the replacement.
      // The result is the original replacement recursively parsed by this dictionary.
      var nonCapturing = replacement.replace(REGGRP_DICT_NON_CAPTURING, _RegGrp_Dict_noCapture);
      if (replacement.indexOf("(") !== -1) {
        var realLength = RegGrp_count(replacement);
      }
      if (replacement.indexOf("<#") !== -1) {
        replacement = this.parse(replacement);
        nonCapturing = this.parse(nonCapturing);
      }
    }
    var item = this.base(expression, replacement, dictionary);
    item._nonCapturing = nonCapturing;
    item._length = realLength || item.length; // underlying number of sub-groups
    return item;
  },

  toString: function RegGrp_Dict__toString() {
    var patterns = this[CONST_PATTERNS];
    if (!patterns || patterns.length === 0) return "()";
    return "(<#" + patterns.join(">)|(<#") + ">)";
  }
});

function _RegGrp_Dict_noCapture(match, escaped) {
  return escaped || "(?:"; // non-capturing
}

RegGrp.Dict = RegGrp_Dict;

// =========================================================================
// base2/Package.js
// =========================================================================

var Package = Base.extend({
  constructor: function Package__constructor(properties) {
    if (properties) {
      var packageName = properties.name;
      if (packageName) packageName += ".";
      for (var name in properties) {
        var object = properties[name];
        if (object && object.ancestorOf && !object.toString._pretty) { // it's a class
          // Provide objects and classes with pretty toString methods
          (object.toString = K("[" + packageName + name + "]"))._pretty = true;
        }
        this[name] = object;
      }
    }
  },

  name: "",
  version: "",
  
  toString: function toString() {
    return this.name ? "[" + this.name + "]" : "[object base2.Package]";
  }
});

// =========================================================================
// base2/Date.js
// =========================================================================

// http://developer.mozilla.org/es4/proposals/date_and_time.html

var NativeDate_parse = Date.parse;
var Date_prototype   = Date.prototype;

var SUPPORTS_ISO_DATE = NativeDate_parse("T00:00") === 0 && NativeDate_parse("1970") === 0;

// big, ugly, regular expression
var DATE_PATTERN = /^(([+-]\d{6}|\d{4})(-(\d{2})(-(\d{2}))?)?)?(T(\d{2}):(\d{2})((:(\d{2})(\.(\d{1,3})(\d)?\d*)?)?)?)?(([+-])(\d{2})(:(\d{2}))?|Z)?$/;

var DATE_PARTS = "FullYear,Month,Date,Hours,Minutes,Seconds,Milliseconds".split(",");
for (var i = 0; i < 7; i++) DATE_PARTS[DATE_PARTS[i]] = i * 2 + 2;
DATE_PARTS.Minutes = 9;

var TIMEZONE_PARTS = {
  precision: 15,
  UTC: 16,
  Sign: 17,
  Hours: 18,
  Minutes: 20
};

now = preferNativeMethod(Date, "now", function now() {
  return +new Date;
});

function base2_Date(yy, mm, dd, h, m, s, ms) { // faux constructor
  if (this && this.constructor != Date) {
    var date = Date();
  } else {
    switch (arguments.length) {
      case 0:
        date = new Date;
        break;

      case 1:
        date = String(yy) === yy ? new Date(Date_parse(yy)) : new Date(+yy);
        break;

      default:
        date = new Date(yy, mm, arguments.length === 2 ? 1 : dd, h || 0, m || 0, s || 0, ms || 0);
    }
  }
  date.toISOString = Date__toISOString;
  date.toJSON = Date__toJSON;
  return date;
}

function Date_parse(string) {
  // parse ISO date
  var parts = String(string).match(DATE_PATTERN);
  if (parts) {
    var month = parts[DATE_PARTS.Month];
    if (month) parts[DATE_PARTS.Month] = String(month - 1); // js months start at zero
    // round milliseconds on 3 digits
    if (parts[TIMEZONE_PARTS.precision] >= 5) parts[DATE_PARTS.Milliseconds]++;
    var utc = parts[TIMEZONE_PARTS.UTC] || parts[TIMEZONE_PARTS.Hours] ? "UTC" : "";
    var date = new Date(0);
    if (parts[DATE_PARTS.Date]) date["set" + utc + "Date"](14);
    for (var i = 0; i < 7; i++) {
      var part = DATE_PARTS[i];
      var value = parts[DATE_PARTS[part]];
      if (value) {
        // set a date part
        date["set" + utc + part](value);
        // make sure that this setting does not overflow
        if (date["get" + utc + part]() != parts[DATE_PARTS[part]]) {
          return NaN;
        }
      }
    }
    // timezone can be set, without time being available
    // without a timezone, local timezone is respected
    if (parts[TIMEZONE_PARTS.Hours]) {
      var hours = Number(parts[TIMEZONE_PARTS.Sign] + parts[TIMEZONE_PARTS.Hours]);
      var minutes = Number(parts[TIMEZONE_PARTS.Sign] + (parts[TIMEZONE_PARTS.Minutes] || 0));
      date.setUTCMinutes(date.getUTCMinutes() + (hours * 60) + minutes);
    }
    return +date;
  } else {
    return /^[TZ\d:.+\-]+$/.test(string) ? NaN : NativeDate_parse(string);
  }
}

var Date__toISOString = preferNativeMethod(Date_prototype, "toISOString", function toISOString() {
  var date = this, i = 0;
  return "####-##-##T##:##:##.###Z".replace(/#+/g, function(digits) {
    var part = DATE_PARTS[i++];
    var value = date["getUTC" + part]();
    if (part === "Month") value++; // js month starts at zero
    return ("000" + value).slice(-digits.length); // pad
  });
});

var Date__toJSON = preferNativeMethod(Date_prototype, "toJSON", Date__toISOString);

base2_Date.UTC       = Date.UTC;
base2_Date.now       = now;
base2_Date.parse     = Date_parse;
base2_Date.prototype = Date_prototype;
base2_Date.toString  = K("[_.Date]");

// =========================================================================
// base2/detect.js
// =========================================================================

function detect() {
  // Two types of detection:
  //  1. Object detection
  //    e.g. detect("(java)");
  //    e.g. detect("!(document.addEventListener)");
  //  2. Platform detection
  //    e.g. detect("MSIE");
  //    e.g. detect("MSIE|Opera");

  var userAgent = "";
  var jscript = NaN/*@cc_on||@_jscript_version@*/; // http://dean.edwards.name/weblog/2007/03/sniff/#comment85164
  var args = "element,style,jscript";
  try {
    document = window.document;
    var element = document.createElement("span");
    var style   = element.style;
    var quirks  = false;
    userAgent = navigator.userAgent;
    element.expando = true;
    if (document.compatMode) {
      quirks = document.compatMode === "BackCompat";
    } else if (!document.xmlVersion) {
      style.width = 1; // Diego Perini
      quirks = style.width === "1px";
    }
  } catch (ex) {}
  if (userAgent) {
    // Close up the space between name and version number.
    //  e.g. MSIE 6.0 -> MSIE6.0
    userAgent = userAgent.replace(/([a-z])[\s\/](\d)/gi, "$1$2");
    
    ;;; userAgent = userAgent.replace(/\.NET CLR[\d\.]*/g, ""); // tidy
    
    // Remove false positives from ua string
    userAgent = userAgent.replace(/\blike \w+/gi, "");
    var MSIE  = /\bMSIE[\d.]*\b/g;
    if (jscript) { // MSIE
      userAgent = userAgent.match(MSIE)[0] + ";" + userAgent
        .replace(MSIE, "")
        .replace(/user\-agent.*$/i, ""); // crap gets appended here
    } else {
      userAgent = userAgent.replace(MSIE, "");
      if ("webkitAppearance" in style) {
        // Chrome is different enough that it counts as a different vendor.
        if (/\bChrome\d/.test(userAgent)) userAgent = userAgent.replace(/\bSafari[\d.]*\b/g, "");
      } else {
        userAgent = userAgent.replace(/\b(Chrome|Safari)[\d.]*\b/g, "");
        if (window.opera && Object__toString.call(window.opera || window.operamini) === "[object Opera]") {
          if (/\bPresto/.test(userAgent)) userAgent = userAgent.replace(/Opera9\.80/, "").replace(/\bVersion/, "Opera");
        } else if (/\bGecko[\d.]*\b/.test(userAgent)) {
          userAgent = userAgent.replace(/Gecko/g, "Gecko/").replace(/rv:/, "Gecko");
        }
      }
    }
    
    if (quirks) userAgent += ";QuirksMode";
    userAgent += "; platform=" + navigator.platform + "; ";
    
    info["user-agent"] = userAgent;
    
    // http://code.google.com/p/base2/issues/detail?id=127
    if (!/\bGecko/.test(userAgent) && !("java" in window)) args += ",java";
  }
  var cache = {};
  detect = function base2_detect(expression) {
    var negated = expression.indexOf("!") === 0;
    if (negated) expression = expression.slice(1);
    if (!(expression in cache)) {
      var returnValue = false;
      var test = expression;
      if (/^\(.+\)$/.test(test)) { // Feature detection
        if (base2.dom) {
          test = test
            .replace(/\bstyle\.(\w+)/g, function($, propertyName) {
              if (!style[propertyName]) {
                propertyName = _private.getStylePropertyName(propertyName);
              }
              return "style." + propertyName;
            });
        }
        test = test
          .replace(/^\(((?:<\w+>|\w+)\.[\w\.]+)\)$/, function($, feature) {
            feature = feature.split(".");
            var propertyName = feature.pop(), object = feature.join(".");
            return "('" + propertyName + "' in " + object + ")";
          })
          .replace(/<(\w+)>/g, function($, tagName) {
            return "document.createElement('" + tagName + "')";
          });
        returnValue = new Function(args, "try{return !!" + test +"}catch(e){return false}")(element, style, jscript);
      } else {
        // Browser sniffing.
        if (/^\/.+\/$/.test(test)) {
          test = test.slice(1, -1);
        }
        var uaString = userAgent + (_private.theme || ""); // this is cheating. ;)
        returnValue = isBrowser ? new RegExp("(" + test + ")").test(uaString) : false;
      }
      cache[expression] = returnValue;
    }
    return !!(negated ^ cache[expression]);
  };
  
  return detect(arguments[0]);
}

// =========================================================================
// base2/es5-shim.js
// =========================================================================

var global = (function(){return this || (1,eval)('this')})(); // kangax //-@DRE

var String_prototype = String.prototype;

commands["es5-shim"] = function() {
  // This doesn't overwrite anything even if it looks like it does.
  Array.isArray = isArray;
  for (var name in Array_extras) {
    Array_prototype[name] = Array_extras[name];
  }
  Array_prototype.slice = ArrayLike_instance.slice; //-@DRE
  if (!SUPPORTS_ISO_DATE) global.Date = base2_Date;
  Date.now = now;
  Date_prototype.toISOString = Date__toISOString;
  Date_prototype.toJSON = Date__toJSON;
  Function_prototype.bind = Function__bind;
  String_prototype.trim = String__trim;
};

if (!SUPPORTS_ISO_DATE) base2_shims.Date = base2_Date;

isArray = preferNativeMethod(Array, "isArray", function isArray(object) {
  return object != null && Object__toString.call(object) === "[object Array]";
});

// http://perfectionkills.com/whitespace-deviations/
// http://blog.stevenlevithan.com/archives/faster-trim-javascript
var S = "[\\s\xa0\u180e\u2000-\u200a\u2028\u2029\u202f\u205f\u3000\\ufeff]";
var LTRIM = new RegExp("^SS*".replace(/S/g, S));
var RTRIM = new RegExp("SS*$".replace(/S/g, S));

var String__trim = preferNativeMethod(String_prototype, "trim", function trim() {
  if (this == null) throw new TypeError(OBJECT_REQUIRED_ERR);
  return String(this).replace(LTRIM, "").replace(RTRIM, "");
});

function preferNativeMethod(object, methodName, fallback) {
  if (typeof object[methodName] != "function") return fallback;
  // This relies on a non-native method to not be enumerable.
  // If the method is implemented with Object.defineProperty() then
  // it may not be enumerable, hopefully it will be a good implmentation. :)
  for (var name in object) if (name === methodName) return fallback;
  return object[methodName];
}

// =========================================================================
// base2/lang.js
// =========================================================================

function assert(condition, message, ErrorClass) {
  if (!condition) {
    throw new (ErrorClass || Error)(message || "Assertion failed.");
  }
}

function assertArity(args, arity, message) {
  if (args.length < arity) {
    throw new SyntaxError(message || NOT_ENOUGH_ARGUMENTS_ERR);
  }
}

function assertType(object, type, message) {
  if (object == null || (typeof type == "function" ? !object.valueOf || !(object instanceof type) : typeof object != type)) {
    throw new TypeError(message || "Invalid type.");
  }
}

function extend(object, source) { // or extend(object, key, value)
  if (object == null) throw new TypeError(OBJECT_REQUIRED_ERR);

  object = Object(object);

  if (arguments.length > 2) { // Extending with a key/value pair (always overrides).
    var key = source;
    var value = arguments[2];
    if (typeof value == "function" && value != object[key] && BASE_CALL.test(value)) {
      value = _override(object[key], value);
    }
    object[key] = value;
  } else if (source != null) {
    var casting = !__prototyping__ && source instanceof Trait;
    var Type_protected = typeof source == "function" && source.call ? Function_protected : Object_protected;
    
    if (__prototyping__ && source.constructor != Object) {
      extend(object, "constructor", source.constructor);
    }
    if (!casting && source.toString != Type_protected.toString) {
      extend(object, "toString", source.toString);
    }
    // Copy each of the source object's properties to the target object.
    var tests = [];
    for (key in source) if (!(key in Type_protected)) {
      value = source[key];
      if (key in object) {
        if (!casting) {
          if (typeof value == "function" && BASE_CALL.test(value)) { // Check for method overriding.
            value = _override(object[key], value);
          }
          object[key] = value;
        }
      } else if (!casting && key < "A" && key > "@") { // Feature detection.
        tests.push(key.slice(1), value);
      } else {
        object[key] = value;
      }
    }
    // Do feature tests last.
    for (var i = 0; i < tests.length; i++) {
      if (detect(tests[i++])) extend(object, tests[i]);
    }
  }

  // Hedger Wow
  /*@if (@_jscript_version < 5.7)
    try {
      return object;
    } finally {
      object = null;
    }
  /*@end @*/
  
  return object;
}

function _override(oldMethod, newMethod) {
  // Return a new method that overrides an existing method.
  var base = function base() {
    var restore = this.base;
    this.base = oldMethod || Undefined;
    var returnValue = arguments.length === 0 ? newMethod.call(this) : newMethod.apply(this, arguments);
    this.base = restore;
    return returnValue;
  };
  // introspection (removed when packed)
  ;;; if (oldMethod) base._underlyingFunction = oldMethod._underlyingFunction || oldMethod;
  ;;; base.toString = K(String(newMethod));
  return base;
}

function forEach(enumerable, eacher, context, mask) {
  if (!isFunction(eacher)) throw new TypeError(FUNCTION_REQUIRED_ERR);
  
  if (enumerable == null) return; // don't throw

  if (mask == null) {
    switch (typeof enumerable) {
      case "function": if (enumerable.call) {
        mask = Function_protected;
        break;
      }
      // It's probably a crappy Safari NodeList

      case "object":
        if (typeof enumerable.length == "number") {
          if (!(enumerable.charAt && Object__toString.call(enumerable) === "[object String]")) {
            Array__forEach.call(enumerable, eacher, context);
          }
          return;
        }

        // Use the object's own forEach method (if it has one) // move up? -@DRE
        var method = enumerable.forEach;
        if (typeof method == "function" && method != forEach) {
          method.call(enumerable, eacher, context);
          return;
        }

        mask = Object_protected;
        break;

      default:
        return;
    }
  }

  for (var key in enumerable) if (!(key in mask)) { // ignore keys that are in mask
    eacher.call(context, enumerable[key], key, enumerable);
  }
}

forEach.csv = function forEach_csv(string, eacher, context) {
  forEach (csv(string), eacher, context);
};

function csv(string) { // private
  return String(string).split(/\s*,\s*/);
}

function format(string, replacement) {
  // e.g. format("{0} {1}{2} {1}a {0}{2}", "she", "se", "lls");
  //  or  format("{0} {1}{2} {1}a {0}{2}", ["she", "se", "lls"]);
  //  or  format("My name is {name} and I am {age} years old.", {name: "John", age: 34});
  
  switch (arguments.length) {
    case 0:
    case 1:
      throw new SyntaxError(NOT_ENOUGH_ARGUMENTS_ERR);

    case 2:
      if (replacement == null) throw new TypeError(OBJECT_REQUIRED_ERR);

      if (typeof replacement != "object") {
        replacement = [replacement];
      }
      break;

    default:
      replacement = Array__slice.call(arguments, 1);
  }
  
  return String(string).replace(/\{([^{}]+)\}/g, function(match, key) {
    return key in replacement ? replacement[key] : match;
  });
}

var lang = new Package({
  name:   "base2.lang",
  version: info.VERSION,

  assert: assert,
  assertArity: assertArity,
  assertType: assertType,

  extend: extend,
  forEach: forEach,
  
  isArray: isArray,
  isFunction: isFunction,
  
  now: now,
  
  format: format,
  trim: trim
});

// =========================================================================
// base2/base2.js
// =========================================================================

base2 = new Package({
  name:   "base2",
  version: info.VERSION,

  lang: lang,
  
  Base: Base,
  Collection: Collection,
  Package: Package,
  RegGrp: RegGrp,
  Trait: Trait,
  
  ArrayLike: ArrayLike,
  Functional: Functional,

  assignID: assignID,
  detect: detect,
  
  info: function base2_info(key) {
    return key == "*" ? copy(info) : info[key];
  }
});

// =========================================================================
// base2/Namespace.js
// =========================================================================

// The "_" object.

var freeze = preferNativeMethod(Object, "freeze", I);

function Namespace(objects, names) {
  if (!names) names = this;
  if (objects) for (var i = 0, object; object = objects[i]; i++) {
    if (object instanceof Package) {
      for (var name in object) if (!(name in Package.prototype)) {
        names[name] = object[name];
      }
    } else if (Trait.ancestorOf(object)) {
      for (name in object) if (!(name in Trait)) {
        names[name] = object[name];
      }
      for (name in object.prototype) if (name in object) {
        names[name] = object[name];
      }
    }
  }
  for (name in names) if (!(name in lang)) {
    this[name] = names[name];
  }

  return freeze(this);
}

var _ = Namespace.prototype;
_.base2 = base2;
_._ = _private;
_Trait_createStaticMethods(ArrayLike, _Trait_createProtectedMethod);
_Trait_createStaticMethods(Functional, _Trait_createProtectedMethod);
extend(_, Functional_static);
lang.bind = Functional.bind;
Namespace.call(_, [base2, lang]);

_.toString = function toString() {
  if ("imports" == arguments[0]) {
    var result = "";
    for (var i in this) if (!Object_protected[i] && i !== "_") {
      result += "var " + i + "=arguments[0]." + i + ";\n";
    }
    return result;
  }
  return "[object Namespace]";
};

function _Trait_createProtectedMethod(protoMethod, methodName) {
  // This is used to create the ArrayLike/Functional methods on the Namespace object (_).
  // These methods may provide ES5 compatibility so the "soft" behaviour of Traits is not appropriate.
  // This is primarily for protection against "bad" implementations of the ES5 spec. :)

  var trait = this;
  trait[methodName] = _[methodName] = function _Trait_method(object) {
    // Throw an error if the supplied object is not a suitable target for this Trait.
    if (!trait.test(object)) {
      throw new TraitError(TRAIT_INVALID_TARGET_FOR_METHOD_ERR, trait, methodName);
    }
    if (object.imap && object instanceof Collection) {
      var method = object[methodName];
    } else {
      if (Array_enumerable[methodName] && !isFunction(arguments[1])) {
        throw new TraitError("Function required by {trait}.{method}().", trait, methodName);
      }
      method = protoMethod;
    }
    return Function__call.apply(method, arguments);
  };
  ;;; trait[methodName]._underlyingFunction = protoMethod._underlyingFunction || protoMethod;
}

// =========================================================================
// base2/require.js
// =========================================================================

var TIMEOUT = isBrowser ? 20000 : 0;

var base2_host = "";

function base2_exec(fn) {
  if (typeof fn == "string") fn = commands[fn];
  if (!isFunction(fn)) throw new TypeError(FUNCTION_REQUIRED_ERR);
  
  return fn.call(undefined, new Namespace);
}

function base2_require(requirements, callback) {
  if (typeof requirements == "string") {
    var strings = csv(requirements);
    requirements = [];
    for (var i = 0; i < strings.length; i++) {
      var parts = strings[i].split("#");
      if (parts.length === 1) { // package identifiers
        var objectID = parts[0];
        var fileName = objectID.replace(/\./g, "/") + ".js";
        requirements.push(objectID, base2_host + fileName);
      } else { // 3rd party scripts
        requirements.push(parts[1], parts[0]);
      }
    }
  }
  return new Requirements(requirements, callback);
}

base2.exec = base2_exec;
base2.require = base2_require;

base2.ready = function base2_ready(callback) {
  if (!isFunction(callback)) throw new TypeError(FUNCTION_REQUIRED_ERR);

  return fn.call(undefined, new Namespace);
};

if (isBrowser) {
  // Get the current host.
  var scripts = document.getElementsByTagName("script"), script, firstScript;
  var i = 0;
  while ((script = scripts[i++])) {
    if (script.id === "base2.js") break;
    if (!firstScript && /base2\b[\w.-]*\.js/.test(script.src)) firstScript = script;
  }
  base2_host = (script || firstScript || "").src || location.pathname;
  base2_host = base2_host.replace(/\?.*$/, "").replace(/[^\/]*$/, "");
  info.host = base2_host;
  
  base2.ready = function base2_ready(callback) {
    if (!isFunction(callback)) throw new TypeError(FUNCTION_REQUIRED_ERR);
    
    base2_require("base2.dom", function(_, dom) {
      _private.isReady |= /loaded|complete/.test(document.readyState);
      
      callback = Function__bind.call(callback, undefined, _, dom);
      
      deferUntil(callback, function() {
        return _private.isReady;
      });
    });
  };

  _private.isReady = /loaded|complete/.test(document.readyState);
  
  if (!_private.isReady && document.addEventListener) {
    document.addEventListener("DOMContentLoaded", function() {
      _private.isReady = true;
    }, false);
  }
}

// =========================================================================
// base2/Requirement.js
// =========================================================================

// Private.

var loadedScripts = {};
if (isBrowser) {
  var head = scripts[0].parentNode;
  var urlResolver = document.createElement("script");
}

var Requirement = Base.extend({
  constructor: function _Requirement__constructor(objectID, src) {
    if (objectID in base2_shims) {
      objectID = "_.shims." + objectID;
    }
    if (!this.object) {
      this.tick = Function__bind.call(Function("_", "try{this.object=" + objectID + "}catch(e){}"), this, _private);
      this.tick();
      if (!this.object && src) {
        src = this.resolve(src);
        if (!loadedScripts[src]) {
          loadedScripts[src] = true;
          this.load(src);
          this.tick();
        }
      }
    }
  },

  load: function _Requirement__load(src) {
    throw new Error("base2.require() is not supported on this platform.");
  },

  resolve: I,
  
  tick: Undefined,

  "@(load)": { // Rhino
    load: function _Requirement__load(src) {
      load(src);
    }
  },

  "@(global.GLOBAL==global)": { // Node.js
    load: function _Requirement__load(src) {
      require(__dirname + "/" + src);
    }
  },
  
  "@(jscript)": { // WSH
    load: function _Requirement__load(src) {
      var xhr = createCOMObject("XMLHTTP");
      xhr.open("GET", src, false);
      xhr.send(null);
      if (xhr.status === 200) {
        Function(xhr.responseText)();
      }
    }
  },

  "@(<script>)": { // browser
    load: function _Requirement__load(src) {
      // load the external script
      var script = document.createElement("script");
      script.type = "text/javascript";
      script.src = src;
      head.insertBefore(script, head.firstChild);
    },

    resolve: function _Requirement__resolve(src) {
      urlResolver.src = src;
      return urlResolver.src;
    }
  }
});

// =========================================================================
// base2/Requirements.js
// =========================================================================

// Private.

var Requirements = Collection.extend({
  constructor: function _Requirements__constructor(requirements, callback) {
    this.base(requirements);

    requirements = this;

    deferUntil(function() { // defer
      if (isFunction(callback)) {
        // Create the namespace object.
        var names = {}, args = [];
        requirements.forEach(function(requirement, objectID) {
          var name = objectID.split(".").pop();
          args.push(names[name] = requirement.object);
        });
        args.unshift(new Namespace(args, names));
        // Execute the callback function.
        callback.apply(undefined, args);
      }
    }, function() { // until
      requirements.invoke("tick");
      return requirements.every(_Requirement_isLoaded);
    }, 0, TIMEOUT, function() { // ontimeout
      throw new Error("Failed to load requirements: " + String(requirements).slice(1, -1));
    });
  }
}, {
  Item: Requirement
});

// help

function _Requirement_isLoaded(requirement) {
  return !!requirement.object;
}

// =========================================================================
// base2/XMLHttpRequest.js
// =========================================================================

var createCOMObject;

/*@if (@_jscript)
var msXmlVersion = 0;
// http://blogs.msdn.com/xmlteam/archive/2006/10/23/using-the-right-version-of-msxml-in-internet-explorer.aspx
createCOMObject = function createCOMObject(libName) {
  var progId = "MSXML2." + libName + "." + msXmlVersion + ".0";
  return typeof ActiveXObject == "function" ? new ActiveXObject(progId) : WScript.CreateObject(progId);
};

msXmlVersion = 6;
try {
  var xhr = createCOMObject("XMLHTTP");
} catch (ex1) {
  msXmlVersion = 3;
  try {
    xhr = createCOMObject("XMLHTTP");
  } catch (ex2) {
    msXmlVersion = 0;
  }
}
_private.createCOMObject = createCOMObject;
xhr = null;
/*@end @*/

base2_shims.XMLHttpRequest = detect("(new XMLHttpRequest)") ? XMLHttpRequest : createCOMObject ? function XMLHttpRequest_msie() {
  return createCOMObject("XMLHTTP");
} : null;

 return base2;
})(base2,Object,Array,Date,Function,RegExp,String,Error,RangeError,ReferenceError,SyntaxError,TypeError); // end: closure

base2.exec(function(_) { // begin: closure

var CONST_CAPTURING_PHASE = 1;
var CONST_AT_TARGET       = 2;
var CONST_BUBBLING_PHASE  = 3;

var CONST_PROPAGATION_STOPPED = 0;
var CONST_DEFAULT_PREVENTED   = 1;

// =========================================================================
// base2/EventTarget/EventTarget.js
// =========================================================================

var EventTarget = _.Trait.extend({
  addEventListener: addEventListener,
  dispatchEvent: dispatchEvent,
  removeEventListener: removeEventListener
});

EventTarget.test = function EventTarget_test(object) {
  return object && typeof object == "object";
};

EventTarget.toString = _.K("[base2.EventTarget]");

base2.EventTarget = EventTarget;

function addEventListener(type, listener, useCapture) {
  // assign a unique id to both objects
  var targetID = _.assignID(this);
  var listenerID = _.assignID(listener);
  // create a hash table of event types for the target object
  var phase = useCapture ? CONST_CAPTURING_PHASE : CONST_BUBBLING_PHASE;
  var typeMap = allEvents[type];
  if (!typeMap) typeMap = allEvents[type] = {1:{}, 3:{}};
  var phaseMap = typeMap[phase];
  // create a hash table of event listeners for each object/event pair
  var listeners = phaseMap[targetID];
  if (!listeners) listeners = phaseMap[targetID] = {};
  // store the event listener in the hash table
  listeners[listenerID] = listener;
}

function removeEventListener(type, listener, useCapture) {
  // delete the event listener from the hash table
  var typeMap = allEvents[type];
  if (typeMap) {
    var phaseMap = typeMap[useCapture ? CONST_CAPTURING_PHASE : CONST_BUBBLING_PHASE];
    if (phaseMap) {
      var listeners = phaseMap[this.nodeType === 1 ? this.uniqueID : this.base2ID];
      if (listeners) delete listeners[listener.base2ID];
    }
  }
}

function dispatchEvent(event) {
  if (typeof event == "string") {
    event = new Event(event);
  }
  if (this != event.target) {
    _private.createGetter(event, "target", this);
  }

  var type = event.type;
  var target = event.target;
  var typeMap = allEvents[type];
  if (typeMap) {
    // Collect nodes in the event hierarchy
    var nodes = [], i = 0;
    while (target) {
      nodes[i++] = target;
      target = target.parentNode;
    }
    // Dispatch.
    var phaseMap = typeMap[CONST_CAPTURING_PHASE];
    if (phaseMap) {
      dispatchPhase(event, CONST_CAPTURING_PHASE, nodes, phaseMap);
    }
    phaseMap = typeMap[CONST_BUBBLING_PHASE];
    if (phaseMap && !event[CONST_PROPAGATION_STOPPED]) {
      if (event.bubbles) {
        nodes.reverse();
      } else {
        nodes.length = 1;
      }
      dispatchPhase(event, CONST_BUBBLING_PHASE, nodes, phaseMap);
    }
  } else {
    var ontype = "on" + type;
    if (typeof target[ontype] == "function") {
      continueIfThrow(target[ontype], target, event);
    }
  }
  return !!event[CONST_DEFAULT_PREVENTED];
}

function dispatchPhase(event, phase, nodes, phaseMap) {
  event.eventPhase = phase;
  var i = nodes.length;
  var ontype = "on" + event.type;
  while (i-- && !event[CONST_PROPAGATION_STOPPED]) {
    var target = event.currentTarget = nodes[i];
    event.eventPhase = target == event.target ? CONST_AT_TARGET : phase;
    if (phase === CONST_BUBBLING_PHASE && typeof target[ontype] == "function") {
      continueIfThrow(target[ontype], target, event);
    }
    var listeners = phaseMap[target.nodeType === 1 ? target.uniqueID : target.base2ID];
    if (listeners) {
      var clonedListeners = {};
      for (var id in listeners) clonedListeners[id] = listeners[id];
      for (id in clonedListeners) {
        var listener = clonedListeners[id];
        if (typeof listener == "function") {
          continueIfThrow(listener, target, event);
        } else {
          continueIfThrow(listener.handleEvent, listener, event);
        }
      }
    }
  }
}

// =========================================================================
// base2/EventTarget/Event.js
// =========================================================================

var Event = _.Base.extend({
  constructor: function Event__constructor(type, data) {
    this.timeStamp = _.now();
    if (type) {
      _private.createGetter(this, "type", String(type));
      for (var i in data) this[i] = data[i];
    }
  },
  
  CAPTURING_PHASE: CONST_CAPTURING_PHASE,
  AT_TARGET:       CONST_AT_TARGET,
  BUBBLING_PHASE:  CONST_BUBBLING_PHASE,

  type: "",
  target: null,
  currentTarget: null,
  bubbles: false,
  cancelable: false,
  eventPhase: 0,
  timeStamp: 0,
  
  preventDefault: function preventDefault() {
    this[CONST_DEFAULT_PREVENTED] = true;
  },

  stopPropagation: function stopPropagation() {
    this[CONST_PROPAGATION_STOPPED] = true;
  },

  initEvent: function initEvent(type, bubbles, cancelable) {
    this.type = String(type);
    this.bubbles = !!bubbles;
    this.cancelable = !!cancelable;
    this.timeStamp = _.now();
  },

  toString: _.K("[object Event]")
});

// =========================================================================
// base2/EventTarget/_private.js
// =========================================================================

// Call a function in a new execution context.
// Even if the function errors, the next line in your program will still execute, you will also get an error message in the console.

// http://dean.edwards.name/weblog/2009/03/callbacks-vs-events/

var _private = _._;
if (!_private.events) _private.events = {};

var allEvents = _private.events;

var HAS_CONSOLE = false;

var Function__bind = _.Functional.prototype.bind;
var Function__call = Function.prototype.call;

function throwLater() {
  try {
    Function__call.apply(Function__bind, arguments)();
  } catch (ex) {
    if (HAS_CONSOLE) console.log(ex); // this only works with Firebug
    setTimeout(function(){throw ex}, 4); // this does not do anything in Firefox 4
  }
}

var continueIfThrow = throwLater;

var isBrowser = _.detect("(<script>)");

if (isBrowser) {
  var document = window.document;
  
  var SUPPORTS_CLICK = false;
  var button = document.createElement("button");
  button.onclick = function() {
    SUPPORTS_CLICK = true;
  };
  button.click();
  
  if (SUPPORTS_CLICK) {
    continueIfThrow = function continueIfThrow() {
      button.onclick = Function__call.apply(Function__bind, arguments);
      button.click();
      button.onclick = null;
    };
  } else if (_.detect("Gecko")) {
    // Firefox doesn't report errors using dispatchEvent().
    // https://bugzilla.mozilla.org/show_bug.cgi?id=503244
    // This bug is currently unfixed and undetectable.
    // This code only exists for debugability in Firefox.
    HAS_CONSOLE = _.detect("(console.log)");
  } else {
    var head = document.getElementsByTagName("script")[0].parentNode;
    if (document.createEvent) {
      var __exec__;
      head.addEventListener("base2:call", function(){__exec__()}, false);
      continueIfThrow = function continueIfThrow() {
        __exec__ = Function__call.apply(Function__bind, arguments);
        var dummyEvent = document.createEvent("Events");
        dummyEvent.initEvent("base2:call", false, false);
        head.dispatchEvent(dummyEvent);
        __exec__ = _.Undefined;
      };
    } else {
      var BASE2_EXEC = "#base2_exec";
      var isMSIE = _.detect("MSIE"), count = 0;
      continueIfThrow = function continueIfThrow() {
        if (isMSIE && ++count > 3) { // MSIE barfs on the fourth script so we use a different technique
          throwLater.apply(undefined, arguments);
        } else { // Use script injection so that events are cancelable
          window[BASE2_EXEC] = Function__call.apply(Function__bind, arguments);
          var script = document.createElement("script");
          script.type = "text/javascript";
          script.text = "window['" + BASE2_EXEC + "']()";
          head.insertBefore(script, head.firstChild);
          head.removeChild(script);
          window[BASE2_EXEC] = undefined;
        }
        count--;
      };
    }
  }
}

_private.continueIfThrow = continueIfThrow;

// =========================================================================
// createGetter
// =========================================================================

(function(Object) {
  var object = {};
  var element = {};
  var SUPPORTS_OBJECT_DEFINE_PROPERTY = false;
  var SUPPORTS_OBJECT_GETTER = !!object.__defineGetter__;
  
  var READ_ONLY_ERR = function() {
    throw new Error("Cannot set read-only property.");
  };
  
  var defineProperty = Object.defineProperty;
  for (var name in Object) if (defineProperty == Object[name]) {
    defineProperty = null;
    break;
  }

  if (defineProperty) {
    try {
      defineProperty(object, "x", {get: _.K(1)});
      SUPPORTS_OBJECT_DEFINE_PROPERTY = object.x === 1;
    } catch (ex) {}
  }
  
  var ENUMERABLE = defineProperty && SUPPORTS_OBJECT_DEFINE_PROPERTY;
  
  var SUPPORTS_GETTERS = SUPPORTS_OBJECT_DEFINE_PROPERTY || SUPPORTS_OBJECT_GETTER;

  _private.createGetter = function(object, propertyName, value, getter) {
    if (SUPPORTS_OBJECT_DEFINE_PROPERTY || (defineProperty && object.componentFromPoint)) {
      defineProperty(object, propertyName, {get:getter || _.K(value), set:READ_ONLY_ERR, enumerable:ENUMERABLE});
    } else if (SUPPORTS_OBJECT_GETTER) {
      object.__defineGetter__(propertyName, getter || _.K(value));
      object.__defineSetter__(propertyName, READ_ONLY_ERR);
    } else {
      object[propertyName] = value;
    }
  };

  _private.createGetters = function(object, properties) {
    if (SUPPORTS_GETTERS) {
      _.forEach (properties, function(value, propertyName) {
        var getter = function() {
          return properties[propertyName];
        };
        if (SUPPORTS_OBJECT_DEFINE_PROPERTY) {
          defineProperty(object, propertyName, {get:getter, set:READ_ONLY_ERR, enumerable:ENUMERABLE});
        } else {
          object.__defineGetter__(propertyName, getter);
          object.__defineSetter__(propertyName, READ_ONLY_ERR);
        }
      });
      return properties;
    } else {
      for (var propertyName in properties) {
        object[propertyName] = properties[propertyName];
      }
      return object;
    }
  };
})(Object);

}); // end: closure

base2.require("base2.EventTarget", function(_, EventTarget) { // begin: closure

/*@cc_on @*/

var undefined;
var _private = _._;
var base2    = _.base2;
var forEach  = _.forEach;

var window = self.window;
var document = window.document;
var documentElement = document.documentElement;
var element = document.createElement("unknown");

var Function__call = Function.prototype.call;
var Array__slice = [].slice;

var DOM_ARITY_ERR = "Not enough arguments for {0}().";
var DOM_TYPE_ERR  = "Invalid target for {0}().";

function ArityError(methodName) {
  if (methodName) this.message = _.format(DOM_ARITY_ERR, methodName);
}
ArityError.prototype = new SyntaxError;
_private.ArityError = ArityError;

function TargetError(methodName) {
  if (methodName) this.message = _.format(DOM_TYPE_ERR, methodName);
}
TargetError.prototype = new TypeError;
_private.TargetError = TargetError;

var SPACE = /\s/;

var TEXT_CONTENT = "textContent" in element ? "textContent" : "innerText";

var NO_CHILDREN  = /^(base|br|hr|img|input|link|meta|param|source)$/i;

var SUPPORTS_TRAVERSAL_API = "nextElementSibling" in element;

var SIBLING = (SUPPORTS_TRAVERSAL_API ? "Element" : "") + "Sibling";

var vendorPrefixes = {
  "Trident": "ms",
  "WebKit":  "Webkit",
  "KHTML":   "Khtml",
  "Gecko":   "Moz",
  "Opera":   "O"
};

var CSS_PREFIX = "";
for (var browser in vendorPrefixes) {
  if (_.detect(browser)) {
    CSS_PREFIX = vendorPrefixes[browser];
    break;
  }
}
var JS_PREFIX = CSS_PREFIX.toLowerCase();
_private.jsPrefix = JS_PREFIX;

function createStaticMethod(name, args, method, test) {
  args = args.split(",");
  if (method) {
    var CALL = "_call.apply(_method, arguments)";
    var ARGS = "_call,_method,_validType";
  } else {
    CALL = "{2}.{0}({3})";
    ARGS = "";
  }
  
  var body = _.format('return function {0}(' + args.join(', ') + ') {\n' +
    '  if (arguments.length < {1}) {\n' +
    '    throw new SyntaxError("' + DOM_ARITY_ERR + '");\n' +
    '  }\n' +
    '  if (!{2} || ' + test + ') {\n' +
    '    throw new TypeError("' + DOM_TYPE_ERR + '");\n' +
    '  }\n' +
    '  return ' + CALL + ';\n' +
    '}'
  , name, args.length, args[0], args.slice(1).join(", "), name);
  
  return Function(ARGS, body)(Function__call, method, QSA_VALID_TYPES);
}

function _contains(child) {
  if (arguments.length < 1) throw new ArityError("contains");
  if (!child || !child.nodeType) throw new TargetError("contains");

  while (child && (child = child.parentNode) && this != child) continue;
  return !!child;
}

function _includes(node, target) {
  while (target && node != target && (target = target.parentNode)) continue;
  return !!target;
}

// These functions are passed to Selectors API queries.

function _getElementChild(element, type) {
  element = element[type + "Child"];
  if (!element) return null;
  if (element.nodeType === 1) return element;
  return _getElementSibling(element, type === "first" ? "next" : "previous");
}

function _getElementSibling(element, direction) {
  direction += SIBLING;
  do {
    element = element[direction];
    if (element && element.nodeType === 1) break;
  } while (element);
  return element;
}

function _getElementSiblingByType(element, direction) {
  var tagName = element.nodeName;
  direction += SIBLING;
  do {
    element = element[direction];
    if (element && element.nodeName === tagName) break;
  } while (element);
  return element;
}

function _isEmpty(element) {
  if (element.canHaveChildren === false) return false;
  if (element.style && NO_CHILDREN.test(element.nodeName)) return false;
  var node = element.firstChild;
  while (node) {
    if (node.nodeType === 3 || node.nodeType === 1) return false;
    node = node.nextSibling;
  }
  return true;
}

// =========================================================================
// base2/dom/attributes.js
// =========================================================================

element.expando = true;

var BROKEN_GET_ATTRIBUTE = element.getAttribute("xyz") != null || element.getAttribute("expando");

var _removeAttribute, _setAttribute;

if (BROKEN_GET_ATTRIBUTE) {
  var _getAttribute = function getAttribute(name) {
    if (arguments.length < 1) throw new ArityError("getAttribute");

    var element = this;
    name = String(name).toLowerCase();

    var attribute = element.getAttributeNode(name);
    var specified = attribute && attribute.specified;

    /*@if (@_jscript)
      if ("className" in element) {
        var defaultName = _DEFAULT_PROPERTY[name];
        if (typeof defaultName == "string" && defaultName in element) {
          if (name === "value") {
            if (element.nodeName === "INPUT") {
              return element.defaultValue || null;
            }
          } else return element[defaultName] ? "" : null;
        }

        var name2 = _BOOLEAN_ALIASES[name] || name;
        if (typeof element[name2] == "boolean") return element[name2] ? "" : null;

        if (specified && name === "style") return element.style.cssText.toLowerCase();

        if ((specified && _USE_IFLAG[name]) || name === "enctype" || name === "type") {
          var value = elementMethods.getAttribute.call(element, name, 2);
          return value == null ? null : String(value);
        }
      }
    /*@end @*/

    return specified ? String(attribute.nodeValue) : null;
  };

  var _hasAttribute = function hasAttribute(name) {
    if (arguments.length < 1) throw new ArityError("hasAttribute");

    return _getAttribute.call(this, name) != null;
  };

  /*@if (@_jscript)
    var _DEFAULT_PROPERTY  = {checked:"defaultChecked", selected:"defaultSelected", value:"defaultValue"};
    var _USE_IFLAG         = {action:1, cite:1, colspan:1, codebase:1, data:1, dynsrc:1, enctype:1, href:1,
                              longdesc:1, lowsrc:1, profile:1, rowspan:1, src:1, type:1, usemap:1, url:1};
    var _BOOLEAN_ALIASES   = {readonly: "readOnly", ismap: "isMap"};
    var _EVENT_ATTRIBUTE   = /^on[a-z]{3,}$/;
    var _DEFAULT_VALUES = {
      COL:      {span: 1},
      COLGROUP: {span: 1},
      FORM:     {enctype: "application/x-www-form-urlencoded"},
      TEXTAREA: {rows: 2, cols: 20},
      TD:       {rowspan: 1, colspan: 1},
      TH:       {rowspan: 1, colspan: 1}
    };

    // Not aware of other browser bugs just MSIE6-8 (IE9 does not get this far unless it is in compatibility mode)
    _removeAttribute = function removeAttribute_msie(name) {
      if (arguments.length < 1) throw new ArityError("removeAttribute");

      var element = this;
      var attribute = element.getAttributeNode(name);
      
      if (attribute) {
        if ("className" in element) {
          name = String(name).toLowerCase();

          if (name === "class") {
            element.className = "";
          } else if (name === "style") {
            element.style.cssText = "";
          } else {
            var nodeName = element.nodeName;
            if (nodeName === "INPUT") {
              switch (name) {
                case "type":
                  return; // can't remove the type attribute but try not to error

                case "checked":
                  element.checked = element.defaultChecked = false;
                  return;

                case "value":
                  element.value = element.defaultValue = "";
              }
            }
            if (_EVENT_ATTRIBUTE.test(name)) {
              element[name] = null;
            } else {
              // reset the nodeValue to its default
              var defaultValues = _DEFAULT_VALUES[nodeName];
              if (defaultValues && name in defaultValues) {
                attribute.nodeValue = defaultValues[name];
              }
            }
          }
        }
        element.removeAttributeNode(attribute);
      }
    };
    _setAttribute = function setAttribute_msie(name, value) {
      if (arguments.length < 2) throw new ArityError("setAttribute");
      
      var element = this;
      name = String(name).toLowerCase();
      value = String(value);

      var isHTML = "className" in element;

      if (isHTML && name === "style") {
        element.style.cssText = value;
      } else {
        if (isHTML && element.nodeName === "INPUT") {
          switch (name) {
            case "checked":
              element.checked = element.defaultChecked = true;
              return;

            case "value":
              element.value = element.defaultValue = value;
          }
        }
        if (isHTML && _EVENT_ATTRIBUTE.test(name)) {
          var document = element.ownerDocument;
          var dummy = Function__call.call(documentMethods.createElement, document, element.nodeName);
          elementMethods.setAttribute.call(dummy, name, value);
          element.mergeAttributes(dummy);
        } else {
          var attribute = element.getAttributeNode(name);
          try {
            if (attribute) {
              attribute.nodeValue = typeof attribute.nodeValue == "boolean" ? true : value;
            } else {
              elementMethods.setAttribute.call(element, name, value);
              //if (isHTML) element.className += ""; // recalc
            }
          } catch (ex) {
            // not much we can do here
          }
        }
      }
    };
  /*@end @*/
} else {
  _getAttribute = element.getAttribute;
  _hasAttribute = element.hasAttribute;
}

// =========================================================================
// base2/dom/properties.js
// =========================================================================

var SET_INNER_HTML_MUST_DESTROY_DOM = _.detect("Maple5"); // Samsung TV memory leaks

var SCRIPT_TEXT = _.detect("(<script>.textContent)") ? "textContent" : "text";

var WRITEABLE = 0, READONLY = 1;

var DOM_PROPERTIES = {
  textContent:            WRITEABLE,
  innerHTML:              WRITEABLE,
  firstElementChild:      READONLY,
  lastElementChild:       READONLY,
  nextElementSibling:     READONLY,
  previousElementSibling: READONLY,
  childElementCount:      READONLY,
  classList:              READONLY,
  dataset:                READONLY
};

dom_get.properties = DOM_PROPERTIES;

function dom_get(node, propertyName) {
  if (arguments.length < 2) throw new ArityError("dom.get");
  if (!node || !node.nodeType) throw new TargetError("dom.get");
    
  var value = node[propertyName];
  
  if (typeof value == "undefined" && node.nodeType === 1) {
    switch (propertyName) {
      case "textContent":
        /*@if (@_jscript)
        if (node.nodeName === "SCRIPT") return node.text;
        /*@end @*/
        return node.innerText;

      case "firstElementChild":
        return _getElementChild(node, "first");

      case "lastElementChild":
        return _getElementChild(node, "last");

      case "nextElementSibling":
        return _getElementSibling(node, "next");

      case "previousElementSibling":
        return _getElementSibling(node, "previous");

      case "childElementCount":
        var count = 0;
        node = node.firstChild;
        while (node) {
          if (node.nodeType === 1) count++;
          node = node.nextSibling;
        }
        return count;
    }
  }

  return value;
}

function dom_set(node, propertyName, value) {
  if (arguments.length < 3) throw new ArityError("dom.set");
  if (!node || !node.nodeType) throw new TargetError("dom.set");
  
  if (node.nodeType === 1) {
    if (DOM_PROPERTIES[propertyName] === READONLY) {
      throw new TypeError("Cannot set read-only property: " + propertyName);
    }
    if (propertyName == "innerHTML") {
      /*@if (@_jscript)
        if (document.documentMode < 9) {
          node.innerHTML = "";
          var document = node.ownerDocument;
          var dummyDIV = Function__call.call(documentMethods.createElement, document, "div");
          document.body.appendChild(dummyDIV);
          dummyDIV.innerHTML = value;
          document.body.removeChild(dummyDIV);
          while (dummyDIV.firstChild) {
            element.appendChild(dummyDIV.firstChild);
          }
          return element.innerHTML;
        }
      @else @*/
        if (SET_INNER_HTML_MUST_DESTROY_DOM) {
          while (node.lastChild) {
            if (node.deleteChild) node.deleteChild(node.lastChild);
            else node.removeChild(node.lastChild);
          }
        }
      /*@end @*/
    } else if (propertyName == "textContent" && !(propertyName in node)) {
      propertyName = "innerText";
      /*@if (@_jscript)
      if (node.nodeName === "SCRIPT") propertyName = "text";
      else if (node.nodeName === "STYLE") {
        node = node.styleSheet;
        propertyName = "cssText";
      }
      /*@end @*/
    }
  }
  
  return node[propertyName] = value;
}

// =========================================================================
// base2/dom/classList.js
// =========================================================================

// http://dev.w3.org/html5/spec/Overview.html#domtokenlist

var SUPPORTS_CLASS_LIST = !!element.classList;

// a constructor that binds ClassList objects to elements
function ClassList(element) {
  // For most platforms, data is the element itself.
  // For MSIE6, data is a pointer to the element in the document.
  /*@if (@_jscript_version < 5.7)
    msieCache[this._element = element.uniqueID] = element;
  @else @*/
    this._element = element;
  /*@end @*/
}

ClassList.prototype.toString = function(token) {
  var element = this._element;
  /*@if (@_jscript_version < 5.7)
     element = msieCache[element];
  /*@end @*/
  return element.className;
};

var classList = (function() {
  var HAS_CLASS     = '(" " + e.c + " ").indexOf(" " + c + " ") !== -1';
  var NOT_HAS_CLASS = HAS_CLASS.replace("!", "=");
  var ADD_CLASS     = 'e.c += (e.c ? " " : "") + c;';
  var REMOVE_CLASS  = 'e.c = base2.lang.trim(e.c.replace(new RegExp("(^|\\\\s)" + c + "(\\\\s|$)", "g"), "$2"));';
  
  function createMethod(name, body) {
    if (SUPPORTS_CLASS_LIST) {
      body = "return e.{0}(c);"
    }
    ;;; if (!SUPPORTS_CLASS_LIST) body = body.split("\n").join("\n  ");
    
    var FN = 'return function classList_{1}(e, c) {\n' +
      '  if (arguments.length < 2) {\n' +
      '    throw new SyntaxError("' + DOM_ARITY_ERR + '");\n' +
      '  }\n' +
      '  if (!e || e.nodeType !== 1) {\n' +
      '    throw new TypeError("' + DOM_TYPE_ERR + '");\n' +
      '  }\n' +
      '  if (/\\s/.test(c)) {\n' +
      '    throw new Error("c cannot contain spaces: {0}().");\n' +
      '  }\n' +
      '  if (c === "") {\n' +
      '    throw new Error("c cannot be an empty string: {0}().");\n' +
      '  }\n  ' +
      body +
      '\n}\n';
      
    var body = _.format(FN, "classList." + name, name).replace(/\bc\b/g, "className");
    ;;; body = body.replace(/\be\b/g, "element");
    
    var fn = Function(body)();

    ClassList.prototype[name] = function(token) {
      var element = this._element;
      /*@if (@_jscript_version < 5.7)
         element = msieCache[element];
      /*@end @*/
      var args = Array__slice.call(arguments);
      args.unshift(element);
      return fn.apply(undefined, args);
    };
    
    return fn;
  }

  return {
    add:      createMethod("add", 'if (' + NOT_HAS_CLASS + ') {\n  ' + ADD_CLASS + '\n}'),
    contains: createMethod("contains", 'return ' + HAS_CLASS + ';'),
    remove:   createMethod("remove", REMOVE_CLASS),
    toggle:   createMethod("toggle", 'if (' + NOT_HAS_CLASS + ') {\n  ' + ADD_CLASS + '\n} else {\n  ' + REMOVE_CLASS + '\n}'),

    toString: _.K("[base2.dom.classList]")
  };
})();

var SUPPORTS_EVENT_TARGET    = !!element.addEventListener;
var SUPPORTS_OBJECT_LISTENER = true; // feature tested later
var FORGETS_CUSTOM_DATA      = false; // feature tested later
// Firefox doesn't report errors using dispatchEvent().
// https://bugzilla.mozilla.org/show_bug.cgi?id=503244
var SILENT_DISPATCH = _.detect("Gecko"); // This bug is undetectable.
var HAS_CONSOLE = SILENT_DISPATCH && _.detect("(console.log)");

var EVENT_API = SUPPORTS_EVENT_TARGET ? "addEventListener" : "attachEvent";

var eventWrappers = {
 DOMContentLoaded: function wrapDOMContentLoaded(type, listener) {
    return _wrap(type, listener, function _wrappedListener(event) {
      event = cloneEvent(event);
      event.type = type;
      event.eventPhase = 2; // AT_TARGET
      event.bubbles = event.cancelable = false;
      removeEventListener(this, type, listener);
      _handleEvent(this, listener, event);
    });
  },

  mouseenter: wrapMouseEnterLeave,
  mouseleave: wrapMouseEnterLeave
};

var customEvents = {};

var _wrappedListeners = {};

var _wrappedTypes = {
  DOMContentLoaded: "base2:DOMContentLoaded",
  mouseenter: "mouseover",
  mouseleave: "mouseout"
};

function _wrap(type, listener, wrapper) {
  var key = type + "." + _.assignID(listener);
  if (!_wrappedListeners[key]) {
    _wrappedListeners[key] = wrapper;
  }
  return _wrappedListeners[key];
}

function _unwrap(type, listener) {
  return _wrappedListeners[type + "." + listener.base2ID] || listener;
}

function wrapMouseEnterLeave(type, listener) {
  return _wrap(type, listener, function _wrappedListener(event) {
    // https://bugzilla.mozilla.org/show_bug.cgi?id=497780
    var xulRelatedTarget = typeof XULElement == "function" && event.relatedTarget instanceof XULElement;
    if (!xulRelatedTarget && _includes(this, event.target) && !_includes(this, event.relatedTarget)) {
      event = cloneEvent(event);
      event.currentTarget = this;
      event.target = this;
      event.type = type;
      event.bubbles = event.cancelable = false;
      _handleEvent(this, listener, event);
    }
  });
}

// All other browsers support onmousewheel even if they don't directly support the onmousewheel property
if (!("onmousewheel" in element) && _.detect("Gecko")) {
  _wrappedTypes.mousewheel = "DOMMouseScroll";
  eventWrappers.mousewheel = function wrapMouseWheel(type, listener) {
    return _wrap(type, listener, function _wrappedListener(event) {
      event = cloneEvent(event);
      event.type = type;
      event.wheelDelta = (-event.detail * 40) || 0;
      _handleEvent(this, listener, event);
    });
  };
}

if (_.detect("\\b(Linux|Mac)\\b|Opera\\d")) { // http://unixpapa.com/js/key.html
  eventWrappers.keydown = function wrapKeyDown(type, listener) {
    // Some browsers do not fire repeated "keydown" events when a key
    // is held down. They do fire repeated "keypress" events though.
    // Cancelling the "keydown" event does not cancel the
    // "keypress" event. We fix all of this here...
    var pressed = false; // in case the browser sniff returns a false positive
    return _wrap(type, listener, function _wrappedListener(keydownEvent) {
      if (pressed) return;
      pressed = true;

      var target = this;
      var firedCount = 0;
      var cancelled = false;

      _.extend(keydownEvent, "preventDefault", function() {
        this.base();
        cancelled = true;
      });

      var handleEvent = function handle_keypress(event) {
        if (cancelled) event.preventDefault();
        if (event == keydownEvent || firedCount > 1) {
          _handleEvent(target, listener, keydownEvent);
        }
        firedCount++;
      };

      var onkeyup = function onkeyup() {
        target.removeEventListener("keypress", handleEvent, true);
        target.removeEventListener("keyup", onkeyup, true);
        pressed = false;
      };
      
      target.addEventListener("keyup", onkeyup, true);
      target.addEventListener("keypress", handleEvent, true);

      handleEvent.call(target, keydownEvent);
    });
  };
}

function wrapObjectListener(type, listener) {
  return _wrap(type, listener, function _wrappedListener(event) {
    listener.handleEvent(event);
  });
}

function wrapListener(type, listener) {
  return _wrap(type, listener, function _wrappedListener_gecko(event) {
    _handleEvent(this, listener, event);
  });
}

function _handleEvent(target, listener, event) {
  if (typeof listener == "object") {
    target = listener;
    listener = target.handleEvent;
  }
  if (FORGETS_CUSTOM_DATA) { // for SamsungTV
    var data = customEvents[event.detail];
    for (var i in data) if (!(i in event)) event[i] = data[i];
  }
  if (SILENT_DISPATCH && event._userGenerated) { // Firefox
    // https://bugzilla.mozilla.org/show_bug.cgi?id=574941
    // Try to let the user know that an error occurred.
    try {
      listener.call(target, event);
    } catch (ex) {
      if (HAS_CONSOLE) console.log(ex); // this only works with Firebug
      setTimeout(function(){throw ex}, 1); // this does not do anything in Firefox 4
    }
  } else {
    listener.call(target, event);
  }
}

function cloneEvent(event) {
  if (event.isClone) return event;

  var clone = {};
  for (var i in event) clone[i] = event[i];

  clone.isClone = true;

  clone.stopPropagation = function stopPropagation() {
    if (event.stopPropagation) {
      event.stopPropagation();
    } else {
      event.cancelBubble = true;
    }
  };
  
  clone.preventDefault = function preventDefault() {
    if (event.preventDefault) {
      event.preventDefault();
    } else {
      event.returnValue = false;
    }
  };
  return clone;
}

/*@if (@_jscript)
// break out of closures to attach events in MSIE
var MSIE_PRIVATE = "#base2_msie";
var _msie_private = window[MSIE_PRIVATE];
if (!_msie_private) {
  var LISTENERS = 0, HANDLERS = 1;
  _msie_private = window[MSIE_PRIVATE] = [{}, {}];
  _private.attachEvent = function attachEvent_msie(target, type, listener) {
    var listenerID = _.assignID(listener);
    var handleEvent = _msie_private[HANDLERS][listenerID];

    if (!handleEvent) {
      _msie_private[LISTENERS][listenerID] = listener;
      handleEvent = _msie_private[HANDLERS][listenerID] = new Function("e", "window['" + MSIE_PRIVATE + "'][0]['" + listenerID + "'](e)");
    }
    if (target.attachEvent) {
      target.attachEvent(type, handleEvent);
    }
  };

  _private.detachEvent = function detachEvent_msie(target, type, listener, permanent) {
    var listenerID = listener.base2ID;
    var handleEvent = _msie_private[HANDLERS][listenerID];

    if (target.detachEvent) {
      target.detachEvent(type, handleEvent);
    }
    if (permanent) {
      delete _msie_private[LISTENERS][listenerID];
      delete _msie_private[HANDLERS][listenerID];
    }
  };
}
/*@end @*/

// =========================================================================
// base2/dom/events/MSIE.js
// =========================================================================

// for MSIE6-8

var _MSIE_DocumentState, _MSIE_DOMContentLoaded;

/*@if (@_jscript)

var BUTTON_MAP      = {2: 2, 4: 1},
    EVENT_MAP       = {focusin: "focus", focusout: "blur"},
    MOUSE_BUTTON    = /^mouse(up|down)|click$/,
    MOUSE_CLICK     = /click$/,
    NO_BUBBLE       = /^((before|un)?load|focus|blur|stop|(readystate|property|filter)change|losecapture)$/,
    CANCELABLE      = /^((dbl)?click|mouse(down|up|move|over|out|wheel)|key(down|up|press)|submit|DOMActivate|(before)?(cut|copy|paste)|contextmenu|drag(start|enter|over)?|drop|before(de)?activate)$/,
    CANNOT_DELEGATE = /^(abort|error|load|scroll|(readystate|property|filter)change|(before)?(cut|copy|paste))$/;

var CONST_PROPAGATION_STOPPED = 0;
var CONST_DEFAULT_PREVENTED   = 1;

// Steal the Event constructor that EventTarget uses
var Event = (function() {
  var target = EventTarget({}), event;
  target.addEventListener("test", function(e) {
    event = e;
  });
  target.dispatchEvent("test");
  return event.constructor;
})();

Event = Event.extend({
  constructor: function Event__constructor(originalEvent) {
    if (originalEvent) {
      for (var i in originalEvent) {
        this[i] = originalEvent[i];
      }
      var type = this.type;
      type = this.type = EVENT_MAP[type] || type;

      if (!this.timeStamp) {
        this.bubbles = !NO_BUBBLE.test(type);
        this.cancelable = CANCELABLE.test(type);
        this.timeStamp = _.now();
      }

      this.relatedTarget = originalEvent[(originalEvent.srcElement == originalEvent.fromElement ? "to" : "from") + "Element"] || null;

      var cancelable = this.cancelable;

      this.preventDefault = function preventDefault() {
        if (cancelable) {
          originalEvent.returnValue = false;
          this[CONST_DEFAULT_PREVENTED] = true;
        }
        if (type === "mousedown") { // cancel a mousedown event
          var target = this.target;
          var document = target.ownerDocument;
          var body = document.body;
          var onbeforedeactivate = function(event) {
            _private.detachEvent(body, "onbeforedeactivate", onbeforedeactivate, true);
            event.returnValue = false;
          };
          _private.attachEvent(body, "onbeforedeactivate", onbeforedeactivate);
        }
      };

      this.stopPropagation = function stopPropagation() {
        originalEvent.cancelBubble = true;
        this[CONST_PROPAGATION_STOPPED] = true;
      };
    }
  },

  relatedTarget: null,
  isClone: true
});

var EventDispatcher = _.Base.extend({
  constructor: function EventDispatcher__constructor(state) {
    this.state = state;
  },

  dispatch: function EventDispatcher__dispatch(event) {
    event = new Event(event);
    var type = event.type;
    if (MOUSE_BUTTON.test(type)) {
      var button = MOUSE_CLICK.test(type) ? this.state._button : event.button;
      event.button = BUTTON_MAP[button] || 0;
    }
    return EventTarget_prototype.dispatchEvent.call(event.target, event);
  }
});

_MSIE_DocumentState = {
  constructor: function DocumentState__constructor_msie(document) {
    this.handleEvent = function(event) {
      if (this["on" + event.type]) {
        this["on" + event.type](event);
      }
      return eventDispatcher.dispatch(event);
    };
    var eventDispatcher = new EventDispatcher(this);
    this._dispatch = function(event) {
      event.target = event.target || event.srcElement || document;
      eventDispatcher.dispatch(event);
    };
    // Allow form events to bubble
    var forms = {};
    this._registerForm = function(form) {
      var formID = form.uniqueID;
      if (!forms[formID]) {
        forms[formID] = true;
        _private.attachEvent(form, "onsubmit", this._dispatch);
        _private.attachEvent(form, "onreset", this._dispatch);
      }
    };
    // Allow select events to bubble
    var state = this;
    this._onselect = function(event) {
      if (state._activeElement == event.target) {
        state._selectEvent = cloneEvent(event);
      } else {
        state._dispatch(event);
      }
    };
    this.base(document);
    if (document.readyState === "complete") {
      this["onbase2:DOMContentLoaded"]();
    }
  },

  registerEvent: function registerEvent(type, target) {
    var targetIsWindow = target && target.Infinity;
    var canDelegate = !targetIsWindow && !CANNOT_DELEGATE.test(type);
    if (!this._registeredEvents[type] || !canDelegate) {
      if (!_private.events[type]) _private.events[type] = {1:{}, 3:{}};
      if (canDelegate || !target) target = this.document;
      this.addEvent(type, target || this.document);
    }
  },

  registered: {},

  fireEvent: function fireEvent(type, event) {
    event = cloneEvent(event);
    event.type = type;
    this.handleEvent(event);
  },

  addEvent: function addEvent(type, target) {
    // Make sure that all events are marshalled through this object
    var key = _.assignID(target) + type;
    if (!this.registered[key] && ("on" + type) in target) {
      this.registered[key] = true;
      var state = this;
      _private.attachEvent(target, "on" + type, function(event) {
        event.target = event.srcElement || target;
        state.handleEvent(event);
        if (type === "mouseup" && state._selectEvent) {
          state._dispatch(state._selectEvent);
          delete state._selectEvent;
        }
      });
    }
  },

  "onbase2:DOMContentLoaded": function onDOMContentLoaded(event) {
    // register forms so that we can bubble form events
    forEach (this.document.forms, this._registerForm, this);
    this.onactivate(this.document.activeElement);
  },

  onmousedown: function onmousedown(event) {
    this.base(event);
    // remember the button number (it's missing in some event types)
    this._button = event.button;
  },

  onmouseup: function onmouseup(event) {
    this.base(event);
    // Fire missing mousedown event in MSIE (on dblclick)
    if (!event._userGenerated && this._button == null) {
      this.fireEvent("mousedown", event);
    }
    delete this._button;
  },

  onfocusin: function onfocusin(event) {
    this.onactivate(event.target);
  },

  onfocusout: _.Undefined,

  onactivate: function onactivate(element) {
    // Allow change events to bubble
    var change = this._registeredEvents.change && "onchange" in element,
       select = this._registeredEvents.select && "onselect" in element;
    if (change || select) {
      var dispatch = this._dispatch, onselect = this._onselect;
      if (change) _private.attachEvent(element, "onchange", dispatch);
      if (select) _private.attachEvent(element, "onselect", onselect);
      var onblur = function() {
        _private.detachEvent(element, "onblur", onblur, true);
        if (change) _private.detachEvent(element, "onchange", dispatch);
        if (select) _private.detachEvent(element, "onselect", onselect);
      };
      _private.attachEvent(element, "onblur", onblur);
    }
  },

  onclick: function onclick(event) {
    // register forms so that we can bubble form events
    var form = event.target.form;
    if (form) this._registerForm(form);
  },

  ondblclick: function ondblclick(event) {
    // Fire missing click event in MSIE
    if (!event._userGenerated) this.fireEvent("click", event);
  }
};

_MSIE_DOMContentLoaded = {
  listen: function DOMContentLoadedEvent__listen_msie(document) {
    var self = this;
    var framed = true; // Rich Dougherty
    try {
      framed = document.parentWindow.frameElement != null;
    } catch (ex) {}
    if (!framed) {
      // Diego Perini: http://javascript.nwbox.com/IEContentLoaded/
      var element = Function__call.call(documentMethods.createElement, document, "div");
      _private.deferUntil(self.fire, function() {
        try {
          element.doScroll("left");
          return true;
        } catch (ex) {
          return false;
        }
      });
    }
    _private.attachEvent(document, "onreadystatechange", function() {
      if (document.readyState === "complete") self.fire();
    });
  }
};

/*@end @*/

// =========================================================================
// base2/dom/events/DocumentEvent.js
// =========================================================================

// http://www.w3.org/TR/DOM-Level-2-Events/events.html#Events-DocumentEvent

var eventCounter = 1;

var createEventFix = function createEvent(eventType) {
  if (arguments.length < 1) throw new ArityError("createEvent");
  
  if (/^Events?$/.test(eventType)) eventType = "UIEvents";
  
  var document = this;
  var event = documentMethods.createEvent.call(document, eventType);
  
  if (FORGETS_CUSTOM_DATA) { // for SamsungTV
    event.initEvent = function initEvent(type, bubbles, cancelable) {
      event.initUIEvent(type, bubbles, cancelable, document.defaultView, eventCounter++);
    };
  }
  return event;
};

if (document.createEvent) {
  if (!_.detect("(document.createEvent('Events'))")) {
    var _createEvent = createEventFix;
  }
} else {
  _createEvent = function createEvent(eventType) {
    if (arguments.length < 1) throw new ArityError("createEvent");
    
    return new Event;
  };
}

// =========================================================================
// base2/dom/events/EventTarget.js
// =========================================================================

// http://www.w3.org/TR/DOM-Level-2-Events/events.html#Events-Registration-interfaces

var EventTarget_prototype = EventTarget.prototype;

function _addEventListener(type, listener, useCapture) {
  var methodName = "addEventListener";
  if (arguments.length < 2) throw new ArityError(methodName);
  
  var target = this;

  if (eventWrappers[type]) {
    if (type == "DOMContentLoaded") useCapture = false;
    listener = eventWrappers[type](type, listener);
    type = _wrappedTypes[type] || type;
  } else if (!SUPPORTS_OBJECT_LISTENER && typeof listener == "object") {
    listener = wrapObjectListener(type, listener);
  } else if (SILENT_DISPATCH || FORGETS_CUSTOM_DATA) {
    listener = wrapListener(type, listener);
  }

  if (SUPPORTS_EVENT_TARGET) {
    var nodeType = target.nodeType;
    var method = nodeType ? (nodeType === 1 ? elementMethods : documentMethods)[methodName] : target[methodName];
    method.call(target, type, listener, !!useCapture);
  } else {
    _DocumentState.getInstance(target).registerEvent(type, target);
    EventTarget_prototype[methodName].call(target, type, listener, useCapture);
  }
}

function _removeEventListener(type, listener, useCapture) {
  var methodName = "removeEventListener";
  if (arguments.length < 2) throw new ArityError(methodName);

  var target = this;

  if (type == "DOMContentLoaded") useCapture = false;
  listener = _unwrap(type, listener);
  type = _wrappedTypes[type] || type;

  if (SUPPORTS_EVENT_TARGET) {
    var nodeType = target.nodeType;
    var method = nodeType ? (nodeType === 1 ? elementMethods : documentMethods)[methodName] : target[methodName];
    method.call(target, type, listener, !!useCapture);
  } else {
    EventTarget_prototype[methodName].call(target, type, listener, useCapture);
  }
}

// feature tests
if (element.dispatchEvent) {
  SUPPORTS_OBJECT_LISTENER = false;
  testEvent({
    handleEvent: function() {
      SUPPORTS_OBJECT_LISTENER = true;
    }
  });
  testEvent(function(event) {
    FORGETS_CUSTOM_DATA = event._customData !== true;
  }, {_customData: true});
  if (FORGETS_CUSTOM_DATA) createEvent = createEventFix;
}

if (!SUPPORTS_EVENT_TARGET || SILENT_DISPATCH || FORGETS_CUSTOM_DATA) {
  var _dispatchEvent = function dispatchEvent(event) {
    var methodName = "dispatchEvent";
    if (arguments.length < 1) throw new ArityError(methodName);

    var target = this;

    event._userGenerated = true;
    
    if (SUPPORTS_EVENT_TARGET) {
      customEvents[event.detail] = event;
      var nodeType = target.nodeType;
      var method = nodeType ? (nodeType === 1 ? elementMethods : documentMethods)[methodName] : target[methodName];
      var returnValue = method.call(target, event);
      delete customEvents[event.detail];
      return returnValue;
    } else {
      event.target = target;
      return _DocumentState.getInstance(target).handleEvent(event, target);
    }
  };
}

function testEvent(listener, data) {
  try {
    var event = createEvent(document, "Events");
    var type = "base2:test";
    event.initEvent(type, true, false);
    for (var i in data) event[i] = data[i];
    documentElement.addEventListener(type, listener, false);
    documentElement.dispatchEvent(event);
    documentElement.removeEventListener(type, listener, false);
  } catch (ex) {}
}

// =========================================================================
// base2/dom/events/DOMContentLoadedEvent.js
// =========================================================================

// http://dean.edwards.name/weblog/2006/06/again

var DOMContentLoadedEvent = _.Base.extend({
  constructor: function DOMContentLoadedEvent__constructor(document) {
    var self  = this;
    var fired = "complete" === document.readyState;
    this.fire = function _DOMContentLoadedEvent_fire() {
      if (document == window.document) _private.isReady = true;
      if (!fired) {
        fired = true;
        var event = createEvent(document, "Events");
        event.initEvent("base2:DOMContentLoaded", true, false);
        dispatchEvent(document.documentElement, event);
      }
    };
    if (fired) this.fire(); else this.listen(document);
  },

  listen: function DOMContentLoadedEvent__listen(document) {
    // if all else fails fall back on window.onload
    addEventListener(document.defaultView, "load", this.fire);
  },

  "@(document.addEventListener)": {
    listen: function DOMContentLoadedEvent__listen(document) {
      this.base(document);
      document.addEventListener("DOMContentLoaded", this.fire, false);
    }
  },

  "@MSIE[678]": _MSIE_DOMContentLoaded,

  "@KHTML": {
    listen: function DOMContentLoadedEvent__listen_webkit(document) {
      this.base(document);
      _private.deferUntil(this.fire, function() { // John Resig
        return /loaded|complete/.test(document.readyState);
      });
    }
  }
});

var _NUMBER  = /\d/,
    CSS_PIXEL   = /\dpx$/i,
    CSS_METRICS = /(width|height|top|bottom|left|right|fontSize)$/i,
    CSS_COLOR   = /color$/i;

var _DASH = /\-/,
    _DASH_LOWER = /\-([a-z])/g,
    _CHAR_UPPER = /[A-Z]/g;

var CSS_NAMED_BORDER_WIDTH = {
  thin: 1,
  medium: 2,
  thick: 4
};

var FIX_COMPUTED_STYLE_COLOR = _.detect("(getComputedStyle(document.documentElement,null).color.charAt(0)==='#')");

var CSS_INLINE_BLOCK = _.detect("Gecko1\\.[^9]") ? "-moz-inline-box" : "inline-block";

var _CALCULATED_STYLE_PROPERTIES = "backgroundPosition,boxSizing,clip,cssFloat,opacity".split(",");

var styleObject = element.style;

function _getStylePropertyName(propertyName) {
  propertyName += "";
  if (propertyName === "float" || propertyName === "cssFloat" || propertyName === "styleFloat") {
    return "cssFloat" in styleObject ? "cssFloat" : "styleFloat";
  }
  if (_DASH.test(propertyName)) {
    propertyName = propertyName.replace(_DASH_LOWER, _toUpperCase);
  }
  if (!(propertyName in styleObject)) {
    var borderRadiusCorner = /^border(\w+)Radius$/;
    if (CSS_PREFIX === "Moz" && borderRadiusCorner.test(propertyName)) {
      propertyName = propertyName.replace(borderRadiusCorner, function(match, corner) {
        return "borderRadius" + corner.charAt(0) + corner.slice(1).toLowerCase();
      });
    }
    var vendorPropertyName = CSS_PREFIX + propertyName.charAt(0).toUpperCase() + propertyName.slice(1);
    if ((vendorPropertyName in styleObject)) {
      propertyName = vendorPropertyName;
    }
  }
  return propertyName;
}

_private.getStylePropertyName = _getStylePropertyName;

function _dash_lower(chr) {
  return "-" + chr.toLowerCase();
}

function _toRGB(value) {
  if (value.indexOf("rgb") === 0) return value.replace(/(\d)\s,/g, "$1,");
  if (value.indexOf("#") !== 0) return value;
  var hex = value.slice(1);
  if (hex.length === 3) hex = hex.replace(/(\w)/g, "$1$1");
  return "rgb(" + _.map(hex.match(/(\w\w)/g), _parseInt16).join(", ") + ")";
}

var _parseInt16  = _.partial(parseInt, undefined, 16);

function _toUpperCase(match, string){
  return string.toUpperCase();
}

/*@if (@_jscript)
var _colorDocument;
try {
  _colorDocument = new ActiveXObject("htmlfile");
  _colorDocument.write("");
  _colorDocument.close();
} catch (ex) {
  _colorDocument = createPopup().document;
}

function _MSIE_getColorValue(color) {
  var body  = _colorDocument.body,
      range = body.createTextRange();
  body.style.color = color.toLowerCase();
  var value = range.queryCommandValue("ForeColor");
  return _.format("rgb({0}, {1}, {2})", value & 0xff, (value & 0xff00) >> 8,  (value & 0xff0000) >> 16);
}

if (!_colorDocument) _MSIE_getColorValue = _.I;

function _MSIE_getPixelValue(element, position, value) {
  var styleLeft = element.style[position];
  var runtimeStyleLeft = element.runtimeStyle[position];
  element.runtimeStyle[position] = element.currentStyle[position];
  element.style[position] = value;
  value = element.style["pixel" + position.charAt(0).toUpperCase() + position.slice(1)];
  element.style[position] = styleLeft;
  element.runtimeStyle[position] = runtimeStyleLeft;
  return value + "px";
}
/*@end @*/

// =========================================================================
// base2/dom/style/ViewCSS.js
// =========================================================================

// http://www.w3.org/TR/DOM-Level-2-Style/css.html#CSS-ViewCSS

if (_.detect("(document.defaultView.getComputedStyle)")) {
  var getComputedStyle = function getComputedStyle(element, pseudoElement) {
    if (arguments.length < 2) throw new ArityError("getComputedStyle");
    if (!element || element.nodeType !== 1) throw new TargetError("getComputedStyle");
    
    var view = element.ownerDocument.defaultView;
    var computedStyle = view.getComputedStyle(element, pseudoElement);
    
    if (FIX_COMPUTED_STYLE_COLOR) { // For Opera 9
      computedStyle = _private.pcopy(computedStyle);
      for (var propertyName in computedStyle) {
        if (CSS_COLOR.test(propertyName)) {
          computedStyle[propertyName] = _toRGB(computedStyle[propertyName]);
        } else if (typeof computedStyle[propertyName] == "function") {
          computedStyle[propertyName] = _.bind(computedStyle[propertyName], computedStyle);
        }
      }
    }
    
    return computedStyle;
  };
} else {
  getComputedStyle = function getComputedStyle(element, pseudoElement) {
    if (arguments.length < 2) throw new ArityError("getComputedStyle");
    if (!element || element.nodeType !== 1) throw new TargetError("getComputedStyle");
    
    var currentStyle = element.currentStyle;
    var computedStyle = {};

    for (var propertyName in currentStyle) {
      if (CSS_METRICS.test(propertyName) || CSS_COLOR.test(propertyName)) {
        computedStyle[propertyName] = style.compute(element, propertyName);
      } else if (propertyName.indexOf("ruby") !== 0) {
        computedStyle[propertyName] = currentStyle[propertyName];
      }
    }
    for (var i = 0; propertyName = _CALCULATED_STYLE_PROPERTIES[i]; i++) {
      computedStyle[propertyName] = style.compute(element, propertyName);
    }
    return computedStyle;
  };
}

// =========================================================================
// base2/dom/style/style.js
// =========================================================================

var style = _.extend({
  toString: _.K("[base2.dom.style]"),
  
  get: function style_get(element, propertyName) {
    if (arguments.length < 2) throw new ArityError("style.get");
    if (!element || element.nodeType !== 1) throw new TargetError("style.get");

    if (!(propertyName in styleObject)) propertyName = _getStylePropertyName(propertyName);

    var value = element.style[propertyName] || "";

    if (value === "-moz-inline-box") value = "inline-block";

    return value;
  },

  set: function style_set(element, propertyName, value, important) {
    if (arguments.length < 2) throw new ArityError("style.set");
    if (!element || element.nodeType !== 1) throw new TargetError("style.set");

    var style = element.style;

    if (arguments.length > 2) {
      if (!(propertyName in styleObject)) {
        propertyName = _getStylePropertyName(propertyName);
        /*@if (@_jscript)
          if (propertyName == "opacity") {
            style.zoom = "100%";
            style.filter = "alpha(opacity=" + ~~(value * 100) + ")";
          }
        /*@end @*/
      }
      if (value == "inline-block") value = CSS_INLINE_BLOCK;
      if (important) {
        propertyName = propertyName.replace(_CHAR_UPPER, _dash_lower);
        if (style.setProperty) {
          style.setProperty(propertyName, String(value), "important");
        } else {
          style.cssText += _.format(";{0}:{1}!important;", propertyName, value);
        }
      } else {
        style[propertyName] = String(value);
      }
    } else {
      var properties = _.extend({}, arguments[1]);
      for (propertyName in properties) {
        value = properties[propertyName];
        if (value == "inline-block") value = CSS_INLINE_BLOCK;
        if (!(propertyName in styleObject)) propertyName = _getStylePropertyName(propertyName);
        if (typeof value == "number" && CSS_METRICS.test(propertyName)) value += "px";
        if (propertyName === "opacity") {
          this.set(element, propertyName, value, "");
        } else {
          style[propertyName] = String(value);
        }
      }
    }
  }
}, {
  "@(element.currentStyle)": { // -@DRE
    compute: function style_compute_msie(element, propertyName) {
      if (arguments.length < 2) throw new ArityError("style.compute");
      if (!element || element.nodeType !== 1) throw new TargetError("style.compute");

      var currentStyle = element.currentStyle;
      var value = currentStyle[propertyName];

      if (value == null) {
        propertyName = _getStylePropertyName(propertyName);
        value = currentStyle[propertyName] || "";
      }

      switch (propertyName) {
        case "float":
        case "cssFloat":
          return currentStyle.cssFloat || currentStyle.styleFloat || "";

        case "opacity":
          return value === "" ? "1" : value;

        case "clip":
          return "rect(" + [
            currentStyle.clipTop,
            currentStyle.clipRight,
            currentStyle.clipBottom,
            currentStyle.clipLeft
          ].join(", ") + ")";

        case "backgroundPosition":
          return currentStyle.backgroundPositionX + " " + currentStyle.backgroundPositionY;

        case "boxSizing":
          return value === ""
            ? element.ownerDocument.compatMode === "BackCompat"
              ? "border-box"
              : "content-box"
            : value;
      }

      if (value.indexOf(" ") > 0) return value;

      if (CSS_METRICS.test(propertyName)) {
        if (CSS_PIXEL.test(value)) return value;
        if (value === "auto") return "0px";
        if (propertyName.indexOf("border") === 0) {
          if (currentStyle[propertyName.replace("Width", "Style")] === "none") return "0px";
          value = CSS_NAMED_BORDER_WIDTH[value] || value;
          if (typeof value == "number") return value + "px";
        }
        /*@if (@_jscript)
          if (_NUMBER.test(value)) return _MSIE_getPixelValue(element, /[Ww]idth|[lL]eft|X/.test(propertyName) ? "left" : "top", value);
        /*@end @*/
      } else if (CSS_COLOR.test(propertyName)) {
        if (value === "transparent") return value;
        if (/^(#|rgb)/.test(value)) return _toRGB(value);
        /*@if (@_jscript)
          return _MSIE_getColorValue(value);
        /*@end @*/
      }

      return value;
    }
  },
  
  "@(document.defaultView.getComputedStyle)": {
    compute: function style_compute(element, propertyName) {
      if (arguments.length < 2) throw new ArityError("style.compute");
      if (!element || element.nodeType !== 1) throw new TargetError("style.compute");

      if (!(propertyName in styleObject)) propertyName = _getStylePropertyName(propertyName);

      if (FIX_COMPUTED_STYLE_COLOR && CSS_COLOR.test(propertyName)) {
        return getComputedStyle(element, null)[propertyName];
      } else {
        var view = element.ownerDocument.defaultView;
        return view.getComputedStyle(element, null)[propertyName];
      }
    }
  }
});

// Many thanks to Diego Perini for testing and inspiration.
// His NWMatcher is awesome: http://javascript.nwbox.com/NWMatcher/

var SUPPORTS_QSA         = !!element.querySelector;
var QSA_VALID_TYPES      = {1:1, 9:1, 11:1};

var BLOCKS               = /\)\{/g;
var COMMA                = /,/;
var QUOTED               = /^['"]/;
var LAST_CHILD           = /last/i;

var PARENT               = "parentElement" in element ? "parentElement" : "parentNode"; // fixes a bug with detached elements
var CHILDREN             = "children" in element ? "children" : "childNodes";
var NEXT_SIBLING         = SUPPORTS_TRAVERSAL_API ? "e.nextElementSibling" : "(e.nextSibling&&_getElementSibling(e,'next'))";
var PREVIOUS_SIBLING     = NEXT_SIBLING.replace(/next/g, "previous");

var NOT_NEXT_BY_TYPE     = "!_getElementSiblingByType(e,'next')&&";
var NOT_PREVIOUS_BY_TYPE = NOT_NEXT_BY_TYPE.replace("next", "previous");
    
var ID_ATTRIBUTE         = "(e.nodeName==='FORM'?e.getAttribute('id'):e.id)";

var object = document.createElement("object");
object.appendChild(document.createElement("param"));
var BUGGY_OBJECT_SELECTORS = object.getElementsByTagName("*").length === 0;
object = null;

if (SUPPORTS_QSA) {
  var USE_BASE2 = _.False;
  
  // Fix for Safari 3.1/3.2 (http://code.google.com/p/base2/issues/detail?id=100)
  var CAPS_SELECTOR = /[#.](\\.|[\w\-]|[^\x00-\xa0])*[A-Z]/;
  var FIX_CAPS_SELECTOR = _.detect("WebKit52"); // This is a browser sniff as the target document may not be in quirks mode
  
  var useBase2 = {};
  
  var pattern = "";
  element.innerHTML = "<a></a>";
  element.firstChild.href = location.href;
  // Empty attribute selectors (MSIE8/Opera10)
  if (element.querySelector("[href^='']")) {
    pattern += "|[\\^*~|$]=\\s*(['\"])\\1";
  }
  // Security
  if (element.querySelector(":visited") != null) {
    pattern += "|:link|:visited";
  }
  // Known bug with Gecko 1.9.0/1
  if (_.detect("Gecko1\\.9(\\.[01])?")) {
    pattern += "|:enabled|:disabled";
  }
  // Known bug with Opera10-10.52
  if (_.detect("Opera10(\\.[0-5])?")) {
    pattern += "|:checked";
  }
  /*@if (@_jscript)
    if (document.documentMode < 9) {
      pattern += "|\\[\\s*(value|ismap|checked|disabled|multiple|readonly|selected)|\\b(object|param|command)\\b";
    }
  /*@end @*/
  // Selectors API 2
  if (!element.queryScopedSelector) {
    pattern += "|:scope";
  }
  if (pattern) {
    USE_BASE2 = new RegExp(pattern.slice(1), "i");
  }
}

// MSIE (and Opera) confuses the name attribute with id for some elements.
// Use document.all to retrieve elements with name/id instead.
try {
  var id = _.assignID();
  
  element.innerHTML = '<a name="' + id + '"></a>';
  documentElement.insertBefore(element, documentElement.firstChild);
  var BUGGY_BY_ID = document.getElementById(id) == element.firstChild;
  documentElement.removeChild(element);

  var _getElementById = BUGGY_BY_ID && document.all ? function getElementById(id) {
    var result = this.all[id] || null;
    // Returns a single element or a collection.
    if (!result || (result.nodeType && _getAttribute.call(result, "id") === id)) return result;
    // document.all has returned a collection of elements with name/id
    for (var i = 0; i < result.length; i++) {
      if (_getAttribute.call(result[i], "id") === id) return result[i];
    }
    return null;
  } : document.getElementById;
} catch(ex){}

// http://dean.edwards.name/weblog/2009/12/getelementsbytagname/
function _getElementsByTagName(node, tagName) {
  var anyTag = tagName === "*";
  
  if (node.getElementsByTagName && !(BUGGY_OBJECT_SELECTORS && anyTag && node.nodeName === "OBJECT")) {
    return node.getElementsByTagName(tagName);
  }
  var elements = [], i = 0;
  var next = node.firstChild;
  var TAGNAME = tagName.toUpperCase();
  while ((node = next)) {
    if (
      anyTag
        ? node.nodeType === 1
        : node.nodeName === TAGNAME || node.nodeName === tagName
    ) elements[i++] = node;
    next = node.firstChild || node.nextSibling;
    while (!next && (node = node.parentNode)) next = node.nextSibling;
  }
  return elements;
}

// Register a node and index its siblings.
_private.qIndex = 1;
var allIndexes = {qIndex: 1};

function _indexOf(element, last, ofType) {
  var parent = element.parentNode;
  if (!parent || parent.nodeType !== 1) return NaN;
  
  var tagName = ofType ? element.nodeName : "";
  if (tagName === "TR" && element.sectionRowIndex >= 0) {
    var index = element.sectionRowIndex;
    return last ? element.parentNode.rows.length - index + 1 : index;
  }
  if ((tagName === "TD" || tagName === "TH") && element.cellIndex >= 0) {
    index = element.cellIndex;
    return last ? element.parentNode.cells.length - index + 1 : index;
  }
  if (allIndexes.qIndex !== _private.qIndex) {
    allIndexes = {qIndex: _private.qIndex};
  }
  var id = (parent.uniqueID || _.assignID(parent)) + "-" + tagName;
  var indexes = allIndexes[id];
  if (!indexes) {
    indexes = {};
    var index = 0;
    var child = parent.firstChild;
    while (child) {
      if (ofType ? child.nodeName === tagName : child.nodeType === 1) {
        indexes[child.uniqueID || _.assignID(child)] = ++index;
      }
      child = child.nextSibling;
    }
    indexes.length = index;
    allIndexes[id] = indexes;
  }
  index = indexes[element.uniqueID];
  return last ? indexes.length - index + 1 : index;
}

function _getLang(element) {
  var lang = "";
  while (element && element.nodeType === 1) {
    lang = element.lang || element.getAttribute("lang") || "";
    if (lang) break;
    element = element.parentNode;
  }
  return lang;
}

// =========================================================================
// base2/dom/selectors-api/StaticNodeList.js
// =========================================================================

// http://www.w3.org/TR/selectors-api/#staticnodelist

// A wrapper for an array of elements or a NodeList.

var INDEX_SIZE_ERR = "INDEX_SIZE_ERR: StaticNodeList";

var StaticNodeList = _.Base.extend({
  constructor: function StaticNodeList__constructor(nodes) {
    if (nodes && nodes.length > 0) {
      var i = 0, node;
      while ((node = nodes[i])) {
        this[i++] = node;
      }
      this.length = i;
    }
  },
  
  length: 0,
  
  item: function StaticNodeList__item(index) {
    if (index < 0) throw new Error(INDEX_SIZE_ERR);
    var element = this[+index];
    return element || null;
  }
});

// =========================================================================
// base2/dom/selectors-api/CSSSelectorParser.js
// =========================================================================

// http://www.w3.org/TR/css3-selectors/#w3cselgrammar (kinda)

var VALID_SELECTOR = /^(\\.|['\s>+~#.\[\]:*(),\w\-\^|$=]|[^\x00-\xa0])+$/;

var CSS_SELECTOR_PARSE_ERR = "SYNTAX_ERR: CSSSelectorParser";

var IMPLIED_ASTERISK    = /(^|[, >+~])([#.:\[])/g,
    SINGLE_QUOTES       = /'/g,
    ESCAPED             = /'(\d+)'/g,
    ESCAPE              = /\\/g,
    HEX_ESCAPE          = /\\([\da-f]{2})/gi,
    UNESCAPE            = /\\([nrtf'"])/g;

var testElement = document.createElement("div");

var CSSSelectorParser = _.RegGrp.extend({
  dictionary: new _.RegGrp.Dict([
    "string1",         /'(\\.|[^'\\])*'/,
    "string2",         /"(\\.|[^"\\])*"/,
    "string",          /<#string1>|<#string2>/,
    "ident",           /\-?(\\.|[a-z_]|[^\x00-\xa0])(\\.|[\w\-]|[^\x00-\xa0])*/,
    "combinator",      /[\s>+~]/,
    "operator",        /[\^~|$*]?=/,
    "nth_arg",         /[+-]?\d+|[+-]?\d*n(?:\s*[+-]\s*\d+)?|even|odd/,
    "tag",             /\*|<#ident>/,
    "id",              /#(<#ident>)/,
    "class",           /\.(<#ident>)/,
    "pseudo",          /\:([\w\-]+)(?:\(([^)]+)\))?/,
    "attr",            /\[(<#ident>)(?:(<#operator>)((?:\\.|[^\]\[#.:])+))?\]/,
    "negation",        /:not\((<#tag>|<#id>|<#class>|<#attr>|<#pseudo>)\)/,
    "sequence",        /(\\.|[~*]=|\+\d|\+?\d*n\s*\+\s*\d|[^\s>+~,\*])+/,
    "filter",          /[#.:\[]<#sequence>/,
    "selector",        /[^>+~](\\.|[^,])*/,
    "grammar",         /^(<#selector>)((,<#selector>)*)$/
  ]),

  ignoreCase: true
}, {
  escape: CSSSelectorParser_escape,
  unescape: CSSSelectorParser_unescape,

  split: function CSSSelectorParser_split(selector) {
    return _.map(CSSSelectorParser_escape(selector).split(","), CSSSelectorParser_unescape);
  },
  
  validate: function(selector) {
    try {
      _matchesSelector.call(testElement, selector);
      return true;
    } catch (ex) {
      return false;
    }
  }
});

var strings;

var normalize = new CSSSelectorParser([
  "<#string>", escapeString,
  "\\\\.|[~*]\\s+=|\\+\\s+\\d", null,
  "\\[\\s+", "[",
  "\\(\\s+", "(",
  "\\s+\\)", ")",
  "\\s+\\]", "]",
  "\\s*([,>+~]|<#operator>)\\s*", "$1",
  "\\s+$", "",
  "\\s+", " "
]);

function CSSSelectorParser_escape(selector) {
  strings = [];
  selector =
    normalize.parse(_.trim(selector).replace(HEX_ESCAPE, "\\x$1"))
    .replace(UNESCAPE, "$1")
    .replace(IMPLIED_ASTERISK, "$1*$2");
  if (!VALID_SELECTOR.test(selector)) throwSelectorError();
  return selector;
}

function CSSSelectorParser_unescape(query) {
  // put string values back
  return query.replace(ESCAPED, unescapeString);
}

function escapeString(string) {
  var index = strings.length;
  strings[index] = string.replace(UNESCAPE, "$1");
  return "'" + index + "'";
}

function unescapeString(match, index) {
  return strings[index];
}

function throwSelectorError() {
  var error = new SyntaxError(CSS_SELECTOR_PARSE_ERR);
  error.code = 12;
  throw error;
}

// =========================================================================
// base2/dom/selectors-api/parser.js
// =========================================================================

element.innerHTML = "";
element.appendChild(document.createComment(""));

var INCLUDES_COMMENTS = element.getElementsByTagName('*').length !== 0;

var BRACES = /\{/g;
var BRACES_ESCAPED = /\\\{/g;
var SPACES = / /g;
var ONE    = {"+": 1, "-": -1};

var FILTER = new CSSSelectorParser([
  ":nth(-last)?-(?:child|(of-type))\\((<#nth_arg>)\\)(<#filter>)?", function(match, last, ofType, args, filters) { // :nth- pseudo classes
    args = args.replace(SPACES, "");

    var index = "_indexOf(e," + !!last + "," + !!ofType + ")";

    if (args === "even") args = "2n";
    else if (args === "odd") args = "2n+1";
    else if (!isNaN(args)) args = "0n" + ~~args;

    args = args.split("n");
    var a = ~~(ONE[args[0]] || args[0] || 1),
        b = ~~args[1];
    if (a === 0) {
      var expr = index + "===" + b;
    } else {
      expr = "((ii=" + index + ")-(" + b + "))%" + a + "===0&&ii" + (a < 0 ? "<" : ">") + "=" + b;
    }
    return this.parse(filters) + expr + "&&";
  },

  "<#negation>", function(match, simple) {
    if (/:not/i.test(simple)) throwSelectorError();

    if (/^[#.:\[]/.test(simple)) {
      simple = "*" + simple;
    }
    return "!(" + MATCHER.parse(simple).slice(3, -2) + ")&&";
  },

  "<#attr>", function(match, name, operator, value) {
    var attr = (operator ? "_getAttribute" : "_hasAttribute") + ".call(e,'" + name + "')";
    if (QUOTED.test(value)) {
      value = strings[value.slice(1, -1)].slice(1, -1).replace(SINGLE_QUOTES, "\\'");
    }
    if (operator.length > 1) {
      if (!value || operator === "~=" && SPACE.test(value)) {
        return "false&&";
      }
      attr = "(" + attr + "||'')";
    }
    return "(" + _.format(ATTR[operator], attr, value) + ")&&";
  },

  "<#id>",    ID_ATTRIBUTE + "==='$1'&&",

  "<#class>", "e.className&&(' '+e.className+' ').indexOf(' $1 ')!==-1&&",

  // PSEDUO
  ":checked",         "e.checked===true&&(e.type==='checkbox'||e.type==='radio')&&",
  ":disabled",        "(e.disabled===true&&'form'in e&&e.type!=='hidden')&&",
  ":enabled",         "(e.disabled===false&&'form'in e&&e.type!=='hidden')&&",
  ":first-child",     "!" + PREVIOUS_SIBLING + "&&",
  ":last-child",      "!" + NEXT_SIBLING + "&&",
  ":only-child",      "!" + PREVIOUS_SIBLING + "&&!" + NEXT_SIBLING + "&&",
  ":first-of-type",   NOT_PREVIOUS_BY_TYPE,
  ":last-of-type",    NOT_NEXT_BY_TYPE,
  ":only-of-type",    NOT_PREVIOUS_BY_TYPE + NOT_NEXT_BY_TYPE,

  // not currently supported
  //":contains\\(([^)]+)\\)",    "e." + TEXT_CONTENT + ".indexOf('$1')!==-1&&",
  //":selected",                 BUGGY_SELECTED ? 'e.selected||((ii=e.parentNode)&&ii.options[ii.selectedIndex]===e)&&' : '',

  ":lang\\(([^)]+)\\)",    "((ii=_getLang(e))==='$1'||ii.indexOf('$1-')===0)&&",

  ":empty",          "_isEmpty(e)&&",
  ":root",           "e==R&&",
  ":target",         "e==T&&",

  ":hover",          "D&&D.isHover(e)&&",
  ":active",         "D&&e==D._activeElement&&",
  ":focus",          "e==F&&",

  ":link",           "e.href&&(e.nodeName==='A'||e.nodeName==='LINK'||e.nodeName==='AREA')&&",
  ":visited",        "false&&", // not implemented (security)

  ":scope",          "e==S&&", // Selectors API 2

  ".", throwSelectorError
]);

var ATTR = {
  "=":  "{0}==='{1}'",                           // "[@{0}='{1}']"
  "~=": "(' '+{0}+' ').indexOf(' {1} ')!==-1",   // "[contains(concat(' ',@{0},' '),' {1} ')]",
  "|=": "{0}==='{1}'||{0}.indexOf('{1}-')===0",  // "[@{0}='{1}' or starts-with(@{0},'{1}-')]",
  "^=": "{0}.indexOf('{1}')===0",                // "[starts-with(@{0},'{1}')]",
  "$=": "{0}.slice(-'{1}'.length)==='{1}'",      // "[ends-with(@{0},'{1}')]",
  "*=": "{0}.indexOf('{1}')!==-1"                // "[contains(@{0},'{1}')]"
};
ATTR[""] = "{0}";                                // "[@{0}]"

var DS    = /:(hover|active|focus)/i;
var HASH  = /:target/i;
var FOCUS = /:focus/i;
var ROOT  = /:root/i;

var COMBINATOR = {
  " ":   ";while(e!=s&&(e=e.parentNode)&&e.nodeType===1){",
  ">":   "." + PARENT + ";if(e){",
  "+":   (SUPPORTS_TRAVERSAL_API ? ".previousElementSibling" : ";while((e=e.previousSibling)&&e.nodeType!==1)continue") + ";if(e){" ,
  "~":   ";while((e=e.previous" + SIBLING + ")){" + (SUPPORTS_TRAVERSAL_API ? "" : "if(e.nodeType===1){")
};

var TOKENS = new _.RegGrp([
  normalize.getAt(0).source, null,
  "\\be\\b", null
]);

var TOKEN = TOKENS.getAt(1);

var MATCHER = new CSSSelectorParser([
  "(?:(<#selector>)(<#combinator>))?(<#tag>)(<#filter>)?$", function(match, before, combinator, tag, filters) {
    var group = "";
    if (tag !== "*") {
      var TAG = tag.toUpperCase();
      group += "if(e.nodeName==='" + TAG + (TAG === tag ? "" : "'||e.nodeName==='" + tag) + "'){";
    }
    if (filters) {
      group += "if(" + FILTER.parse(filters).slice(0, -2) + "){";
    }
    TOKEN.replacement = "e" + this.index;
    group = TOKENS.parse(group);
    if (combinator) {
      group += "var e=e" + (this.index++) + COMBINATOR[combinator];
      TOKEN.replacement = "e" + this.index;
      group = TOKENS.parse(group);
    }
    if (before) {
      group += this.parse(before);
    }
    return group;
  }
]);

var matchQuery = new CSSSelectorParser([
  "<#grammar>", function(match, selector, selectors) {
    selector = CSSSelectorParser_escape(selector);
    MATCHER.index = 0;
    var group = MATCHER.parse(selector) + "return true;";
    group += closeBlock(group) + matchQuery.parse(selectors.replace(COMMA, ""));
    return CSSSelectorParser_unescape(group);
  },

  ".", throwSelectorError
]);

var cache = matchQuery.cache = {"*": _.True};

matchQuery.create = function(selector) {
  if (!(selector in cache)) {
    selector = CSSSelectorParser_escape(selector);
    cache[selector] = createQuery("function(s){" +
      "var c=this;" +
      getConstants(selector) +
      "var e0=c;" + CSSSelectorParser_unescape(matchQuery.parse(selector)) +
    "return false}");
  }
  return cache[selector];
};

_private.createMatcher = matchQuery.create;

var selectQuery = (function() {
  var BY_ID       = "e0=_getElementById.call(d,'{0}');if(e0){";
  var BY_TAG_NAME = "var n=_getElementsByTagName(c,'{0}');";
  var STORE       = "if(r==null)return e0;r[k++]=e0;";

  var SELECTOR = new CSSSelectorParser([
    "^((?:<#selector>)?(?:<#combinator>))(<#tag>)(<#filter>)?$", true
  ]);

  var selectById = new CSSSelectorParser([
    "^(<#tag>)#(<#ident>)(<#filter>)?( [^,]*)?$", function(match, tagName, id, filters, after) {
      var block = _.format(BY_ID, id), endBlock = "}";
      if (filters) {
        block += MATCHER.parse(tagName + filters);
        endBlock = closeBlock(block);
      }
      if (after) {
        block += "s=c=e0;" + selectQuery.parse("*" + after);
      } else {
        block += STORE;
      }
      return block + endBlock;
    },

    "^([^#,]+)#(<#ident>)(<#filter>)?$", function(match, before, id, filters) {
      var block = _.format(BY_ID, id);
      if (before === "*") {
        block += STORE;
      } else {
        block += MATCHER.parse(before + filters) + STORE + "break";
      }
      return block + closeBlock(block);
    },

    "^.*$", ""
  ]);

  var TAG_NAME = 1;

  var selectQuery = new CSSSelectorParser([
    "<#grammar>", function(match, selector, remainingSelectors) {
      if (!this.groups) this.groups = [];

      var group = SELECTOR.exec(" " + selector);

      if (!group) throwSelectorError();

      this.groups.push(group.slice(1));

      if (remainingSelectors) {
        return this.parse(remainingSelectors.replace(COMMA, ""));
      }

      var groups = this.groups,
          tagName = groups[0][TAG_NAME]; // first tag name

      for (var i = 1; group = groups[i]; i++) { // search tag names
        if (tagName !== group[TAG_NAME]) {
          tagName = "*"; // mixed tag names, so use "*"
          break;
        }
      }

      var matcher = "", store = STORE + "continue filtering;";

      for (var i = 0; group = groups[i]; i++) {
        MATCHER.index = 0;
        if (tagName !== "*") group[TAG_NAME] = "*"; // we are already filtering by tagName
        group = group.join("");
        if (group === " *") { // select all
          matcher = store;
          break;
        } else {
          group = MATCHER.parse(group);
          matcher += group + store + closeBlock(group);
        }
      }

      // reduce to a single loop
      return _.format(BY_TAG_NAME, tagName) +
        "filtering:while((e0=n[i++]))" +
        (INCLUDES_COMMENTS && tagName === "*" ? "if(e0.nodeType===1){" : "{") +
          matcher +
        "}";
    },

    ".", throwSelectorError
  ]);

  var cache = selectQuery.cache = {};

  var REDUNDANT_NODETYPE = /\&\&(e\d+)\.nodeType===1(\)\{\s*if\(\1\.nodeName=)/g;

  selectQuery.create = function(selector) {
    if (!(selector in cache)) {
      selector = CSSSelectorParser_escape(selector);
      this.groups = null;
      MATCHER.index = 0;
      var block = this.parse(selector);
      this.groups = null;
      MATCHER.index = 0;
      if (selector.indexOf("#") !== -1) {
        var byId  = selectById.parse(selector);
        if (byId) {
          block =
            "if(t===1||t===11|!c.getElementById){" +
              block +
            "}else{" +
              byId +
            "}";
        }
      }
      // remove redundant nodeType==1 checks
      block = block.replace(REDUNDANT_NODETYPE, "$2");
      block = getConstants(selector) + CSSSelectorParser_unescape(block);
      cache[selector] = createQuery("function(r,s){var c=this,i=0,k=0,e0;if(_private.isReady)_private.qIndex++;" + block + "if(r)r.length=k;return r}");
    }
    return cache[selector];
  };

  return selectQuery;
})();

setTimeout(function() {
  selectQuery.create("a #b[c]"); // initialise parsers
}, 4);

function getConstants(selector) {
  var constants = "";
  if (ROOT.test(selector)) constants += ",R=d.documentElement";
  if (HASH.test(selector)) constants += ",H=d.location,H=H&&H.hash.replace('#',''),T=H&&d.getElementById(H)";
  if (DS.test(selector)) constants += ",D=_DocumentState[d.base2ID]";
  if (FOCUS.test(selector)) constants += ",F=!d.hasFocus||d.hasFocus()?d.activeElement:null";
  if (constants || selector.indexOf("#") !== -1) {
    constants = ",t=c.nodeType,d=t===9?c:c.ownerDocument" + constants;
  }
  return "var S=c,ii" + constants + ";";
}

function createQuery(query) {
  return new Function(
    "_getElementById,_getElementsByTagName,_getAttribute,_hasAttribute,_indexOf,_getElementSibling,_getElementSiblingByType,_isEmpty,_getLang,_DocumentState,_private",
      "return " + query
    )(
     _getElementById,_getElementsByTagName,_getAttribute,_hasAttribute,_indexOf,_getElementSibling,_getElementSiblingByType,_isEmpty,_getLang,_DocumentState,_private
  );
}

function closeBlock(group) {
  return Array((group.replace(BRACES_ESCAPED, "").match(BRACES) || "").length + 1).join("}");
}

// =========================================================================
// base2/dom/selectors-api/NodeSelector.js
// =========================================================================

// http://www.w3.org/TR/selectors-api/#nodeselector

var safeSelectors = {};

var HTMLDocument__getElementById = _getElementById;

if (!element.matchesSelector) {
  if ("mozMatchesSelector" in element) {
    var _matchesSelector = function matchesSelector(selector) {
      if (arguments.length < 1) throw new ArityError("matchesSelector");
      return this.mozMatchesSelector(selector);
    };
  } else {
    _matchesSelector = function matchesSelector(selector) {
      if (arguments.length < 1) throw new ArityError("matchesSelector");

      if (selector == null) return false;

      var query = matchQuery.cache[selector];
      if (!query) {
        query = matchQuery.create(selector);
      }
      return query.call(this, null);
    };
  }
}

var _querySelector = function querySelector(selector) {
  if (arguments.length < 1) throw new ArityError("querySelector");
  
  return selector == null ? null : _executeQuery("querySelector", this, selector);
}

var _querySelectorAll = function querySelectorAll(selector) {
  if (arguments.length < 1) throw new ArityError("querySelectorAll");

  return selector == null ? new StaticNodeList : _executeQuery("querySelectorAll", this, selector);
}

function _executeQuery(methodName, node, selector) {
  if (SUPPORTS_QSA) {
    var document = node.ownerDocument || node;
    if (!(selector in useBase2)) {
      useBase2[selector] = USE_BASE2.test(selector) || (FIX_CAPS_SELECTOR && document.compatMode === "BackCompat" && CAPS_SELECTOR.test(selector));
    }
    var shouldUseBase2 = useBase2[selector] ||
                        !(methodName in node) ||
                        (BUGGY_OBJECT_SELECTORS && node.nodeName === "OBJECT") ||
                        !/^HTML$/i.test(document.documentElement.nodeName); // XML
    if (!shouldUseBase2) {
      var method = (node.nodeType === 1 ? elementMethods : documentMethods)[methodName];
      if (selector in safeSelectors) {
        return method.call(node, selector);
      } else {
        try {
          var result = method.call(node, selector);
          safeSelectors[selector] = true;
          return result;
        } catch (ex) {
          // assume it's an unsupported selector
          useBase2[selector] = true;
        }
      }
    }
  }
  
  var query = selectQuery.cache[selector] || selectQuery.create(selector);
  
  return query.call(node, methodName === "querySelector" ? null : new StaticNodeList, null);
}

// Quite a lot of browser sniffing here. It's not really possible to feature
// detect all of the various bugs. Newer browsers mostly get it right though.

var TABLE_TH_TD  = /^(TABLE|TH|TD)$/;

var QUIRKS_MODE  = _.detect("QuirksMode");
var MSIE6        = _.detect("MSIE6");
var FIX_BORDER   = _.detect("WebKit5|KHTML4") ? TABLE_TH_TD : _.False;
                  
var _offsets = new _.Base({
  _getBodyClient: function _getBodyClient(document) {
    var left = 0,
        top = 0,
        view = document.defaultView,
        body = document.body,
        bodyStyle = getComputedStyle(body, null),
        position = bodyStyle.position,
        isAbsolute = position !== "static";
        
    if (isAbsolute) {
      left += parseInt(bodyStyle.left) + parseInt(bodyStyle.marginLeft);
      top  += parseInt(bodyStyle.top) + parseInt(bodyStyle.marginTop);
      if (position === "relative") {
        var rootStyle = getComputedStyle(document.documentElement, null);
        left += parseInt(rootStyle.paddingLeft) + parseInt(rootStyle.borderLeftWidth);
        top  += parseInt(rootStyle.paddingTop) + parseInt(rootStyle.borderTopWidth);
        if (!MSIE6) { // MSIE6 stores the margin but doesn't apply it.
          left += parseInt(rootStyle.marginLeft);
          top += parseInt(rootStyle.marginTop);
        }
      }
    } else {
      var dummy = Function__call.call(documentMethods.createElement, document, "div");
      body.insertBefore(dummy, body.firstChild);
      left += dummy.offsetLeft - parseInt(bodyStyle.paddingLeft);
      top += dummy.offsetTop - parseInt(bodyStyle.paddingTop);
      body.removeChild(dummy);
    }

    return {
      position: position,
      isAbsolute: isAbsolute,
      left: left,
      top: top
    };
  },

  _getBodyOffset: function _getBodyOffset(document) {
    var client = this._getBodyClient(document),
        view = document.defaultView,
        body = document.body;
    
    return {
      isAbsolute: client.isAbsolute,
      left: client.left + parseInt(style.compute(body, "borderLeftWidth")),
      top: client.top + parseInt(style.compute(body, "borderTopWidth"))
    };
  },

  _getViewport: function _getViewport(document) {
    var view = document.defaultView,
        documentElement = document.documentElement;
    return {
      left: parseInt(style.compute(documentElement, "marginLeft")),
      top: parseInt(style.compute(documentElement, "marginTop"))
    };
  },

  _getGeckoRoot: function _getGeckoRoot(document) {
    var rootStyle = document.defaultView.getComputedStyle(document.documentElement, null);
        
    return {
      x: parseInt(rootStyle.marginLeft) + parseInt(rootStyle.borderLeftWidth),
      y: parseInt(rootStyle.marginTop) + parseInt(rootStyle.borderTopWidth)
    };
  },

  "@MSIE.+QuirksMode": {
    _getViewport: _.K({left: 0, top: 0})
  },

  "@(true)": {
    _getBodyClient: _memoise(1),
    _getBodyOffset: _memoise(2),
    _getViewport: _memoise(3),
    _getGeckoRoot: _memoise(4)
  }
});

function _memoise(type) {
  return function(document) {
    var key = type + (document.base2ID || _.assignID(document));
    if (!_memoise[key]) _memoise[key] = this.base(document);
    return _memoise[key];
  };
}

// =========================================================================
// base2/dom/cssom/ElementView.js
// =========================================================================

// http://www.w3.org/TR/cssom-view/#extensions-to-the-element-interface

_private.getOffsetFromBody = getOffsetFromBody;

if (element.getBoundingClientRect) {
  if (_.detect("Gecko1\\.9([^\\.]|\\.0)")) { // bug in Gecko 1.9.0 only
    var _getBoundingClientRect = function getBoundingClientRect_gecko_190() {
      var element = this;
      var clientRect = elementMethods.getBoundingClientRect.call(element);

      // This bug only occurs when the document body is absolutely positioned.
      if (!/^HTML$/i.test(element.nodeName) && "absolute" === _offsets._getBodyClient(element.ownerDocument).position) {
        var offset = _offsets._getGeckoRoot(document);
        
        return {
          top:    clientRect.top - offset.y,
          right:  clientRect.right - offset.x,
          bottom: clientRect.bottom - offset.y,
          left:   clientRect.left - offset.x
        };
      }
      return clientRect;
    };
    _private.getOffsetFromBody = function getOffsetFromBody_gecko_pre190(element) {
      var offset = getOffsetFromBody(element);

      // Slightly different rules when the body is absolutely positioned
      if (!_offsets._getBodyClient(element.ownerDocument).isAbsolute) {
        var rootOffset = _offsets._getGeckoRoot(document);
        offset.left -= rootOffset.x;
        offset.top -= rootOffset.y;
      }

      return offset;
    };
  }
} else if (_.detect("WebKit5|KHTML4")) {
  _getBoundingClientRect = function getBoundingClientRect_webkit() {
    var element = this;
    var clientRect = getBoundingClientRect_calc.call(element);

    // Tweak the result for Safari 3.x if the document body is absolutely positioned.
    if (!/^HTML$/i.test(element.nodeName)) {
      var document = element.ownerDocument;
      var offset = _offsets._getBodyOffset(document);
      
      if (!offset.isAbsolute) {
        offset = _offsets._getViewport(document)
      }
      clientRect.left += offset.left;
      clientRect.top += offset.top;
    }

    return clientRect;
  };
  _private.getOffsetFromBody = function getOffsetFromBody_safari3(element) {
    var elementOffset = getOffsetFromBody(element);

    // Tweak the result for Safari 3.x if the document body is absolutely positioned.
    if (!/^BODY$/i.test(element.nodeName)) {
      var document = element.ownerDocument;
      var offset = _offsets._getBodyOffset(document);

      if (!offset.isAbsolute) {
        offset = _offsets._getViewport(document)
      }
      elementOffset.left -= offset.left;
      elementOffset.top -= offset.top;
    }

    return elementOffset;
  };
} else if (document.getBoxObjectFor) {
  _getBoundingClientRect = function getBoundingClientRect_gecko() {
    var element = this;
    var document = element.ownerDocument;
    var  view = document.defaultView;
    var documentElement = document.documentElement;
    var box = document.getBoxObjectFor(element);
    var computedStyle = view.getComputedStyle(element, null);
    var left = box.x - parseInt(computedStyle.borderLeftWidth);
    var top = box.y - parseInt(computedStyle.borderTopWidth);
    var parentNode = element.parentNode;

    if (element != documentElement) {
      while (parentNode && parentNode != documentElement) {
        left -= parentNode.scrollLeft;
        top -= parentNode.scrollTop;
        computedStyle = view.getComputedStyle(parentNode, null);
        if (computedStyle.position !== "absolute") {
          left += parseInt(computedStyle.borderTopWidth);
          top  += parseInt(computedStyle.borderLeftWidth);
        }
        parentNode = parentNode.parentNode;
      }

      if (computedStyle.position !== "fixed") {
        left -= view.pageXOffset;
        top -= view.pageYOffset;
      }

      var bodyPosition = view.getComputedStyle(document.body, null).position;
      if (bodyPosition === "relative") {
        var offset = document.getBoxObjectFor(documentElement);
      } else if (bodyPosition === "static") {
        offset = _offsets._getGeckoRoot(document);
      }
      if (offset) {
        left += offset.x;
        top += offset.y;
      }
    }

    return {
      top: top,
      right: left + element.clientWidth,
      bottom: top + element.clientHeight,
      left: left
    };
  };
} else {
  _getBoundingClientRect = getBoundingClientRect_calc;
}

function getBoundingClientRect_calc() {
  var element = this;
  var document = element.ownerDocument;

  switch (element.nodeName) {
    case "html":
    case "HTML":
      var offset = _offsets._getViewport(document);
      break;

    case "body":
    case "BODY":
      offset = _offsets._getBodyClient(document);
      break;

    default:
      var left = element.offsetLeft;
      var top = element.offsetTop;
      var view = document.defaultView;
      var documentElement = document.documentElement;
      var computedStyle = view.getComputedStyle(element, null);
      var offsetParent = element.offsetParent;

      while (offsetParent && (offsetParent != documentElement || computedStyle.position === "static")) {
        left += offsetParent.offsetLeft - offsetParent.scrollLeft;
        top += offsetParent.offsetTop - offsetParent.scrollTop;

        computedStyle = view.getComputedStyle(offsetParent, null);

        if (FIX_BORDER.test(offsetParent.nodeName)) {
          if (offsetParent.clientLeft == null) {
            left += parseInt(computedStyle.borderLeftWidth);
            top  += parseInt(computedStyle.borderTopWidth);
          } else {
            left += offsetParent.clientTop;
            top  += offsetParent.clientLeft;
          }
        }
        offsetParent = offsetParent.offsetParent;
      }
      offset = {
        left: left,
        top: top
      };
  }

  return {
    top:    offset.top,
    right:  offset.left + element.clientWidth,
    bottom: offset.top + element.clientHeight,
    left:   offset.left
  };
}

function getOffsetFromBody(element) {
  var left = 0, top = 0;

  if (!/^BODY$/i.test(element.nodeName)) {
    var document = element.ownerDocument;
    var view = document.defaultView;
    var documentElement = document.documentElement;
    var body = document.body;
    var bodyOffset = _offsets._getBodyOffset(document);
    var clientRect = dom.getBoundingClientRect(element);

    left = clientRect.left + Math.max(documentElement.scrollLeft, body.scrollLeft);
    top = clientRect.top + Math.max(documentElement.scrollTop, body.scrollTop);

    /*@if (@_jscript)
      if (MSIE6 && body.currentStyle.position !== "relative") {
        left -= documentElement.clientLeft;
        top -= documentElement.clientTop;
      }
      if (@_jscript_version === 5.7 || document.documentMode === 7) {
        var rect = documentElement.getBoundingClientRect();
        left -= rect.left;
        top -= rect.top;
      }
      if (QUIRKS_MODE) {
        left -= body.clientLeft;
        top -= body.clientTop;
        bodyOffset.isAbsolute = false;
      }
    /*@end @*/

    if (bodyOffset.isAbsolute) {
      left -= bodyOffset.left;
      top -= bodyOffset.top;
    }
  }

  return {
    left: left,
    top: top
  };
}

// =========================================================================
// base2/dom/DocumentState.js
// =========================================================================

// Store some state for HTML documents.
// Used for fixing event handlers and supporting the Selectors API.

var _DocumentState = _.Base.extend({
  constructor: function DocumentState__constructor(document) {
    this.document = document;
    this._registeredEvents = {};
    this._hoverElement = document.documentElement;
    var EVENT_HANDLER = /^on((DOM)?\w+|[a-z]+)$/;
    for (var name in this) if (EVENT_HANDLER.test(name)) {
      this.registerEvent(name.slice(2));
    }
    var id = _.assignID(document);
    _DocumentState[id] = this;
    new DOMContentLoadedEvent(document);
  },

  _activeElement: null,
  _hoverElement: null,

  isHover: function isHover(element) {
    return _includes(element, this._hoverElement);
  },

  handleEvent: function handleEvent(event) {
    this["on" + event.type](event);
  },

  onmouseout: function onmouseout(event) {
    this._hoverElement = null;
  },

  onmouseover: function onmouseover(event) {
    this._hoverElement = event.target;
  },

  onmousedown: function onmousedown(event) {
    var element = event.target;
    if (element.href || element.tabIndex || (element.disabled === false && "form" in element)) {
      this._activeElement = event.target;
    }
  },

  onmouseup: function onmouseup() {
    this._activeElement = null;
  },

  registerEvent: function registerEvent(type) {
    addEventListener(this.document, type, this, true);
    this._registeredEvents[type] = true;
  },

  "@!(document.activeElement)": {
    constructor: function DocumentState__constructor(document) {
      this.base(document);
      document.activeElement = document.documentElement;
    },

    onfocus: function onfocus(event) {
      this.document.activeElement = event.target;
    },

    onblur: function onblur() {
      this.document.activeElement = null;
    }
  },

  "@!(element.addEventListener)": _MSIE_DocumentState
}, {
  getInstance: function getInstance(node) {
    var document = node.ownerDocument || node.document || node;
    return this[document.base2ID] || new this(document);
  }
});

// =========================================================================
// base2/dom/package.js
// =========================================================================

var dom = new _.Package({
  name:    "base2.dom",
  version:  base2.version,

  get: dom_get,
  set: dom_set,

  CSSSelectorParser: CSSSelectorParser,
  StaticNodeList:    StaticNodeList,
  
  classList:         classList,
  style:             style,
  
  getComputedStyle:  getComputedStyle
});

// =========================================================================
// base2/dom/init.js
// =========================================================================

var documentMethods = {
  createElement: document.createElement
};
var elementMethods  = {};

var msieCache;

(function() {
  var SUPPORTS_DOM_METHOD_CALL = !!element.getAttribute.call;

  var SUPPORTS_PROTOTYPES = Object.defineProperty || {}.__defineGetter__;
  if (SUPPORTS_PROTOTYPES) {
    var proto = (window.HTMLElement || window.Element || {}).prototype || {};
    var name = _.now();
    proto[name] = 1;
    SUPPORTS_PROTOTYPES = element[name];
    delete proto[name];
  }
  SUPPORTS_PROTOTYPES = !!SUPPORTS_PROTOTYPES;

  var FORBIDDEN = {APPLET:1, EMBED:1, OBJECT:1};

  var bindingMethods = SUPPORTS_PROTOTYPES ? {} : {
    querySelector: function querySelector(selector) {
      if (arguments.length < 1) throw new ArityError("querySelector");
      
      var element = _executeQuery("querySelector", this, selector);
      if (element && isBound[element.uniqueID]) bindElements([element]);
      return element;
    },

    querySelectorAll: function querySelectorAll(selector) {
      if (arguments.length < 1) throw new ArityError("querySelectorAll");
      
      return bindElements(_executeQuery("querySelectorAll", this, selector));
    }
  };

  var IS_NODE     = "!{2}.nodeType";
  var IS_DOCUMENT = "{2}.nodeType !== 9";
  var IS_ELEMENT  = "{2}.nodeType !== 1";

  var IS_EVENT_TARGET = "!{2}['" + EVENT_API + "']";
  var IS_QSA_TARGET   = "!_validType[{2}.nodeType]";

  var iNode = createInterface(null, {
    contains:              [_contains,              IS_NODE,           "parent,child"],
    addEventListener:      [_addEventListener,      IS_EVENT_TARGET,   "target,type,listener"],
    removeEventListener:   [_removeEventListener,   IS_EVENT_TARGET,   "target,type,listener"],
    dispatchEvent:         [_dispatchEvent,         IS_EVENT_TARGET,   "target,event"],
    querySelector:         [_querySelector,         IS_QSA_TARGET,     "node,selector"],
    querySelectorAll:      [_querySelectorAll,      IS_QSA_TARGET,     "node,selector"]
  });

  var iDocument = createInterface(iNode, {
    createEvent:           [_createEvent,           IS_DOCUMENT,       "document,eventType", document],
    getElementById:        [_getElementById,        IS_DOCUMENT,       "document,id",        document]
  });

  var iElement = createInterface(iNode, {
    getAttribute:          [_getAttribute,          IS_ELEMENT,        "element,name"],
    hasAttribute:          [_hasAttribute,          IS_ELEMENT,        "element,name"],
    removeAttribute:       [_removeAttribute,       IS_ELEMENT,        "element,name"],
    setAttribute:          [_setAttribute,          IS_ELEMENT,        "element,name,value"],
    matchesSelector:       [_matchesSelector,       IS_ELEMENT,        "element,selector"],

    getBoundingClientRect: [_getBoundingClientRect, IS_ELEMENT,        "element"]
  });

  var isBound = {};

  function bindDocument(document) {
    _DocumentState.getInstance(document);
    
    isBound[document.base2ID] = true;

    var view = document.defaultView;
    view = view || (document.defaultView = document.parentWindow);
    if (view && !view.getComputedStyle) {
      view.getComputedStyle = getComputedStyle;
    }

    for (var i in iDocument) document[i] = iDocument[i];
    
    if (SUPPORTS_PROTOTYPES) {
      var proto = (view.HTMLElement || view.Element).prototype;
      _private.createGetter(proto, "classList", null, get_classList);
      for (var i in iElement) proto[i] = iElement[i];
    } else {
      var _createElement = document.createElement;
      document.createElement = function createElement(tagName) {
        var element = Function__call.call(_createElement, document, tagName);
        bindElements([element]);
        return element;
      };

      document.getElementById = function getElementById(id) {
        var element = Function__call.call(_getElementById, document, id);
        if (element && !isBound[element.uniqueID]) bindElements([element]);
        return element;
      };
    }
  }

  function bindElements(elements) {
    var i = 0, element;
    while ((element = elements[i++])) {
      if (!isBound[element.uniqueID]) {
        isBound[element.uniqueID] = true;

        if (!FORBIDDEN[element.nodeName]) {
          if (!SUPPORTS_CLASS_LIST) {
            element.classList = new ClassList(element);
          }
          /*@cc_on
          if (!SUPPORTS_DOM_METHOD_CALL) {
            // MSIE6-7
            // attribute methods are unique for each element:
            // element1.getAttribute != element2.getAttribute
            msieCache[element.uniqueID + "_getAttribute"] = element.getAttribute;
            msieCache[element.uniqueID + "_setAttribute"] = element.setAttribute;
          }
          @*/
          for (var i in iElement) element[i] = iElement[i];
        }
      }
    }
    return elements;
  }
  
  function get_classList() {
    var classList = new ClassList(this);
    _private.createGetter(this, "classList", classList);
    return classList;
  }

  /*@cc_on
  if (!SUPPORTS_DOM_METHOD_CALL) {
    // MSIE6-7
    // attribute methods are unique for each element:
    // element1.getAttribute != element2.getAttribute
    
    msieCache = document["#base2_cache"] = {};

    elementMethods.getAttribute = {
      call: function(element, name) {
        var getAttribute = msieCache[element.uniqueID + "_getAttribute"] || element.getAttribute;
        return Function__call.call(getAttribute, element, name, 2);
      }
    };
    
    elementMethods.setAttribute = {
      call: function(element, name, value) {
        var setAttribute = msieCache[element.uniqueID + "_setAttribute"] || element.setAttribute;
        Function__call.call(setAttribute, element, value);
      }
    };
  }
  @*/

  function createInterface(_super, methods) {
    var _interface = _private.pcopy(_super);
    
    forEach (methods, function(descriptor, methodName) {
      var provider = descriptor[3] || element;
      var args = descriptor[2];
      var test = descriptor[1];
      
      documentMethods[methodName] = document[methodName];
      elementMethods[methodName] = element[methodName];

      var method = descriptor[0];

      if (method == provider[methodName]) method = null;

      dom[methodName] = createStaticMethod(methodName, args, method, test);

      if (method) _interface[methodName] = bindingMethods[methodName] || method;
    });
    
    return _interface;
  }
  
  dom.bind = function bind(node) {
    if (node == null || !node.nodeType) throw new TargetError("dom.bind");

    switch (node.nodeType) {
      case 9: // Document
        if (!isBound[node.base2ID]) bindDocument(node);
        break;

      case 1: // Element
        if (!(SUPPORTS_PROTOTYPES && isBound[node.ownerDocument.base2ID]) && !isBound[node.uniqueID]) {
          bindElements([node]);
        }
    }

    return node;
  };
})();

new _DocumentState(document);

base2.dom = dom;

}); // end: closure
