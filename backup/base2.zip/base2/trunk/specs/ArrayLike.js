
base2.exec(function(_) {
  function isNumber(value) {
    return typeof value == "number";
  }

  function isTwo(value) {
    return value == 2;
  }

  function isFive(value) {
    return value == 5;
  }

  function isElement(o) {
    return o && o.nodeType === 1
  }

  function square(value) {
    return value * value;
  }

  function add(a, b) {
    return a + b;
  }

  function concat(a, b) {
    return String(a) + String(b);
  }

  describe('ArrayLike', {
    'Should cast arrays': function() {
      var a = _.ArrayLike([]);
      value_of(typeof a.pluck).should_be("function");
    },

    'Should NOT cast null': function() {
      var err = false;
      try {
        _.ArrayLike(null);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    }
  });

  describe('ArrayLike.every', {
    'Should throw if first argument is null/undefined': function() {
      var err = false;
      try {
        var result = _.every(null, function(){});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should throw if second argument is not a function': function() {
      var err = false;
      try {
        var result = _.every([]);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    "Should support arrays": function() {
      value_of(_.every([], _.True)).should_be(true);

      var enumerable = [1,2,3];
      value_of(_.every(enumerable, isNumber)).should_be(true);
      value_of(_.every(enumerable, isTwo)).should_be(false);
      value_of(_.every(enumerable, isFive)).should_be(false);
    },

    "Should support sparse arrays": function() {
      var array = ["a", "b"];
      array[3] = "d";
      value_of(_.every(array, function(value) { return typeof value != 'undefined'; })).should_be(true);
    },

    "Should support array-likes": function() {
      var element = document.createElement("div");
      
      value_of(_.every(element.childNodes, _.True)).should_be(true);

      element.innerHTML = "<br><br><br>";
      value_of(_.every(element.childNodes, isElement)).should_be(true);
      value_of(_.every(element.childNodes, _.isArray)).should_be(false);
    },

    "Should support collections": function() {
      value_of(_.every(new _.Collection, _.True)).should_be(true);
      
      var enumerable = new _.Collection({a:1, b:2, c:3});
      value_of(_.every(enumerable, isNumber)).should_be(true);
      value_of(_.every(enumerable, isTwo)).should_be(false);
      value_of(_.every(enumerable, isFive)).should_be(false);
    },

    'Should throw for everything else': function() {
      var err = false;
      try {
        var result = _.every(new Function, _.True);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);

      var err = false;
      try {
        var result = _.every(1, _.True);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);

      var err = false;
      try {
        var result = _.every(true, _.True);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    }
  });

  describe('ArrayLike.filter', {
    'Should throw if first argument is null/undefined': function() {
      var err = false;
      try {
        var result = _.filter(null, function(){});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should throw if second argument is not a function': function() {
      var err = false;
      try {
        var result = _.filter([]);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    "Should filter arrays": function() {
      var enumerable = [1,2,3];
      var numbers = _.filter(enumerable, isNumber);
      var twos = _.filter(enumerable, isTwo);
      value_of(numbers.length).should_be(3);
      value_of(numbers[0]).should_be(1);
      value_of(twos.length).should_be(1);
      value_of(twos[0]).should_be(2);
    },

    "Should filter sparse arrays": function() {
      var array = ["a", "b"];
      array[3] = "d";
      array[4] = undefined;
      value_of(_.filter(array, function(value) { return typeof value != 'undefined'; }).join("")).should_be("abd");
      value_of(_.filter(array, function(value) { return typeof value == 'undefined'; }).join("")).should_be("");
    },

    "Should filter collections": function() {
      var enumerable = new _.Collection({a:1, b:2, c:3});
      var numbers = _.filter(enumerable, isNumber);
      var twos = _.filter(enumerable, isTwo);
      value_of(numbers.size()).should_be(3);
      value_of(numbers.get("a")).should_be(1);
      value_of(twos.size()).should_be(1);
      value_of(twos.get("b")).should_be(2);
    }
  });

  describe('ArrayLike.map', {
    'Should throw if first argument is null/undefined': function() {
      var err = false;
      try {
        var result = _.map(null, function(){});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should throw if second argument is not a function': function() {
      var err = false;
      try {
        var result = _.map([]);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    "Should map arrays": function() {
      var enumerable = [1,2,3];
      var squares = _.map(enumerable, square);
      value_of(squares.length).should_be(3);
      value_of(squares[0]).should_be(1);
      value_of(squares[1]).should_be(4);
      value_of(squares[2]).should_be(9);
    },

    "Should filter collections": function() {
      var enumerable = new _.Collection({a:1, b:2, c:3});
      var squares = _.map(enumerable, square);
      value_of(squares.size()).should_be(3);
      value_of(squares.get("a")).should_be(1);
      value_of(squares.get("b")).should_be(4);
      value_of(squares.get("c")).should_be(9);
    }
  });

  describe('ArrayLike.reduce', {
    'Should throw if first argument is null/undefined': function() {
      var err = false;
      try {
        var result = _.reduce(null, function(){});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should throw if second argument is not a function': function() {
      var err = false;
      try {
        var result = _.reduce([]);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },
    
    'Should throw if third argument is omitted and the enumerable object is empty': function() {
      var err1 = false;
      try {
        var fn = _.reduce([], function(){});
      } catch (ex) {
        err1 = true;
      }
      value_of(err1).should_be(true);
      
      var err2 = false;
      try {
        var fn = _.reduce({}, function(){});
      } catch (ex) {
        err2 = true;
      }
      value_of(err2).should_be(true);

      var err3 = false;
      try {
        var fn = _.reduce(new _.Collection, function(){});
      } catch (ex) {
        err3 = true;
      }
      value_of(err3).should_be(true);

      var err4 = false;
      try {
        var fn = _.reduce("", function(){});
      } catch (ex) {
        err4 = true;
      }
      value_of(err4).should_be(true);
    },

    "Should reduce arrays": function() {
      var enumerable = [1,2,3];
      value_of(_.reduce(enumerable, add)).should_be(6);
      value_of(_.reduce(enumerable, add, 10)).should_be(16);

      value_of(_.reduce(enumerable, concat)).should_be("123");
      value_of(_.reduce(enumerable, concat, "0")).should_be("0123");
    },

    "Should reduce collections": function() {
      var enumerable = new _.Collection(["a",1, "b",2, "c",3]);
      value_of(_.reduce(enumerable, add)).should_be(6);
      value_of(_.reduce(enumerable, add, 10)).should_be(16);
    }
  });

  describe('ArrayLike.reduceRight', {
    'Should throw if first argument is null/undefined': function() {
      var err = false;
      try {
        var result = _.reduceRight(null, function(){});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should throw if second argument is not a function': function() {
      var err = false;
      try {
        var result = _.reduceRight([]);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should throw if third argument is omitted and the enumerable object is empty': function() {
      var err1 = false;
      try {
        var fn = _.reduceRight([], function(){});
      } catch (ex) {
        err1 = true;
      }
      value_of(err1).should_be(true);

      var err2 = false;
      try {
        var fn = _.reduceRight({}, function(){});
      } catch (ex) {
        err2 = true;
      }
      value_of(err2).should_be(true);

      var err3 = false;
      try {
        var fn = _.reduceRight(new _.Collection, function(){});
      } catch (ex) {
        err3 = true;
      }
      value_of(err3).should_be(true);

      var err4 = false;
      try {
        var fn = _.reduceRight("", function(){});
      } catch (ex) {
        err4 = true;
      }
      value_of(err4).should_be(true);
    },

    "Should reduce arrays": function() {
      var enumerable = [1,2,3];
      
      value_of(_.reduceRight(enumerable, add)).should_be(6);
      value_of(_.reduceRight(enumerable, add, 10)).should_be(16);

      value_of(_.reduceRight(enumerable, concat)).should_be("321");
      value_of(_.reduceRight(enumerable, concat, "0")).should_be("0321");
    },

    "Should reduce collections": function() {
      var enumerable = new _.Collection(["a",1, "b",2, "c",3]);
      
      value_of(_.reduceRight(enumerable, add)).should_be(6);
      value_of(_.reduceRight(enumerable, add, 10)).should_be(16);

      value_of(_.reduceRight(enumerable, concat)).should_be("321");
      value_of(_.reduceRight(enumerable, concat, "0")).should_be("0321");
    }
  });

  describe('ArrayLike.indexOf', {
    'Should index an Array': function() {
      var a  = [1,2,3,4,5];
      value_of(_.indexOf(a)).should_be(-1);
      value_of(_.indexOf(a, 1)).should_be(0);
      value_of(_.indexOf(a, 4)).should_be(3);
    },

    'Should support fromIndex': function() {
      var a  = [1,2,1,1,5];
      value_of(_.indexOf(a, 1, 1)).should_be(2);
      value_of(_.indexOf(a, 1, -3)).should_be(2);
      value_of(_.indexOf(a, 1, -1e9)).should_be(0);
    },

    'Should index an Array-like object': function() {
      var a  = {"0":1,"1":2,"2":3,"3":4,"4":5,length:5};
      value_of(_.indexOf(a)).should_be(-1);
      value_of(_.indexOf(a, 1)).should_be(0);
      value_of(_.indexOf(a, 4)).should_be(3);
    },

    'Should index a node list': function() {
      var c = document.createElement("div");
      c.innerHTML = "<br><br><br><br>";
      var a = c.childNodes;
      value_of(_.indexOf(a)).should_be(-1);
      value_of(_.indexOf(a, a[0])).should_be(0);
      value_of(_.indexOf(a, a[3])).should_be(3);
    }
  });

  describe('ArrayLike.lastIndexOf', {
    'Should index an Array': function() {
      var a  = [1,2,3,1,1];
      value_of(_.lastIndexOf(a)).should_be(-1);
      value_of(_.lastIndexOf(a, 1)).should_be(4);
      value_of(_.lastIndexOf(a, 2)).should_be(1);
    },

    'Should support fromIndex': function() {
      var a  = [1,2,1,1,5];
      value_of(_.lastIndexOf(a, 1, 1)).should_be(0);
      value_of(_.lastIndexOf(a, 1, -3)).should_be(2);
      value_of(_.lastIndexOf(a, 1, 100)).should_be(3);
    },

    'Should index an Array-like object': function() {
      var a  = {"0":1,"1":2,"2":3,"3":1,"4":1,length:5};
      value_of(_.lastIndexOf(a)).should_be(-1);
      value_of(_.lastIndexOf(a, 1)).should_be(4);
      value_of(_.lastIndexOf(a, 2)).should_be(1);
    },

    'Should index a node list': function() {
      var c = document.createElement("div");
      c.innerHTML = "<br><br><br><br>";
      var a = c.childNodes;
      value_of(_.lastIndexOf(a)).should_be(-1);
      value_of(_.lastIndexOf(a, a[0])).should_be(0);
      value_of(_.lastIndexOf(a, a[3])).should_be(3);
    }
  });

  describe('ArrayLike.slice', {
    'Should slice an Array': function() {
      var a  = [1,2,3,4,5];
      value_of(_.slice(a).join("")).should_be("12345");
      value_of(_.slice(a, 1).join("")).should_be("2345");
      value_of(_.slice(a, 0, -1).join("")).should_be("1234");
    },

    'Should slice an Array-like object': function() {
      var a  = {"0":1,"1":2,"2":3,"3":4,"4":5,length:5};
      value_of(_.slice(a).sort().join("")).should_be("12345");
      value_of(_.slice(a, 1).sort().join("")).should_be("2345");
      value_of(_.slice(a, 0, -1).sort().join("")).should_be("1234");
    },

    'Should slice a node list': function() {
      var c = document.createElement("div");
      c.innerHTML = "<br><br><br><br>";
      var a = c.childNodes;
      value_of(_.slice(a).length).should_be(4);
      value_of(_.slice(a, 1).length).should_be(3);
      value_of(_.slice(a, 0, -1).length).should_be(3);
    }
  });

  describe('ArrayLike.some', {
    'Should throw if first argument is null/undefined': function() {
      var err = false;
      try {
        var result = _.some(null, function(){});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should throw if second argument is not a function': function() {
      var err = false;
      try {
        var result = _.some([]);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    "Should support arrays": function() {
      value_of(_.some([], _.True)).should_be(false);

      var enumerable = [1,2,3];
      value_of(_.some(enumerable, isNumber)).should_be(true);
      value_of(_.some(enumerable, isTwo)).should_be(true);
      value_of(_.some(enumerable, isFive)).should_be(false);
    },

    "Should support sparse arrays": function() {
      var array = ["a", "b"];
      array[3] = "d";
      value_of(_.some(array, function(value) { return typeof value == 'undefined'; })).should_be(false);
    },

    "Should support array-likes": function() {
      var element = document.createElement("div");

      value_of(_.some(element.childNodes, _.True)).should_be(false);

      element.innerHTML = "<br><br><br>";
      value_of(_.some(element.childNodes, isElement)).should_be(true);
      value_of(_.some(element.childNodes, _.isArray)).should_be(false);
    },

    "Should support collections": function() {
      value_of(_.some(new _.Collection, _.True)).should_be(false);

      var enumerable = new _.Collection({a:1, b:2, c:3});
      value_of(_.some(enumerable, isNumber)).should_be(true);
      value_of(_.some(enumerable, isTwo)).should_be(true);
      value_of(_.some(enumerable, isFive)).should_be(false);
    },

    'Should throw for everything else': function() {
      var err = false;
      try {
        var result = _.some(new Function, _.True);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
      
      var err = false;
      try {
        var result = _.some(1, _.True);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
      
      var err = false;
      try {
        var result = _.some(true, _.True);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    }
  });

  describe('ArrayLike.invoke', {
    "Should support arrays": function() {
      var enumerable = [
        {value: "A"},
        {value: "B"},
        {value: "C"},
        null
      ];
      function test() {
        return this.value;
      }
      var values = _.invoke(enumerable, test);
      value_of(values.length).should_be(4);
      value_of(values[0]).should_be("A");
      value_of(values[1]).should_be("B");
      value_of(values[2]).should_be("C");
      value_of(values[3]).should_be(undefined);
    },
    
    "Should support collections": function() {
      var enumerable = new _.Collection([
        "a", {value: "A"},
        "b", {value: "B"},
        "c", {value: "C"},
        "d", null
      ]);
      function test() {
        return this.value;
      }
      var values = _.invoke(enumerable, test);
      value_of(values.size()).should_be(4);
      value_of(values.get("a")).should_be("A");
      value_of(values.get("b")).should_be("B");
      value_of(values.get("c")).should_be("C");
      value_of(values.get("d")).should_be(undefined);
    }
  });

  describe('ArrayLike.plant', {
    "Should support arrays": function() {
      var enumerable = [
        {name: "a"},
        {name: "b"},
        {name: "c"},
        null
      ];
      _.plant(enumerable, "value", 99);
      value_of(enumerable[0].value).should_be(99);
      value_of(enumerable[1].value).should_be(99);
      value_of(enumerable[2].value).should_be(99);
    },

    "Should support collections": function() {
      var enumerable = new _.Collection([
        "a", {name: "a"},
        "b", {name: "b"},
        "c", {name: "c"},
        "d", null
      ]);
      _.plant(enumerable, "value", 99);
      value_of(enumerable.get("a").value).should_be(99);
      value_of(enumerable.get("b").value).should_be(99);
      value_of(enumerable.get("c").value).should_be(99);
    }
  });

  describe('ArrayLike.pluck', {
    "Should support arrays": function() {
      var enumerable = [
        {value: "A"},
        {value: "B"},
        {value: "C"},
        null
      ];
      var values = _.pluck(enumerable, "value");
      value_of(values.length).should_be(4);
      value_of(values[0]).should_be("A");
      value_of(values[1]).should_be("B");
      value_of(values[2]).should_be("C");
      value_of(values[3]).should_be(undefined);
    },
    
    "Should support collections": function() {
      var enumerable = new _.Collection([
        "a", {value: "A"},
        "b", {value: "B"},
        "c", {value: "C"},
        "d", null
      ]);
      var values = _.pluck(enumerable, "value");
      value_of(values.size()).should_be(4);
      value_of(values.get("a")).should_be("A");
      value_of(values.get("b")).should_be("B");
      value_of(values.get("c")).should_be("C");
      value_of(values.get("d")).should_be(undefined);
    }
  });
});