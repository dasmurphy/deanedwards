
base2.exec(function(_) {
  var Trait = base2.Trait;
  
  describe('Trait', {
    'Should not construct': function() {
      var err = false;
      try {
        var result = new Trait;
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should cast objects': function() {
      var Person = Trait.extend({
        getName: function() {
          return this.name;
        }
      });
      value_of(Person({name: "Homer"}).getName()).should_be("Homer");
    },

    'Should implement trait methods as static': function() {
      var Person = Trait.extend({
        getAge: function() {
          return this.age;
        },

        getName: function() {
          return this.name;
        }
      });

      value_of(typeof Person.getAge).should_be("function");
      value_of(typeof Person.getName).should_be("function");

      var Simpson = Person.extend({
        doh: function() {alert("Doh!")}
      });

      value_of(typeof Simpson.getAge).should_be("function");
      value_of(typeof Simpson.getName).should_be("function");
      value_of(typeof Simpson.doh).should_be("function");
    },

    'Should inherit trait methods': function() {
      var Person = Trait.extend({
        getAge: function() {
          return this.age;
        },

        getName: function() {
          return this.name;
        }
      });

      var Simpson = Person.extend({
        doh: function() {alert("Doh!")}
      });

      value_of(typeof Simpson.getAge).should_be("function");
      value_of(typeof Simpson.getName).should_be("function");
    },

    'Should implement instance methods': function() {
      var Homer = Trait.extend({
        getName: function() {
          return "Homer";
        }
      });
      value_of(Homer({}).getName()).should_be("Homer");
    }
  });

  describe('Trait.extend', {
    'Should create a new Trait': function() {
      var t = Trait.extend({
        method: function(){}
      });
      value_of(Trait.ancestorOf(t)).should_be(true);
    },

    'Should only allow methods in the trait interface': function() {
      var err = false;
      try {
        var result = Trait.extend({
          a: 1,
          method: function(){}
        });
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    }
  });

  describe('Trait.test', {
    'Should only allow casting of objects that pass test': function() {
      var ArrayTrait = Trait.extend({
        method: function(){}
      }, {
        test: _.isArray
      });
      var err = false;
      try {
        var result = ArrayTrait({});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
      
      var a = ArrayTrait([])
      value_of(typeof a.method).should_be("function");
    },

    'Should only allow method calls on objects that pass test': function() {
      var ArrayTrait = Trait.extend({
        method: function(){return 99}
      }, {
        test: _.isArray
      });

      var err1 = false;
      try {
        var result = ArrayTrait.method();
      } catch (ex) {
        err1 = true;
      }
      value_of(err1).should_be(true);

      var err2 = false;
      try {
        var result = ArrayTrait.method({});
      } catch (ex) {
        err2 = true;
      }
      value_of(err2).should_be(true);
      
      value_of(ArrayTrait.method([])).should_be(99);
    },

    'Should inherit test()': function() {
      var ArrayTrait1 = Trait.extend({
        method1: function(){return 88}
      }, {
        test: _.isArray
      });
      
      var ArrayTrait2 = ArrayTrait1.extend({
        method2: function(){return 99}
      });

      var err = false;
      try {
        var result = ArrayTrait2.method2({});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);

      value_of(ArrayTrait2.method1([])).should_be(88);
      value_of(ArrayTrait2.method2([])).should_be(99);
    }
  });
});
