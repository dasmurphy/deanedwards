
base2.require("jsb", function(_) {
  
  var element = document.createElement("div");
  element.innerHTML = '<ul><li id="a">a<li id="b" class="bb">b<li id="c">c</ul>';
  var nodes = jsb.behavior.querySelectorAll(element, "li");

  describe('ExtendedNodeList', {
    "Should cast an existing NodeList": function() {
      var nodes = jsb.ExtendedNodeList(element.getElementsByTagName("*"));
      value_of(typeof nodes.forEach).should_be("function");
    },

    "Should return from querySelectorAll()": function() {
      value_of(typeof nodes.forEach).should_be("function");
      value_of(nodes.length).should_be(3);
    },

    "Should support forEach()": function() {
      var text = "";
      nodes.forEach(function(node) {
        text += node.id;
      });
      value_of(text).should_be("abc");
    },

    "Should support map()": function() {
      var text = nodes.map(function(node) {
        return node.id;
      }).join("");
      value_of(text).should_be("abc");
    },

    "Should support filter() by function": function() {
      var result = nodes.filter(function(node) {
        return node.id != "b";
      });
      value_of(result.length).should_be(2);
    },

    "Should support filter() by selector": function() {
      var result = nodes.filter(":not([id=b])");
      value_of(result.length).should_be(2);
    },

    "Should support not() by function": function() {
      var result = nodes.not(function(node) {
        return node.id == "b";
      });
      value_of(result.length).should_be(2);
    },

    "Should support not() by selector": function() {
      var result = nodes.not("[id=b]");
      value_of(result.length).should_be(2);
    },

    "Should support item()": function() {
      value_of(nodes.item(-1)).should_be(nodes[nodes.length - 1]);
    },

    "Should support indexOf()": function() {
      value_of(nodes.indexOf(nodes[2])).should_be(2);
    },

    "Should support slice()": function() {
      var result = nodes.slice(1);
      value_of(_.pluck(result, "id").join("")).should_be("bc");
      result = nodes.slice(0, -1);
      value_of(_.pluck(result, "id").join("")).should_be("ab");
    },

    "Should support every()": function() {
      value_of(nodes.every("[id]")).should_be(true);
      value_of(nodes.every("[class]")).should_be(false);
    },

    "Should support some()": function() {
      value_of(nodes.some("[class]")).should_be(true);
      value_of(nodes.some("[href]")).should_be(false);
    }
  });
});