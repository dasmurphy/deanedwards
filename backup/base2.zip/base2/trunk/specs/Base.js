
base2.exec(function(_) {
  var Base = base2.Base;

  describe('Base', {
    "Should implement static class interface": function() {
      value_of(Base.ancestor).should_be(null);
      value_of(typeof Base.ancestorOf).should_be("function");
      value_of(typeof Base.base).should_be("function");
      value_of(typeof Base.extend).should_be("function");
      value_of(typeof Base.implement).should_be("function");
    }
  });

  describe('Base.ancestorOf', {
    "Should return true for descendants": function() {
      var subclass = Base.extend();
      var subclass2 = subclass.extend();

      value_of(Base.ancestorOf(Base)).should_be(false);
      value_of(subclass.ancestorOf(Base)).should_be(false);
      value_of(Base.ancestorOf(subclass)).should_be(true);
      value_of(Base.ancestorOf(subclass2)).should_be(true);
      value_of(subclass.ancestorOf(subclass2)).should_be(true);
      value_of(subclass2.ancestorOf(subclass2)).should_be(false);
    }
    
    /*"Should throw if supplied class is not a function": function() {
      var err1 = false;
      try {
        var result = Base.ancestorOf({});
      } catch (ex) {
        err1 = true;
      }
      value_of(err1).should_be(true);
      
      var err2 = false;
      try {
        var result = Base.ancestorOf(null);
      } catch (ex) {
        err2 = true;
      }
      value_of(err2).should_be(true);
    }*/
  });

  describe('Base.extend', {
    "Should create a subclass": function() {
      var subclass = Base.extend();

      value_of(subclass.ancestor).should_be(Base);
      value_of(typeof subclass.ancestorOf).should_be("function");
      value_of(typeof subclass.base).should_be("function");
      value_of(typeof subclass.extend).should_be("function");
      value_of(typeof subclass.implement).should_be("function");

      var o = new subclass;
      value_of(o instanceof subclass).should_be(true);
      value_of(o instanceof Base).should_be(true);
      value_of(typeof o.base).should_be("function");
    },

    "Subclasses should be extendable": function() {
      var subclass = Base.extend();
      var subclass2 = subclass.extend();

      value_of(subclass2.ancestor).should_be(subclass);
      value_of(typeof subclass2.ancestorOf).should_be("function");
      value_of(typeof subclass2.base).should_be("function");
      value_of(typeof subclass2.extend).should_be("function");
      value_of(typeof subclass2.implement).should_be("function");

      var o = new subclass2;
      value_of(o instanceof subclass2).should_be(true);
      value_of(o instanceof subclass).should_be(true);
      value_of(o instanceof Base).should_be(true);
      value_of(typeof o.base).should_be("function");
    },

    "Subclasses should inherit constructors": function() {
      var subclass = Base.extend({
        a: 0,
        constructor: function(x){this.a=x+10}
      });
      var subclass2 = subclass.extend();
      var o = new subclass2(1);
      value_of(o.a).should_be(11);
    }
  });

  describe('Base.implement', {
    "Should implement an interface defined by an object": function() {
      var subclass = Base.extend();

      subclass.implement({
        a: 1,
        method: function(){}
      });

      var o = new subclass;
      value_of(o instanceof subclass).should_be(true);
      value_of(o.a).should_be(1);
      value_of(typeof o.method).should_be("function");
    },

    "Should implement an interface defined by another class": function() {
      var MyInterface = Base.extend({
        a: 1,
        method: function(){}
      });

      var subclass = Base.extend();

      subclass.implement(MyInterface);

      var o = new subclass;
      value_of(o instanceof subclass).should_be(true);
      value_of(o.a).should_be(1);
      value_of(typeof o.method).should_be("function");
    },

    "Should implement an interface defined by a Trait": function() {
      var MyTrait = _.Trait.extend({
        method: function(){}
      });

      var subclass = Base.extend();

      subclass.implement(MyTrait);

      var o = new subclass;
      value_of(o instanceof subclass).should_be(true);
      value_of(typeof o.method).should_be("function");
    }
  });

  describe('Base::constructor', {
    "Should construct": function() {
      var o = new Base();
      value_of(o instanceof Base).should_be(true);
      value_of(typeof o.base).should_be("function");
    },

    "Should construct from object": function() {
      var o = new Base({
        a: 1,
        b: 2,
        c: 3
      });
      value_of(o instanceof Base).should_be(true);
      value_of(o.a).should_be(1);
      value_of(typeof o.base).should_be("function");
    }
  });

  describe('Base::base', {
    "Should provide access to super method": function() {
      var subclass = Base.extend({
        test: function(x){return x+10}
      });
      var subclass2 = subclass.extend({
        test: function(x){return this.base(x+100)}
      });
      var o = new subclass2();
      value_of(o.test(1)).should_be(111);
    },
    
    "Should provide access to super constructor": function() {
      var subclass = Base.extend({
        a: 0,
        constructor: function(x){this.a=x+10}
      });
      var subclass2 = subclass.extend({
        constructor: function(x){this.base(x+100)}
      });
      var o = new subclass2(1);
      value_of(o.a).should_be(111);
    }
  });
});
