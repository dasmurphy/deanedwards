

base2.exec(function(_) {
  var NativeDate = Date;

  base2.exec("es5-shim");
  
  function isNumber(value) {
    return typeof value == "number";
  }

  function isTwo(value) {
    return value == 2;
  }

  function isFive(value) {
    return value == 5;
  }

  function isElement(o) {
    return o && o.nodeType === 1
  }

  function square(value) {
    return value * value;
  }

  function add(a, b) {
    return a + b;
  }

  function concat(a, b) {
    return String(a) + String(b);
  }

  describe('Array.isArray', {
    'Should detect identify Arrays': function() {
      value_of(Array.isArray([])).should_be(true);
      value_of(Array.isArray({length: 0})).should_be(false);
      value_of(Array.isArray(null)).should_be(false);
    }
  });

  describe('Array::every', {
    'Should throw if context is null/undefined': function() {
      var err = false;
      try {
        var result = [].every.call(null, function(){});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should throw if first argument is not a function': function() {
      var err = false;
      try {
        var result = [].every();
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    "Should support arrays": function() {
      value_of(_.every([], _.True)).should_be(true);

      var array = [1,2,3];
      value_of(array.every(isNumber)).should_be(true);
      value_of(array.every(isTwo)).should_be(false);
      value_of(array.every(isFive)).should_be(false);
    },

    "Should support array-likes": function() {
      var element = document.createElement("div");

      value_of([].every.call(element.childNodes, _.True)).should_be(true);

      element.innerHTML = "<br><br><br>";
      value_of([].every.call(element.childNodes, isElement)).should_be(true);
      value_of([].every.call(element.childNodes, _.isArray)).should_be(false);
    }
  });

  describe('Array::filter', {
    'Should throw if context is null/undefined': function() {
      var err = false;
      try {
        var result = [].filter.call(null, function(){});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should throw if first argument is not a function': function() {
      var err = false;
      try {
        var result = [].filter();
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    "Should filter arrays": function() {
      var array = [1,2,3];
      var numbers = array.filter(isNumber);
      var twos = array.filter(isTwo);
      value_of(numbers.length).should_be(3);
      value_of(numbers[0]).should_be(1);
      value_of(twos.length).should_be(1);
      value_of(twos[0]).should_be(2);
    }
  });

  describe('Array::map', {
    'Should throw if context is null/undefined': function() {
      var err = false;
      try {
        var result = [].map.call(null, function(){});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should throw if first argument is not a function': function() {
      var err = false;
      try {
        var result = [].map();
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    "Should map arrays": function() {
      var array = [1,2,3];
      var squares = array.map(square);
      value_of(squares.length).should_be(3);
      value_of(squares[0]).should_be(1);
      value_of(squares[1]).should_be(4);
      value_of(squares[2]).should_be(9);
    }
  });

  describe('Array::reduce', {
    'Should throw if context is null/undefined': function() {
      var err = false;
      try {
        var result = [].reduce.call(null, function(){});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should throw if first argument is not a function': function() {
      var err = false;
      try {
        var result = [].reduce();
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should throw if second argument is omitted and the array is empty': function() {
      var err = false;
      try {
        var fn = [].reduce(function(){});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    "Should reduce arrays": function() {
      var array = [1,2,3];
      value_of(array.reduce(add)).should_be(6);
      value_of(array.reduce(add, 10)).should_be(16);

      value_of(array.reduce(concat)).should_be("123");
      value_of(array.reduce(concat, "0")).should_be("0123");
    }
  });

  describe('Array::reduceRight', {
    'Should throw if context is null/undefined': function() {
      var err = false;
      try {
        var result = [].reduceRight.call(null, function(){});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should throw if first argument is not a function': function() {
      var err = false;
      try {
        var result = [].reduceRight();
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should throw if second argument is omitted and the array object is empty': function() {
      var err = false;
      try {
        var fn = [].reduceRight(function(){});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    "Should reduce arrays": function() {
      var array = [1,2,3];

      value_of(array.reduceRight(add)).should_be(6);
      value_of(array.reduceRight(add, 10)).should_be(16);

      value_of(array.reduceRight(concat)).should_be("321");
      value_of(array.reduceRight(concat, "0")).should_be("0321");
    }
  });

  describe('Array::slice', {
    'Should slice an Array': function() {
      var array  = [1,2,3,4,5];
      value_of(array.slice().join("")).should_be("12345");
      value_of(array.slice(1).join("")).should_be("2345");
      value_of(array.slice(0, -1).join("")).should_be("1234");
    },

    'Should slice an Array-like object': function() {
      var a  = {"0":1,"1":2,"2":3,"3":4,"4":5,length:5};
      value_of([].slice.call(a).sort().join("")).should_be("12345");
      value_of([].slice.call(a, 1).sort().join("")).should_be("2345");
      value_of([].slice.call(a, 0, -1).sort().join("")).should_be("1234");
    },

    'Should slice a node list': function() {
      var c = document.createElement("div");
      c.innerHTML = "<br><br><br><br>";
      var a = c.childNodes;
      value_of([].slice.call(a).length).should_be(4);
      value_of([].slice.call(a, 1).length).should_be(3);
      value_of([].slice.call(a, 0, -1).length).should_be(3);
    }
  });

  describe('Array::some', {
    'Should throw if context is null/undefined': function() {
      var err = false;
      try {
        var result = [].some.call(null, function(){});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should throw if first argument is not a function': function() {
      var err = false;
      try {
        var result = [].some();
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    "Should support arrays": function() {
      value_of([].some(_.True)).should_be(false);

      var array = [1,2,3];
      value_of(array.some(isNumber)).should_be(true);
      value_of(array.some(isTwo)).should_be(true);
      value_of(array.some(isFive)).should_be(false);
    },

    "Should support array-likes": function() {
      var element = document.createElement("div");

      value_of(_.some(element.childNodes, _.True)).should_be(false);

      element.innerHTML = "<br><br><br>";
      value_of(_.some(element.childNodes, isElement)).should_be(true);
      value_of(_.some(element.childNodes, _.isArray)).should_be(false);
    }
  });
  
  describe('Date', {
    'Should construct from date': function() {
      var today = new NativeDate;
      value_of(new Date(today).valueOf()).should_be(today.valueOf());
    },

    'Should construct from number': function() {
      var today = new NativeDate;
      value_of(new Date(today.valueOf()).valueOf()).should_be(today.valueOf());
    },

    'Should construct from ISO string': function() {
      value_of(new Date("1999-01-01T00:00:00.000Z").valueOf()).should_be(NativeDate.UTC(1999, 0, 1));
    },

    'Should construct with 3 or more arguments': function() {
      value_of(new Date(1999, 0, 1).valueOf()).should_be(new NativeDate(1999, 0, 1).valueOf());
      value_of(new Date(1999, 0, 1, 1).valueOf()).should_be(new NativeDate(1999, 0, 1, 1).valueOf());
    },

    'Should return string date when not used as a constructor': function() {
      value_of(typeof Date(new NativeDate)).should_be("string");
    }
  });

  describe('Date.now', {
    'Should return the time in milliseconds': function() {
      value_of(typeof Date.now()).should_be("number");
      value_of(Date.now() > 0).should_be(true);
    }
  });

  describe('Date.parse', {
    'Should parse ISO string to number (milliseconds since the epoch (1st Jan 1970))': function() {
      value_of(Date.parse("1999-01-01T00:00:00.000Z")).should_be(NativeDate.UTC(1999,0,1));
    }
  });

  describe('Date.now', {
    'Should return current elapsed time in milliseconds since the epoch (1st Jan 1970)': function() {
      var now1 = Date.now();
      var now2 = new NativeDate().valueOf()
      value_of(now1).should_be(now2);
    }
  });

  describe('Date::toISOString', {
    'Should convert to ISO string': function() {
      value_of(new Date(NativeDate.UTC(2001, 0, 1)).toISOString()).should_be("2001-01-01T00:00:00.000Z");
    }
  });

  describe('Function::bind', {
    'Should throw if context is not a function': function() {
      var err = false;
      try {
        var fn = Function.prototype.bind.call();
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should bind a function to an object': function() {
      var obj = {
        a: 99,
        test: function() {
          return this.a;
        }
      }
      var fn = obj.test.bind(obj);
      value_of(fn()).should_be(99);
    },

    'Should pass supplied arguments': function() {
      var obj = {
        a: 1,
        test: function(a, b, c) {
          return _.slice(arguments).join("");
        }
      }
      var fn = obj.test.bind(obj, 1, 2, 3);
      value_of(fn()).should_be("123");
    },

    'Should pass all additional arguments': function() {
      var obj = {
        a: 1,
        test: function(a, b, c) {
          return _.slice(arguments).join("");
        }
      }
      var fn = obj.test.bind(obj, 1, 2);
      value_of(fn(3)).should_be("123");
    }
  });

  describe('String::trim', {
    'Should throw if context is null': function() {
      var err = false;
      try {
        var result = "".trim.call(null);
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    },

    'Should trim a string': function() {
      value_of("1 ".trim()).should_be("1");
      value_of(" 2 ".trim()).should_be("2");
      value_of(" 3".trim()).should_be("3");
    }
  });
});
