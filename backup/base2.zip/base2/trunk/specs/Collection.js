
base2.exec(function(_) {
  var Collection = base2.Collection;
  
  var coll;

  describe('Collection::constructor', {
    "Should construct from object": function() {
      coll = new Collection({
        a: {name: "a", value: 1},
        b: {name: "b", value: 2},
        c: {name: "c", value: 3},
        d: {name: "d", value: 4}
      });
      value_of(coll instanceof Collection).should_be(true);
      value_of(coll.get("a").value).should_be(1);
      value_of(coll.get("e")).should_be(undefined);
    },
    
    "Should construct from array": function() {
      coll = new Collection([
        "a", {name: "a", value: 1},
        "b", {name: "b", value: 2},
        "c", {name: "c", value: 3}
      ]);
      value_of(coll instanceof Collection).should_be(true);
      value_of(coll.get("a").value).should_be(1);
      value_of(coll.get("e")).should_be(undefined);
    }
  });

  describe('Collection::add', {
    "Should support add()": function() {
      coll.add("d", {name: "d", value: 4});
      value_of(coll.get("d").value).should_be(4);
    },
    
    "Should throw when using add() to add a duplicate key": function() {
      var err = false;
      try {
        coll.add("d", {name: "d", value: 4});
      } catch (ex) {
        err = true;
      }
      value_of(err).should_be(true);
    }
  });

  describe('Collection::clear', {
    "Should support clear()": function() {
      var coll2 = new Collection([
        "a", {name: "a", value: 1},
        "b", {name: "b", value: 2},
        "c", {name: "c", value: 3}
      ]);
      value_of(coll2.size()).should_be(3);
      coll2.clear();
      value_of(coll2.size()).should_be(0);
    }
  });

  describe('Collection::clone', {
    "Should support clone()": function() {
      var coll2 = coll.clone();
      value_of(coll2.size()).should_be(4);
    },
    
    "clone() should preserve custom properties": function() {
      var coll1 = new Collection([
        "a", {name: "a", value: 1},
        "b", {name: "b", value: 2},
        "c", {name: "c", value: 3}
      ]);
      coll1.x = 99;
      var coll2 = coll1.clone();
      value_of(coll2.x).should_be(99);
    },

    "clone() should preserve class info": function() {
      var Collection2 = Collection.extend();
      var coll2 = new Collection2([
        "a", {name: "a", value: 1},
        "b", {name: "b", value: 2},
        "c", {name: "c", value: 3}
      ]);
      var coll3 = coll2.clone();
      value_of(coll3 instanceof Collection2).should_be(true);
    }
  });

  describe('Collection::every', {
    "Should support every()": function() {
      value_of(coll.every(function(item) {
        return typeof item.value == "number";
      })).should_be(true);

      value_of(coll.every(function(item) {
        return item.value % 2 == 0;
      })).should_be(false);
    }
  });

  describe('Collection::filter', {
    "Should support filter()": function() {
      var result = coll.filter(function(item) {
        return item.name != "b";
      });
      value_of(result instanceof Collection).should_be(true);
      value_of(result.size()).should_be(3);
    }
  });

  describe('Collection::forEach', {
    "Should support forEach()": function() {
      var text = "";
      coll.forEach(function(item) {
        text += item.name;
      });
      value_of(text).should_be("abcd");
    }
  });

  describe('Collection::get', {
    "Should support get()": function() {
      value_of(coll.get("a").value).should_be(1);
      value_of(coll.get("e")).should_be(undefined);
    }
  });

  describe('Collection::getAt', {
    "Should support getAt()": function() {
      value_of(coll.getAt(0).value).should_be(1);
      value_of(coll.getAt(5)).should_be(undefined);
    }
  });

  describe('Collection::keys', {
    "Should support keys()": function() {
      var keys = coll.keys();
      value_of(keys instanceof Array).should_be(true);
      value_of(keys.join("")).should_be("abcd");
    }
  });

  describe('Collection::values', {
    "Should support values()": function() {
      var values = coll.values();
      value_of(values instanceof Array).should_be(true);
      value_of(values[1].name).should_be("b");
    }
  });

  describe('Collection::has', {
    "Should support has()": function() {
      value_of(coll.has("a")).should_be(true);
      value_of(coll.has("e")).should_be(false);
    }
  });

  describe('Collection::indexOf', {
    "Should support indexOf()": function() {
      value_of(coll.indexOf("a")).should_be(0);
      value_of(coll.indexOf("e")).should_be(-1);
    }
  });

  describe('Collection::insertAt', {
    "Should support insertAt()": function() {
      coll.insertAt(0, "x", {name: "x", value: 99});
      value_of(coll.indexOf("x")).should_be(0);
      value_of(coll.getAt(0).value).should_be(99);
      coll.remove("x");
    },
    
    "Should support negative indices": function() {
      coll.insertAt(-1, "x", {name: "x", value: 99});
      value_of(coll.indexOf("x")).should_be(3);
      coll.remove("x");
    }
  });

  describe('Collection::invoke', {
    "Should support invoke()": function() {
      function test() {
        return this.value;
      }
      var result = coll.invoke(test);
      value_of(result.join("")).should_be("1234");
    }
  });

  describe('Collection::join', {
    "Should support join()": function() {
      var coll1 = new Collection([
        "a", 1,
        "b", 2,
        "c", 3,
        "d", 4
      ]);
      value_of(coll1.join("")).should_be("1234");
    }
  });

  describe('Collection::keyAt', {
    "Should support keyAt()": function() {
      value_of(coll.keyAt(0)).should_be("a");
    },

    "Should support negative indices": function() {
      value_of(coll.keyAt(-1)).should_be("d");
    }
  });

  describe('Collection::map', {
    "Should support map()": function() {
      var result = coll.map(function(item) {
        return item.name;
      });
      value_of(result instanceof Collection).should_be(true);
      var text = result.values().join("");
      value_of(text).should_be("abcd");
    }
  });

  describe('Collection::merge', {
    "Should merge objects": function() {
      var coll1 = new Collection({
        a: 1,
        b: 2,
        c: 3
      });
      coll1.merge({
        c: 3,
        d: 4,
        e: 5
      });
      value_of(coll1.sort().join("")).should_be("12345");
    },

    "Should merge arrays": function() {
      var coll1 = new Collection({
        a: 1,
        b: 2,
        c: 3
      });
      coll1.merge([
        "c", 3,
        "d", 4,
        "e", 5
      ]);
      value_of(coll1.sort().join("")).should_be("12345");
    },

    "Should merge collections": function() {
      var coll1 = new Collection({
        a: 1,
        b: 2,
        c: 3
      });
      coll1.merge(new Collection([
        "c", 3,
        "d", 4,
        "e", 5
      ]));
      value_of(coll1.sort().join("")).should_be("12345");
    },

    "Should merge multiple arguments": function() {
      var coll1 = new Collection({
        a: 1,
        b: 2,
        c: 3
      });
      coll1.merge([
        "c", 3,
        "d", 4,
        "e", 5
      ], {
        f: 6
      });
      value_of(coll1.sort().join("")).should_be("123456");
    }
  });

  describe('Collection::plant', {
    "Should support plant()": function() {
      var coll1 = new Collection({
        a: {name: "a"},
        b: {name: "b"},
        c: {name: "c"}
      });
      coll1.plant("value", 99);
      value_of(coll1.get("a").value).should_be(99);
      value_of(coll1.get("b").value).should_be(99);
      value_of(coll1.get("c").value).should_be(99);
    }
  });

  describe('Collection::pluck', {
    "Should support pluck()": function() {
      var text = coll.pluck("name").join("");
      value_of(text).should_be("abcd");
    }
  });

  describe('Collection::set', {
    "Should support set()": function() {
      coll.set("e", {name: "e", value: 5});
      value_of(coll.has("e")).should_be(true);
    }
  });

  describe('Collection::setAt', {
    "Should support setAt()": function() {
      coll.setAt(4, {name: "f", value: 6});
      value_of(coll.has("f")).should_be(false);
      value_of(coll.get("e").name).should_be("f");
      value_of(coll.get("e").value).should_be(6);
    }
  });

  describe('Collection::reduce', {
    "Should support reduce()": function() {
      function sum(a, b) {
        return a + b;
      }
      
      var coll1 = new Collection({
        a: 1,
        b: 2,
        c: 3,
        d: 4
      });
      
      value_of(coll1.reduce(sum, 10)).should_be(20);
    }
  });

  describe('Collection::remove', {
    "Should support remove()": function() {
      value_of(coll.has("e")).should_be(true);
      coll.remove("e");
      value_of(coll.has("e")).should_be(false);
    }
  });

  describe('Collection::removeAt', {
    "Should support removeAt()": function() {
      var coll1 = new Collection({
        a: 1,
        b: 2,
        c: 3,
        d: 4
      });
      value_of(coll1.has("c")).should_be(true);
      coll1.removeAt(2);
      value_of(coll1.has("c")).should_be(false);
    },

    "Should support negative indices": function() {
      var coll1 = new Collection({
        a: 1,
        b: 2,
        c: 3,
        d: 4
      });
      value_of(coll1.has("c")).should_be(true);
      coll1.removeAt(-2);
      value_of(coll1.has("c")).should_be(false);
    }
  });

  describe('Collection::some', {
    "Should support some()": function() {
      value_of(coll.some(function(item) {
        return item.value % 2 == 0;
      })).should_be(true);

      value_of(coll.some(function(item) {
        return typeof item.value == "string";
      })).should_be(false);
    }
  });

});