
Blob = function Blob() {
}

Blob.prototype.z = 99;

alert(Blob);
