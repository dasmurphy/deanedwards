
// This code is loosely based on Douglas Crockford's original:
//  http://www.json.org/json.js

var JSON;

if (!JSON) base2.require("Date", function(_, Date) { // begin: closure

var Object__toString  = {}.toString;
var Date__toJSON = new Date().toJSON;

var JSON_STRING_VALID = /^("(\\.|[^"\\\n\r])*?"|[,:{}\[\]0-9.\-+Eaeflnr-u \n\r\t])+?$/;

var JSON_STRING_ESCAPE = new _.RegGrp([
  '\b',  '\\b',
  /\t/, '\\t',
  /\n/, '\\n',
  /\f/, '\\f',
  /\r/, '\\r',
  /"/,  '\\"',
  /\\/, '\\\\',
  '[\\x00-\\x1f\\x7f-\\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\ufffe\uffff]', function(chr) {
    return "\\u" + ("0000" + chr.charCodeAt(0).toString(16)).slice(-4);
  }
]);

function JSON_parse(string) {
  try {
    if (JSON_STRING_VALID.test(string)) {
      return Function("return " + string).call();
    }
  } catch (ex) {}

  throw new SyntaxError("JSON.parse");
}

function JSON_stringify(object) {
  switch (typeof object) {
    case "string":
      return '"' + JSON_STRING_ESCAPE.parse(object) + '"';

    case "number":
      return isFinite(object) ? String(object) : "null";

    case "boolean":
      return String(object);

    case "object":
      if (object == null) return "null";

      switch (Object__toString.call(object)) {
        case "[object Array]":
          var strings = [];
          var i = object.length;
          while (i--) {
            var value = JSON_stringify(object[i]);
            strings[i] = value == null ? "null" : value;
          }
          return "[" + strings.join(",") + "]";

        case "[object Object]":
          strings = [], i = 0;
          for (var name in object) if (object.hasOwnProperty(name)) {
            value = JSON_stringify(object[name]);
            if (value != null) {
              strings[i++] = '"' + JSON_STRING_ESCAPE.parse(name) + '":' + value;
            }
          }
          return "{" + strings.join(",") + "}";

        case "[object Date]":
          return '"' + Date__toJSON.call(object) + '"';

        case "[object String]":
        case "[object Number]":
        case "[object Boolean]":
          return JSON_stringify(object.valueOf());
      }
  }
  return undefined;
}

JSON = {
  parse:     JSON_parse,
  stringify: JSON_stringify,
  toString:  _.K("[object JSON]")
};

}); // end: closure
