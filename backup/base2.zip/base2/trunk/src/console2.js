
// Dean Edwards, 2008-2011

var console2;
(function(document) {
//@cc_on
var CONSOLE_CSS = "position:fixed;top:0;right:0;height:400px;width:25%;border:1px solid silver;z-index:999";
var doc;
var count = 0;
var lines = [];

function init() {
  var iframes = document.getElementsByTagName("iframe");
  var iframe = iframes[iframes.length - 1];
  iframe.frameBorder = "0";
  doc = iframe.contentDocument || iframe.contentWindow.document;
  doc.open();
  doc.write('<style>body{padding:5px;margin:0;font-size:12px;font-family:consolas,monospace}</style>');
  doc.close();
  doc.ondblclick = clear;
  for (var i = 0; i < lines.length; i++) {
    writeLine(lines[i]);
  }
  lines = null;
}

function writeLine(line) {
  line = ++count + ": " + line;
  var text = doc.createElement("div");
  /*@if (@_jscript)
    text.innerText = line;
  @else @*/
    text.textContent = line;
  /*@end @*/
  doc.body.appendChild(text);
  doc.body.scrollTop = 9999;
}

function clear() {
  if (document.body) {
    doc.body.innerHTML = "";
  } else {
    lines = [];
  }
  count = 0;
}

if (typeof console2 == "undefined") {
  console2 = {};
  if (document.body) {
    var iframe = document.createElement("iframe");
    iframe.style.cssText = CONSOLE_CSS;
    document.body.appendChild(iframe);
  } else {
    document.write('<iframe style="' + CONSOLE_CSS + '"></iframe>');
  }
  console2.log = function(text) {
    if (document.body) {
      if (lines) init();
      writeLine(text);
    } else {
      lines.push(text);
    }
  };
  console2.clear = clear;
  // fixed positioning for MSIE6
  /*@if (@_jscript_version < 5.7)
    setTimeout(function() {
      var iframes = document.getElementsByTagName("iframe");
      var iframe = iframes[iframes.length - 1];
      if (iframe && document.body) {
        with (document.body.style) {
          backgroundRepeat = "no-repeat";
          backgroundImage = "url(http://ie7-js.googlecode.com/svn/trunk/lib/blank.gif)"; // dummy
          backgroundAttachment = "fixed";
        }
        with (iframe.style) {
          position = "absolute";
          setExpression("pixelRight", "parseInt(document.documentElement.scrollLeft)");
          setExpression("pixelTop", "parseInt(document.documentElement.scrollTop)");
          setExpression("pixelBottom", "parseInt(document.documentElement.scrollHeight-document.documentElement.scrollTop)");
        }
      } else setTimeout(arguments.callee, 15);
    }, 15);
  /*@end @*/
}
})(document);
