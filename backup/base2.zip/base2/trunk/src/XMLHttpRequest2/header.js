
//@cc_on

XMLHttpRequest = XMLHttpRequest.wrapped || XMLHttpRequest;

var _private = _._;

var NOT_ENOUGH_ARGUMENTS_ERR = "Not enough arguments.";

var MIME_TYPE_XML = /[\/+]xml\s*(;|$)/i;

var UNSENT =            0,
    OPENED =            1,
    HEADERS_RECEIVED =  2,
    LOADING =           3,
    DONE =              4;

var XHR_INVALID_STATE_ERR = "INVALID_STATE_ERR: XMLHttpRequest";

var XHR_DEFAULT_VALUES = {
  //responseBody: null,
  responseXML: null,
  responseText: "",
  status: 0,
  statusText: ""
};

var XHR_PROPERTIES = _private.pcopy(XHR_DEFAULT_VALUES, {readyState: UNSENT});
