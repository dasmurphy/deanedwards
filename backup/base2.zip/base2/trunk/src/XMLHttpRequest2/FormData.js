
var STORE = "toString";

if (!FormData) FormData = _.Base.extend({
  constructor: function FormatData__constructor(form) {
    this.toString = _.K("[object FormData]");
    this[STORE].data = form ? serialize(form) : "";
  },

  append: function FormatData__append(key, value) {
    var data = this[STORE].data;
    if (data) data += "&";
    data += key + "=" + encodeURIComponent(value);
    this[STORE].data = data;
  }
});

// help

function serialize(form) {
  var successful = _.filter(form.elements, isSuccessful);

  return _.map(successful, encode).join("&");
}

function isSuccessful(element) {
  if (!element.name || element.disabled) return false;

  switch (element.type) {
    case "radio":
    case "checkbox":
      return element.checked;

    case "button":
    case "reset":
      return false;

    case "image":
    case "submit":
      return element == element.form.ownerDocument.activeElement;

    default:
      return true;
  }
}

function encode(element) {
  return element.name + "=" + encodeURIComponent(element.value);
}
