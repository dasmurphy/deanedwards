
// http://www.w3.org/TR/XMLHttpRequest2/

// Credits: Sergey Ilinsky (http://www.ilinsky.com/articles/XMLHttpRequest/)

XMLHttpRequest2 = function XMLHttpRequest2__constructor() {
  var self = this;
  var transport;
  var requestHeaders, responseHeaders;
  var isAsync, requestMethod;
  var isSent, error;
  var timeout, timer, started;
  var overridingMimeType;

  var properties = _private.createGetters(this, _private.pcopy(XHR_PROPERTIES));

  var onerror = _.partial(_XMLHttpRequest2__dispatchError, "error");
  var ontimeout = _.partial(_XMLHttpRequest2__dispatchError, "timeout");
  var onprogress = _.partial(_XMLHttpRequest2__dispatchEvent, "progress");

  this.abort = function XMLHttpRequest2__abort() {
    error = true;
    _XMLHttpRequest2__abort();
    if (isSent && properties.readyState < DONE) {
      isSent = false;
      properties.readyState = DONE;
      _XMLHttpRequest2__dispatchEvent("readystatechange");
      _XMLHttpRequest2__dispatchEvent("abort");
      _XMLHttpRequest2__dispatchEvent("loadend");
    }
    properties.readyState = UNSENT;
  };

  this.open = function XMLHttpRequest2__open(method, url, async, user, password) {
    switch (arguments.length) {
      case 0:
      case 1:
        throw new ArityError("open", this);

      case 2: async = true;
      case 3: user = "";
      case 4: password = "";
    }

    if (transport) _XMLHttpRequest2__abort();

    isAsync = async;
    requestMethod = String(method).toUpperCase();
    isSent = error = false;
    requestHeaders = {};
    timeout = 0;
    responseHeaders = "";

    try {
      transport = new XMLHttpRequest();
      if (overridingMimeType && transport.overrideMimeType) {
        transport.overrideMimeType(overridingMimeType);
      }
      transport.open(method, url, async, user, password);
    } catch (ex) {
      error = ex;
    }
    properties.readyState = OPENED;
    _XMLHttpRequest2__dispatchEvent("readystatechange");
  };

  this.send = function XMLHttpRequest2__send(data) {
    if (isSent || properties.readyState !== OPENED) {
      throw new Error(XHR_INVALID_STATE_ERR);
    }
    if (arguments.length === 0 || requestMethod === "GET" || requestMethod === "HEAD") {
      data = null;
    }
    if (data && data.valueOf && _.Base.ancestorOf(FormData) && data instanceof FormData) {
      data = data.toString.data;
    }
    /*
    // http://www.ilinsky.com/articles/XMLHttpRequest/#bugs-safari-send-document
    if (data && data.nodeType) {
      data = typeof XMLSerializer == "function" ? new XMLSerializer().serializeToString(data) : data.xml || data;
      if (!requestHeaders["content-type"]) {
        transport.setRequestHeader("Content-Type", "application/xml");
      }
    }
    */
    timeout = self.timeout;
    if (!error) {
      try {
        transport.send(data);
        started = _.now();
      } catch (ex) {
        error = ex;
      }
    }
    if (isAsync) {
      isSent = true;
      _XMLHttpRequest2__dispatchEvent("loadstart");
    }
    if (error) {
      properties.readyState = DONE;
      _XMLHttpRequest2__dispatchEvent("readystatechange");
      _XMLHttpRequest2__dispatchEvent("error");
      throw error;
    }
    if ("onerror" in transport) {
      transport.onerror = onerror;
    }
    if (timeout && !isNaN(timeout)) {
      timer = setTimeout(ontimeout, timeout + started - _.now());
    }
    if (isAsync && "onprogress" in transport) {
      transport.onprogress = onprogress;
    }
    transport.onreadystatechange = _XMLHttpRequest2__onreadystatechange;
    _XMLHttpRequest2__onreadystatechange();
  };

  this.overrideMimeType = function XMLHttpRequest2__overrideMimeType(mimeType) {
    overridingMimeType = mimeType;
    if (transport && transport.overrideMimeType) {
      transport.overrideMimeType(mimeType);
    }
  };

  this.setRequestHeader = function XMLHttpRequest2__setRequestHeader(header, value) {
    if (isSent || properties.readyState !== OPENED) {
      throw new Error(XHR_INVALID_STATE_ERR);
    }
    requestHeaders[String(header).toLowerCase()] = value;
    transport.setRequestHeader(header, value);
  };

  this.getAllResponseHeaders = function XMLHttpRequest2__getAllResponseHeaders() {
    if (properties.readyState < HEADERS_RECEIVED || error) return null;
    return responseHeaders;
  };

  this.getResponseHeader = function XMLHttpRequest2__getResponseHeader(header) {
    if (properties.readyState < HEADERS_RECEIVED || error) return null;
    var header = String(header).replace(/\-/g, "\\-");
    return _.trim(responseHeaders.replace(new RegExp("^[\\s\\S]*" + header + ":([^\\n]+)[\\s\\S]*$", "i"), "$1"));
  };

  function _XMLHttpRequest2__abort() {
    if (transport) {
      clearTimeout(timer);
      transport.onreadystatechange = _.Undefined;
      _.extend(properties, XHR_DEFAULT_VALUES);
      if (NativeXHR) {
        transport.onprogress = null;
        transport.onerror = null;
      }
      try {
        transport.abort();
      } catch(ex) {
        // ignore
      }
      _XMLHttpRequest2__destroy();
    }
  }

  function _XMLHttpRequest2__destroy() {
    if (transport) {
      transport.onreadystatechange = _.Undefined;
      if (transport.destroy) { // Samsung TV
        transport.destroy();
      }
      transport = null; // de-reference
    }
  }

  function _XMLHttpRequest2__dispatchError(type) {
    error = true;
    _XMLHttpRequest2__abort();
    properties.readyState = DONE;
    _XMLHttpRequest2__dispatchEvent(type);
    _XMLHttpRequest2__dispatchEvent("loadend");
    properties.readyState = UNSENT;
  }

  function _XMLHttpRequest2__dispatchEvent(type) {
    return EventTarget.dispatchEvent(self, type);
  }

  function _XMLHttpRequest2__onreadystatechange() {
    if (!transport) return;

    if (timeout && (_.now() - started > timeout)) {
      _XMLHttpRequest2__dispatchError("timeout");
      return;
    }

    while (transport && properties.readyState < transport.readyState) {
      switch (properties.readyState + 1) {
        case HEADERS_RECEIVED:
          try {
            responseHeaders = transport.getAllResponseHeaders(); // test readyState
          } catch (ex) { // MISE6-7 and Opera 9
            // process this readyState the next time round
          }
          if (!responseHeaders) return;
          break;

        case LOADING:
          if (transport.status === 304 && !requestHeaders["if-none-match"] && !requestHeaders["if-modified-since"]) {
            properties.status = 200;
            properties.statusText = "OK";
          } else {
            properties.status = transport.status;
            properties.statusText = transport.statusText;
          }
          break;

        case DONE:
          clearTimeout(timer);
          properties.responseText = transport.responseText;
          //properties.responseBody = transport.responseBody || null;
          var xml = transport.responseXML;
          if (xml) {
            var root = xml.documentElement;
            /*@if (1)
              // http://www.ilinsky.com/articles/XMLHttpRequest/#bugs-ie-responseXML-content-type
              if (_private.createCOMObject && !root && MIME_TYPE_XML.test(overridingMimeType || transport.getResponseHeader("Content-Type"))) {
                xml = _private.createCOMObject("DOMDocument");
                xml.async = false;
                xml.validateOnParse = false;
                xml.loadXML(properties.responseText);
              }
              properties.responseXML = xml.parseError == 0 ? xml : null;
            @else @*/
              if (root && !/parsererror/.test(root.namespaceURI)) {
                properties.responseXML = xml;
              }
            /*@end @*/
            if (overridingMimeType && !MIME_TYPE_XML.test(overridingMimeType)) {
              properties.responseXML = null;
            }
          }
          break;
      }
      properties.readyState++;
      _XMLHttpRequest2__dispatchEvent("readystatechange");
      if (properties.readyState === DONE) {
        _XMLHttpRequest2__dispatchEvent("load");
        _XMLHttpRequest2__dispatchEvent("loadend");
      }
    }
    if (properties.readyState === DONE) {
      _XMLHttpRequest2__destroy();
    }
  }
};

// Instantiate the constructor above so that the source text of methods are visible on the prototype.
var XMLHttpRequest2_prototype = new XMLHttpRequest2;
XMLHttpRequest2_prototype.toString = _.K("[object XMLHttpRequest2]");
XMLHttpRequest2 = _.Base.extend(XMLHttpRequest2_prototype);
XMLHttpRequest2.toString = _.K("[XMLHttpRequest2]");

var constants = { // Add the constants to both interfaces
  UNSENT:            UNSENT,
  OPENED:            OPENED,
  HEADERS_RECEIVED:  HEADERS_RECEIVED,
  LOADING:           LOADING,
  DONE:              DONE
};

_private.createGetters(XMLHttpRequest2, constants);
_private.createGetters(XMLHttpRequest2.prototype, constants);

XMLHttpRequest2.implement({
  timeout: 0,
  onreadystatechange: null,
  onloadstart:        null,
  onprogress:         null,
  onabort:            null,
  onerror:            null,
  onload:             null,
  ontimeout:          null,
  onloadend:          null
});

XMLHttpRequest2.implement(EventTarget);
