
base2.require("Colorizer,jsb", function(_, Colorizer, jsb) {
  jsb.Rule("form", {
    "jsb:oncontentready": function(form) {
      this.output(form, "");
      this.ready(form);
    },

    ":onclick": {
      "#clear": function(form) {
        form.input.value = "";
        this.output(form, "");
        this.ready(form);
      },

      "#colorize": function(form) {
        try {
          this.output(form, "");
          if (form.input.value) {
            var language = form.language.value;
            var scheme = Colorizer.getScheme(language);
            var value = "Scheme not found."
            var output = this.find(form, "#output");
            output.className = "";
            if (scheme) {
              value = scheme.parse(form.input.value);
              this.output(form, value);
              output.className = "colorized colorize-" + language;
            } else {
              this.error(form, "scheme not found: " + language);
            }
          }
        } catch (error) {
          this.error(form, "error colorizing text", error);
        }
      }
    },

    output: function(form, value) {
      this.find(form, "#output").innerHTML = value;
    },

    error: function(form, text, error) {
      if (error) {
        text += ": " + error.message
      }
      this.message(form, text, "error");
    },

    message: function(form, text, className) {
      var message = this.find(form, "#message");
      message.innerHTML = text;
      message.className = className || "";
    },

    ready: function(form) {
      this.message(form, "ready");
      form.input.focus();
    }
  });
});
