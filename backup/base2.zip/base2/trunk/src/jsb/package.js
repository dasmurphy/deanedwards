
var pkg = jsb = new _.Package({
  name:    "jsb",
  version: "%%VERSION%%",

  element: new Behavior,
  
  ExtendedNodeList: ExtendedNodeList,

  Rule: Rule,
  RuleList: RuleList
});
