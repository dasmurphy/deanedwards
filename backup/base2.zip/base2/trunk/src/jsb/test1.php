<!doctype html>
<title>JSB: Test Page</title>
<meta charset="utf-8">
<script src="/base2/trunk/src/base2-jsb.js"></script>

<script>
new jsb.Rule("*", {
  onattach: function(element) {
    console.log(element.nodeName + ".onattach");
  },

  oncontentready: function(element) {
    console.log(element.nodeName + ".oncontentready");
  }/*,

  ondocumentready: function(element) {
    console.log(element.id + ".ondocumentready");
  }*/
});
</script>

<style>
#example {
  background: red;
  border: 10px solid lime;
  padding: 50px;
  width: 200px;
  color: white;
  font-weight: bold;
  cursor: default;
}
#example p {
  background: white;
  color: red;
  width: 80px;
  padding: 5px;
}
</style>

<h1>JSB: Animation Test Page</h1>

<div id="example">
 <p id="p1">Hover to <span id="span1a">start <b id="b1a">the</b> animation</span>, <span id="span1b"><b id="b1b">click</b></span> to <span id="span1c">accelerate</span>.</p>
 <p id="p2">Hover to <span id="span2a">start <b id="b2a">the</b> animation</span>, <span id="span2b"><b id="b2b">click</b></span> to <span id="span2c">accelerate</span>.</p>
 <p id="p3">Hover to <span id="span3a">start <b id="b3a">the</b> animation</span>, <span id="span3b"><b id="b3b">click</b></span> to <span id="span3c">accelerate</span>.</p>
</div>
