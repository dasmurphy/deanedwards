
var dummy = document.createElement("div");

var view = jsb.element.extend({
  template: "",

  create: function(container, data) {
    var element = this.render(data);
    container.appendChild(element);
    this.attach(element);
    return element;
  },

  render: function(data) {
    if (typeof this.template == "string") {
      this.template = this.find(document, this.template);
    }
    var outerHTML = _.format(this.template.textContent, data);
    dummy.innerHTML = _.trim(outerHTML);

    return dummy.firstChild;
  }
});
