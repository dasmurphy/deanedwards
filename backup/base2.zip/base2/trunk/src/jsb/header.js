
//@cc_on

var undefined;
var forEach  = _.forEach;
var _private = _._;

// Max time for hogging the processor.
var CONST_TIMEOUT  = 100; // milliseconds

// Interval between refreshes of the rule engine.
var CONST_INTERVAL = 100; // milliseconds

var SECRET = {};

var SUPPORTS_DATASET = _.detect("(element.dataset)");

var FUNCTION_REQUIRED_ERR = "Function required by {0}().";

var head = dom.find(document, "head") || dom.find(document, "script").parentNode;
var domElement  = document.createElement("div");
var styleObject = domElement.style;

var matches = _private.get(domElement, "matches") || _private.get(domElement, "matchesSelector");

try {
  matches.call(domElement, ":not(a)");
} catch(ex) {
  matches = null;
}

var aliases = _private.aliases;
var ArityError  = _private.ArityError;
var TargetError = _private.TargetError;
var _getStylePropertyName = _private.getStylePropertyName;
var _offset = _private.offset;
var _pcopy = _private.pcopy;

var _attachedByRuleEngine_ = false;

var cssParser = new dom.CSSSelectorParser([
  "^((?:<#selector>)?(?:<#combinator>))(<#tag>)(#<#ident>)?(<#filter>)?$", true
]);

var allAttachments = {};

function toBehavior(behavior) {
  if (!baseBehavior.ancestorOf(behavior)) {
    behavior = baseBehavior.extend(behavior);
  }
  return behavior;
}


function Modification(behavior, properties) {
  if (behavior == SECRET) return this._attached;
  _.extend(this, properties);
  this._attached = {};
  this.attach = function(element) {
    behavior.attach(element);
    this._attached[element.uniqueID] = true;
  };
}

Modification.prototype.toString = _.K("[object Modification]");

function Transition(properties) {
  for (var i in properties) if (i !== "transitionProperty") {
    this[i] = properties[i];
  }
}

Transition.prototype = {
  transitionDelay: "0s",
  transitionDuration: "1s",
  transitionTimingFunction: "ease"
};

function hexUnescape(text) {
  return text.replace(/\\x([\da-f]{2})/g, function(match, hex) {
    return String.fromCharCode(parseInt(hex, 16));
  });
}

function chunk(array, block, oncomplete) {
  var index = 0;
  var length = array.length;
  
  var chunker = function _chunker() {
    var time = Date.now();
    var start = time;
    var k = 0;
    
    while (index < length && (time - start < CONST_TIMEOUT)) {
      block(array[index++]);
      if (k++ < 5 || k % 50 === 0) time = Date.now();
    }
    if (index < length) {
      setTimeout(chunker, 50);
    } else {
      if (oncomplete) oncomplete();
    }
  };
  chunker();
}
