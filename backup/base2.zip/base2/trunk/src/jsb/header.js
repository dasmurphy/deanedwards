
//@cc_on

var undefined;
var _private = _._;
var forEach  = _.forEach;

var window   = self.window;
var document = window.document;
var domElement  = document.createElement("div");

var matches = _private.get(domElement, "matches") || domElement.mozMatchesSelector; // check other engines (webkit blows) -@DRE

var JSB_TYPE_ERR  = "Invalid target for {0}().";

var ArityError  = _private.ArityError;
var TargetError = _private.TargetError;

var IS_CONNECTED = _.detect("(element.parentElement)") ? "parentElement" : "parentNode";

// Interval between refreshes of the rule engine.
var CONST_INTERVAL = 100; // milliseconds

// Max time for hogging the processor.
var CONST_TIMEOUT  = 100; // milliseconds

var SPECIFICITY_ID     = /#/g;
var SPECIFICITY_CLASS  = /[.:\[]/g;
var SPECIFICITY_TAG    = /^[^*]|[\s>+~][^*=]/g;

var _attachedByRuleEngine_ = false;

var CSSSelectorParser  = dom.CSSSelectorParser;

var isValidSelector = _.memoize(function(selector) {
  try {
    matches ? matches.call(domElement, selector) : _private.createMatcher(selector)(domElement);
    return true;
  } catch (ex) {
    return false;
  }
});

var metaBehaviors = {};

var allAttachments = {};

function toBehavior(behavior) {
  if (!pkg.element.ancestorOf(behavior)) {
    behavior = pkg.element.extend(behavior);
  }
  return behavior;
}

function Transition(properties) {
  for (var i in properties) if (i !== "transitionProperty") {
    this[i] = properties[i];
  }
}

Transition.prototype = {
  transitionDelay: "0s",
  transitionDuration: "1s",
  transitionTimingFunction: "ease"
};

function hexUnescape(text) {
  return text.replace(/\\x([\da-f]{2})/g, function(match, hex) {
    return String.fromCharCode(parseInt(hex, 16));
  });
}

function chunk(array, block, oncomplete) {
  var index = 0;
  var length = array.length;
  
  var chunker = function _chunker() {
    var time = _.now();
    var start = time;
    var k = 0;
    
    while (index < length && (time - start < CONST_TIMEOUT)) {
      block(array[index++]);
      if (k++ < 5 || k % 50 === 0) time = _.now();
    }
    if (index < length) {
      setTimeout(chunker, 50);
    } else {
      if (oncomplete) oncomplete();
    }
  };
  setTimeout(chunker, 1);
}
