
//@cc_on

var undefined;
var forEach  = _.forEach;
var _private = _._;

var SECRET = {};

// Max time for hogging the processor.
var CONST_TIMEOUT  = 100; // milliseconds

// Interval between refreshes of the rule engine.
var CONST_INTERVAL = 100; // milliseconds

var window   = self.window;
var document = window.document;
var head = dom.querySelector(document, "head") || dom.querySelector(document, "script").parentNode;
var domElement  = document.createElement("div");
var styleObject = domElement.style;

var animationQueue;

var matches = _private.get(domElement, "matches") || _private.get(domElement, "matchesSelector");

var JSB_TYPE_ERR  = "Invalid target for {0}().";

var ArityError  = _private.ArityError;
var TargetError = _private.TargetError;

var IS_CONNECTED = _.detect("(element.parentElement)") ? "parentElement" : "parentNode";

var SUPPORTS_DATASET = _.detect("(element.dataset)");

var _attachedByRuleEngine_ = false;

function Collection__set_detect(key, value) { // allow feature detection
  key = String(key);
  if (key < "A" && key > "@") {
    if (_.detect(key.slice(1))) this.merge(value);
  } else {
    this.base.apply(this, arguments);
  }
}

var CSSSelectorParser = dom.CSSSelectorParser;

var isValidSelector = _.memoize(function(selector) {
  try {
    matches ? matches.call(domElement, selector) : _private.createMatcher(selector).call(domElement);
    return true;
  } catch (ex) {
    return false;
  }
});

var allAttachments = {};

function toBehavior(behavior) {
  if (!baseBehavior.ancestorOf(behavior)) {
    behavior = baseBehavior.extend(behavior);
  }
  return behavior;
}

function Modification(behavior, properties) {
  if (behavior == SECRET) return this._attached;
  _.extend(this, properties);
  this._attached = {};
  this.attach = function(element) {
    behavior.attach(element);
    this._attached[element.uniqueID] = true;
  };
}

Modification.prototype.toString = _.K("[object Modification]");

function Transition(properties) {
  for (var i in properties) if (i !== "transitionProperty") {
    this[i] = properties[i];
  }
}

Transition.prototype = {
  transitionDelay: "0s",
  transitionDuration: "1s",
  transitionTimingFunction: "ease"
};

function hexUnescape(text) {
  return text.replace(/\\x([\da-f]{2})/g, function(match, hex) {
    return String.fromCharCode(parseInt(hex, 16));
  });
}

function chunk(array, block, oncomplete) {
  var index = 0;
  var length = array.length;
  
  var chunker = function _chunker() {
    var time = _.now();
    var start = time;
    var k = 0;
    
    while (index < length && (time - start < CONST_TIMEOUT)) {
      block(array[index++]);
      if (k++ < 5 || k % 50 === 0) time = _.now();
    }
    if (index < length) {
      setTimeout(chunker, 50);
    } else {
      if (oncomplete) oncomplete();
    }
  };
  chunker();
}
