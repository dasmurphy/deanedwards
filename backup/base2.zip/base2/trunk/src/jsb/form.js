
function isSuccessful(element) {
  if (!element.name || !element.form || element.disabled) return false;

  switch (element.type) {
    case "radio":
    case "checkbox":
      return element.checked;

    case "button":
    case "reset":
      return false;

    case "image":
    case "submit":
      return this.matches(element, ":active");

    case "select-multiple":
    case "select-one":
      return !this.matches(input, "datalist :scope");

    default:
      return true;
  }
}

function serialize(element) {
  return element.name + "=" + encodeURIComponent(element.value);
}

var form = baseBehavior.extend({
  name: "form",

  serialize: function serialize(form) {
    var successful = _.filter(form.elements, isSuccessful);
    return _.map(successful, serialize).join("&");
  }
});

form.element = baseBehavior.extend({
  name: "form.element",

  isSuccessful: isSuccessful,
  serialize: serialize
});
