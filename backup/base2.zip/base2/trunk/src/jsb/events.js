
var EVENT              = /^[^:]*:on(.+)$/;
var EVENT_BUBBLES      = /^((dbl)?click|mouse(down|up|move|over|out|wheel)|touch(start|end|move|cancel)|key(down|up|press)|submit|reset|change|select|transitionend)$/;

var EVENT_BUTTON       = /^(document:)?(mouse(down|up)|(dbl)?click)$/;
var EVENT_MOUSE        = /^(document:)?(mouse(down|up|over|out|move|wheel|enter|leave)|(dbl)?click)$/;
var EVENT_TEXT         = /^(document:)?key(down|up|press)/;
var EVENT_MULTI        = /^([^:]+:)?\(.+?\)$/;

var EVENT_TRANSITION          = /^(document:)?transitionend/;
var EVENT_TRANSITION_PROPERTY = /^(document:)?transitionend\(/;

var MOUSE_BUTTON_LEFT = /^[^12]$/;

var HANDLER_TYPE = {
  "object": 1,
  "function": 1
};

var EVENT_API = _.detect("(element.addEventListener)") ? "addEventListener" : "attachEvent";

var JSB_EVENT_DICT = {bubbles: false};

var _continueIfThrow = _private.continueIfThrow;

var delegatedEvents = {};

var contentReadyQueue  = {};
var contentReadyCount  = 0;
var documentReadyQueue = [];

function delegateEvent(event) {
  var element = event.target;
  
  if (element.nodeType !== 1) return;
  
  var type = event.type;

  var map = delegatedEvents[type];
  if (!map || !map.length) return;
  
  if (EVENT_MOUSE.test(type) && captureElement) return;
  
  var cancelBubble = !event.bubbles;

  if (!cancelBubble) {
    _.extend(event, "stopPropagation", function() {
      this.base();
      cancelBubble = true;
    });
  }
  
  // Dispatch events.
  do {
    var uniqueID = element.uniqueID;
    if (allAttachments[uniqueID]) {

      for (var i = 0, meta; meta = map[i]; i++) {
        // make sure it's an attached element
        if (meta[uniqueID]) {
          dispatchEvent(meta.behavior, element, event, meta, true);
        }
      }
    }
    element = element.parentNode;
  } while (element && !cancelBubble)
}

function dispatchEvent(behavior, element, event, meta, isDelegated) {
  var type = event.type;
  
  if (!captureElement && !isDelegated) {
    var currentTarget = event.currentTarget;
    if (currentTarget == document) {
      type = "document:" + type;
    } else if (currentTarget == window) {
      type = "window:" + type;
    } else if (event.eventPhase === 1) {
      type = "capture:" + type;
    }
  }

  // Left clicks only.
  if (!behavior.jsbExtendedMouse && EVENT_BUTTON.test(event.type)
    && !MOUSE_BUTTON_LEFT.test(event.button || 0)) return;

  if (EVENT_TEXT.test(type)) {
    var listener = meta.keyHandlers.getListener(type, event);
  } else {
    listener = meta.events[type];
    if (EVENT_TRANSITION.test(type)) {
      listener = meta.transitionEvents[type + "(" + event.propertyName + ")"] || listener;
    }
  }

  if (!listener || listener == _.Undefined) return;

  // A listener can also be map of selectors to event handlers (object listener)
  if (typeof listener == "function") { // normal listener
    var listeners = {":scope": listener}; // create a fake map
    var target = element;
  } else { // object listener
    listeners = listener;
    target = event.target;
  }
  
  // Ascend from the target to the attached element.
  // If the listener is an object then check each selector in the object.
  search: do {
    for (var selector in listeners) {
      if (
        selector === ":scope"
          ? target == element
          : matches ?
            matches.call(target, selector) :
            _private.createMatcher(selector).call(target)
      ) {
        listener = listeners[selector];
        event.jsbTarget = target;
        // Trigger the event handler.
        if (isDelegated) {
          // Use the host's event dispatch mechanism so that we get a separate execution context.
          _continueIfThrow(listener, behavior, element, event);
        } else {
          listener.call(behavior, element, event);
        }
        break search;
      }
    }
  } while (
    target != element &&
    (target = target.parentNode) &&
    target.nodeType === 1
  )
}

function dispatchFocusEvent(behavior, element, meta) {
  var event = new _private.Event("focus");
  event.target = event.currentTarget = element;
  dispatchEvent(behavior, element, event, meta);
}

function fire(target, type, dict, defaultAction) {
  if (arguments.length < 2) {
    throw TypeError(Arity("fire", this));
  }
  if (!target || !(EVENT_API in target)) {
    throw TypeError(Target("fire", this));
  }

  if (!dict) dict = {};

  if (!("bubbles" in dict)) dict.bubbles = true; // default is "true" for behavior.fire
  if (defaultAction) dict.cancelable = true;

  var event = new dom.CustomEvent(type, dict);

  for (var i in dict) if (!(i in event)) {
    event[i] = dict[i];
  }
  
  var defaultPrevented = !dom.dispatchEvent(target, event);
  if (!defaultPrevented && _.isFunction(defaultAction)) {
    defaultAction.call(this, target);
  }

  return !defaultPrevented;
}

var PseudoEvent = _private.Event.extend({
  constructor: function PseudoEvent(behavior, element, type, listener) {
    this.type = "jsb:" + type;
    this.target = this.currentTarget = this.jsbTarget = element;
    this.timeStamp = Date.now();
    _continueIfThrow(listener, behavior, element, this);
  }
});
