
// This is because IE8 is incredibly slow to calculate clientWidth/Height.

// http://stackoverflow.com/questions/800693/clientwidth-performance-in-ie8

// The fix is pretty horrible.
// I use an HTC file (dimensions.htc) that grabs the clientWidth and
// clientHeight properties and caches them.
// If the HTC fails to load then the original clientWidth/Height getters are used

var WIDTH  = "clientWidth";
var HEIGHT = "clientHeight";

if (8 === document.documentMode) {
  WIDTH = "base2Width";
  HEIGHT = "base2Height";

  jsb.clientWidth2 = {};
  jsb.clientHeight2 = {};

  Object.defineProperty(Element.prototype, WIDTH, {
    enumerable: false, // hide
    
    get: function() {
      return jsb.clientWidth2[this.uniqueID] || this.clientWidth;
    }
  });

  Object.defineProperty(Element.prototype, HEIGHT, {
    enumerable: false, // hide
    
    get: function() {
      return jsb.clientHeight2[this.uniqueID] || this.clientHeight;
    }
  });
}
