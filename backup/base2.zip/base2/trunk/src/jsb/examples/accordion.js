
var accordion = jsb.element.extend({
  PANE: ".pane",

  defaultPane: 0,
  min: 0,
  max: 200,
  sticky: false,
  duration: 500,
  ease: "ease-out",
  event: "mouseenter",
  
  metrics: {
    horizontal: {
      size: "width",
      offset: "offsetWidth"
    },
    
    vertical: {
      size: "height",
      offset: "offsetHeight"
    }
  },

  "jsb:oncontentready": function(element) {
    var panes = this.getPanes(element);
    if (panes.length) {
      var orientation = this.classList.contains(element, "horizontal") ? "horizontal" : "vertical";
      var metrics = this.metrics[orientation];

      if (orientation === "horizontal") {
        var nextElement = this.get(element, "nextElementSibling");
        if (nextElement) nextElement.style.clear = "left";
        var lastPane = panes.item(-1);
        this.style.set(element, {
          width:  lastPane.offsetLeft + lastPane.offsetWidth - panes[0].offsetLeft,
          height: lastPane.offsetHeight,
          overflow: "hidden"
        });
      }
      var data = {
        metrics: metrics,
        size: panes[0][metrics.offset]
      };
      this.setUserData(element, "accordion", data);
      var eventType = this.get(element, "event");
      var max = this.get(element, "max");
      var min = this.get(element, "min");
      panes.forEach(function(pane) {
        this.addEventListener(pane, eventType, function() {
          accordion.animatePane(element, pane, max, min);
        });
      }, this);
      
      if (this.get(element, "sticky")) {
        this.animatePane(element, panes[this.get(element, "defaultPane")], max, min, 0.01);
      }
    }
  },

  ":onmouseleave": function(element) {
    if (!this.get(element, "sticky")) {
      var data = this.getUserData(element, "accordion");
      if (data) this.animatePane(element, data.current, data.size);
    }
  },

  getPanes: function(element) {
    return this.findAll(element, this.PANE);
  },

  animatePane: function(element, currentPane, max, min, duration) {
    if (!currentPane) return;

    if (duration == null) {
      duration = this.get(element, "duration");
    }
    
    var panes = this.getPanes(element);
    var count = panes.length;
    var data = this.getUserData(element, "accordion");
    var metrics = data.metrics;
    var totalSize = data.size * count;

    data.current = currentPane;
    panes = panes.filter(function(pane) {
      return pane != currentPane;
    });
    count--;

    var sizes = panes.pluck(metrics.offset);
    var collapsedSize = min || Math.round((totalSize - max) / count);
    
    var ease = this.get(element, "ease");
    
    var propertyName = metrics.size;

    this.animate(element, {
      transitionDuration: duration + "ms",
      transitionTimingFunction: ease,

      onstep: function(step) {
        var expandedSize = totalSize;
        for (var i = 0; i < count; i++) {
          var value = sizes[i] + Math.round(step * (collapsedSize - sizes[i]));
          if (value < 0) value = 0;
          panes[i].style[propertyName] = value + "px";
          expandedSize -= value;
        }
        currentPane.style[propertyName] = expandedSize + "px";
      }
    });
  }
});
