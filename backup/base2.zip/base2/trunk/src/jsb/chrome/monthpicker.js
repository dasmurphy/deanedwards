
var monthpicker = spinner.extend({
  // constants

  FORMAT: "yyyy-mm",
  
  // properties
  
  type: "month", // HTML5 type
  block: 12,
  appearance: "monthpicker",
  placeholder: "yyyy-mm",

  /*onchange: function(element) {
    this.base(element);
    if (!this.classList.contains(element, "jsb-error") && element.value) {
      var date = this.getValueAsDate(element, true);
      this.showToolTip(element, chrome.locale.months[date.getUTCMonth()] + " " + date.getUTCFullYear());
    }
  },*/

  // methods

  convertValueToNumber: function monthpicker_convertValueToNumber(value) {
    if (value == "" || isNaN(Date.parse(value + "-01"))) return NaN;
    value = value.split("-");
    return (value[0] * 12) + parseInt(value[1], 10) - 1;
  },

  convertNumberToValue: function monthpicker_convertNumberToValue(number) {
    return isNaN(number) ? "" : new Date(~~(number / 12), number % 12, 12).toISOString().slice(0, 7);
  },

  getDefaultValue: function monthpicker_getDefaultValue() {
    var date = new Date;
    return date.getFullYear() * 12 + date.getMonth();
  },

  getValueAsNumber: function monthpicker_getValueAsNumber(element, external) {
    return external ? Date.parse(element.value + "-01T00Z") : this.base(element);
  },

  setValueAsNumber: function monthpicker_setValueAsNumber(element, value, external) {
    if (external) {
      value = this.convertValueToNumber(new Date(value).toISOString().slice(0, 7));
    }
    this.base(element, value);
  },

  getValueAsText: function monthpicker_getValueAsText(element) {
    var parts = element.value.split("-");
    return chrome.locale.months[parts[1] - 1] + " " + parts[0];
  }
});
