
var Popup = _.Base.extend({
  constructor: function Popup__constructor() {
    var body = this.body = this.createBody();
    body.className = "jsb-popup";
    if (this.role) {
      body.setAttribute("role", this.role);
    }
    var appearance = this.appearance;
    if (appearance && appearance !== "popup") {
      body.className += " jsb-" + appearance;
    }
    for (var i in this) {
      if (EVENT.test(i)) {
        dom.addEventListener(body, i.slice(2), this, true);
      }
    }
  },

  // properties

  appearance: "popup",
  element: null,
  body: null,
  
  // the following properties describe how the popup should be positioned.
  
  width: "auto", // "auto" or length
  height: "auto",
  
  position: "below", // "above" or "below" the control?

  scrollX: false, // allow scrolling?
  scrollY: false,

  offsetX: 0, // offset distance from the control
  offsetY: 0,
  
  // events

  "onmousedown": function Popup__onmousedown_gecko(event) {
    if (event.target == this.body) {
      event.preventDefault();
    }
  },

  handleEvent: function Popup__handleEvent(event) {
    switch (event.type) {
      case "mouseover":
      case "mouseout":
        if (event.target == this.body) return;
    }
    this["on" + event.type](event);
  },
  
  // methods

  createBody: function Popup__createBody() {
    return document.createElement("div");
  },

  getRect: function Popup__getRect() {
    var viewport = QUIRKS_MODE ? document.body : document.documentElement,
        popup    = this.body,
        element  = this.element,
        rect     = dom.getBoundingClientRect(element),
        left     = 0,
        top      = this.position === "below" ? element.offsetHeight - 1 : - 1 - element.offsetHeight,
        width    = this.width,
        height   = this.height,
        offsetX  = this.offsetX,
        offsetY  = this.offsetY;

    if (width === "base") {
      width = element.offsetWidth;
    }

    // resize
    if (width === "auto" || height === "auto") {
      if (height === "auto") {
        height = popup.scrollHeight + 2;
        var unitHeight = this.getUnitHeight();
        if (this.scrollY) {
          height = Math.min(height, Math.max(viewport[HEIGHT] - rect.bottom - 2, rect.top - 2));
        }
        if (unitHeight > 1) height = 2 + ~~(height / unitHeight) * unitHeight;
      }
      if (width === "auto") {
        width = popup.scrollWidth + 2;
        if (height < popup.scrollHeight + 2) width += 22; // scrollbars
        if (this.scrollX) {
          width = Math.min(width, Math.max(viewport[WIDTH] - rect.left - 2, rect.right - 2));
        }
        width =  Math.max(width, element.offsetWidth);
      }
    }
    if (height > viewport[HEIGHT] - rect.bottom && height < rect.bottom) {
      top = -height;
      offsetY *= -1;
    }
    if (width > viewport[WIDTH] - rect.right && width < rect.right) {
      left = element.offsetWidth - width;
      offsetX *= -1;
    }
    return new Rect(left + offsetX, top + offsetY, width, height);
  },
  
  getUnitHeight: K(1),

  hide: function Popup__hide() {
    this.removeBody();
  },

  isOpen: function Popup__isOpen() {
    return !!this.body[PARENT_ELEMENT];
  },

  layout: _.Undefined,

  movesize: function Popup__movesize() {
    var rect = this.getRect();
    var adjust = QUIRKS_MODE ? 0 : 2;
    var offset = control.offset(this.element);
    dom.style.set(this.body, {
      left: offset.left + "px",
      top: (offset.top + rect.top) + "px",
      width: Math.max(rect.width - adjust, 100) + "px",
      height: Math.max(rect.height - adjust, 22) + "px"
    });
  },

  find: function Popup__find(selector) {
    return dom.find(this.body, selector);
  },

  findAll: function Popup__findAll(selector) {
    return jsb.element.findAll(this.body, selector);
  },

  removeBody: function Popup__removeBody() {
    var parent = this.body[PARENT_ELEMENT];
    if (parent) parent.removeChild(this.body);
  },

  render: function Popup__render(html) {
    this.body.innerHTML = _.trim(html) || "";
  },

  setUnselectable: function Popup__setUnselectable(element) {
    element.unselectable = "on";
    dom.style.set(element, "userSelect", "none");
  },

  show: function Popup__show(element) {
    this.element = element;
    this.render();
    this.style();
    document.body.appendChild(this.body);
    this.movesize();
    this.body.style.visibility = "visible";
    this.layout();
  },

  style: _.Undefined,

  "@MSIE6": { // prevent <select> boxes from bleeding through
    removeBody: function Popup__removeBody_ie6() {
      var iframe = Popup._iframe;
      if (iframe[PARENT_ELEMENT]) {
        document.body.removeChild(iframe);
      }
      this.base();
    },

    createBody: function Popup__createBody_ie6() {
      var iframe = Popup._iframe;
      if (!iframe) {
        iframe = Popup._iframe = document.createElement("iframe");
        iframe.style.cssText = "position:absolute;z-index:999998!important";
        iframe.frameBorder = "0";
        iframe.scrolling = "no";
        iframe.src = "javascript:''";
        iframe.tabIndex = -1;
        iframe.setAttribute("role", "presentation");
        iframe.setAttribute("aria-hidden", "true");
      }
      return this.base();
    },

    show: function Popup__show_ie6(element) {
      this.base(element);
      var iframe = Popup._iframe;
      var body = this.body;
      var bodyStyle = body.currentStyle;
      dom.style.set(iframe, {
        left: bodyStyle.left,
        top: bodyStyle.top,
        width: body.offsetWidth,
        height: body.offsetHeight,
        backgroundColor: bodyStyle.backgroundColor
      });
      document.body.appendChild(iframe);
    }
  }
});
