
var Suggestions = PopupWindow.extend({
  // properties

  appearance: "menulist",
  role: "menu",

  // events

  "onmouseup": function Suggestions__onmouseup(event) {
    this.select(this.currentItem);
  },

  "onkeydown": function Suggestions__onkeydown(event) {
    switch (event.keyCode) {
      case 9: // tab
        this.hide();
        this.element.focus();
        return;
        
      case 13: // return
        event.preventDefault();
        this.select(this.currentItem, true);
        return;
        
      case 38: // up
        if (this.currentItem) {
          this.highlight(dom.get(this.currentItem, "previousElementSibling"));
        } else {
          this.highlight(dom.get(this.body, "firstElementChild"));
        }
        break;
        
      case 40: // down
        if (this.currentItem) {
          this.highlight(dom.get(this.currentItem, "nextElementSibling"));
        } else {
          this.highlight(dom.get(this.body, "firstElementChild"));
        }
        break;
        
      case 36: // home
        this.highlight(dom.get(this.body, "firstElementChild"));
        break;
        
      case 35: // end
        this.highlight(dom.get(this.body, "lastElementChild"));
        break;
        
      default:
        this.base(event);
        return;
    }
    event.preventDefault();
  },

  "onmouseover": function Suggestions__onmouseover(event) {
    this.highlight(event.target);
  },

  // methods

  focus: _.Undefined,

  getNodeIndex: function Suggestions__getNodeIndex(node) {
    var index = 0;
    while (node && (node = node.previousSibling)) index++;
    return index;
  },

  getUnitHeight: function Suggestions__getUnitHeight() {
    var item = dom.get(this.body, "firstElementChild");
    return item ? item.offsetHeight : 1;
  },
  
  "@MSIE9": {
    getUnitHeight: function Suggestions__getUnitHeight() {
      var items = this.body.getElementsByTagName("div");
      return items.length === 0 ? 1 : this.body.scrollHeight / items.length;
    }
  },

  highlight: function Suggestions__highlight(item) {
    if (item) {
      this.reset(this.currentItem);
      this.currentItem = item;
      dom.classList.add(item, "jsb-selected");
      item.tabIndex = 0;
      item.setAttribute("aria-selected", true);
    }
  },

  layout: function Suggestions__layout() {
    this.currentItem = null;
    this.highlight(dom.get(this.body, "firstElementChild"));
  },

  refresh: function Suggestions__refresh() {
    var html = "";
    var filtered = [], value;
    var elementValue = this.element.value.toLowerCase();
    if (elementValue) {
      var started = false;
      for (var i = 0, j = 0; value = this.values[i]; i++) {
        if (value.toLowerCase().indexOf(elementValue) === 0) {
          started = true;
          filtered[j++] = value;
        } else if (started) {
          break;
        }
      }
    } else {
      filtered = this.values;
    }
    if (filtered.length) {
      var openTag = '<div role="menuitem" unselectable="on" tabindex="-1">';
      var closeTag = '</div>';
      html = openTag + filtered.join(closeTag + openTag) + closeTag;
      this.render(html);
      this.movesize();
      this.layout();
    } else {
      this.hide();
    }
  },

  render: function Suggestions__render(html) {
    if (!html) {
      var list = this.element.getAttribute("list");
      this.values = suggestions[list] || getSuggestions(list);
      if (this.values.length) {
        this.refresh();
      }
    } else {
      this.base(html);
    }
  },

  reset: function Suggestions__reset(item) {
    if (item) {
      dom.classList.remove(item, "jsb-selected");
      item.removeAttribute("aria-selected");
      item.tabIndex = -1;
    }
  },

  select: function Suggestions__select(item, suppressInputEvent) {
    var value = item.getAttribute("value") || _.trim(item[TEXT_CONTENT]);
    this.owner.setValue(this.element, value, suppressInputEvent);
    this.hide();
    this.element.focus();
  }
});

// help

var suggestions = {};

var dummy = document.createElement("div");

function caselessCompare(a, b) {
  a = a.toLowerCase();
  b = b.toLowerCase();
  return a < b ? -1 : a > b ? 1 : 0;
}

function getSuggestions(id) {
  var values = [], value;
  var list = document.getElementById(id);
  if (list && /^DATALIST$/i.test(list.nodeName)) {
    list = list.getElementsByTagName("select")[0] || list;
    dummy.innerHTML = "<select>" + list.innerHTML + "</select>";
    var options = dummy.getElementsByTagName("option"), option;
    for (var i = 0, j = 0; option = options[i]; i++) {
      if (!option.disabled) {
        value = option.value || option.innerText || option.textContent;
        if (value) values[j++] = value;
      }
    }
    values.sort(caselessCompare);
    suggestions[id] = values;
  }
  return values;
}
