
var colorpicker = dropdown.extend({
  PATTERN: /^#[\da-f]{6}$/,
  
  type: "color", // HTML5 type
  name: "colorpicker",
  appearance: "colorpicker",

  // events

  "@MSIE": _preventScroll,

  ":onkeydown": function colorpicker_onkeydown(element, event) {
    this.base(element, event);
    
    if (event.keyCode < 33 || event.shiftKey || event.ctrlKey || event.altKey || event.metaKey) return;

    event.preventDefault();
  },

  "@!theme=aqua": {
    ":onfocus": function colorpicker_onfocus_aqua(element) {
      if (element != control._active) {
        this.classList.add(element, this.appearance + _FOCUS);
      }
      this.base(element);
    }
  },
  
  getState: function colorpicker_getState(element) {
    if (this.classList.contains(element, this.appearance + _FOCUS)) {
      return this.states.hover;
    } else {
      return this.base(element);
    }
  },

  layout: function colorpicker_layout(element) {
    this.base(element);
    var color = element.value;
    if (!this.PATTERN.test(color)) color = "#000000";
    element.style.color =
    element.style.backgroundColor = color;
  },

  hitTest: _.True, // click wherever you want...

  Popup: {
    appearance: "colorpicker-popup", // popup style class

    "@MSIE": {
      layout: _.Undefined,
      movesize: _.Undefined,
      style: _.Undefined,

      createBody: function Popup__createBody() {
        var body = this.base();
        body.innerHTML = "<object width=0 height=0 classid=clsid:3050f819-98b5-11cf-bb82-00aa00bdce0b></object>";
        return body;
      },

      show: function colorpicker_popup_render_msie(element) {
        var object = this.body.firstChild;
        var value = object.ChooseColorDlg(element.value.slice(1));
        this.owner.setValue(element, "#" + pad((+value).toString(16), 6));
      }
    },

    "@!MSIE": {
      "onchange": function colorpicker_popup_onchange(event) {
        var rgb = _.map(_.pluck(this.controls, "value"), Number); // array of rgb values
        var value = _.reduce(rgb, function(value, channel) {    // convert to: #string
          return value += pad(channel.toString(16));
        }, "#");
        this.owner.setValue(this.element, value);
        event.stopPropagation();
      },

      layout: function colorpicker_popup_layout() {
        var rgb = _.map(this.element.value.slice(1).match(/(\w\w)/g), _.partial(parseInt, undefined, 16)); // array of rgb values
        this.controls.forEach(function(channel, i) {
          channel.value = rgb[i];
          slider.layout(channel); // redraw
        });
      },

      render: function colorpicker_popup_render() {
        var SLIDER = ': <input type="range" class="jsb-colorpicker-slider" min="0" max="255">';
        this.base(wrapHTML([
          "R" + SLIDER,
          "G" + SLIDER,
          "B" + SLIDER
        ], "div", 'nowrap unselectable="on"'));

        if (!supported.range) {
          this.controls.forEach(slider.attach); // 3 sliders
        }

        this.render = _.Undefined; // render once
      }
    }
  }
});
