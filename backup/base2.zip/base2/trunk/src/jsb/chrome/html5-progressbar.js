
// implemented as <progress> element.

var progressbar = null;
