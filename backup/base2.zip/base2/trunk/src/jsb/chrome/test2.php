<!doctype html>
<title>chrome: Test Page</title>
<meta charset="utf-8">
<script src="/base2/trunk/src/console2.js"></script>
<script src="/base2/trunk/src/base2-jsb.js"></script>
<script src="/base2/trunk/src/jsb/chrome.js"></script>
<style>
input,select{vertical-align:middle}
progress{min-height:1em;min-width:1em;padding:0;vertical-align:middle}
</style>
<script>
jsb.Rule("input", {
  ":oninvalid": function(element, event) {
    console2.log(event.type);
  },
  ":onchange": function(element, event) {
    console2.log(event.type);
  },
  ":oninput": function(element, event) {
    console2.log(event.type);
  }
});
</script>
<body>
<form action="/" method="post" enctype="multipart/form-data">
<h1><b>chrome</b>: Test Page</h1>
<p><progress style="height:204px;width:18px;vertical-align:middle" value="<?php echo rand(1,99) ?>" max="100"></progress>
<input style="height:204px;width:24px" type="range" value="<?php echo rand(1,99) ?>" disabled>
<progress style="height:204px;width:18px;vertical-align:middle" value="<?php echo rand(1,99) ?>" max="100"></progress>
<input style="height:204px;width:24px" type="range" value="<?php echo rand(1,99) ?>"></p>

<?php
for ($i = 0; $i < 1; $i++) {
?>
<h2>Block <?php echo $i+1 ?></h2>
<ol style="width:70%;line-height:2">
<?php
  for ($j = 1; $j < 20; $j++) {
?>
 <li><p><input class="jsb-combobox" name="combobox<?php echo $i.$j; ?>" type="text" list="titles"<?php if($j==2)echo ' disabled' ?>>
  <select name="select<?php echo $i.$j; ?>" <?php if($j==2)echo 'disabled' ?>>
    <option>Baroness
    <option>Dr
    <option>Lady
    <option>Lord
    <option>Miss
    <option>Mr
    <option>Mrs
    <option>Prof
    <option>Rt Hon
    <option>Sir
  </select>
  <input class="jsb-colorpicker" name="colorpicker<?php echo $i.$j; ?>" type="color" value="#<?php
    for ($k = 0; $k < 3; $k++) {
      $r = rand(0, 255);
      if ($r < 16) echo "0";
      echo dechex($r);
    }
   ?>" <?php if($j==2)echo 'disabled' ?>>
  <input name="text<?php echo $i.$j; ?>" type="text"<?php if($j==2)echo ' disabled' ?> placeholder="placeholder">
  <input class="jsb-spinner" name="spinner<?php echo $i.$j; ?>" type="number"<?php if($j==2)echo ' disabled' ?>>
  <input class="jsb-slider" name="slider<?php echo $i.$j; ?>" type="range" value="<?php echo rand(1,99) ?>" <?php if($j==2)echo 'disabled' ?>>
  <input class="jsb-monthpicker" name="monthpicker<?php echo $i.$j; ?>" type="month" step="2" value="2009-03" <?php if($j==2)echo 'disabled' ?>>
  <input class="jsb-timepicker" name="timepicker<?php echo $i.$j; ?>" type="time" value="12:00" <?php if($j==2)echo 'disabled' ?>>
  <input class="jsb-datepicker" name="datepicker<?php echo $i.$j; ?>" type="date" min="2007-08-28" max="2010-08-28" <?php if($j==2)echo 'disabled' ?>>
  <input class="jsb-weekpicker" name="weekpicker<?php echo $i.$j; ?>" type="week" step="2" <?php if($j==2)echo 'disabled' ?>>
  <progress value="<?php echo rand(1,99) ?>" max="100"></progress>
  <label for="checkbox<?php echo $i.$j; ?>"><input name="checkbox<?php echo $i.$j; ?>" type="checkbox" id="checkbox<?php echo $i.$j; ?>" <?php if($j==2)echo 'disabled' ?>> oranges</label>
  <label for="radio<?php echo $i.$j; ?>"><input name="radio<?php echo $i.$j; ?>" type="radio" id="radio<?php echo $i.$j; ?>" <?php if($j==2)echo 'disabled' ?>> apples</label></p></li>

<?php
  }
?>
</ol>
<!--script type="text/javascript">
console2.log("Loading blocking script...");
document.write('<script src="block.js.php?' + (+new Date) + '"><\/script>');
</script-->
<?php
}
?>
<p><button type="submit">Submit</button></p>
</form>
<datalist id="titles"><select>
 <option>Baroness
 <option>Dr
 <option>Lady
 <option>Lord
 <option>Miss
 <option>Mr
 <option>Mrs
 <option>Prof
 <option>Rt Hon
 <option>Sir
</select></datalist>
