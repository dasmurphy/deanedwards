
var combobox = dropdown.extend({
  // properties
  role: "combobox",
  
  // methods

  get_list: function combobox_get_list(element) {
    var id = this.getAttribute(element, "list");
    return id ? this.find(document, "#" + id) : null;
  },

  Popup: MenuList
});
