
var Rect = _.Base.extend({
  constructor: function Rect__constructor(left, top, width, height) {
    this.left = left;
    this.top = top;
    this.width = width;
    this.height = height;
    this.right = left + width;
    this.bottom = top + height;
  },
  
  contains: function Rect__contains(x, y) {
    return x >= this.left && x <= this.right && y >= this.top && y <= this.bottom;
  }
});
