
var ToolTip = Popup.extend({
  appearance: "tooltip",
  role: "tooltip",
  text: "",

  offsetX: 2,
  offsetY: 4,
  
  "@Safari": { // focus ring
    offsetY: 6
  },

  "ontransitionend": function ToolTip__ontransitionend(event) {
    if (event.propertyName === "opacity" && event.target.style.opacity == "0") {
      this.removeBody();
    }
  },

  fadeIn: function ToolTip__fadeIn() {
    animate(this.body, {opacity: 1});
  },

  fadeOut: function ToolTip__fadeOut() {
    animate(this.body, {opacity: 0});
  },

  hide: function ToolTip__hide() {
    if (this.isOpen()) this.fadeOut();
    delete this.element;
    ToolTip.current = null;
    clearTimeout(this._timeout);
  },

  render: function ToolTip__render() {
    this.base(this.text);
    dom.style.set(this.body, {
      opacity: 0,
      width: "",
      height: ""
    });
  },
  
  show: function ToolTip__show(element, text, duration) {
    // Show the tooltip for 5 seconds.
    // If the user hovers over the tooltip (or the control itself)
    // then don't hide the tooltip.
    duration = duration || ToolTip.TIMEOUT;
    var tooltip = ToolTip.current = this;
    tooltip.text = text;
    if (tooltip._timeout) clearTimeout(tooltip._timeout);
    var checkHoverState = function() {
      if (dom.matches(element, ":hover") || dom.matches(tooltip.body, ":hover")) { // user is hovering over the control
        tooltip._timeout = setTimeout(checkHoverState, ToolTip.TIMEOUT / 3);
      } else {
        delete tooltip._timeout;
        tooltip.hide();
      }
      duration = ToolTip.TIMEOUT;
    };
    tooltip._timeout = setTimeout(checkHoverState, duration);
    this.base(element); // default behaviour
    this.fadeIn();
  }
}, {
  TIMEOUT: 5000,
  
  current: null
});
