
var suggest = dropdown.extend({
  // properties
  name: "suggest",
  appearance: "suggest",
  role: "combobox",

  // events

  ":oninput": function suggest_oninput(element, event) {
    if (this.isOpen(element)) {
      this.popup.refresh();
    } else {
      this.showPopup(element);
    }
  },

  // methods

  get_list: function suggest_get_list(element) {
    var id = this.getAttribute(element, "list");
    return id ? this.find(document, "#" + id) : null;
  },

  hitTest: function suggest_hitTest(element, event) {
    return !element.value && control._focus == element;;
  },

  layout: _.Undefined,

  Popup: Suggestions
});
