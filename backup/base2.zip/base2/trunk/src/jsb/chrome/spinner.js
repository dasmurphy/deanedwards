
var spinner = control.extend(number, {
  // constants

  states: {
    normal:      0,
    up_hover:    1,
    up_active:   2,
    down_hover:  3,
    down_active: 4,
    disabled:    5,
    length:      6
  },

  // properties

  type: "number", // HTML5 type
  appearance: "spinner",
  role: "spinbutton",

  // events

  onkeydown: function spinner_onkeydown(element, event) {
    if (!this.isEditable(element)) return;

    var keyCode = event.keyCode;
    
    if (!/^(3[348]|40)$/.test(keyCode)) return; // valid key codes

    event.preventDefault();

    switch (keyCode) {
      case 34: // page-down
        var block = true;
        break;

      case 33: // page-up
        block = true;

      case 38: // up-arrow
        var direction = "up";
    }
    if (!control._activeThumb) {
      this.activate(element, direction || "down", block);
    }
    this.increment(element, ~~(spinner._steps * spinner._direction), !!spinner._block);
  },

  onkeyup: function spinner_onkeyup(element, event) {
    if (!this.isEditable(element)) return;
    
    if (!/^(3[348]|40)$/.test(event.keyCode)) return; // valid key codes

    this.deactivate(element);
  },

  onmousedown: function spinner_onmousedown(element, event) {
    this.base(element, event);
    if (control._activeThumb) {
      this.startTimer(element);
    }
  },

  "jsb:onlosecapture": function spinner_onlosecapture(element, event) {
    this.base(element, event);
    this.deactivate(element);
  },

  // methods

  activate: function spinner_activate(element, direction, block) {
    control._activeThumb = control._hoverThumb = direction;
    this.layout(element);
    spinner._steps = 1;
    spinner._block = block;
    spinner._direction = control._activeThumb === "up" ? 1 : -1;
    //this.startTimer(element);
  },

  deactivate: function spinner_deactivate(element) {
    this.stopTimer(element);
    delete control._activeThumb;
    //delete control._hoverThumb;
    delete spinner._block;
    this.layout(element);
    if (element.select) element.select();
  },

  getState: function spinner_getState(element) {
    if (element.disabled) {
      var state = "disabled";
    } else if (element.readOnly && element != control._readOnlyTemp) {
      state = "normal";
    } else if ((element == control._hover || element == control._focus) && control._activeThumb) {
      state = control._activeThumb + _ACTIVE;
    } else if (element == control._hover && control._hoverThumb) {
      state = control._hoverThumb + _HOVER;
    } else {
      state = "normal";
    }
    return this.states[state];
  },

  hitTest: function spinner_hitTest(element, event) {
    var offset = this.getOffsetXY(element, event.clientX, event.clientY);
    if (offset.x < element[WIDTH] - this._IMAGE_WIDTH) return null;
    return offset.y <= (element[HEIGHT] / 2) ? "up" : "down";
  },

  startTimer: function spinner_startTimer(element) {
    if (!_timers[element.uniqueID + _TIMER]) {
      spinner._direction = control._activeThumb === "up" ? 1 : -1;
      spinner._steps = 1;
      this.base(element);
    }
  },

  stopTimer: function spinner_stopTimer(element) {
    if (_timers[element.uniqueID + _TIMER]) {
      this.base(element);
      if (!spinner._firedOnce) this.tick(element);
      delete spinner._firedOnce;
      if (element.select) element.select();
      this.syncCursor(element)
    }
  },

  tick: function spinner_tick(element) {
    this.increment(element, ~~(spinner._steps * spinner._direction), !!spinner._block);
    spinner._steps *= 1.05; // accelerate
    spinner._firedOnce = true;
  },

  "@MSIE": _MSIEShim // prevent typing over the background image
});
