
var timepicker = spinner.extend({
  // constants

  FORMAT: "hh:mm:ss",

  // properties

  appearance: "timepicker",
  block: 60,
  step: "60",
  stepScale: 1000,
  type: "time", // HTML5 type

  // events

  // methods

  convertValueToNumber: function timepicker_convertValueToNumber(value) {
    return value == "" ? NaN : Date.parse("1970-01-01T" + value + "Z");
  },

  convertNumberToValue: function timepicker_convertNumberToValue(number) {
    return isNaN(number) ? "" : new Date(number).toISOString().slice(11, 16);
    //var value = new Date(number).toISOString().slice(11).replace(/\.\d{3}Z$/, "");
    //return value.replace(/:00$/, ""); // fix me: this should be dependant on an element's step attribute
  },

  getDefaultValue: function timepicker_getDefaultValue() {
    var date = new Date;
    return Date.UTC(1970, 0, 1, date.getHours(), date.getMinutes(), 0, 0);
  },

  getValueAsText: function timepicker_getValueAsText(element) {
    return new Date("T" + element.value).toTimeString();
  },

  "@(Date.prototype.toLocaleTimeString)": {
    getValueAsText: function timepicker_getValueAsText(element) {
      return new Date("T" + element.value).toLocaleTimeString();
    }
  }
});
