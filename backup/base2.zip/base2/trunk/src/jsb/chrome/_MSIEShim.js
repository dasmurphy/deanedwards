
// Damn. This is way too big. :-(
// All this because MSIE does not respect padding in <input> elements.

// This shim places a little widget over the current <input> element.
// The widget looks exactly like the chrome control and forwards its events.

var _MSIEShim = {
  ":onfocus": function _MSIEShim_onfocus(element, event) {
    this.base(element, event);

    var behavior = this, timer;
    if (!shim.control) {
      shim.control = this._createShim();
      document.body.insertBefore(shim.control, document.body.firstChild);
      shim.attach(shim.control);
    }
    shim.element = element;
    shim.behavior = behavior;
    var style = shim.control.style;
    style.display = "none";
    style.position = "absolute";
    style.fontSize = "0";
    style.border = "0";
    style.height = element.clientHeight + "px";
    style.width = behavior._IMAGE_WIDTH + "px";
    style.backgroundImage = this.style.compute(element, "backgroundImage");
    shim.layout();

    function onpropertychange(event) {
      if (event.propertyName === "value") element.scrollLeft = 9999;
    }
    function position() {
      var offset = _private.getOffsetFromBody(element);
      var rect = element.getBoundingClientRect();
      var adjustRight = rect.right - rect.left - element.offsetWidth;
      style.left = (offset.left + adjustRight + element[WIDTH] - behavior._IMAGE_WIDTH + element.clientLeft) + "px";
      style.top = (offset.top + element.clientTop) + "px";
      timer = null;
    }
    function onfocusout() {
      element.detachEvent("onpropertychange", onpropertychange);
      element.detachEvent("onfocusout", onfocusout);
      window.detachEvent("onresize", onresize);
      style.display = "none";
      element.scrollLeft = 9999;
      delete shim.element;
    }
    function onresize() {
      if (!timer) timer = setTimeout(position, 50);
    }
    element.attachEvent("onpropertychange", onpropertychange);
    element.attachEvent("onfocusout", onfocusout);
    window.attachEvent("onresize", onresize);
    position();
    setTimeout(function() {
      if (shim.element) {
        style.display = "block";
      }
    }, 1);
  },

  _createShim: function() {
    return document.createElementNS("http://www.w3.org/2000/svg", "rect");
  },

  "@MSIE[678]": {
    _createShim: function() {
      var control = document.createElement("x");
      control.attachEvent("onmousedown", _shimMouse);
      control.attachEvent("onmousemove", _shimMouse);
      return control;
    },

    ":onmouseover": _shimMouseOverOut,
    ":onmouseout": _shimMouseOverOut,

    ":onmousedown": _shimLayout,
    ":onmouseup": _shimLayout
  },

  ":onkeydown": _shimLayout,

  ":onkeyup": function _MSIEShim_onkeyup(element, event) {
    if (!_PopupWindow_activePopup && event.keyCode === 35) { // END key
      element.scrollLeft = 9999;
    } else {
      this.base(element, event);
    }
    if (shim.element == element) shim.layout();
  },

  layout: function _MSIEShim_layout(element, state) {
    this.base(element, state);
    if (element == shim.element) {
      shim.layout();
    }
  }
};

var shim = jsb.element.extend({
  "@MSIE[678]": {
    jsbExtendedMouse: true,

    ":onmouseover": shim_onmouseoverout,
    ":onmouseout": shim_onmouseoverout
  },

  layout: function shim_layout() {
    if (this.element) {
      this.control.style.backgroundPosition = this.element.style.backgroundPosition;
    }
  }
});

function _shimLayout(element, event) {
  this.base(element, event);
  if (element == shim.element) shim.layout();
}

function _shimMouse(event) {
  if (event.type === "mousedown") {
    var onbeforedeactivate = function(event) {
      event.returnValue = false;
      shim.element.detachEvent("onbeforedeactivate", onbeforedeactivate);
    };
    shim.element.attachEvent("onbeforedeactivate", onbeforedeactivate);
    event.returnValue = false;
  }
  shim.element.fireEvent("on" + event.type, event);
  event.cancelBubble = true;
  shim.layout();
  if (event.type === "mousedown") {
    shim.element.focus();
  }
}

function _shimMouseOverOut(element, event) {
  if (element != shim.element || (event.relatedTarget && event.relatedTarget != shim.control)) {
    this.base(element, event);
  }
  if (shim.element == element) shim.layout();
}

function shim_onmouseoverout(element, event) {
  event.stopPropagation();
  if (this.element && event.relatedTarget != this.element) {
    event.target = this.element;
    this.behavior[":on" + event.type](this.element, event);
  }
  this.layout();
}
