
var WIDTH = "clientWidth",
    HEIGHT = "clientHeight";

if (jsb.clientWidth2) {
  WIDTH = "clientWidth2";
  HEIGHT = "clientHeight2";
}
