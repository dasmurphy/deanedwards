
// shared by progressbar and slider

var range = control.extend(number, {
  // constants

  _IMAGE_SIZE: 3000,
  
  // properties
  
  min:  "0",
  max:  "100",
  
  allowVertical: true,

  // methods

  set: function range_set(element, propertyName, value) {
    value = this.base.apply(this, arguments);
    if (/^(max|min|step|value)$/.test(propertyName)) {
      this.layout(element);
    }
    return value;
  },

  getProperties: function range_getProperties(element) {
    var properties = this.base(element);
    var value = this.getValue(element);
    properties.relativeValue = ((properties.value = parseFloat(value) || 0) - properties.min) / (properties.max - properties.min);
    return properties;
  },

  getRelativeValue: function range_getRelativeValue(element) {
    return this.getProperties(element).relativeValue;
  },

  setRelativeValue: function range_setRelativeValue(element, relativeValue) {
    var properties = this.getProperties(element);
    this.setValueAsNumber(element, (properties.max - properties.min) * relativeValue);
  },

  getValidValue: function range_getValidValue(element, value, round) {
    return this.base(element, value, round || "round");
  },

  getCursor: K("")
});
