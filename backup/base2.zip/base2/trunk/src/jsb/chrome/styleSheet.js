
var StyleSheet = jsb.StyleSheet.extend({
  constructor: function StyleSheet__constructor(rules) {
    _.Collection.call(this);

    this.vars = _private.pcopy(this.vars);

    for (var i = 0; rules = arguments[i]; i++) {
      var vars = rules["@vars@"];
      rules = _.extend({}, rules, true);
      rules["@vars@"] = vars;
      var baseRule = rules["*"];
      if (baseRule) {
        delete rules["*"];
        this.baseRule = _.extend({}, baseRule, true);
      }
      this.merge(rules);
    }
  },

  baseRule: null,

  set: function StyleSheet__set(selectorText, properties) {
    var baseRule = this.baseRule;
    if (baseRule) {
      properties = _private.pcopy(baseRule, properties);
    }
    this.base(selectorText, properties);
  },

  toString: function StyleSheet__toString() {
    var URL = /(url\s*\(\s*['"]?)([\w\.]+[^:\)]*['"]?\))/gi;
    var assets = base2.info("host").replace(/(lib|src)\/$/, "assets/");

    return this.base()
      .replace(/%theme%/g, "themes/" + theme.name)
      .replace(URL, "$1" + assets + "$2")
      .replace(/!/g, "!important");
  }
});

var styleSheet = new StyleSheet({
  "@vars@": theme,

  "*": {
    backgroundPosition:        "9999px 9999px",
    backgroundAttachment:      "scroll!",
    backgroundRepeat:          "no-repeat!",

    "@!theme=classic": {
      border:                  "1px solid",
      borderColor:             "border",

      "@theme=aero": {
        borderRadius:          "1px"
      }
    },

    "@theme=aqua": {
      borderWidth:             "2px 1px 1px 1px",
      borderColor:             "#9e9e9e #b4b4b4 #dadada #b4b4b4"
    }
  },

  ".jsb-spinner,.jsb-timepicker,.jsb-monthpicker": {
    backgroundImage:    "url(%theme%/spinner.png)!"
  },

  ".jsb-colorpicker,.jsb-datepicker,.jsb-weekpicker": {
    "@theme=aqua": {
      borderRadius:           "5px",
      boxShadow:              "0 1px 4px rgba(160, 160, 160, 0.5)",

      "@(style.borderImage)": {
        borderImage:          "url(%theme%/dropdown.png) 1 18 1 4!",
        borderStyle:          "none!"
      },

      "@!(style.borderImage)": {
        backgroundImage:      "url(%theme%/bg-dropdown.png)!",
        backgroundPosition:   "right center!",
        border:               "1px solid #545454!"
      }
    },

    "@!theme=aqua": {
      backgroundImage:        "url(%theme%/dropdown.png)!"
    }
  },

  ".jsb-slider,.jsb-colorpicker,.jsb-progressbar": {
    color:                    "transparent",
    cursor:                   "default",
    textIndent:               "-100%!", // hide text for purely visual controls (Gecko, WebKit and Opera)
    userModify:               "read-only!",
    MozUserSelect:            "none!", // still buggy in webkit

    "@MSIE[6-9]": { // hide text for purely visual controls (MSIE6-9)
      textIndent:             0,
      lineHeight:             "999",

      "@MSIE[^67]": {
        verticalAlign:        "middle" // Argh! This is bad. It means that the normal vertical alignment doesn't work. :(
      }
    }
  },

  ".jsb-progressbar,.jsb-slider": {
    verticalAlign:         "middle" // not sure about this
  },

  ".jsb-progressbar": {
    display:               "inline-block",
    lineHeight:            "normal",
    minHeight:             "8px",
    borderColor:           "threeddarkshadow",
    borderWidth:           "1px",
    borderStyle:           "solid",
    borderRadius:          "5px",
    backgroundColor:       "white",
    backgroundImage:       "url(%theme%/progressbar.png)!",

    width:                 "10em",
    height:                "1em",
    boxSizing:             "border-box"
  },

  ".jsb-slider": {
    borderStyle:           "none",
    backgroundColor:       "transparent",
    backgroundImage:       "url(%theme%/slider.png)!"
  },

  ".jsb-popup": {
    visibility:         "hidden",
    backgroundColor:    "window",
    borderWidth:        "1px!",
    position:           "absolute!",
    zIndex:             "999999!",
    cursor:             "default",
    padding:            "0!",
    margin:             "0!",

    "@Gecko|Opera|theme=aqua|WebKit": {
      borderColor:      "threedshadow!",
      borderStyle:      "outset!",

      "@Safari": {
        boxShadow:      "2px 2px 4px rgba(80, 80, 80, 0.75)!"
      },

      "@Opera": {
        borderStyle:    "solid!"
      }
    },

    "@NT(6\\.1|[7-9])": { // Windows 7
      borderColor:      "#828790!"
    },

    "@theme=classic": {
      borderColor:      "threedshadow!",
      borderStyle:      "solid!"
    }
  },

  ".jsb-popup .jsb-datepicker-days": {
    userSelect:         "none!",
    width:              "100%!",
    margin:             "2px 0 0 0!",
    padding:            "2px!",
    backgroundColor:    "window",
    color:              "windowtext"
  }
}, {
  "*": {
    "@!theme=classic": {
      padding:          "2px"
    },

    "@theme=aqua": {
      padding:          "1px 2px 2px 2px"
    }
  },

  ".jsb-spinner,.jsb-timepicker,.jsb-monthpicker": {
    width:              "5em",

    "@!theme=aqua": {
      paddingRight:     "19px!"
    },

    "@!(style.borderImage)": {
      paddingRight:     "19px!"
    }
  },

  ".jsb-timepicker,.jsb-monthpicker": {
    width:              "5em",

    "@QuirksMode": {
      width:            "7em"
    }
  },

  ".jsb-timepicker": {
    "@theme=aqua": {
      width:            "5em"
    }
  },

  ".jsb-colorpicker,.jsb-datepicker,.jsb-weekpicker": {
    width:         "8em",

    "@theme=aqua": {
      "@(style.borderImage)": {
        borderWidth: "1px 18px 1px 4px!",
        padding:   "1px"
      },

      "@!(style.borderImage)": {
        padding:   "1px 22px 1px 4px!"
      }
    },

    "@!theme=aqua": {
      paddingRight: "19px!"
    }
  },

  ".jsb-slider": {
    height:        "21px",
    minHeight:     "21px",
    padding:       0,
    border:        "none"
  },

  ".jsb-colorpicker": {
    width:         "4em",

    "@QuirksMode": {
      width:       "6em"
    }
  },

  ".jsb-datepicker": {
    width:         "7em",

    "@QuirksMode": {
      width:       "8em"
    }
  },

  ".jsb-weekpicker": {
    width:         "6.5em",

    "@QuirksMode": {
      width:       "7em"
    }
  },

  "@theme=aqua": {
    ".jsb-spinner,.jsb-timepicker,.jsb-monthpicker": {
      borderTopWidth: "1px",
      paddingTop:     "2px"
    },

    "@(style.borderImage)": {
      ".jsb-spinner,.jsb-timepicker,.jsb-monthpicker": {
        paddingRight: "19px!"
      }
    },

    ".jsb-datepicker": {
      width:         "7em"
    },

    ".jsb-weekpicker": {
      width:         "6em"
    },

    ".jsb-monthpicker": {
      width:         "5em"
    }
  }
}, {
  "datalist": {
    display: "none"
  },

  // popups

  ".jsb-popup *": {
    margin: "0!",
    padding: "0!"
  },

  ".jsb-popup option": {
    padding: "0 3px!"
  },

  ".jsb-menulist": {
    overflowY:     "auto!",

    "@Safari": {
      borderColor:     "windowtext!"
    }
  },

  ".jsb-menulist div": {
    margin:          "0!",
    padding:         "1px 2px!",
    overflow:        "hidden!",
    whiteSpace:      "nowrap!",
    outline:         "none!"
  },

  ".jsb-colorpicker-popup": {
    backgroundColor:      "buttonface!",
    color:                "buttontext!",
    fontSize:             "11px!",
    padding:              "4px!",
    overflow:             "hidden!",
    whiteSpace:           "nowrap!",
    userSelect:           "none!",

    "@WebKit(52[^89])|Chrome[1-3]": {
      backgroundColor: "#ece9d8!"
    }
  },

  ".jsb-colorpicker-slider": {
    fontSize:        "11px",
    margin:          "4px 2px!",
    verticalAlign:   "middle",
    width:           "127px"
  },

  ".jsb-datepicker-popup": {
    backgroundColor:      "#fcfcfd!",
    overflow:             "hidden!",

    "@theme=classic": {
      backgroundColor:    "threedface!"
    }
  },

  ".jsb-datepicker-year": {
    boxSizing:         "border-box!",
    width:             "5em!",
    marginLeft:        "2px!",
    padding:           "2px",

    "@QuirksMode": {
      width:           "4.5em!"
    }
  },

  ".jsb-datepicker-popup th": {
    backgroundColor: "infobackground!",
    color:           "infotext!",
    fontWeight:      "normal!",
    marginBottom:    "20px!"
  },

  ".jsb-datepicker-popup th,.jsb-datepicker-days td": {
    padding:         "2px 1px!",
    textAlign:       "center!",
    width:           "14%!"
  },

  ".jsb-datepicker-days td.disabled,.jsb-datepicker-days tr.disabled td": {
    color:           "graytext!"
  },

  ".jsb-selected,tr.jsb-selected td": {
    backgroundColor: "highlight!",
    color:           "highlighttext!"
  },

  ".jsb-selected": {
    outline:         "initial"
  },

  "@KHTML": {
    ".jsb-slider:focus:not(.slider_focus)": {
      outline:       "none!"
    }
  },

  "@!KHTML": {
    ".jsb-slider": {
      outlineWidth:  "1px",
      outlineStyle:  "none"
    },
    ".slider_focus": {
      outlineWidth:  "1px",
      outlineStyle:  "dotted"
    }
  },

  "@theme=luna\\/blue": {
    ".jsb-datepicker-popup th": {
      backgroundColor: "#ffffe1!"
    }
  },

  "@theme=(human|clearlooks)": {
    ".jsb-datepicker,.jsb-weekpicker,.jsb-colorpicker": {
      borderTopRightRadius:          "5px",
      borderBottomRightRadius:       "5px"
    }
  },

  "@theme=aqua": {
    ".jsb-spinner,.jsb-timepicker,.jsb-monthpicker": {
      borderTopWidth:                  "1px",
      borderRightColor:                "transparent",
      borderTopRightRadius:            "5px",
      borderBottomRightRadius:         "5px"
    },

    ".jsb-spinner[disabled],.jsb-spinner[readonly],.jsb-timepicker[disabled],.jsb-timepicker[readonly],.jsb-monthpicker[disabled],.jsb-monthpicker[readonly]": {
      borderColor:      "#d6d6d6 #e0e0e0 #f0f0f0 #e0e0e0"
    },

    "..jsb-datepicker[readonly],.jsb-datepicker[disabled],.jsb-weekpicker[readonly],.jsb-weekpicker[disabled]": {
      "@(style.borderImage)": {
        borderImage:   "url(%theme%/dropdown-disabled.png) 1 18 1 4!"
      },

      "@!(style.borderImage)": {
        backgroundImage:   "url(%theme%/bg-dropdown-disabled.png)!"
      }
    },

    "@(style.borderImage)": {
      ".jsb-colorpicker": {
        borderImage:       "url(%theme%/colorpicker.png) 1 18 1 4!"
      },

      ".jsb-colorpicker[readonly],.jsb-colorpicker[disabled]": {
        borderImage:       "url(%theme%/colorpicker-disabled.png) 1 18 1 4!"
      }
    },

    "@!(style.borderImage)": {
      ".jsb-colorpicker": {
        backgroundImage:   "url(%theme%/bg-colorpicker.png)!"
      },

      ".jsb-colorpicker[readonly],.jsb-colorpicker[disabled]": {
        backgroundImage:   "url(%theme%/bg-colorpicker-disabled.png)!"
      }
    },

    ".jsb-datepicker[disabled],.jsb-weekpicker[disabled],.jsb-colorpicker[disabled],.jsb-progressbar[disabled]": {
      color:         "windowtext",
      opacity:       0.5
    },

    ".jsb-colorpicker-popup,.jsb-datepicker-popup": {
      backgroundColor: "window!",
      backgroundImage: "url(%theme%/metal.png)!",
      backgroundRepeat: "repeat!"
    },

    ".jsb-datepicker-popup th": {
      backgroundColor: "#89acd5!",
      color:           "white!"
    }
  },

  ".jsb-tooltip": {
    borderColor:        "graytext",
    backgroundColor:    "infobackground",
    color:              "infotext",
    fontSize:           "small",
    fontFamily:         "tahoma,arial",
    boxShadow:          "2px 4px 4px rgba(160, 160, 160, 0.5)",
    padding:            "0 2px!",
    textAlign:          "center!",
    verticalAlign:      "middle!",

    "@MSIE.+QuirksMode": {
      fontSize:         "x-small"
    }
  },

  ".jsb-error": {
    borderColor:      "#ff5e5e",
    outlineColor:     "#ff5e5e"
  },

  "@Safari.+Win(32|64)": {
    "@!theme=aqua": {
      "input,select,.jsb-selected": {
        outlineColor:  "border"
      }
    }
  },

  ".jsb-progressbar::-webkit-progress-bar": {
    display: "none"
  },

  ".jsb-progressbar::-moz-progress-bar": {
    backgroundColor: "transparent"
  },

  ".jsb-slider::-webkit-slider-container,.jsb-slider::-webkit-slider-runnable-track,.jsb-slider::-webkit-slider-thumb": {
    display: "none"
  },

  ".jsb-progressbar-vertical": {
    appearance: "progress-bar-vertical",
    backgroundImage: "url(%theme%/progressbar-vertical.png)!"
  },

  ".jsb-slider-vertical": {
    appearance: "slider-vertical",
    backgroundImage: "url(%theme%/slider-vertical.png)!"
  }
});
