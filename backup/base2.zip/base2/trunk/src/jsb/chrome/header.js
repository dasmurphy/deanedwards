
// Browser chrome.

// Credits: some code written by Erik Arvidsson.

var undefined;
var K        = _.K;
var forEach  = _.forEach;
var _private = _._;

var document = window.document;
var element  = document.createElement("div");
var head     = dom.querySelector(document, "head") || dom.querySelector(document, "script").parentNode;

var _ACTIVE = "\x5factive";
var _HOVER  = "\x5fhover";
var _FOCUS  = "\x5ffocus";
var _TIMER  = "\x5ftimer";

var EVENT = /^(\w+:)?on(\w+)$/;

var TEXT_CONTENT = "textContent" in element ? "textContent" : "innerText";

var INLINE_BLOCK = _.detect("Gecko1\\.[^9]") ? "-moz-inline-box" : "inline-block";

var QUIRKS_MODE = _.detect("QuirksMode");

var SUPPORTS_ATTRIBUTE_SELECTORS = !_.detect("MSIE[67]");

var DAY = 86400000;

var PARENT_ELEMENT = "parentElement" in element ? "parentElement" : "parentNode";

var _attachments = {};
var _timers      = {};

var styleObject = document.createElement("div").style;

var animate  = jsb.element.animate;

var  _preventScroll = {
  onfocus: function _preventScroll_onactivate(element, event) {
    this.base(element);
    if (!element.onscroll) {
      element.scrollTop = 0;
      element.onscroll = _resetScroll;
    }
  }
};

function _resetScroll() {
  this.scrollTop = 0;
}

function pad(number, length) {
  return "0000".slice(0, (length || 2) - String(number).length) + number;
}

function wrapHTML(items, tagName, attributes) {
  return _.reduce(items, function(html, text) {
    return html += "<" + tagName + " " + (attributes || "") + ">" + text + "</" + tagName + ">";
  }, "");
}

function forEach_detect(object, eacher, context) {
  var forEach_detector = function _forEach_detector(value, key) {
    if (key.indexOf("@") === 0) { // object/feature detection
      if (_.detect(key.slice(1))) forEach (value, forEach_detector);
    } else eacher.call(context, value, key, object);
  };
  forEach (object, forEach_detector);
}
