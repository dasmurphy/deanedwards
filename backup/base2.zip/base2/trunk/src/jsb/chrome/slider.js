
var slider = range.extend({
  // constants

  _HORIZONTAL_HEIGHT: 21,
  _VERTICAL_WIDTH: 22,
  _THUMB_SIZE: 11,
  _IMAGE_SIZE: 3000,

  // properties

  appearance: "slider",
  role: "slider",
  type: "range", // HTML5 type

  // events

  "@MSIE": _preventScroll,

  onfocus: function slider_onfocus(element, event) {
    if (element != control._active) {
      this.classList.add(element, this.appearance + _FOCUS);
    }
    this.base(element, event);
  },

  onkeydown: function slider_onkeydown(element, event) {
    var keyCode = event.keyCode;

    if (!this.isEditable(element) || keyCode < 33 || event.ctrlKey || event.metaKey) return;

    event.preventDefault();

    if (keyCode > 40) return;

    var amount = 1;

    switch (keyCode) {
      case 35: // end
        var value = 1;

      case 36: // home
        this.setRelativeValue(element, value || 0);
        return;

      case 33: // page up
        var block = true;
        break;

      case 34: // page down
        block = true;

      case 37: // left
      case 40: // down
        amount = -1;
    }
    this.increment(element, amount, block);
  },

  onmousedown: function slider_onmousedown(element, event) {
    event.preventDefault();
    
    if (this.isEditable(element)) {
      var offset = this.getOffsetXY(element, event.clientX, event.clientY);
      this.setValueByPosition(element, offset.x - this._THUMB_SIZE / 2, offset.y - this._THUMB_SIZE / 2);

      var thumb = this.getThumbRect(element);
      control._dragInfo = {
        dx: event.screenX - thumb.left,
        dy: event.screenY - thumb.top
      };
    }
    this.base(element, event);
  },

  onmousemove: function slider_onmousemove(element, event) {
    var dragInfo = control._dragInfo;
    if (dragInfo) {
      this.setValueByPosition(element, event.screenX - dragInfo.dx, event.screenY - dragInfo.dy);
    } else {
      this.base(element, event);
    }
  },

  // methods

  increment: function slider_increment(element, amount, block) {
    var type = block ? "Block" : "Unit";
    amount *= this["get" + type + "Increment"](element);
    this.setRelativeValue(element, this.getRelativeValue(element) + amount);
  },

  getBlockIncrement: function slider_getBlockIncrement(element) {
    // try to get as close as possible to 10% while still being a multiple
    // of the step and make sure that the block increment is not smaller than
    // twice the size of the unit increment
    var ui = this.getUnitIncrement(element);
    return Math.max(2 * ui, Math.round(0.1 / ui) * ui);
  },

  getUnitIncrement: function slider_getUnitIncrement(element) {
    var properties = this.getProperties(element);
    return properties.step / (properties.max - properties.min) || this.base(element);
  },

  getState: function slider_getState(element) {
    if (element.disabled) {
      var state = "disabled";
    } else if (element == control._active && control._activeThumb) {
      state = "active";
    } else if (element == control._focus || (!element.readOnly && element == control._hover && control._hoverThumb)) {
      state = "hover";
    } else {
      state = "normal";
    }
    return this.states[state];
  },

  getThumbRect: function slider_getThumbRect(element) {
    var clientWidth = element[WIDTH];
    var clientHeight = element[HEIGHT];
    var relativeValue = this.getProperties(element).relativeValue;
    
    if (clientHeight > clientWidth) {
      return new Rect(
        (clientWidth - this._VERTICAL_WIDTH) / 2,
        (clientHeight -= this._THUMB_SIZE) - ~~(clientHeight * relativeValue),
        this._VERTICAL_WIDTH,
        this._THUMB_SIZE
      );
    } else {
      return new Rect(
        ~~((clientWidth - this._THUMB_SIZE) * relativeValue),
        ~~((clientHeight - this._HORIZONTAL_HEIGHT) / 2),
        this._THUMB_SIZE,
        this._HORIZONTAL_HEIGHT
      );
    }
  },

  getValueByPosition: function slider_getValueByPosition(element, x, y) {
    var clientWidth = element[WIDTH];
    var clientHeight = element[HEIGHT];
    var properties = this.getProperties(element);
    
    if (clientWidth >= clientHeight) {
      var size = clientWidth - this._THUMB_SIZE;
      var pos = x;
    } else {
      size = clientHeight - this._THUMB_SIZE;
      pos = size - y;
    }
    return (properties.max - properties.min) * (pos / size);
  },

  setValueByPosition: function slider_setValueByPosition(element, x, y) {
    this.setValueAsNumber(element, this.getValueByPosition(element, x, y));
  },

  hitTest: function slider_hitTest(element, event) {
    if (element.disabled) return null;
    var offset = this.getOffsetXY(element, event.clientX, event.clientY);
    return control._active == element || this.getThumbRect(element).contains(offset.x, offset.y);
  },

  layout: function slider_layout(element, state) {
    if (state == null) state = this.getState(element);

    var thumb = this.getThumbRect(element);
    var style = element.style;
    var thumbOffset = Math.ceil((this._IMAGE_SIZE - this._THUMB_SIZE) / 2) + state * this._IMAGE_SIZE;

    if (element[HEIGHT] > element[WIDTH]) {
      var left = thumb.left;
      var top = thumb.top - thumbOffset;
    } else {
      left = thumb.left - thumbOffset;
      top = thumb.top;
    }

    var backgroundPosition = left + "px" + " " + top + "px";
    if (style.backgroundPosition !== backgroundPosition) {
      style.backgroundPosition = backgroundPosition;
    }
  }
});
