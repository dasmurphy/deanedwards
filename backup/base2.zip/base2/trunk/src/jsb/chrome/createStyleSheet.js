
var URL = /(url\s*\(\s*['"]?)([\w\.]+[^:\)]*['"]?\))/gi;

var asset_host = base2.info("host");
asset_host = asset_host.replace(/(lib|src)\/$/, "assets/");
  
function createStyleSheet(cssText) {
  cssText = String(cssText)
    .replace(/%theme%/g, "themes/" + theme.name)
    .replace(URL, "$1" + asset_host + "$2");
    
  var style = document.createElement("style");
  head.insertBefore(style, head.firstChild);
  dom.set(style, "textContent", cssText);
  /*@
    // Preserve specificty for MSIE
    var links = dom.querySelectorAll(head, "link,style"), link;
    for (var i = 0; link = links[i]; i++) {
      head.insertBefore(link, link.nextSibling);
    }
  @*/
  return cssText;
}

function compileStyleSheet(rules) {
  var styleSheet = {
    toString: function() {
      var memo = new _.Collection(this).map(function(properties, selector) {
        return selector + properties;
      }).join("\n").replace(/!([^\w])/g, "!important$1");
      this.toString = K(memo);
      return memo;
    }
  };

  var baseRule;

  var createRule = function(properties, selector) {
    if (/,/.test(selector)) {
      forEach (selector.split(/\s*,\s*/), _.partial(createRule, properties));
    } else {
      if (!baseRule) {
        baseRule = selector === "*" ? properties : {};
      }
      if (selector !== "*") {
        var rule = styleSheet[selector];
        if (!rule) {
          rule = styleSheet[selector] = _.extend({toString: function() {
            var memo = " {\n" +
              new _.Collection(this).map(function(value, propertyName) {
                return "  " + propertyName.replace(/[A-Z]/g, "-$&").toLowerCase() + ": " + value;
              }).join(";\n") +
            "\n}\n";
            this.toString = K(memo);
            return memo;
          }}, baseRule);
        }
        forEach_detect (properties, function(value, propertyName) {
          var isFloat = propertyName === "float";
          if (!isFloat && !(propertyName in styleObject)) {
            propertyName = _private.getStylePropertyName(propertyName);
          }
          if (isFloat || propertyName in styleObject) {
            if (value === "initial") {
              forEach (rule, function(initialPropertyValue, initialPropertyName) {
                if (initialPropertyName.indexOf(propertyName) === 0) {
                  delete rule[initialPropertyName];
                }
              });
              delete rule[propertyName];
            } else {
              if (value === "inline-block") value = INLINE_BLOCK;
              rule[propertyName] = value;
            }
          }
        });
      }
    }
  };

  forEach_detect(rules, createRule);

  return styleSheet;
}

function mergeStyleSheets(sheet1, sheet2) {
  for (var selector in sheet2) {
    var rule1 = sheet1[selector];
    var rule2 = sheet2[selector];
    if (rule1) {
      for (var propertyName in rule2) {
        rule1[propertyName] = rule2[propertyName];
      }
    } else {
      sheet1[selector] = rule2;
    }
  }
}
