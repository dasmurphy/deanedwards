
var vertical = {
  allowVertical: false, // weird huh?

  "jsb:onattach": function(element) {
    var className = "jsb-" + this.name;
    var isVertical = element[HEIGHT] > element[WIDTH];
    if (isVertical) {
      this.classList.add(element, className + "-vertical");
      if (this.style.compute(element, "appearance") === this.appearance + "-vertical") {
        element.style.backgroundImage = "none";
        this.detach(element);
      } else {
        this.classList.add(element, className);
        this.style.set(element, "appearance", "none");
        this.base(element);
      }
    } else {
      this.classList.remove(element, className);
      this.detach(element);
    }
    return isVertical;
  },

  "@Opera": {
    "jsb:onattach": function(element) {
      if (this.base(element)) {
        element.value = 0;
      }
    }
  }
};

var vslider      = slider.extend(vertical);
var vprogressbar = progressbar.extend(vertical);
