
var chrome = jsb.chrome = new _.Package({
  name:    "jsb.chrome",
  version: "%%VERSION%%",
  
  theme: theme.name,
  
  // these are for extensibility
  dropdown: dropdown,
  Popup: Popup,
  PopupWindow: PopupWindow,
  MenuList: MenuList,
  ToolTip: ToolTip,

  locale: new Locale(navigator.language || navigator.systemLanguage),

  getBehavior: function getBehavior(element) {
    return _attachments[element.uniqueID] || null;
  },
  
  combobox: combobox,
  progressbar: progressbar,
  slider: slider,
  spinner: spinner,
  colorpicker: colorpicker,
  datepicker: datepicker,
  weekpicker: weekpicker,
  monthpicker: monthpicker,
  timepicker: timepicker
});
