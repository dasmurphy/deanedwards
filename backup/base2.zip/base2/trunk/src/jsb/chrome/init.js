
var USE_BASE2 = !_.detect("\\bOpera\\d");

var cssText = "";

var cssParser = new _.RegGrp;

var controls = {
  range: slider,
  number: spinner
};

var rules = new _.RuleList;

if (_.detect("WebKit")) {
  cssText = "input[type=range]{-webkit-appearance:none}" +
            "input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;display:none}" +
            "input::-webkit-inner-spin-button,input::-webkit-outer-spin-button,input::-webkit-input-list-button{-webkit-appearance:none;display:none}\n\n";
}

var input = document.createElement("input");
forEach.csv("color,range,number,time,date,week,month", function(type) {
  input.setAttribute("type", type);
  register("input[type=" + type + "]", controls[type] || chrome[type + "picker"], !USE_BASE2 && input.type === type);
});

//register("input[list]", combobox, "list" in input &&  _.detect("(<datalist>.options)"));
register("input[list]", combobox, "list" in input);
register("progress", progressbar, _.detect("(<progress>.value)"));

cssText += styleSheet;

if (cssParser.size()) {
  cssText = cssParser.parse(cssText);
}

createStyleSheet(cssText);
styleSheet = null;

/*@if (@_jscript_version == 5.6)
  document.execCommand("BackgroundImageCache", false, true);
/*@end @*/

delete _private.theme;

function register(selector, control, isSupported) {
  var pattern = "\\*?\\.jsb\\-" + control.appearance + "([^-])";
  if (isSupported) {
    cssParser.set(pattern + "[^{]*\\{[^}]+\}\\s*", ""); // remove CSS rules
  } else {
    if (SUPPORTS_ATTRIBUTE_SELECTORS || !/\[/.test(selector)) {
      cssParser.set(pattern, selector + "$1"); // convert class selectors to attribute selectors
    }
    rules.set(selector, control);
    if (jsb.clientWidth2) {
      cssText += selector + "{behavior:url(dimensions.htc)}\n\n";
    }
  }
}
