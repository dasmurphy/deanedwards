
var rules = new _.RuleList;
var supported = {};

(function() {

var isOpera  = _.detect("Opera\\d");
var isWebKit = _.detect("WebKit\\d");

var cssText = "";

var cssParser = new _.RegGrp;

var controls = {
  range: slider,
  number: spinner
};

var input = document.createElement("input");
head.appendChild(input);

function check(type) {
  try {
    input.type = type
  } catch (ex) {}
  var isSupported = isOpera && type !== "color";
  if (!isSupported && input.type === type) {
    isSupported = isOpera || (_private.compute(input, "appearance") || "textfield") !== "textfield";
    if (!isSupported) {
      input.value = ":)"; // Modernizr
      isSupported = input.value !== ":)";
      input.value = "";
    }
  }
  if (isWebKit && !isSupported) {
    cssText += "input[type=" + type + "]::-webkit-inner-spin-button,input[type=" + type + "]::-webkit-outer-spin-button{-webkit-appearance:none;display:none}\n";
  }
  /*@
  isSupported &= type !== "number"; // :(
  @*/
  return isSupported;
}

forEach.csv("color,number,time,date,week,month", function(type) {
  var isSupported = check(type);
  var control = controls[type] || chrome[type + "picker"];
  control.isSupported = isSupported;
  register("[type=" + type + "]", control, isSupported);
  supported[type] = isSupported;
});

head.removeChild(input);

register("[list]", suggest, "list" in input);

if (_.detect("(<progress>.value)")) {
  progressbar.isSupported = true;
  rules.set("progress", vprogressbar);
} else {
  register("progress", progressbar, false);
}

if (check("range") && !isOpera) {
  rules.set("[type=range]", vslider);
} else {
  register("[type=range]", slider, isOpera);
}

rules.set("datalist[id]", {
  "jsb:oncontentready": function(element) {
    getSuggestions(element.id);
  }
});

cssText += "\n" + cssParser.parse(styleSheet);

new jsb.StyleSheet(cssText);

/*@if (@_jscript_version == 5.6)
  document.execCommand("BackgroundImageCache", false, true);
/*@end @*/

delete _private.theme;

function register(selector, control, isSupported) {
  var pattern = "\\*?\\.jsb\\-" + control.appearance + "([^\\w-])";
  if (isSupported) {
    cssParser.set(pattern + "[^{]*\\{[^}]+\}\\s*", ""); // remove CSS rules
  } else {
    if (SUPPORTS_ATTRIBUTE_SELECTORS || !/\[/.test(selector)) {
      cssParser.set(pattern, selector + "$1"); // convert class selectors to attribute selectors
    }
    rules.set(selector, control);
    if (jsb.clientWidth2) {
      cssText += selector + "{behavior:url(dimensions.htc)}\n\n";
    }
  }
}

})();
