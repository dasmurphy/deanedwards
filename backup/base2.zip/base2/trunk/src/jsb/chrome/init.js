
var rules = new _.RuleList;
var supported = {};

(function() {

var isOpera  = _.detect("Opera\\d");
var isWebKit = _.detect("WebKit\\d");

var cssText = "";

var cssParser = new _.RegGrp;

var controls = {
  range: slider,
  number: spinner
};

var input = document.createElement("input");
head.appendChild(input);

forEach.csv("color,range,number,time,date,week,month", function(type) {
  try {
    input.type = type
  } catch (ex) {}
  var isSupported = isOpera && type !== "color";
  if (!isSupported && input.type === type) {
    isSupported = isOpera || (_private.compute(input, "appearance") || "textfield") !== "textfield";
    if (!isSupported) {
      input.value = ":)";
      isSupported = input.value !== ":)";
      input.value = "";
    }
  }
  var control = controls[type] || chrome[type + "picker"];
  register("[type=" + type + "]", control, isSupported);
  if (isWebKit && !isSupported && spinner.ancestorOf(control)) {
    cssText += "input[type=" + type + "]::-webkit-inner-spin-button,input[type=" + type + "]::-webkit-outer-spin-button{-webkit-appearance:none;display:none}\n";
  }
  supported[type] = isSupported;
});

head.removeChild(input);

register("[list]", combobox, "list" in input);
register("progress", progressbar, _.detect("(<progress>.value)"));

cssText += "\n" + cssParser.parse(styleSheet);

new jsb.StyleSheet(cssText);

/*@if (@_jscript_version == 5.6)
  document.execCommand("BackgroundImageCache", false, true);
/*@end @*/

delete _private.theme;

function register(selector, control, isSupported) {
  var pattern = "\\*?\\.jsb\\-" + control.appearance + "([^\\w-])";
  if (isSupported) {
    cssParser.set(pattern + "[^{]*\\{[^}]+\}\\s*", ""); // remove CSS rules
  } else {
    if (SUPPORTS_ATTRIBUTE_SELECTORS || !/\[/.test(selector)) {
      cssParser.set(pattern, selector + "$1"); // convert class selectors to attribute selectors
    }
    rules.set(selector, control);
    if (jsb.clientWidth2) {
      cssText += selector + "{behavior:url(dimensions.htc)}\n\n";
    }
  }
}

})();
