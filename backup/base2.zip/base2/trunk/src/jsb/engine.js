
var rulesByTagName = {};

var engine = {
  addRule: function addRule(rule) {
    if (!rule._activity) {
      engine._faster = true;
      var tagName = rule._tagName;
      rule._activity = rule._isActive ? -1 : engine._ticking ? 2 : 1;
      if (!rulesByTagName[tagName]) {
        rulesByTagName[tagName] = rulesByTagName[tagName.toUpperCase()] = [];
      }
      rulesByTagName[tagName].push(rule);
      if (!engine._started) engine.start();
    }
  },

  start: function start() {
    engine._started = true;
    setTimeout(function(){engine.tick()}, 4); // start the timer
  },

  tick: function tick(nextElement) {
    if (document.body) {
      engine._ticking = true;
      
      nextElement = nextElement || document.documentElement;

      var element, lastElement;
      var start = _.now(), k = 0;

      while ((element = nextElement)) {
        var checkTime = false;
        
        if (element.nodeType === 1) {
          for (var i = 0; i < 2; i++) {
            var rules = rulesByTagName[i ? element.nodeName : "*"], rule;
            if (rules) for (var j = 0; rule = rules[j]; j++) {
              if (!rule._attached[element.uniqueID]) { // not already attached
                var behavior = rule._behavior;
                if (rule.id) {
                  if (rule.id === element.id && (rule._isWildCard || rule._matches.call(element, rule._selector))) {
                    rules.splice(j, 1); // remove the rule
                    checkTime = true;
                    _attachedByRuleEngine_ = true;
                    behavior.attach(element);
                  }
                } else if (rule._isWildCard || ((rule._hasNoClassSelector || element.className) && rule._matches.call(element, rule._selector))) {
                  checkTime = true;
                  _attachedByRuleEngine_ = true;
                  behavior.attach(element);
                }
              }
            }
          }
        }

        nextElement = element.firstChild || element.nextSibling;

        while (!nextElement && (element = element.parentNode)) {
          if (contentReadyCount) {
            var uniqueID = element.uniqueID;
            if (uniqueID && contentReadyQueue[uniqueID]) {
              delete contentReadyQueue[uniqueID];
              contentReadyCount--;
              checkTime = true;
              fire(element, "jsb:contentready", JSB_EVENT_DATA);
            }
          }
          nextElement = element.nextSibling;
        }
        
        lastElement = nextElement || lastElement;

        checkTime |= k++ % 200 === 0; // check the time every 200 elements unless something interesting happened.
        if (checkTime && _.now() - start > CONST_TIMEOUT) break;
      }
    }
    
    if (!_private.isReady || nextElement) {
      var callback = function(){engine.tick(lastElement)};
    } else {
      delete engine._ticking;
      callback = engine.end;
    }
    setTimeout(callback, engine._faster ? CONST_INTERVAL / 2 : CONST_INTERVAL);
  },

  end: function end() {
    delete engine._faster;
    engine._ready = true;
    var queue = documentReadyQueue.reverse();
    documentReadyQueue = [];
    chunk(queue, function _fireDocumentReady(element) {
      fire(element, "jsb:documentready", JSB_EVENT_DATA);
    }, function oncomplete() {
      delete engine._started;
      var hasActiveRules = false;
      forEach (rulesByTagName, function(rules, tagName) {
        rules = _.filter(rules, byActivity);
        if (rules.length === 0) {
          delete rulesByTagName[tagName];
        } else {
          rulesByTagName[tagName] = rules;
          hasActiveRules = true;
        }
      });
      if (hasActiveRules) engine.start();
    });
  }
};

// help

function byActivity(rule) {
  if (rule._activity > 0) rule._activity--;
  return rule._activity !== 0;
}
