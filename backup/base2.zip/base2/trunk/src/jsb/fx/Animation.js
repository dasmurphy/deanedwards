
Animation = _.Base.extend({
  constructor: function Animation__constructor(object, params, styleElement) {
    params = params || {};
    
    var transitions = {};
    var defaultDelay = params.delay || 0;
    var defaultDuration = params.duration || 1000;
    var defaultTimingFunction = params.timingFunction || "ease";

    function createTransition(transition, propertyName) { // recurse after we've broken down shorthand properties
      if (DEFAULT_PROPERTIES.test(propertyName)) return;
      
      // If the transition is a string then it defines the end point
      // of the transition only.
      if (typeof transition == "object") {
        transition = qcopy(transition);
      } else {
        transition = {end: String(transition)};
      }
      transition.styleElement = styleElement;
      if (transition.delay == null) {
        transition.delay = defaultDelay;
      }
      if (transition.duration == null) {
        transition.duration = defaultDuration;
      }
      if (transition.timingFunction == null) {
        transition.timingFunction = defaultTimingFunction;
      }

      // Break shorthand properties into the longhand version.
      // This only parses property names. Values are parsed in Transition.js.
      // Some shorthand properties cannot be parsed.
      // (I may fix backgroundPosition eventually).
      if (/^(font|background(Position)?)$/.test(propertyName)) {
        throw new SyntaxError("Cannot animate shorthand property '" + propertyName + "'.");
      } else if (/^border(Top|Right|Bottom|Left)?$/.test(propertyName)) { // shorthand border properties
        var property = propertyName;
        var start = _split(transition.start);
        var end = _split(transition.end);
        var names = ["Width", "Style", "Color"];
        // recurse after we've broken down shorthand properties
        forEach (end, function(end, i) {
          var params = qcopy(transition);
          params.start = start[i];
          params.end = end;
          createTransition(params, property + names[i]);
        });
      } else if (/^(margin|padding|border(Width|Color|Style))$/.test(propertyName)) { // shorthand rect properties (T,R,B,L)
        var property = propertyName.replace(/Width|Color|Style/, "");
        var name = propertyName.replace(property, "");
        start = _split(transition.start, true);
        end = _split(transition.end, true);
        forEach.csv("Top,Right,Bottom,Left", function(side, i) {
          var params = qcopy(transition);
          params.start = start[i];
          params.end = end[i];
          transitions[property + side + name] = params;
        });
      } else {
        transitions[propertyName] = transition;
      }
    };
    
    forEach (params, createTransition);
    
    forEach (transitions, function(params, propertyName) {
      transitionQueue.add(object, propertyName, params);
    });
  }
});
