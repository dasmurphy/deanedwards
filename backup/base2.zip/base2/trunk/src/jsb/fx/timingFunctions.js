
var cubizBezier = _.memoize(function cubizBezier(x1, y1, x2, y2) {
  // Based on https://github.com/rdallasgray/bez/

  var timingFunction = function timingFunction(t, b, c, d) {
    var C = 3 * x1;
    var B = 3 * (x2 - x1) - C;
    var A = 1 - C - B;
    var x = (t /= d), z;
    var i = 0;
    while (++i < 14) {
      z = (x * (C + x * (B + x * A))) - t;
      if (z === 0 || (z > 0 && z < 1e-3) || (z < 0 && z > -1e-3)) break;
      x -= z / (C + x * (2 * B + 3 * A * x));
    }
    C = 3 * y1;
    B = 3 * (y2 - y1) - C;
    A = 1 - C - B;
    return c * (x * (C + x * (B + x * A))) + b;
  };
  ;;; timingFunction.toString = _.K("cubic-bezier(" + [x1, y1, x2, y2].join(",") + ")");
  return timingFunction;
});

var timingFunctions = {
  "bounce": function bounce(t, b, c, d) {
    if ((t /= d) < (1 / 2.75)) {
      return c * (7.5625 * t * t) + b;
    } else if (t < (2 / 2.75)) {
      return c * (7.5625 * (t-=(1.5/2.75)) * t + .75) + b;
    } else if (t < (2.5 / 2.75)) {
      return c * (7.5625 * (t-=(2.25/2.75)) * t + .9375) + b;
    } else {
      return c * (7.5625 * (t-=(2.625/2.75)) * t + .984375) + b;
    }
  },

  "ease": cubizBezier(0.25, 0.1, 0.25, 1),
  "ease-in": cubizBezier(0.42, 0, 1, 1),
  "ease-out": cubizBezier(0, 0, 0.58, 1),
  "ease-in-out": cubizBezier(0.42, 0, 0.58, 1),

  "linear": function linear(t, b, c, d) {
    return c*t/d + b;
  }
};
