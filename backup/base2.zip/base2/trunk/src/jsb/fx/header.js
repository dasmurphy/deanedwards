
var fx, Animation;

(function(){ // begin: closure

var CONST_INTERVAL  = 16; // 60 fps
var CONST_PRECISION = 1000;

var CUBIC_BEZIER = /^cubic\-bezier\([\.\d]+,[\.\d]+,[\.\d]+,[\.\d]+\)$/;

var NON_NEGATIVE = /((^w|W)idth|(^h|H)eight|Radius|^(opacity|fontSize))$/;

var DEFAULT_PROPERTIES = /^(delay|duration|timingFunction)$/;

var DIGITS = /\d+/g;

var parseInt16 = _.partial(parseInt, undefined, 16);

var styleObject = domElement.style;

var computeStyle = dom.style.compute;
var getStyle = dom.style.get;
var setStyle = dom.style.set;

// polyfill (for when it doesn't suck)
// var requestAnimationFrame = _private.get(window, "requestAnimationFrame") ||
function requestAnimationFrame(callback) {
  setTimeout(callback, 1, null);
};

function _split(value, fill) { // used for splitting multiple CSS values
  if (value == null) return [];
  value = _.trim(value).split(/\s+/);
  if (fill) {
    if (value.length === 1) value[1] = value[0];
    if (value.length === 2) value[2] = value[0];
    if (value.length === 3) value[3] = value[1];
  }
  return value;
}

function getTransitionKey(object, propertyName, params) {
  var target = params.styleElement || object;
  var key = _.assignID(target);
  if (params.styleElement) key += ".style";
  return key + "." + propertyName;
}

function parseTime(time) {
  return +String(time).replace(/(m)?s$/, function($, ms) {
    return ms ? "" : "000";
  });
}

var colorElement;

var parseColor = _.memoize(function parseColor(color) { // return an array of rgb values
  if (color.indexOf("rgb(") === 0) {
    var rgb = _.map(color.match(/\d+%?/g), function(value) {
      return /%/.test(value) ? Math.round(2.55 * value.slice(0, -1)) : ~~value;
    });
  } else if (color.indexOf("#") === 0) {
    var hex = color.slice(1);
    if (hex.length === 3) hex = hex.replace(/([0-9a-f])/gi, "$1$1");
    rgb = _.map(hex.match(/([0-9a-f]{2})/gi), parseInt16);
  } else {
    // If it's a named colour then use getComputedStyle to parse it.
    // Meh. It's ugly but it's less code than a table of colour names.
    var computedColor;
    var body = document.body || document.documentElement;
    if (!colorElement) {
      colorElement = document.createElement("input");
      setStyle(colorElement, {
        position: "absolute",
        left: "-9999px"
      });
    }
    body.appendChild(colorElement);
    try {
      colorElement.style.color = color;
      if ((colorElement.style.color)) {
        computedColor = computeStyle(colorElement, "color");
      }
    } catch (ex) {}
    body.removeChild(colorElement);
    if (computedColor && computedColor != color) {
      rgb = parseColor(computedColor);
    }
  }
  if (!_.isArray(rgb) || rgb.length !== 3) {
    throw new TypeError("Invalid color: '" + color + "'.");
  }
  return rgb;
});

var cachedColors = parseColor.cache;
