
// Special parsing of colours and "clip" are bulking this out. :-(

var Transition = _.Base.extend({
  constructor: function Transition__constructor(key, object, propertyName, params) {
    _.extend(this, params);

    this.toString = _.K(key);
    
    this.propertyName = propertyName;
    
    var styleElement = this.styleElement;
    var timestamp = 0;
    var reversed = false;
    var started = 0;
    var paused = 0;
    var speed = 1;
    var elapsedTime = 0;

    var delay = this.delay;
    if (typeof delay != "number") {
      delay = parseTime(delay);
    }

    var duration = this.duration;
    if (typeof duration != "number") {
      duration = parseTime(duration);
    }
    
    var ease = this.timingFunction;
    if (!_.isFunction(ease)) {
      ease = timingFunctions[ease];
      if (!ease) {
        ease = String(this.timingFunction).replace(/\s+/g, "");
        if (CUBIC_BEZIER.test(ease)) {
          ease = cubizBezier.apply(null, ease.slice(13, -1).split(","));
        }
      }
    }
    if (!_.isFunction(ease)) throw new TypeError("Invalid timing function.");

    if (this.start == null) {
      this.start = object[propertyName] || (styleElement ? computeStyle(styleElement, propertyName) : null);
    }
    
    var typeValue = this.end;
    if (styleElement && typeValue === "auto") {
      var value = getStyle(styleElement, propertyName);
      setStyle(styleElement, propertyName, "");
      this.end = computeStyle(styleElement, propertyName);
      setStyle(styleElement, propertyName, value);
    }
    
    // Parse the start/end values and create the easing function.
    if (/[cC]olor$/.test(propertyName)) {
      var startValue = cachedColors[this.start] || parseColor(this.start);
      var endValue = cachedColors[this.end] || parseColor(this.end);
      var delta = _.map(startValue, function(value, i) {
        return endValue[i] - value;
      });
      var calculateValue = function calculateValue_color(t) {
        return "rgb(" + _.map(startValue, function(startValue, i) {
          var value = Math.round(ease(t, startValue, delta[i], duration));
          if (value < 0) value = 0; else if (value > 255) value = 255;
          return value;
        }).join(", ") + ")";
      };
    } else if (styleElement && propertyName === "clip") {
      startValue = _.map(match(this.start, DIGITS), Number);
      endValue = _.map(match(this.end, DIGITS), Number);
      delta = _.map(startValue, function(value, i) {
        return endValue[i] - value;
      });
      calculateValue = function calculateValue_clip(t) {
        return "rect(" + _.map(startValue, function(value, i) {
          return Math.round(ease(t, value, delta[i], duration));
        }).join("px, ") + "px)";
      };
    } else if (this.end === "" || /^\-?\.?\d/.test(this.end)) { // Numeric.
      if (styleElement) {
        if (this.start != null) {
          setStyle(styleElement, propertyName, this.start);
        }
        startValue = parseInt(computeStyle(styleElement, propertyName));
        setStyle(styleElement, propertyName, this.end);
        endValue = parseInt(computeStyle(styleElement, propertyName));
        setStyle(styleElement, propertyName, startValue + "px");
      } else {
        endValue = Number(this.end);
        startValue = Number(this.start);
      }
      delta = endValue - startValue;
      var nonNegative = NON_NEGATIVE.test(propertyName);
      calculateValue = function calculateValue_number(t) {
        var value = Math.floor(ease(t, startValue, delta, duration) * CONST_PRECISION) / CONST_PRECISION;
        value = (nonNegative && value < 0 ? 0 : Math.round(value)) + "px";
        return value;
      };
    } else {
      endValue = this.end || "";
      calculateValue = function calculateValue_binary(t) { // flip only at the end
        return ease(t, 0, 1, duration) < 1 ? startValue : endValue;
      };
    }
    
    this.tick = function Transition__tick(now) {
      if (!timestamp) timestamp = now;
      if (!this.complete && !paused) {
        elapsedTime = now - timestamp;
        if (!started && elapsedTime >= delay) {
          started = now;
        }
        if (started) {
          elapsedTime = Math.round(Math.min((now - started) * speed, duration));

          this.complete = elapsedTime >= duration;

          if (this.complete) {
            var value = this.end;
          } else {
            var t = reversed ? duration - elapsedTime : elapsedTime;
            value = calculateValue(t);
          }

          if (styleElement && !(propertyName in styleObject)) {
            setStyle(styleElement, propertyName, value);
          } else {
            object[propertyName] = value;
          }
          
          if (this.complete) {
            this.elapsedTime = (now - timestamp) / 1000;
          }
        }
      }
    };

    this.reverse = function Transition__reverse() {
      var start = this.start;
      this.start = this.end;
      this.end = start;
      this.complete = false;
      reversed = !reversed;
      if (started) {
        started = _.now() - (duration - elapsedTime) / speed;
      }
    };

    /*this.stop = function() {
      speed = 1;
      paused = 0;
      complete = true;
    };

    this.pause = function() {
      paused = _.now();
    };

    this.resume = function() {
      started += _.now() - paused;
      paused = 0;
    };*/

    this.setSpeed = function Transition__setSpeed(s) {
      speed = s;
      if (started) {
        started = _.now() - elapsedTime / speed;
      }
    };

    this.accelerate = function Transition__accelerate(rate) {
      this.setSpeed(speed * rate);
    };
  },

  complete: false,
  delay: 0,
  duration: 1, // seconds
  timingFunction: "ease",
  start: null,
  end: null,

  compare: function Transition__compare(value, position) {
    if (/[cC]olor$/.test(this.propertyName)) {
      var color1 = cachedColors[this[position]] || parseColor(this[position]);
      var color2 = cachedColors[value] || parseColor(value);
      return color1[0] === color2[0] && color1[1] === color2[1] && color1[2] === color2[2];
    } else if (this.propertyName === "clip") {
      // Stoopid incompatible clip rects:
      // http://www.ibloomstudios.com/articles/misunderstood_css_clip/
      var COMMAS = /,\s+/g;
      return this[position].replace(COMMAS, ",") === value.replace(COMMAS, ",");
    }
    return this[position] == value;
  }
});
