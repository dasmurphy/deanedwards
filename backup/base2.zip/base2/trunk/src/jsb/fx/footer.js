
var transitionQueue = new TransitionQueue;

})(); // end: closure
