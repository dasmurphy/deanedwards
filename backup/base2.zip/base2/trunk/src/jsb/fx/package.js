
fx = new _.Package({
  name:    "jsb.fx",
  version: "%%VERSION%%",
  
  timingFunctions: timingFunctions,

  animate: function fx_animate(object, transitions) {
    if (arguments.length < 2) throw new ArityError("fx.animate");
    if (object == null) throw new TargetError(JSB_TYPE_ERR, "fx.animate");

    new Animation(object, transitions);
  }
});
