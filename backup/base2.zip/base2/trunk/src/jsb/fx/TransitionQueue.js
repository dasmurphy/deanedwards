
var TransitionQueue = _.Collection.extend({
  constructor: function TransitionQueue__constructor(transitions) {
    this.base(transitions);
    this.tick = _.bind(this.tick, this);
  },
  
  add: function TransitionQueue__add(object, propertyName, params) {
    var key = getTransitionKey(object, propertyName, params);
    var transition = this.get(key);
    if (transition) {
      if (transition.duration != params.duration) {
        transition.setSpeed(transition.duration / (params.duration || 1)); // change gears
        if (transition.compare(params.end, "end")) {
          return transition;
        }
      }
      if (transition.compare(params.end, "start")) { // flipped start/end points indicate the reversal of a transition
        transition.reverse();
        return transition;
      }
    }
    transition = this.set(key, object, propertyName, params);
    if (!this._started) {
      this._started = true;
      requestAnimationFrame(this.tick);
    }
    return transition;
  },

  tick: function TransitionQueue__tick() {
    this.invoke("tick", _.now());

    var complete = this.filter(function(transition) {
      return transition.complete;
    });

    if (complete.size() > 0) {
      complete.forEach(this.remove, this);

      setTimeout(function() {
        complete.forEach(function(transition) {
          var element = transition.styleElement;
          if (element) {
            delete transition.styleElement;
            fire(element, "jsb:transitionend", {
              bubbles: true,
              propertyName: transition.propertyName,
              elapsedTime: transition.elapsedTime
            });
          }
        });
      }, 4);
    }

    if (this.size() > 0) {
      requestAnimationFrame(this.tick);
    } else {
      delete this._started;
    }
  }
}, {
  Item: Transition
});
