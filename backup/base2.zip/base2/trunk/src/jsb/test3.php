<!doctype html>
<title>JSB: Test Page</title>
<meta charset="utf-8">
<script src="/base2/trunk/src/console2.js"></script>
<script src="/base2/trunk/src/base2-jsb.js"></script>

<script>
new jsb.Rule("#example", {
  "jsb:onattach": function(element, event) {
    console2.log(event.type + ": " + event.timeStamp);
  },

  onmouseenter: function(element) { // start the animation
    this.animate(element, {
      width: "600px",
      backgroundColor: "blue",
      borderColor: "yellow",
      timingFunction: "linear",
      duration: 2000
    });
  },

  onmouseleave: function(element) { // reverse the animation
    this.animate(element, {
      width: "200px",
      backgroundColor: "red",
      borderColor: "lime",
      timingFunction: "linear",
      duration: 250
    });
  },

  onclick: function(element) {  // accelerate the animation
    this.animate(element, {
      width: "600px",
      backgroundColor: "blue",
      borderColor: "yellow",
      timingFunction: "linear",
      duration: 500
    });
  },

  "jsb:ontransitionend": function(element, event) {
    console2.log(event.type + ": " + event.propertyName);
  }
});
</script>

<style>
#example {
  background: red;
  border: 10px solid lime;
  padding: 50px;
  width: 200px;
  color: white;
  font-weight: bold;
  cursor: default;
}
#example p {
  background: white;
  color: red;
  width: 80px;
  padding: 5px;
}
</style>

<h1>JSB: Animation Test Page</h1>

<div id="example"><p>Hover to start the animation, click to accelerate.</p></div>
