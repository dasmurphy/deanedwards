
var SUPPORTS_USER_DATA = _.detect("(element.getUserData('')===null)");

if (typeof WeakMap == "undefined") {
  var userData = {
    get: function(element) {
      var key = element.uniqueID || _.assignID(element);
      return this[key];
    },

    set: function(element, value) {
      var key = element.uniqueID || _.assignID(element);
      this[key] = value;
    },

    "delete": function(element) {
      var key = element.uniqueID || _.assignID(element);
      delete this[key];
    }
  };
} else {
  userData = new WeakMap;
}

function getUserData(element, key) {
  if (arguments.length < 2) {
    throw TypeError(Arity("getUserData", this));
  }
  if (!element || element.nodeType !== 1) {
    throw TypeError(Target(JSB_TYPE_ERR, "getUserData", this));
  }

  if (SUPPORTS_USER_DATA) {
    return element.getUserData("jsb:" + key);
  }

  var data = userData.get(element);

  return data && key in data ? data[key] : null;
}

function setUserData(element, key, value) {
  if (arguments.length < 3) {
    throw TypeError(Arity("setUserData"));
  }
  if (!element || element.nodeType !== 1) {
    throw TypeError(Target(JSB_TYPE_ERR, "setUserData"));
  }

  if (SUPPORTS_USER_DATA) {
    element.setUserData("jsb:" + key, value, null);
    return;
  }

  var data = userData.get(element);

  if (value === null) {
    if (data) {
      delete data[key];
      for (var i in data) return;
      userData["delete"](element);
    }
  } else {
    if (!data) {
      userData.set(element, data = {});
    }
    data[key] = value;
  }
}
