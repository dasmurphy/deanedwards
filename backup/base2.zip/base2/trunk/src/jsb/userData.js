
var SUPPORTS_USER_DATA = _.detect("(element.getUserData('')==null)");

var userData = {};

function getUserData(element, key) {
  if (arguments.length < 2) throw new ArityError("getUserData");
  if (!element || element.nodeType !== 1) throw new TargetError(JSB_TYPE_ERR, "getUserData");
  
  if (SUPPORTS_USER_DATA) return element.getUserData("jsb:" + key);
  
  key = (element.uniqueID || _.assignID(element)) + "." + key;
  
  return key in userData ? userData[key] : null;
}
  
function setUserData(element, key, value) {
  if (arguments.length < 3) throw new ArityError("setUserData");
  if (!element || element.nodeType !== 1) throw new TargetError(JSB_TYPE_ERR, "setUserData");

  if (SUPPORTS_USER_DATA) return element.setUserData("jsb:" + key, value, null);

  key = (element.uniqueID || _.assignID(element)) + "." + key;
  
  var returnValue = key in userData ? userData[key] : null;
  
  if (value === null) {
    delete userData[key];
  } else {
    userData[key] = value;
  }
    
  return returnValue;
}
