
var template = element.extend({
  "jsb:onattach": function onattach(element) {
    this.setAttribute(element, "data-repeat", "template");
    
    var min   = this.get(element, "repeatMin");
    var start = this.get(element, "repeatStart");
    
    var i = 0;
    
    while (i++ < start) {
      this.addRepetitionBlock(element, null);
    }

    i = this.get(element, "repetitionBlocks").length;
    
    while (i++ < min) {
      this.addRepetitionBlock(element, null);
    }
  },

  onadded: dispatchBlocksModifiedEvent,
  onmoved: dispatchBlocksModifiedEvent,
  onremoved: dispatchBlocksModifiedEvent
});
