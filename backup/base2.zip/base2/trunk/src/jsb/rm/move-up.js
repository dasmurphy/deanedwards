
var moveup = move.extend({
  RELATIVE_NODE:  PREVIOUS_SIBLING,
  DIRECTION:      -1
});
