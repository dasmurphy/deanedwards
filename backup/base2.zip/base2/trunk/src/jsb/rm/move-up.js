
var moveup = move.extend({
  name: "rm.moveup",

  RELATIVE_NODE:  PREVIOUS_SIBLING,
  DIRECTION:      -1
});
