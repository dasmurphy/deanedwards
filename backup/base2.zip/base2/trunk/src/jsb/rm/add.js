
var add = button.extend({
  name: "rm.add",

  "jsb:onattach": function onattach(element) {
    if (this.hasAttribute(element, "data-template")) {
      var template = this.get(element, "htmlTemplate");
    } else {
      var block = this.getBlock(element);
      if (block) {
        template = this.get(block, "repetitionTemplate");
      }
    }
    if (template) {
      rm.template.attach(template);
    }
    element.disabled = !template;
  },

  ":onclick": function onclick(element, event) {
    event.preventDefault(); // prevent submit

    if (this.hasAttribute(element, "data-template")) {
      var template = this.get(element, "htmlTemplate");
      var block = null;
    } else {
      block = this.getBlock(element);
      if (block) {
        template = this.get(block, "repetitionTemplate");
      }
    }
    if (template) {
      this.addRepetitionBlock(template, block);
    }
  }
});
