
var move = button.extend({
  "jsb:onattach": function onattach(element) {
    var self = this;
    function setDisabled() {
      var block = self.getBlock(element);
      while (block && (block = block[self.RELATIVE_NODE]) && !self.isBlock(block)) {
        continue;
      }
      element.disabled = !block;
    }
    var block = this.getBlock(element);
    if (block) {
      this.addEventListener(block.parentNode, "rmBlocksModified", setDisabled);
    }
    setDisabled();
  },

  onclick: function onclick(element, event) {
    event.preventDefault(); // prevent submit
    var block = this.getBlock(element);
    if (block) {
      this.moveRepetitionBlock(block, this.DIRECTION);
    }
  }
});
