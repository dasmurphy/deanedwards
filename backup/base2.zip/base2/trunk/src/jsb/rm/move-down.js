
var movedown = move.extend({
  name: "rm.movedown",

  RELATIVE_NODE:  NEXT_SIBLING,
  DIRECTION:      1
});
