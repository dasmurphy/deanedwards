
var button = element.extend({
  name: "rm.button",

  get_htmlTemplate: function get_htmlTemplate(element) {
    var id = this.getAttribute(element, "data-template");
    var template = document.getElementById(id);
    if (template && this.isTemplate(template)) {
      return template;
    }
    return null;
  },

  getBlock: function(element) {
    var block = element;

    while (block && !this.isBlock(block)) {
      block = block.parentNode;
    }
    return block;
  }
});
