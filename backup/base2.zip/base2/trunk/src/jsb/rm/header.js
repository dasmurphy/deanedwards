
// http://www.w3.org/Submission/web-forms2/#repeatingFormControls

var window = self.window;
var document = window.document;
var TypeError = window.TypeError;

var REPETITION_NONE     = 0;
var REPETITION_TEMPLATE = 1;
var REPETITION_BLOCK    = 2;

var FIX_MSIE_BROKEN_TAG = /(<\/?):/g;
var IGNORE_NAME         = /[\[\u02d1\u00b7\]]/;
var MAX_VALUE           = Math.pow(2, 32) - 1;
var SAFE_NAME           = /([\/(){}|*+-.,^$?\\])/g;

if (_.detect("(element.firstElementChild)")) {
  var FIRST_CHILD = "firstElementChild";
  var PREVIOUS_SIBLING = "previousElementSibling";
  var NEXT_SIBLING = "nextElementSibling";
} else {
  FIRST_CHILD = "firstChild";
  PREVIOUS_SIBLING = "previousSibling";
  NEXT_SIBLING = "nextSibling";
}

function dispatchTemplateEvent(templateElement, type, affectedElement) {
  return template.fire(templateElement, "rm:" + type, {element: affectedElement});
}
