
// A CSS selector associated with a behavior.

var Rule = _.Base.extend({
  constructor: function Rule__constructor(selector, behavior) {
    if (!isValidSelector(selector)) throw new SyntaxError("Invalid selector: " + selector);
    if (behavior == null) throw new TypeError("Invalid object.");
    
    if (typeof behavior == "string") { // external resource
      var resource = behavior;
      behavior = {
        attach: function(element) {
          _.base2.require(resource, function(_, behavior) {
            _.plant(metaRules, "attach", behavior.attach);
            behavior.attach(element);
          });
        }
      };
      behavior.attach._meta = {};
    } else if (behavior instanceof Modification) {
      behavior._registerSelector(selector);
    } else {
      behavior = toBehavior(behavior);
    }
    
    // Split comma separated selectors and create meta information.
    var metaRules = _.map(CSSSelectorParser.split(selector), createMetaRule, this);
    _.plant(metaRules, "attach", behavior.attach);

    this.refresh = function Rule__refresh() {
      forEach (metaRules, engine.addRule);
    };

    this.toString = _.K(String(selector));
    
    this.refresh();
  },
  
  // defined in the constructor function
  refresh: _.Undefined
});

var ActiveRule = Rule.extend();

// help

function createMetaRule(selector) {
  var parsed = parser.exec(" " + CSSSelectorParser.escape(selector));
  var tagName = parsed[2].toLowerCase();
  var id = parsed[3];
  if (id) id = hexUnescape(id.slice(1));
  var filter = parsed[4];
  parsed[2] = "*";
  parsed[3] = "";
  selector = CSSSelectorParser.unescape(parsed.slice(1).join("").slice(1));
  var isWildCard = "*" === selector;
  return {
    id: id,
    tagName: tagName,
    selector: selector,
    isWildCard: isWildCard,
    hasNoClassSelector: !filter || filter.replace(/\\./g, "").indexOf(".") === -1,
    match: isWildCard ? _.True : matches || _private.createMatcher(selector),
    isActive: this instanceof ActiveRule
  };
}
