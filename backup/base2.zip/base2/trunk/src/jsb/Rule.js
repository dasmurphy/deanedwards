
// A CSS selector associated with a behavior.

var Rule = _.Base.extend({
  constructor: function Rule__constructor(selector, behavior) {
    if (!isValidSelector(selector)) throw new SyntaxError("Invalid selector: " + selector);
    
    if (typeof behavior == "string") { // external resource
      behavior = {
        attach: function(element) {
          _.base2.require(behavior, function(_, behavior) {
            behavior.attach(element);
          });
        }
      };
    } else {
      behavior = toBehavior(behavior);
    }

    // Create meta information.
    var metaRules = _.map(CSSSelectorParser.split(selector), createMetaRule, behavior);

    this.refresh = function Rule__refresh() {
      forEach (metaRules, engine.addRule);
    };

    this.toString = _.K(String(selector));
    
    this.refresh();
  },
  
  // defined in the constructor function
  refresh: _.Undefined
});

// help

function createMetaRule(selector) {
  var parsed = parser.exec(" " + CSSSelectorParser.escape(selector));
  var tagName = parsed[2].toLowerCase();
  var id = parsed[3];
  if (id) id = hexUnescape(id.slice(1));
  var filter = parsed[4];
  parsed[2] = "*";
  parsed[3] = "";
  selector = CSSSelectorParser.unescape(parsed.slice(1).join("").slice(1));
  var isWildCard = "*" === selector;
  return {
    id: id,
    tagName: tagName,
    selector: selector,
    isWildCard: isWildCard,
    hasNoClassSelector: !filter || filter.replace(/\\./g, "").indexOf(".") === -1,
    matches: isWildCard ? _.True : matches || _private.createMatcher(selector),
    behavior: this,
    attached: metaBehaviors[this.toString("id")]
    ///isActive: this instanceof ActiveRule
  };
}
