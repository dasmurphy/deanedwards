
// A CSS selector associated with a behavior.

var Rule = _.Base.extend({
  constructor: function Rule__constructor(selector, behavior) {
    if (!cssParser.validate(selector)) {
      throw new SyntaxError("Invalid selector: " + selector);
    }
    
    if (typeof behavior == "string") { // external resource
      var resource = behavior, queue;
      behavior = {
        constructor: _.K({}),
        attach: function(element) {
          if (queue) {
            queue.push(element);
          } else {
            queue = [element];
            _.base2.require(resource, function(_, resource) {
              behavior = resource;
              _.plant(metaRules, "_attached", behavior.constructor(SECRET));
              _.plant(metaRules, "_behavior", behavior);
              _attachedByRuleEngine_ = false;
              chunk(queue, behavior.attach);
              queue = null;
            });
          }
        }
      };
    } else if (!(behavior instanceof Modification)) {
      behavior = toBehavior(behavior);
    }

    // Create meta information.
    var metaRules = _.map(cssParser.split(selector), createMetaRule, behavior);

    function Rule__refresh() {
      forEach (metaRules, engine.addRule);
    }

    if (/*@ this.valueOf && @*/ this instanceof Rule) {
      this.apply = function Rule__apply(node) {
        var elements = dom.findAll(node || document, selector);
        chunk(elements, behavior.attach);
      };

      this.refresh = Rule__refresh;

      this.toString = _.K(String(selector));
    }

    Rule__refresh();
  },
  
  // defined in the constructor function
  apply: _.Undefined,
  refresh: _.Undefined
});

function createMetaRule(selector) {
  var parsed = cssParser.exec(" " + cssParser.escape(selector));
  var tagName = parsed[2].toLowerCase();
  var id = parsed[3];
  if (id) id = hexUnescape(id.slice(1));
  var filter = parsed[4];
  parsed[2] = "*";
  parsed[3] = "";
  selector = cssParser.unescape(parsed.slice(1).join("").slice(1));
  var isWildCard = "*" === selector;
  return {
    id: id,
    _tagName: tagName,
    _selector: selector,
    _isWildCard: isWildCard,
    _hasNoClassSelector: !filter || filter.replace(/\\./g, "").indexOf(".") === -1,
    _matches: isWildCard ? _.True : matches || _private.createMatcher(selector),
    _behavior: this,
    _attached: this.constructor(SECRET)
  };
}
