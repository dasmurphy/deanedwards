
var pageview = jsb.element.extend({
  // locale
  PAGE_NEXT: "Next page",
  PAGE_PREV: "Previous page",
  PAGE_GOTO: "Page {page}",

  // event handlers

  "jsb:onattach": function(element) {
    this.classList.add(element, "pageview-enabled");
  },

  "jsb:oncontentready": function(element) {
    this.classList.remove(element, "pageview-enabled");
    var pages = this.get(element, "pages");
    this.classList.add(pages[0], "page-selected");
    this.setUserData(element, "pageIndex", 0);
    this._createScrollArea(element);
    this._createControls(element);
    this[":onresize"](element);
    this.classList.add(element, "pageview-enabled");
  },

  "document:onkeydown": function(element, event) {
    if (this._scrolling || "form" in event.target) return; // Allow arrow keys to work in form fields

    switch (event.keyCode) {
      case 33: // page-up
      case 37: // left-arrow
        this.scrollBack(element);
        event.preventDefault();
        break;

      case 34: // page-down
      case 39: // right-arrow
        this.scrollForward(element);
        event.preventDefault();
        break;

      case 35: // end
        var pages = this.get(element, "pages");
        var lastIndex = pages.length - 1;
        var pageIndex = this.get(element, "pageIndex");
        if (pageIndex !== lastIndex) {
          this.scrollToPage(element, lastIndex);
        }
        event.preventDefault();
        break;

      case 36: // home
        var pageIndex = this.get(element, "pageIndex");
        if (pageIndex !== 0) {
          this.scrollToPage(element, 0);
        }
        event.preventDefault();
        break;
    }
  },

  ":onclick": {
    ".pageview-progress-marker": function(element, event) {
      event.preventDefault();
      var markers = this.findAll(element, ".pageview-progress-marker");
      var index = markers.indexOf(event.target);
      this.scrollToPage(element, index);
    },

    ".pageview-back": function(element, event) {
      event.preventDefault();
      this.scrollBack(element);
    },

    ".pageview-forward": function(element, event) {
      event.preventDefault();
      this.scrollForward(element);
    }
  },

  ":onmouseover": {
    ":scope": function(element, event) {
      var controls = this.find(element, ".pageview-controls");
      this.classList.remove(controls, "pageview-controls-zoom");
    },

    ".pageview-controls": function(element, event) {
      var controls = this.find(element, ".pageview-controls");
      this.classList.add(controls, "pageview-controls-zoom");
    }
  },

  ":onresize": function(element) {
    var pages = this.get(element, "pages");
    var scrollArea = this.find(element, ">.pageview-scrollarea");
    scrollArea.style.width = (element.offsetWidth * pages.length) + "px";
    var paddingLeft = parseInt(this.style.compute(pages[0], "paddingLeft"));
    var paddingRight = parseInt(this.style.compute(pages[0], "paddingRight"));
    var pageWidth = ((element.clientWidth || element.offsetWidth) - paddingLeft - paddingRight) + "px";
    pages.forEach(function(page) {
      page.style.width = pageWidth;
    });
    var pageIndex = this.get(element, "pageIndex");
    this.scrollToPage(element, pageIndex, 0);
  },

  "@!(element.onresize)": {
    "window:onresize": function(element) {
      this[":onresize"](element);
    }
  },

  "@MSIE": {
    "window:onresize": function(element) {
      if (document.body == element) {
        this[":onresize"](element);
      }
    }
  },

  ":ontouchstart": {
    ":scope": function(element, event) {
      this._swiping = !this._scrolling && !("form" in event.target) && !("href" in event.target);

      if (this._swiping) {
        this.classList.add(element, "pageview-scrolling");
        var touch = event.touches[0];
        this._swipeStart = touch.screenX;
        this._swipePosition = this._swipeStart;
      }
    },

    ".pageview-back": function(element, event) {
      event.preventDefault();
      this.scrollBack(element);
    },

    ".pageview-forward": function(element, event) {
      event.preventDefault();
      this.scrollForward(element);
    }
  },

  ":ontouchmove": function(element, event) {
    if (this._swiping) {
      event.preventDefault();
      var touch = event.touches[0];
      var x = this._x + touch.screenX - this._swipePosition;
      this._swipePosition = touch.screenX;
      this._scrollToX(element, x);
    }
  },

  ":ontouchend": function(element, event) {
    if (this._swiping) {
      delete this._swiping;
      var pageWidth = element.clientWidth;
      var delta = (this._swipeStart - this._swipePosition) / pageWidth;
      var pageIndex = this.get(element, "pageIndex");
      if (delta > 0.125) { // 12.5%
        this.scrollToPage(element, pageIndex + 1, 250 * (1 - delta));
      } else if (delta < -0.125) {
        this.scrollToPage(element, pageIndex - 1, 250 * (1 + delta));
      } else {
        this.scrollToPage(element, pageIndex, 50);
      }
    }
  },

  ":ontouchcancel": function(element, event) {
    if (this._swiping) {
      delete this._swiping;
      this.classList.remove(element, "pageview-scrolling");
      var pageIndex = this.get(element, "pageIndex");
      this.scrollToPage(element, pageIndex, 0);
    }
  },

  ":ontransitionend": function(element, event) {
    if (this.matches(event.target, ".pageview-scrollarea")) {
      this.style.set(event.target, "transitionProperty", "none");

      var pages = this.get(element, "pages");
      var pageIndex = this.get(element, "pageIndex");
      var lastIndex = pages.length - 1;

      this._setArrowState(element, "back", pageIndex === 0);
      this._setArrowState(element, "forward", pageIndex === lastIndex);

      var progress = this.find(element, ".pageview-progress");
      if (progress) {
        var activeMarkerFlag  = "pageview-progress-marker-active";
        var activeMarker = this.find(progress, "." + activeMarkerFlag);
        if (activeMarker) this.classList.remove(activeMarker, activeMarkerFlag);

        var currentMarkerFlag = "pageview-progress-marker-current";
        var currentMarker = this.find(progress, "." + currentMarkerFlag);
        if (currentMarker) this.classList.remove(currentMarker, currentMarkerFlag);

        currentMarker = this.findAll(progress, ".pageview-progress-marker")[pageIndex];
        if (currentMarker) this.classList.add(currentMarker, currentMarkerFlag);
      }

      this.classList.remove(element, "pageview-scrolling");

      this.fire(element, "scroll", {pageIndex: pageIndex});

      delete this._scrolling;
    }
  },

  // public properties

  pages: null,
  pageIndex: -1,

  get_pages: function(element) {
    var scrollArea = this.find(element, ">.pageview-scrollarea");
    return this.findAll(scrollArea || element, ".page");
  },

  get_pageIndex: function(element) {
    var pageIndex = this.getUserData(element, "pageIndex");
    return pageIndex == null ? this.pageIndex : pageIndex;
  },

  // public methods

  scrollBack: function scrollBack(element) {
    if (!this._scrolling) {
      var pageIndex = this.get(element, "pageIndex");
      if (pageIndex > 0) {
        this.scrollToPage(element, pageIndex - 1);
      }
    }
  },

  scrollForward: function scrollForward(element) {
    if (!this._scrolling) {
      var pages = this.get(element, "pages");
      var pageIndex = this.get(element, "pageIndex");
      var lastIndex = pages.length - 1;
      if (pageIndex < lastIndex) {
        this.scrollToPage(element, pageIndex + 1);
      }
    }
  },

  scrollToPage: function scrollToPage(element, pageIndex) {
    var pages = this.get(element, "pages");

    if (pageIndex < 0 || pageIndex >= pages.length) {
      throw RangeError("Page index out of bounds.");
    }

    // Maintain the read-only pageIndex property.
    var oldIndex = this.get(element, "pageIndex");
    var newIndex = pageIndex;

    if (oldIndex === newIndex) return;

    this.classList.remove(pages[oldIndex], "page-selected");
    this.classList.add(pages[newIndex], "page-selected");
    this.setUserData(element, "pageIndex", newIndex);

    var direction = newIndex > oldIndex ? "forward" : "back";
    var arrow = this.find(element, ".pageview-" + direction);
    if (arrow) this.classList.add(arrow, "pageview-arrow-active");

    var progress = this.find(element, ".pageview-progress");
    if (progress) {
      var activeMarker = this.findAll(progress, ".pageview-progress-marker")[pageIndex];
      if (activeMarker) {
        this.classList.add(activeMarker, "pageview-progress-marker-active");
      }
      var currentMarker = this.find(progress, ".pageview-progress-marker-current");
      if (currentMarker) {
        this.classList.remove(currentMarker, "pageview-progress-marker-current");
      }
    }

    var scrollArea = this.find(element, ">.pageview-scrollarea");
    var pageWidth = element.clientWidth;
    var scrollPosition = (-pageIndex * pageWidth) + "px";

    var duration = arguments[2];
    if (duration === 0) {
      scrollArea.left = scrollPosition;
    } else {
      this.animate(scrollArea, {
        left: scrollPosition,
        transitionDuration: (duration || 250) + "ms",
        transitionTimingFunction: "cubic-bezier(0.33,0.66,0.66,1)"
      });
      this._scrolling = true;
      this.classList.add(element, "pageview-scrolling");
    }
  },

  // private methods

  _createControls: function(element) {
    var controls = document.createElement("div");
    controls.className = "pageview-controls";

    var self = this;
    function createArrow(type, caption, tooltip, disabled) {
      var arrow = document.createElement("a");
      self.set(arrow, "textContent", caption);
      arrow.href = "#";
      arrow.className = "pageview-arrow pageview-" + type + (disabled ? " pageview-arrow-disabled" : "");
      arrow.setAttribute("unselectable", "on"); // for MSIE
      arrow.title = tooltip;
      controls.appendChild(arrow);
    }

    // Create the back scroll arrow.
    createArrow("back", "\u2190", this.PAGE_PREV, true);

    // Create the page progress indicator.
    var progress = document.createElement("span");
    progress.className = "pageview-progress";
    var pages = this.get(element, "pages"), page;
    for (var i = 0; page = pages[i]; i++) {
      var marker = document.createElement("a");
      marker.href = "#";
      marker.className = "pageview-progress-marker";
      if (i === 0) marker.className += " pageview-progress-marker-current";
      var heading = this.find(page, "h1,h2,h3,h4,h5,h6");
      marker.title = heading ? this.get(heading, "textContent") : this.PAGE_GOTO.replace("{page}", i + 1);
      progress.appendChild(marker);
    }
    controls.appendChild(progress);

    // Create the forward scroll arrow.
    createArrow("forward", "\u2192", this.PAGE_NEXT);

    element.appendChild(controls);
  },

  _createScrollArea: function(element) {
    if (!this.find(element, ".pageview-scrollarea")) {
      var scrollArea = document.createElement("div");
      scrollArea.className = "pageview-scrollarea";
      var pages = this.get(element, "pages");
      pages.forEach(function(page) {
        scrollArea.appendChild(page);
      });
      element.appendChild(scrollArea);
    }
    element.style.overflow = "hidden";
  },

  _scrollToX: function(element, x) {
    var scrollArea = this.find(element, ">.pageview-scrollarea");
    this.style.set(scrollArea, "left", x + "px");
    this._x = x;
  },

  "@(style.transform)": {
    _scrollToX: function(element, x) {
      var scrollArea = this.find(element, ">.pageview-scrollarea");
      this.style.set(scrollArea, "transform", "translateX(" + x + "px)");
      this._x = x;
    }
  },

  _setArrowState: function(element, type, disabled) {
    var arrow = this.find(element, ".pageview-" + type);
    if (arrow) {
      this.classList[disabled ? "add" : "remove"](arrow, "pageview-arrow-disabled");
      this.classList.remove(arrow, "pageview-arrow-active");
    }
  }
});

jsb.Rule(".pageview", pageview);
