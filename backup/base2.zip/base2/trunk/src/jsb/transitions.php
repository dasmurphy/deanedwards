<!doctype html>
<title>JSB: Test Page</title>
<meta charset="utf-8">
<script src="/base2/trunk/src/console2.js"></script>
<script src="/base2/trunk/src/base2-jsb.js"></script>

<script>

new jsb.Rule("#example", {
  "document:onclick": {  // accelerate the animation
    "#color": function(element, event) {
      this.animate(element, {
        backgroundColor: "blue",
        transitionDuration: "2s",
        transitionTimingFunction: "linear"
      });
    },

    "#size": function(element, event) {
      this.animate(element, {
        width: "600px",
        transitionDuration: "2s",
        transitionTimingFunction: "linear"
      });
    },

    "#reset": function(element, event) {
      this.animate(element, {
        width: "200px",
        backgroundColor: "lime",
        transitionDuration: "250ms",
        transitionTimingFunction: "linear"
      });
    }
  },

  ontransitionend: function(element, event) {
    console2.log(event.propertyName + " (" + event.elapsedTime + ")");
  }
});
</script>

<style>
#example {
  background: lime;
  border: 10px solid red;
  padding: 50px;
  width: 200px;
  color: white;
  font-weight: bold;
  cursor: default;
}
</style>

<h1>JSB: Animation Test Page</h1>

<div id="example"></div>

<p><button id="color">Color</button> <button id="size">Size</button> <button id="reset">Reset</button></p>
