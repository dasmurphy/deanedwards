
var ExtendedNodeList = _.Base.extend({
  constructor: function ExtendedNodeList__constructor(nodes) {
    if (/*@ this.valueOf && @*/ this instanceof ExtendedNodeList) { // construct
      if (nodes && nodes.length > 0) {
        var i = 0, node;
        while ((node = nodes[i])) {
          this[i++] = node;
        }
        this.length = i;
      }
      return this;
    } else { // cast
      if (nodes == null || typeof nodes.length != "number") {
        throw new TargetError(JSB_TYPE_ERR, "ExtendedNodeList");
      }
      var methods = ExtendedNodeList.prototype;
      for (var name in methods) if (typeof methods[name] == "function") {
        nodes[name] = methods[name];
      }
      return nodes;
    }
  },

  length: 0,

  item: function ExtendedNodeList__item(index) {
    // Allow negative indexes (offset from the end)
    if (index < 0) index += this.length;
    if (index >= 0) var element = this[+index];
    return element || null;
  },

  not: function ExtendedNodeList__not(test, context) {
    return this.filter(function _not(element) {
      return !test(element);
    }, context);
  }
});

ExtendedNodeList.implement(_.ArrayLike);

ExtendedNodeList.implement({
  every:  _ExtendedNodeList_matches,
  filter: _ExtendedNodeList_matches,
  not:    _ExtendedNodeList_matches,
  some:   _ExtendedNodeList_matches,

  plant:  function ExtendedNodeList__plant(propertyName, value) {
    this.forEach(function _planter(element) {
      dom.set(element, propertyName, value);
    });
  },

  pluck:  function ExtendedNodeList__pluck(propertyName) {
    return this.map(function _plucker(element) {
      return dom.get(element, propertyName);
    });
  }
});

ExtendedNodeList.implement({
  filter: _ExtendedNodeList_create,
  slice:  _ExtendedNodeList_create
});

function _ExtendedNodeList_matches(test, context) {
  if (typeof test == "string") {
    var selector = test;
    test = function _matcher(element) {
      return dom.matches(element, selector);
    };
  }
  return this.base(test, context);
}

function _ExtendedNodeList_create() {
  return new ExtendedNodeList(this.base.apply(this, arguments));
}
