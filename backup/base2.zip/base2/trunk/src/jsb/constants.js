
var constants = {
  // Node types
  ELEMENT_NODE: 1,
  ATTRIBUTE_NODE: 2,
  TEXT_NODE: 3,
  CDATA_SECTION_NODE: 4,
  ENTITY_REFERENCE_NODE: 5,
  ENTITY_NODE: 6,
  PROCESSING_INSTRUCTION_NODE: 7,
  COMMENT_NODE: 8,
  DOCUMENT_NODE: 9,
  DOCUMENT_TYPE_NODE: 10,
  DOCUMENT_FRAGMENT_NODE: 11,
  NOTATION_NODE: 12,

  // Event phase
  CAPTURING_PHASE: 1,
  AT_TARGET: 2,
  BUBBLING_PHASE: 3,

  // Document position
  DOCUMENT_POSITION_DISCONNECTED: 0x01,
  DOCUMENT_POSITION_PRECEDING: 0x02,
  DOCUMENT_POSITION_FOLLOWING: 0x04,
  DOCUMENT_POSITION_CONTAINS: 0x08,
  DOCUMENT_POSITION_CONTAINED_BY: 0x10,

  // Key codes
  KEY_CANCEL: 3,
  KEY_HELP: 6,
  KEY_BACKSPACE: 8,
  KEY_TAB: 9,
  KEY_CLEAR: 12,
  KEY_RETURN: 13,
  KEY_ENTER: 14,
  KEY_SHIFT: 16,
  KEY_CTRL: 17,
  KEY_ALT: 18,
  KEY_PAUSE: 19,
  KEY_CAPSLOCK: 20,
  KEY_ESCAPE: 27,
  KEY_SPACE: 32,
  KEY_PGUP: 33,
  KEY_PGDN: 34,
  KEY_END: 35,
  KEY_HOME: 36,
  KEY_LEFT: 37,
  KEY_UP: 38,
  KEY_RIGHT: 39,
  KEY_DOWN: 40,
  KEY_PRINTSCREEN: 44,
  KEY_INSERT: 45,
  KEY_DELETE: 46,
  KEY_SEMICOLON: 59,
  KEY_EQUALS: 61,
  KEY_CONTEXTMENU: 93,
  KEY_MULTIPLY: 106,
  KEY_ADD: 107,
  KEY_SEPARATOR: 108,
  KEY_SUBTRACT: 109,
  KEY_DECIMAL: 110,
  KEY_DIVIDE: 111,
  KEY_NUMLOCK: 144,
  KEY_SCROLLLOCK: 145,
  KEY_COMMA: 188,
  KEY_PERIOD: 190,
  KEY_SLASH: 191,
  KEY_BACKQUOTE: 192,
  KEY_OPENBRACKET: 219,
  KEY_BACKSLASH: 220,
  KEY_CLOSEBRACKET: 221,
  KEY_QUOTE: 222,
  KEY_META: 224
};

addNumericKey("", 48, 58);
addNumericKey("NUMPAD", 96, 106);
addNumericKey("F", 112, 136, 1);

for (var i = 65; i < 91; i++) {
 constants["KEY_" + String.fromCharCode(i)] = i;
}

function addNumericKey(prefix, start, stop, offset) {
  offset |= 0;
  for (var i = start; i < stop; i++) {
   constants["KEY_" + prefix + (i - start + offset)] = i;
  }
};
