
// Allow registration of events like: onkeydown(ctrl+a)

var CONST_DEFAULT_KEY = -1;

var keyCodes = {
  backspace: 8, tab: 9, enter: 13,
  shift: 16, ctrl: 17, alt: 18, meta: 224,
  pause: 19, esc: 27, space: 32,
  pgup: 33, pgdn: 34, end: 35, home: 36,
  left: 37, up: 38, right: 39, down: 40,
  ins: 45, del: 46
};

for (var keyCode = 112; keyCode < 136; keyCode++) {
  keyCodes["f" + (keyCode - 111)] = keyCode;
}

var KeyHandlers = _.Base.extend({
  register: function KeyHandlers__register(signature, listener) {
    var parts = signature.toLowerCase().replace(/\s+|\)$/g, "").split("(");
    var type = parts[0];
    if (!this[type]) this[type] = [];
    if (parts[1]) {
      var modifiers = parts[1].split("+");
      var key = modifiers.pop();
      this[type].push({
        keyCode: keyCodes[key] || (key.length === 1 ? key.toUpperCase().charCodeAt(0) : +key || -1),
        modifiers: modifiers,
        listener: listener
      });
    } else {
      this[type][CONST_DEFAULT_KEY] = listener;
    }
    this.sort = KeyHandlers__sort;
    return type;
  },

  getListener: function KeyHandlers__getListener(type, event) {
    var handlers = this[type], handler;
    searching: for (var i = 0; handler = handlers[i]; i++) {
      if (handler.keyCode === event.keyCode) {
        var modifiers = handler.modifiers, modifier;
        for (var j = 0; modifier = modifiers[j]; j++) {
          if (!event[modifier + "Key"]) continue searching;
        }
        return handler.listener;
      }
    }
    return handlers[CONST_DEFAULT_KEY] || _.Undefined;
  },

  sort: _.Undefined
});

// help

function KeyHandlers__sort() {
  // e.g. onkeydown(ctrl+a) takes precedence over onkeydown(a)
  for (var type in this) if (!KeyHandlers.prototype[type]) {
    this[type].sort(_keyHandlers_sorter);
  }
}

function _keyHandlers_sorter(handler1, handler2) {
  return handler2.modifiers.length - handler1.modifiers.length;
}
