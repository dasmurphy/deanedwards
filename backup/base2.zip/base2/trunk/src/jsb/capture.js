
var captureElement, captureBehavior, captureMeta;

var captureEvents = {
  mouseup:   forwardEvent,
  mousedown: forwardEvent,
  mousemove: forwardEvent,

  mouseover: stopPropagation,
  mouseout:  stopPropagation
};

function releaseCapture() {
  if (captureElement) {
    for (var type in captureEvents) {
      dom.removeEventListener(document, type, captureEvents[type], true);
    }
    fire(captureElement, "jsb:losecapture");
    if (!dom.matches(captureElement, ":hover")) {
      fire(captureElement, "mouseout");
    }
  }
  captureElement = null;
}

function stopPropagation(event) {
  if (captureElement) {
    event.stopPropagation();
  }
}

function forwardEvent(event) {
  if (captureElement) {
    dispatchEvent(captureBehavior, captureElement, event, captureMeta);
    event.stopPropagation();
  }
}

/*@
window.attachEvent("onblur", releaseCapture);
@*/
