
var captureElement, captureBehavior;

var captureEvents = {
  mouseup:   forwardEvent,
  mousedown: forwardEvent,
  mousemove: forwardEvent,

  mouseover: stopPropagation,
  mouseout:  stopPropagation
};

function setCapture(element) {
  if (!element || element.nodeType !== 1) throw new TargetError(JSB_TYPE_ERR, "setCapture");

  if (element != captureElement) releaseCapture();
  captureElement = element;
  captureBehavior = this;
  for (var type in captureEvents) {
    dom.addEventListener(document, type, captureEvents[type], true);
  }
}

function releaseCapture() {
  if (captureElement) {
    for (var type in captureEvents) {
      dom.removeEventListener(document, type, captureEvents[type], true);
    }
    new PseudoEvent(captureBehavior, captureElement, "losecapture");
    if (!dom.matches(captureElement, ":hover")) {
      fire(captureElement, "mouseout");
    }
  }
  captureElement = null;
  captureBehavior = null;
}

function stopPropagation(event) {
  if (captureElement) {
    event.stopPropagation();
  }
}

function forwardEvent(event) {
  if (captureElement) {
    dispatchEvent(captureBehavior, captureElement, event);
    event.stopPropagation();
  }
}

/*@
window.attachEvent("onblur", releaseCapture);
@*/
