
var Behavior = _.Base.extend({
  jsbExtendedMouse: false, // allow right and middle button clicks
  jsbUseDelegation: false, // use event delegation (appropriate events are handled by the document object)
  
  data: null,

  attach: _.Undefined, // these methods are defined when the behavior is created
  detach: _.Undefined,
  modify: _.Null,

  ancestorOf: function behavior_ancestorOf(behavior) {
    return behavior instanceof this.constructor;
  },
  
  extend: function behavior_extend(_interface) {
    // Extend a behavior to create a new behavior.

    // Create the Behavior constructor.
    var Behavior = function Behavior(){};
    (Behavior.prototype = new this.constructor).constructor = Behavior;
    
    var data = qcopy(this.data);

    // Decorate the prototype.
    for (var i = 0; i < arguments.length; i++) {
      _interface = arguments[i];
      if (_interface) {
        _.extend(Behavior.prototype, _interface);
        if (_interface.data) _.extend(data, _interface.data);
      }
    }

    // Single instance.
    var behavior = new Behavior;
    behavior.data = data;

    var keyHandlers = new KeyHandlers;
    var meta = {behavior: behavior, keyHandlers: keyHandlers};
    var attachedEvents = {}, allEvents = {};

    function eventListener(event) {
      dispatchEvent(behavior, event.currentTarget, event, meta);
    }
    
    var forwardListener = {};

    function forwardEvent(element) {
      var listener = function eventListener(event) {
        if (element[IS_CONNECTED]) { // make sure the element is in the DOM
          dispatchEvent(behavior, element, event, meta);
        }
      };
      forwardListener[element.uniqueID] = listener;
      return listener;
    }

    // Extract event handlers.
    for (var name in behavior) {
      var handler = behavior[name];
      if (handler && (typeof handler == "function" || typeof handler == "object") && EVENT.test(name)) {
        var type = name.replace(ON, "$1");
        if (EVENT_TEXT.test(type)) {
          type = keyHandlers.register(type, handler);
        }
        // Store event handlers.
        if (!allEvents[type]) {
          allEvents[type] = true;
          if (behavior.jsbUseDelegation && EVENT_BUBBLES.test(type)) {
            if (!delegatedEvents[type]) {
              delegatedEvents[type] = [];
              dom.addEventListener(document, type, delegateEvent);
            }
            delegatedEvents[type].push(meta);
          } else {
            var parts = type.split(":");
            if (parts.length === 1) {
              attachedEvents[type] = false;
            } else {
              var namespace = parts[0];
              type = parts[1];
              switch (namespace) {
                case "window":
                  attachedEvents[type] = window;
                  break;
                  
                case "document":
                  attachedEvents[type] = document;
                  break;
                  
                case "capture":
                  attachedEvents[type] = true;
                  break;
                  
                default:
                  attachedEvents[namespace + ":" + type] = false;
              }
            }
          }
        }
      }
    }

    keyHandlers.sort();

    // Maintain attachments.

    behavior.attach = function behavior_attach(element) {
      if (!element || element.nodeType !== 1) throw new TargetError(JSB_TYPE_ERR, "behavior.attach");

      var attachedByRuleEngine = _attachedByRuleEngine_;
      _attachedByRuleEngine_ = false;
      
      var uniqueID = element.uniqueID || _.assignID(element);

      if (!meta[uniqueID] || !attachedByRuleEngine) {
        // Maintain attachment state.
        meta[uniqueID] = true;
        if (!allAttachments[uniqueID]) allAttachments[uniqueID] = 0;
        allAttachments[uniqueID]++;

        // Add event handlers
        for (var type in attachedEvents) {
          var capture = attachedEvents[type];
          if (typeof capture == "boolean") {
            dom.addEventListener(element, type, eventListener, capture);
          } else {
            dom.addEventListener(capture, type, forwardEvent(element));
          }
        }
        if (behavior["jsb:onattach"]) {
          new PseudoEvent(behavior, element, "attach");
        }
        if (behavior["jsb:oncontentready"]) {
          if (attachedByRuleEngine) {
            contentReadyQueue[uniqueID] = true;
            contentReadyCount++;
          } else {
            new PseudoEvent(behavior, element, "contentready");
          }
        }
        if (behavior["jsb:ondocumentready"]) {
          if (attachedByRuleEngine || !engine._ready) {
            if (!(uniqueID in documentReadyQueue)) {
              documentReadyQueue[uniqueID] = true;
              documentReadyQueue.push(element);
            }
          } else {
            new PseudoEvent(behavior, element, "documentready");
          }
        }
        if (behavior.onfocus && element == document.activeElement) {
          fire(element, "focus");
        }
      }
    };

    behavior.detach = function behavior_detach(element) {
      if (!element || element.nodeType !== 1) throw new TargetError(JSB_TYPE_ERR, "behavior.detach");

      var uniqueID = element.uniqueID;
      if (meta[uniqueID]) {
        delete meta[uniqueID];
        allAttachments[uniqueID]--;
        for (var type in attachedEvents) {
          var capture = attachedEvents[type];
          if (typeof capture == "boolean") {
            dom.removeEventListener(element, type, eventListener, capture);
          } else {
            dom.removeEventListener(capture, type, forwardListener[uniqueID]);
            delete forwardListener[uniqueID];
          }
        }
      }
    };

    behavior.attach._meta = meta;

    // Maintain modifications.

    var modifications = [];

    Behavior._get = function _Behavior_get(element, propertyName, isDataAttribute) {
      var source = behavior, modification;
      if (isDataAttribute) source = source.data;
      for (var i = 0; modification = modifications[i]; i++) {
        var source = isDataAttribute ? modification.data || {} : modification;
        if (propertyName in source && dom.matches(element, modification._selector)) return source[propertyName];
      }
      return (isDataAttribute ? behavior.data : behavior)[propertyName];
    };

    behavior.modify = function behavior_modify(attributes) {
      Behavior._isModified = true;
      return new Modification(behavior, attributes, modifications);
    };

    return behavior;
  },
  
  get: function behavior_get(element, propertyName) {
    if (arguments.length < 2) throw new ArityError("behavior.get");
    if (!element || !element.nodeType) throw new TargetError(JSB_TYPE_ERR, "behavior.get");

    // Retrieve a DOM property.
    
    var getter = "get_" + propertyName;
    if (typeof this[getter] == "function") {
      return this[getter](element);
    }

    var isDataAttribute = propertyName in this.data;
    var defaultValue = isDataAttribute ? this.data[propertyName] : this[propertyName];

    var value = isDataAttribute ? undefined : element[propertyName];

    if (typeof defaultValue != "undefined") {
      if (typeof value == "undefined") {
        var attributeName = isDataAttribute
          ? "data-" + propertyName.replace(/([A-Z])/g, "-$1").toLowerCase()
          : propertyName;
        value = dom.getAttribute(element, attributeName);
        if (value == null) {
          var Behavior = this.constructor;
          return Behavior._isModified
            ? Behavior._get(element, propertyName, isDataAttribute)
            : defaultValue;
        }
      }

      // Cast.
      switch (typeof defaultValue) {
        case "boolean": return true;
        case "number":  return +value;
        case "string":  return String(value);
      }
    } else if (propertyName in dom.get.properties) {
      // handled by base2.dom
      value = dom.get(element, propertyName);
    }

    return value;
  },

  set: function behavior_set(element, propertyName, value) {
    if (arguments.length < 3) throw new ArityError("behavior.set");
    if (!element || !element.nodeType) throw new TargetError(JSB_TYPE_ERR, "behavior.set");

    // Set a DOM property.

    var setter = "set_" + propertyName;
    if (typeof this[setter] == "function") {
      return this[setter](element, value);
    }
    
    var isDataAttribute = propertyName in this.data;
    var defaultValue = isDataAttribute ? this.data[propertyName] : this[propertyName];
    var type = typeof defaultValue;
    
    if (type === "undefined") {
      if (propertyName in dom.get.properties) {
        // handled by base2.dom
        value = dom.set(element, propertyName, value);
      } else {
        value = element[propertyName] = value;
      }
    } else {
      var attributeName = propertyName.replace(/([A-Z])/g, "-$1").toLowerCase();
      if (isDataAttribute) attributeName = "data-" + attributeName;
      if (type === "boolean") {
        value = !!value;
        if (value) {
          dom.setAttribute(element, attributeName, "");
        } else {
          dom.removeAttribute(element, attributeName);
        }
      } else {
        dom.setAttribute(element, attributeName, value);
        value = type === "number" ? +value : String(value);
      }
    }
    
    return value;
  },

  // Node.

  contains: dom.contains,

  getUserData: getUserData,
  setUserData: setUserData,

  // Attributes.

  classList: dom.classList,

  getAttribute:    dom.getAttribute,
  hasAttribute:    dom.hasAttribute,
  removeAttribute: dom.removeAttribute,
  setAttribute:    dom.setAttribute,

  // Selectors API

  matches:       dom.matches,
  find:          dom.find,

  findAll: function behavior_findAll(node, selector) {
    // This method returns an ExtendedNodeList
    var elements = dom.findAll.apply(dom, arguments);
    return ExtendedNodeList(elements);
  },

  // EventTarget.

  addEventListener: dom.addEventListener,
  removeEventListener: dom.removeEventListener,

  fire: fire,

  // Style.

  style: dom.style,

  animate: function behavior_animate(element) {
    if (!element || element.nodeType !== 1) throw new TargetError(JSB_TYPE_ERR, "animate");

    this.style.set(element, "transitionProperty", "all");

    for (var i = 1; i < arguments.length; i++) {
      this.style.set(element, new Transition(arguments[i]));
      var recalc = element.clientWidth;
    }

    this.style.set(element, "transitionDuration", "");
  },

  // CSS Object Model.

  getBoundingClientRect: dom.getBoundingClientRect,

  getOffsetFromBody: function behavior_getOffsetFromBody(element) {
    if (!element || element.nodeType !== 1) throw new TargetError(JSB_TYPE_ERR, "getOffsetFromBody");

    return _private.getOffsetFromBody(element);
  },

  // Mouse capture.

  setCapture: setCapture,
  releaseCapture: releaseCapture,
  
  toString: _.K("[object Behavior]")
});

forEach.csv("setInterval,setTimeout", function(timerName) {
  Behavior.prototype[timerName] = function _timer(callback, delay) {
    if (typeof callback == "string") callback = this[callback];

    var args = _.slice(arguments, 2);
    var self = this;

    return window[timerName](function _callback() {
      callback.apply(self, args);
    }, delay || 16);
  };
});
