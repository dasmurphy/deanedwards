
var StyleSheet = _.Collection.extend({
  constructor: function StyleSheet__constructor(rules) {
    this.vars = _private.pcopy(this.vars);

    this.style = document.createElement("style");
    head.insertBefore(this.style, dom.querySelector(head, "link,style") || head.firstChild);

    if (typeof rules == "string") {
      this.toString = _.K(rules);
    } else {
      this.base.apply(this, arguments);
    }

    dom.set(this.style, "textContent", this.toString());

    /*@
      // Preserve specificty for MSIE
      var links = dom.querySelectorAll(head, "link,style"), link;
      for (var i = 0; link = links[i]; i++) {
        head.insertBefore(link, link.nextSibling);
      }
    @*/
  },

  style: null,

  vars: {
    "inline-block": _.detect("Gecko1\\.[^9]") ? "-moz-inline-box" : "inline-block"
  },

  createItem: function StyleSheet__createItem(selector, properties) {
    return this.base(selector, properties, this);
  },

  createKey: function StyleSheet__createKey(selector) {
    return _.trim(selector).replace(/^\*(\S)/, "$1");
  },

  merge: function StyleSheet__merge(styleSheet) {
    for (var i = 0; i < arguments.length; i++) {
      styleSheet = arguments[i];
      if (styleSheet) {
        var vars = styleSheet["@vars@"];
        if (vars) _.extend(this.vars, vars, true);
        this.base(styleSheet);
      }
    }
    return this;
  },

  set: function StyleSheet__set(key, properties) {
    key = String(key);
    if (key < "A" && key > "@") {
      if (key !== "@vars@" && _.detect(key.slice(1))) {
        this.merge(properties);
      }
    } else {
      var selectors = key.indexOf(",") === -1 ? [key] : CSSSelectorParser.split(key);
      for (var i = 0; key = selectors[i]; i++) {
        var rule = this.get(key);
        if (rule) {
          rule.merge(properties);
        } else {
          this.base(key, properties);
        }
      }
    }
  },

  toString: function StyleSheet__toString() {
    return this.join("\n");
  }
});

StyleSheet.Item = CSSRule;
