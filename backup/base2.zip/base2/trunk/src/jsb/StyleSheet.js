
var StyleSheet = _.Collection.extend({
  constructor: function StyleSheet__constructor(rules) {
    this.vars = _pcopy(this.vars);

    this.style = document.createElement("style");
    head.insertBefore(this.style, dom.querySelector(head, "link,style") || head.firstChild);

    if (typeof rules == "string") {
      this.toString = _.K(rules);
    } else {
      this.base.apply(this, arguments);
    }

    dom.set(this.style, "textContent", this.toString());

    /*@
      // Preserve specificty for MSIE
      var links = dom.querySelectorAll(head, "link,style"), link;
      for (var i = 0; link = links[i]; i++) {
        head.insertBefore(link, link.nextSibling);
      }
    @*/
  },

  style: null,

  vars: {
    "inline-block": _.detect("Gecko1\\.[^9]") ? "-moz-inline-box" : "inline-block"
  },

  clear: StyleSheet__recompile,
  remove: StyleSheet__recompile,
  removeAt: StyleSheet__recompile,

  createItem: function StyleSheet__createItem(selector, properties) {
    return this.base(selector, properties, this);
  },

  createKey: _.trim,

  merge: function StyleSheet__merge(rules) {
    if (!this._merging) this._merging = 0;
    this._merging++;
    for (var i = 0; i < arguments.length; i++) {
      rules = arguments[i];
      if (rules) {
        var vars = rules["@vars@"];
        if (vars) _.extend(this.vars, vars, true);
        this.base(rules);
      }
    }
    this._merging--;
    if (!this._merging && this.style) {
      delete this._merging;
      dom.set(this.style, "textContent", this.toString());
    };
    return this;
  },

  set: function StyleSheet__set(selector, properties) {
    var key = String(selector);
    if (key < "A" && key > "@") {
      if (_.detect(key.slice(1))) {
        this.merge(properties);
      }
    } else {
      var selectors = key.indexOf(",") === -1
        ? [key]
        : cssParser.split(key);

      for (var i = 0; selector = selectors[i]; i++) {
        var rule = this.get(selector);
        if (rule) {
          rule.merge(properties);
        } else {
          this.base(selector, properties);
        }
      }
    }
    if (!this._merging && this.style) {
      dom.set(this.style, "textContent", this.toString());
    };
  },

  toString: function StyleSheet__toString() {
    return this.join("\n");
  }
});

StyleSheet.Item = CSSRule;

function StyleSheet__recompile() {
  var returnValue = this.base.apply(this, arguments);
  dom.set(this.style, "textContent", this.toString());
  return returnValue;
}
