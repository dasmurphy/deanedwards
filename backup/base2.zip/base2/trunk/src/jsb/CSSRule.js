
var CSSRule = _.Collection.extend({
  constructor: function CSSRule__constructor(selectorText, properties, parentStyleSheet) {
    this.selectorText = selectorText;
    this.parentStyleSheet = parentStyleSheet;
    this.base(properties);
  },

  set: Collection__set_detect,

  createItem: function CSSRule__createItem(propertyName, value) {
    value = this.parentStyleSheet.vars[value] || value;
    return String(value).replace(/!$/g, "!important");
  },

  createKey: function CSSRule__createKey(propertyName) {
    propertyName = String(propertyName);
    if (propertyName === "float") return propertyName;
    if (!(propertyName in styleObject)) {
      propertyName = _private.getStylePropertyName(propertyName);
    }
    return propertyName.replace(/[A-Z]/g, "-$&").toLowerCase();
  },

  toString: function CSSRule__toString() {
    return this.selectorText + " {\n" +
      this.map(Property__toString).sort().join("") +
    "}\n";
  }
});

// help

function Property__toString(value, propertyName) {
  return "  " + propertyName + ": " + value + ";\n";
}
