
// A collection of Rule objects

var RuleList = _.Collection.extend({
  apply: function RuleList__apply(node) {
    this.invoke("apply", node);
  },

  refresh: function RuleList__refresh() {
    this.invoke("refresh");
  },

  set: Collection__set_detect
});

RuleList.Item = Rule;
