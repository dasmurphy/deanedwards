
// A collection of Rule objects

var RuleList = _.Collection.extend({
  refresh: function RuleList__refresh() {
    this.invoke("refresh");
  },

  set: function RuleList__set(key, value) { // allow feature detection
    key = String(key);
    if (key.indexOf("@") === 0) {
      if (_.detect(key.slice(1))) this.merge(value);
    } else {
      this.base.apply(this, arguments);
    }
  }
});

RuleList.Item = Rule;
