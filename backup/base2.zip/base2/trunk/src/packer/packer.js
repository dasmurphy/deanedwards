
var defaultOptions = {
  shrinkVariables: true,
  removeAllWhiteSpace: false,
  base62Encode: false,
  shrinkBase2Requirements: false,
  shrinkPrivates: false
};

packer = new _.Package({
  name:    "packer",
  version: "%%VERSION%%",
  
  pack: function(script, options) {
    options = _.extend({}, defaultOptions, options);
    var header = _.trim(license.parse(script));
    if (header) header += "\n";
    script = encoder.encode(script);
    script = clean.parse(script);
    if (options.removeAllWhiteSpace) {
      script = strictWhitespace.parse(script);
    } else {
      script = simpleWhitespace.parse(script);
    }
    if (options.shrinkVariables) {
      script = shrinker.parse(script, options.removeAllWhiteSpace, options.shrinkBase2Requirements);
    }
    script = encoder.decode(script);
    if (options.shrinkPrivates) {
      script = privatesEncoder.encode(script);
    }
    if (options.base62Encode) {
      script = base62Encoder.encode(script);
    }
    return header + script.replace(/^;*\s*/, "").replace(/;*\s*$/, "") + ";\n";
  },
  
  toString: _.K("/packer/")
});
