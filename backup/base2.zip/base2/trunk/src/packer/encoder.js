
var ENCODED_DATA = /\x01(\d+)\x01/g;
var ESCAPE_CRLF  = /\\\r?\n/g;

var encoder = new Parser([
  /(<#BASE2_COMMENT>)/, REMOVE,

  /<#CONDITIONAL>/, IGNORE,

  /<#COMMENT>/, REMOVE,

  /<#OP_WORD>/, IGNORE,

  /<#DIVISION>/, "$1/$2",

  /<#REGEXP>/, function(regexp) {
    var replacement = "\x01" + this._data.length + "\x01";
    this._data.push(regexp);
    return replacement;
  },

  /<#STRING>/, function(string) {
    var replacement = "\x01" + this._data.length + "\x01";
    this._data.push(string.replace(ESCAPE_CRLF, ""));
    return replacement;
  }
]);

_.extend(encoder, {
  decode: function(script) {
    // put strings and regular expressions back
    var data = this._data; // encoded strings and regular expressions
    delete this._data;
    return script.replace(ENCODED_DATA, function(match, index) {
      return data[index];
    });
  },
  
  encode: function(script) {
    this._data = [];
    return this.parse(script);
  }
});
