
var ENCODED_DATA = /([/'"])([\d+]+)(\1)/g;
var ESCAPE_CRLF  = /\\\r?\n/g;

var encoder = new JSParser([
  /(<#BASE2_COMMENT>)/, REMOVE,

  /<#CONDITIONAL>/, IGNORE,

  /<#COMMENT>/, REMOVE,

  /<#OP_WORD>/, IGNORE,

  /<#DIVISION>/, "$1/$2",

  /<#REGEXP>|<#STRING>/, function(data) {
    var delim = data.charAt(0);
    var replacement = delim + this._data.length + delim;
    if (delim === "/") {
      data = data.replace(ESCAPE_CRLF, "");
    }
    this._data.push(data);
    return replacement;
  }
]);

_.extend(encoder, {
  decode: function(script) {
    // put strings and regular expressions back
    var data = this._data; // encoded strings and regular expressions
    delete this._data;
    script = script.replace(/'\+'|"\+"/g, "+");
    return script.replace(ENCODED_DATA, function(match, delim, index) {
      if (delim === "/") {
        return data[index];
      } else {
        var replacement = delim;
        var indexes = index.split("+");
        for (var i = 0; index = indexes[i]; i++) {
          replacement += data[index].slice(1, -1);
        }
        return replacement + delim;
      }
    });
  },
  
  encode: function(script) {
    this._data = [];
    return this.parse(script);
  }
});
