/*
	Packer version 3.1 (alpha 2) - copyright 2004-2007, Dean Edwards
	http://opensource.org/licenses/mit-license.php

	.NET UI created by Alex Lein
*/

::: INSTALLATION :::

1)	Copy all the files to a new directory, I suggest C:\Program Files\Packer3\
	or something similar.

2)	Right-click on pack.wsc and choose Register.  A dialog will pop-up saying
	the registration was successful.  If it is not successful, the application
	will not work.

3)	Run Packer3.exe anytime.  You can also use Packer3 as an ActiveX component
	in your code by calling CreateObject("base2.Packer").  Check the included
	source code for example usage.