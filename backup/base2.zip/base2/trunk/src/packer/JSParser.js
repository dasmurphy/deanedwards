
// Use a string to create the CHAR pattern.
// This protects against a bug in Safari 2.
// Finally, we need to separate the \uffff char (this is for Opera).
var CHAR = "\\w\u00a1-\ufffe\uffff";

var JSParser = _.RegGrp.extend({
  ignoreCase: true,
  
  dictionary: new _.RegGrp.Dict([
    "POSTFIX",       /\+\+|\-\-/,
    "OPERATOR",      /[\[({\^<=>,:;&|!*?+-]/,
    "OP_WORD",       /\b(return|typeof|instanceof|do|yield)\b/,
    "BLOCK_COMMENT", /\/\*[^*]*\*+([^\/][^*]*\*+)*\//,
    "LINE_COMMENT",  /\/\/[^\n]*/,
    "BASE2_COMMENT", /;;;[^\n]*/,
    "COMMENT",       /<#BLOCK_COMMENT>|<#LINE_COMMENT>/,
    "NUMBER",        /\b\-?(\d+\.\d+|\.\d+|\d+\.|\d+)([eE][-+]?\d+)?\b/,
    "STRING1",       /'(\\\r?\n|\\.|[^'\\])*'/,
    "STRING2",       /"(\\\r?\n|\\.|[^"\\])*"/,
    "STRING",        /<#STRING1>|<#STRING2>/,
    "CONDITIONAL",   /\/\*@(?:\s|\w*)|@\*\/|\/\/@[^\n]+\n/, // conditional comments
    "DIVISION",      /([\.\w)\]]|\+\+|\-\-)\s*\/\s*([^*\/])/,
    "REGEXP",        /\/(\[(\\.|[^\n\]\\])+\]|\\.|[^\/\n\\])+\/[gim]*/
  ])
});
