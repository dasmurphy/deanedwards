<?php

include('base2/classes.php');

include('Words.php');
include('Parser.php');
include('Encoder.php');
include('Packer.php');
include('Minifier.php');
include('Privates.php');
include('Shrinker.php');
include('Base62.php');

?>
