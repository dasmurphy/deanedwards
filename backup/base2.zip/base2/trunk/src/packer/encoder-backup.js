
var ENCODED_DATA = /\x01(\d+)\x01/g;
var ESCAPE_CRLF  = /\\\r?\n/g;

var encoder = new Parser([
  /\s*(<#BASE2_COMMENT>)/, REMOVE,

  /<#POSTFIX>/, IGNORE,

  /(<#OPERATOR>)\s*(\/\*@)/, IGNORE,
  /@\*\//, IGNORE,

  /(<#OPERATOR>)(\s*)(<#COMMENT>)/, "$1$2",

  /(<#OPERATOR>|\b(?:return|typeof|instanceof|do))(\s*)(<#REGEXP>)/, function(match, operator, space, regexp) {
    var replacement = "\x01" + this._data.length + "\x01";
    this._data.push(regexp);
    return operator + space + replacement;
  },

  /<#CONDITIONAL>/, IGNORE,

  /<#BLOCK_COMMENT>/, REMOVE,
  
  /\s*(<#LINE_COMMENT>)/, REMOVE,

  /<#STRING>/, function(match) {
    var replacement = "\x01" + this._data.length + "\x01";
    this._data.push(match.replace(ESCAPE_CRLF, ""));
    return replacement;
  }
]);

_.extend(encoder, {
  decode: function(script) {
    // put strings and regular expressions back
    var data = this._data; // encoded strings and regular expressions
    delete this._data;
    return script.replace(ENCODED_DATA, function(match, index) {
      return data[index];
    });
  },
  
  encode: function(script) {
    this._data = [];
    return this.parse(script);
  }
});
