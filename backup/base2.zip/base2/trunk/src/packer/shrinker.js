
var VAR_SPLITTER = new _.RegGrp([
  /\)\s*var\s+/, IGNORE,
  /\bvar\s+[\w$]+\s+in/, IGNORE,
  /(\bvar\s+[^;}]+[;}]\s*){2,}/, function(match) {
    return match.split(/;\s*var\s+/).join(",");
  },
]);

var shrinker = {
  parse: function(script, removeAllWhiteSpace, shrinkBase2Requirements) {
    // identify blocks, particularly identify function blocks (which define scope)
    var IMPORTED      = /\b(base2\.(?:exec|require|ready|Package))\((?:(?:(\x01\d+\x01),)?)(function#(\d+)#)\)/;
    var BLOCK         = /((?:\b(?:do|else|finally|try)\b)|\)|(([=:,\[?!~\^|&%(*\w+-]\s*)?\bfunction\b\s*([^{(#\s]*)?\s*(\(\s*[^)]*\s*\))))?\s*(\{[^{}]*\})/;
    var BLOCK_g       = globalize(BLOCK);
    var BRACKETS      = /\([^()]*\)|\[[^\[\]]*\]/;
    var BRACKETS_g    = globalize(BRACKETS);
    var ENCODED_BLOCK = /#@?(\d+)#/;
    var IDENTIFIER    = /\b[a-zA-Z_$][\w$]*/g;
    var REQUIREMENT   = /[^\s,]+/g;
    var SCOPED        = /#@(\d+)#/;
    var VAR_g         = /\bvar\b/g;
    var VARS          = /\b(const|let|var)\s+[\w$]+\s+in\b|\b(const|let|var)\s+[\w$]+[^;}]*|\bfunction\s+[\w$]+|\bcatch\s*\([^)]+/g;
    var VAR_TIDY      = /\b(const|let|var|function|catch\s*\()\b|\sin\b[^;]+|\s+in\b/g;
    var VAR_EQUAL     = /\s*=[^,;}]*/g;
    var PREFIX        = "\x02";
    var SHRUNK        = /\x02\d+\b/g;

    var ALLOWED = {
      "base2": 1,
      "base2.EventTarget": 1,
      "base2.Functional": 1,
      "base2.ArrayLike": 1,
      "base2.lang": 1,
      "base2.dom": 1,
      "base2.io": 1,
      "base2.jst": 1,
      "jsb": 1,
      "jsb.chrome": 1,
      "Date": 1,
      "Math": 1
    };

    var atTop  = false;
    var blocks = []; // store program blocks (anything between braces {})
    // encoder for program blocks
    function encodeBlocks($, prefix, isFunction, anon, functionName, args, block) {
      if (!prefix) prefix = "";
      if (removeAllWhiteSpace) block = VAR_SPLITTER.parse(block);

      var count = 0;
      function shrinkId(block, id, shrunkId, isArgs) {
        if (!shrunkId) {
          while (new RegExp(PREFIX + count + "\\b").test(block)) count++;
          shrunkId = PREFIX + count;
          count++;
        }

        id = id.replace(/\$/g, "\\$");
        var match1 = "([^\\w$.])" + id + "([^\\w$:])";
        var match2 = "(\\bcase\\s+|[+=\\/%~|&^!*?:-]\\s*)" + id + ":";

        // encode variable names
        var reg1 = new RegExp(match1);
        while (reg1.test(block)) {
          block = block.replace(globalize(reg1), "$1" + shrunkId + "$2");
        }
        var reg2 = new RegExp(match2, "g");
        return block.replace(reg2, "$1" + shrunkId + ":");
      }

      // process each identifier
      var processed = {};
      function processIds(block, ids, isArgs) {
        ids = String(ids).match(IDENTIFIER) || [];
        for (var i = 0; i < ids.length; i++) {
          var id = ids[i];
          if (!processed["@" + id]) {
            processed["@" + id] = true;
            // encode variable names
            if (/^CONST_[A-Z_]+$/.test(id)) {
              var value;
              var CONST = new RegExp("(var |,)\\b" + id + "+=([^;,]+)([,;])", "g");
              block = block.replace(CONST, function(match, dec, v, terminator) {
                value = v;
                if (terminator === ";") {
                  return dec == "var " ? "" : terminator;
                }
                return dec == "var " ? dec : terminator;
              });
              block = shrinkId(block, id, value, isArgs);
            } else {
              block = shrinkId(block, id, "", isArgs);
            }
          }
        }
        return block;
      }

      if (isFunction) {
        // decode the function block (THIS IS THE IMPORTANT BIT)
        // We are retrieving all sub-blocks and will re-parse them in light
        // of newly shrunk variables
        block = args + decodeBlocks(block, SCOPED);
        prefix = prefix.replace(BRACKETS, "");

        // create the list of variable and argument names
        args = args.slice(1, -1);

        var vars = (block.match(VARS) || []).join(";\n").replace(VAR_g, ";\nvar");
        while (BRACKETS.test(vars)) {
          vars = vars.replace(BRACKETS_g, "0");
        }
        vars = vars.replace(VAR_TIDY, "").replace(VAR_EQUAL, "");
        
        block = decodeBlocks(block, ENCODED_BLOCK);

        block = processIds(block, args, true);
        block = processIds(block, vars);
        
        if (anon && functionName) {
          prefix = anon;
          block = shrinkId("function " + functionName + block, functionName);
          var shrunkId = PREFIX + (count - 1);
          if ((block.match(new RegExp(shrunkId + "\\b", "g")) || "").length === 1) {
            block = block.replace(new RegExp("\\s" + shrunkId + "\\b"), "");
          }
        }
        var replacement = prefix + "#" + blocks.length + "#";
      } else {
        replacement = prefix + (prefix ? "#@" : "#") + blocks.length + "#";
      }
      blocks.push(block);
      return replacement;
    }

    // decoder for program blocks
    function decodeBlocks(script, encoded) {
      if (atTop) {
        script = base2Whitespace.parse(script);
      }
      while (encoded.test(script)) {
        if (atTop && shrinkBase2Requirements && IMPORTED.test(script)) {
          script = script.replace(globalize(IMPORTED), encodeImports);
        }
        script = script.replace(globalize(encoded), function($, index) {
          return blocks[index];
        });
        atTop = false;
      }
      return script;
    }

    var DATA = encoder._data;
    
    function encodeImports($, exec, require, fn, index) {
      if (require) {
        require = DATA[require.slice(1, -1)].slice(1, -1).match(REQUIREMENT);
        require.unshift("_");
      }
      var block = blocks[index];
      var count = 0;
      while (new RegExp(PREFIX + count + "\\b").test(block)) count++;
      var args = block.slice(0, block.indexOf(")") + 1).match(/[^\s,()]+/g);
      if (args) {
        var vars = {};
        var declarations = [];
        var shrunkId;
        for (var i = 0; i < args.length; i++) {
          if (i == 0 || !require || ALLOWED[require[i]]) {
            var arg = new RegExp(args[i] + "\\.", "g");
            var match = block.match(arg);
            if (match) {
              var pattern = new RegExp(args[i] + "\\.(\\w+)", "g");
              block = block.replace(pattern, function($, id) {
                if (!vars[id]) {
                  shrunkId = PREFIX + count++;
                  declarations.push(shrunkId + "=" + $);
                  vars[id] = shrunkId;
                }
                return vars[id];
              });
            }
          }
        }
        if (declarations.length) {
          declarations = "var " + declarations.join(",") + ";";
          block = block.replace(/\{(\x01\d+\x01;)?/, "{$1" + declarations);
        }
        blocks[index] = block;
      }
      return $;
    }
    
    // encode blocks, as we encode we replace variable and argument names
    while (BLOCK.test(script)) {
      script = script.replace(BLOCK_g, encodeBlocks);
    }
    
    // put the blocks back
    atTop = true;
    if (removeAllWhiteSpace) script = VAR_SPLITTER.parse(script);
    script = decodeBlocks(script, ENCODED_BLOCK);
    
    var shortId, count = 0;
    var shrunk = new JSEncoder(SHRUNK, function() {
      // find the next free short name
      do shortId = encode52(count++);
      while (new RegExp("[^\\w$.]" + shortId + "[^\\w$:]").test(script));
      return shortId;
    });
    script = shrunk.encode(script);
    
    return script;
  }
};
