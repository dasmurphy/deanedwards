
var clean = new Parser([
  /\(\s*([^;)]*)\s*;\s*([^;)]*)\s*;\s*([^;)]*)\)/, "($1;$2;$3)", // for (;;) loops
  /throw\s*\x01\d+\x01;/, IGNORE, // a Safari 1.3 bug
  /;+\s*([};])/, "$1",
  /\s+$/, REMOVE
]);
