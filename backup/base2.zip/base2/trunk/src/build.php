<?php

# PHP5 required
error_reporting(E_ERROR | E_PARSE);

$loaded = Array(
  "Date" => true,
  "JSON" => true,
  "XMLHttpRequest" => true,
  "window" => true,
  "document" => true
);
$REG_JSON = '/\\w+\\.json$/';
$PACKAGE = isset($_GET['package']) ? $_GET['package'] : '';
$fullBuild = isset($_GET['full']);
if (isset($_REQUEST['src'])) {
  $SRC = $_REQUEST['src'];
  if ($SRC == 'base2-dom.js') {
    $PACKAGE = 'base2/dom/package.json';
    $fullBuild = true;
  } else if ($SRC == 'base2-jsb.js') {
    $PACKAGE = 'jsb/package.json';
    $fullBuild = true;
  }
} else {
  $SRC = '';
}
$HBASE = dirname(realpath("./header.txt"));
$PBASE = '';

if (!$PACKAGE && !$SRC) {
?>
<!doctype html>
<html>
<title>base2 build tool</title>
<style>
body {padding:0 20px;}
ul {padding:0; margin:0 1em;}
dd {margin:0 1em;}
dd p {margin:1ex 0;}
</style>

<h1>Build</h1>
<p>Use the <i>src</i> parameter to identify a package:</p>
<pre>    build.php?src=path/to/package.js</pre>
<p>Here are some examples:</p>
<dl>
<dt><a href="build.php?src=base2.js">build.php?src=base2.js</a>
<dd><p>just base2
<dt><a href="build.php?src=base2/dom.js">build.php?src=base2/dom.js</a>
<dd><p>just base2.dom
<dt><a href="build.php?src=base2-dom.js">build.php?src=base2-dom.js</a>
<dd><p>base2.dom and <em>all</em> dependencies
</dl>
<p>An alterntaive syntax is to use the <i>package</i> parameter.</p>
<p>This gives more fine-grained control for specific builds:</p>
<pre>
    ?package=path/to/package.json
</pre>
<p><i>path</i> is relative to <code>trunk/src</code>. Paths within the <code>package.json</code> file are relative to <code>package.json</code>.</p>
<p>To make a path relative to <code>trunk/src</code>, use "~/" at the start of the path.</p>
<p>To include all dependencies, add 'full' to the query string:</p>
<pre>    build.php?package=path/to/package.json&amp;full</pre>
<?php
	exit;
}

header('Content-Type: application/x-javascript');
header('Expires: ' . gmdate('D, d M Y H:i:s') . ' GMT');
header('Cache-Control: no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

if ($PACKAGE) {
  $PBASE = dirname($PACKAGE);

  print_header();

  $p = path_resolve($PACKAGE, $HBASE);
  $json = json_decode(file_get_contents($p), true);
  $package =  $json['_build'];
  $package['name'] = $json['name'];
  $package['version'] = $json['version'];

  if ($fullBuild) {
    $isLite = $package['lite'] == 'true';
  	if ($package['name'] != 'base2') {
      if ($isLite) {
  		  load_package(path_resolve('~/base2/lite.json',$PBASE), true);
      } else {
  		  load_package(path_resolve('~/base2/package.json',$PBASE), true);
      }
  	}
  }

  print_package($package, $PBASE, true);
} else {
  print_header();
	$load = explode(" ", preg_replace('/\.js$/', '', $SRC));
  foreach ($load as $index => $name) {
    $p = '~/';
    if ($index > 0) {
      $p .= 'base2/';
    }
    $p = path_resolve($p.$name.'/package.json', $PBASE);
    if (file_exists($p)) {
      load_package($p, true);
    } else {
      print_script($SRC);
    }
  }
}

function print_script($src) {
  print_banner($src);
  global $HBASE;
  $src = path_resolve($src, $HBASE);
  readfile($src);
}

function print_header() {
  readfile(path_resolve('~/header.txt'));
  print("\r\n// timestamp: ".gmdate('D, d M Y H:i:s')."\r\n");
}

function print_banner($message) {
	print("\r\n// =========================================================================\r\n");
	print('// '.$message);
	print("\r\n// =========================================================================\r\n");
}

// Paths are resolved relative to the current package.json,
// bootstrapped with path of build.php
// Home directory notation (~/) is relative to build.php
// Absolute path's are relative to the root
function path_resolve($path, $package = '') {
	global $HBASE;
	if (substr($path, 0, 2) == '~/') return $HBASE.substr($path, 1);
	if (substr($path, 0, 1) != '/') return $package."/".$path;
	return $path;
}

function load_package($path, $closure) {
  $json = json_decode(file_get_contents($path), true);
  $package =  $json['_build'];
  $package['name'] = $json['name'];
  $package['version'] = $json['version'];
	print_package($package, dirname($path), $closure);
}

function print_package($package, $pbase, $closure) {
	global $REG_JSON, $PBASE, $BASE, $fullBuild, $loaded, $isLite;

	$name = $package['name'];
  $version = $package['version'];
	$isCore = $name == 'base2';
  $require = $package['require'];

  if ($fullBuild && !$isCore) {
  	if ($require) {
    	$requirements = explode(',', $require);
      foreach ($requirements as $name) {
	      $name = preg_replace('/\:\w+/', '', $name);
        if (!isset($loaded[$name])) {
          $loaded[$name] = true;
	        $name = preg_replace('/\./', '/', $name);
          $jsFile = '~/'.$name.'.js';
          if (file_exists(path_resolve($jsFile))) {
            print_script($jsFile, true);
          } else {
            if ($isLite && $name == 'base2/dom') {
              load_package(path_resolve('~/'.$name.'/lite.json', $PBASE), true);
            } else {
              $jsonFile = path_resolve('~/'.$name.'/package.json', $PBASE);
              if (file_exists($jsonFile)) {
                load_package($jsonFile, true);
              }
            }
          }
        }
      }
    }
  }

	$name = $package['name'];
	
	$header = $package['header'];
	if ($header) {
    readfile(path_resolve($header, $pbase));
  }
  
  if (!$isCore && $name && !preg_match('/\./', $name)) {
    print("\r\nvar ".$name.";\r\n");
  }

  $globals = 'base2,Object,Array,Date,Function,RegExp,String,Error,RangeError,ReferenceError,SyntaxError,TypeError';
  
	if ($closure) {
    if ($isCore) {
      print("\r\nvar base2 = (function(".$globals.",getObject) { // begin: closure\r\n");
      print("\r\n\"use strict\";\r\n");
    } else {
      if ($require == '') {
        print("\r\nbase2.exec(function(_) { // begin: closure\r\n");
        print("\r\n\"use strict\";\r\n");
      } else {
	      $requires = preg_replace('/[\w+\.]+[\.:]/', '', $require);
        $requires = implode(', ', explode(',', $requires));
	      $require = preg_replace('/\:\w+/', '', $require);
        print("\r\nbase2.require(\"$require\", function(_, ".$requires.") { // begin: closure\r\n");
        print("\r\n\"use strict\";\r\n");
      }
    }
  } else if ($package['closure']) {
    print("\r\n(function() { // begin: closure\r\n");
    print("\r\n\"use strict\";\r\n");
  }
  
	$includes = $package['files'];
	foreach ($includes as $src) {
		$fileName = path_resolve($src, $pbase);
		if (preg_match($REG_JSON, $src)) {
      print_banner(preg_replace('/\./', '/', $name).'/'.$src);
			load_package($fileName, false);
		} else {
			if ($src != 'header.js' && $src != 'footer.js') {
        $title = preg_replace('/^\//', '', preg_replace('/[\w\-]+\/\.\./', '', preg_replace('/\./', '/', $name).'/'.$src));
        $title = preg_replace('/^[^~]+~\//', '', $title);
        print_banner($title);
      }
      $text = file_get_contents($fileName);
      $text = preg_replace('/%%VERSION%%/', $version, $text);
      echo($text);
		}
	}
	if ($closure) {
    if ($isCore) {
      $getObject = "function(objectID) {\r\n  try {\r\n    eval(\"arguments[2]=\" + objectID);\r\n  } catch(ex){}\r\n  return arguments[2];\r\n}";
      print("\r\nreturn base2;\r\n\r\n})(".$globals.",".$getObject."); // end: closure\r\n");
    } else {
      print("\r\n}); // end: closure\r\n");
    }
  } else if ($package['closure']) {
    print("\r\n})(); // end: closure\r\n");
  }
}
?>
