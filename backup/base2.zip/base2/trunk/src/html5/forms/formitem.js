
var formitem = behavior.extend({
  labels: null,

  get_labels: function(element) {
    return ? element.id
      ? this.findAll("label[for=" + element.id + "]")
      : new jsb.ExtendedNodeList;
  }
});
