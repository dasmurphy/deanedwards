
var label = behavior.extend({
  control: null,

  get_control: function(element) {
    return element.htmlFor ? this.find("#" + element.htmlFor) : null;
  }
});
