
registerElement("textarea", {
  "implements": [validation],
  
  autofocus: false,
  required: false,
  placeholder: "",

  onfocus: function(element) {
    if (this.get(element, "required")) {
      element.setAttribute("aria-required", "true");
    }
  }
}, formitem);
