
registerElement("datalist", {
  options: null,
  
  get_options: function(element) {
    return element.getElementsByTagName("option");
  }
});
