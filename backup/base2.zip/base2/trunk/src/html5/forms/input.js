
registerElement("input", {
  "implements": [validation],
  
  pattern: "",
  placeholder: "",
  autofocus: false,
  required: false,

  onfocus: function(element) {
    if (this.get(element, "required")) {
      element.setAttribute("aria-required", "true");
    }
  },

  get_valueAsNumber: function(element) {
    return _getChromeValue(element, _TYPE_NUMBER, NaN);
  },

  get_valueAsDate: function(element) {
    return _getChromeValue(element, _TYPE_DATE, null);
  },

  get_list: function(element) {
    var id = this.getAttribute(element, "list");
    return id ? this.find("#" + id) : null;
  },
  
  stepDown: function(element, n) {
    _step(element, -n);
  },

  setUp: function(element, n) {
    _step(element, n);
  }
}, formitem);
