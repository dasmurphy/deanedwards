
var ValidityState = _.Base.extend({
});
