
jsb.createStyleSheet(html5.cssParser.parse(jsb.theme.cssText));

var noValidation = {
  formNoValidate: false,
  get_willValidate: K(false),
  checkValidity: _.True,
  setCustomValidity: html5.NOT_SUPPORTED
};

var TYPE_DATE   = /^(date|month|time|week)$/,
    TYPE_NUMBER = /^(number|range|date|month|time|week)$/;

var registerElement = _.detect("(document.implementation.hasFeature('WebForms','2.0'))") ? _.Undefined : function(tagName, _interface, ancestor) {
  html5[tagName] = (ancestor || behavior).extend(_interface);
};

function _getChromeValue(element, TYPE, defaultValue) {
  var type = getAttribute(element, "type");
  if (TYPE.test(type)) {
    var control = chrome.getBehavior(element);
    if (control) {
      if (TYPE == TYPE_DATE) {
        return control.getValueAsDate(element, true);
      } else {
        return control.getValueAsNumber(element, true);
      }
    }
  }
  return defaultValue;
}

// I'm not sure that I can really support this.
// I don't want to make form submission too complicated.
/*function _getFormOwner(element) {
  var form = getAttribute(element, "form");
  if (form) return querySelector(document, "#" + form);
  form = element;
  while (form && form.nodeName !== "FORM") form = form.parentNode;
  return form || null;
};*/

function _step(element, n) {
  var control = chrome.getBehavior(element);
  if (control && control.increment) {
    control.increment(element, n);
  }
}
