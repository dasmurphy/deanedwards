
var DragEvent = dom.Event.extend({
  "@!(document.createEvent('DragEvents'))": {
    initDragEvent: function(event, type, bubbles, cancelable, view, detail, dataTransfer) {
      this.initEvent(event, type, bubbles, cancelable);
      this.view = view || window;
      this.detail = detail;
      this.dataTransfer = new DataTransfer;
    }
  }
});
