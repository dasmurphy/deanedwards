
var DataTransfer = _.Base.extend({
  constructor: function() {
    var _data = {};
    var _elements = {};
    var _dragImage;

    this.clearData = function(format) {
      delete _data[format];
    };

    this.setData = function(format, data) {
      _data[format] = data;
    };

    this.getData = function(format) {
      return _data[format];
    };

    this.setDragImage = function(image, x, y) {
      _dragImage = {
        image: image,
        x: x,
        y: y
      };
    };

    this.addElement = function(element) {
      _elements[_.assignID(element)] = element;
    };
  },
  
  dropEffect: "none",
  effectAllowed: "uninitialized",
  
  addElement: _.Undefined,
  clearData: _.Undefined,
  getData: _.Undefined,
  setData: _.Undefined,
  setDragImage: _.Undefined,
});
