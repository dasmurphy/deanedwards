
var CANVAS_JS = "canvas.js#html5.canvas";
;doc; CANVAS_JS = "canvas.php#html5.canvas";

/*var _hasSilverlight = false;
try {
  new ActiveXObject('AgControl.AgControl');
  _hasSilverlight = true;
} catch (ex) {}*/

registerElement("canvas", {
  detect: "getContext",

  display: "block",

  // if <canvas> is not implemented then we can at least support it for MSIE
  //behavior: _.detect("MSIE") ? _CANVAS_JS + "#html5.canvas_" + (_hasSilverlight ? "silverlight" : "vml") : null,
  behavior: _.detect("MSIE") ? CANVAS_JS : null,
  
  methods: "getContext"
});
