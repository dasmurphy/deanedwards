
function registerElement(tagName, definition) {
  var element = document.createElement(tagName);
  if (definition) {
    if (typeof definition == "string") {
      definition = {display: definition};
    } else {
      definition = _.extend({}, definition, true);
    }
    if (!(definition.detect in element)) {
      var style = definition.style,
          behavior = definition.behavior;
      if (definition.display) {
        if (!style) style = {};
        style.display = definition.display;
        if (style.display.indexOf("block") === 0 && !style.margin) {
          style.margin = "1em 0"; // default margin for block elements
        }
      }
      if (style) {
        if (styleSheet[tagName]) {
          _.extend(styleSheet[tagName], style, true);
        } else {
          styleSheet[tagName] = style;
        }
      }
      if (definition.extraStyles) {
        _.extend(styleSheet, definition.extraStyles, true);
      }
      if (behavior) {
        if (typeof behavior == "string") {
          behavior = HOST + behavior;
        } else {
          if (!jsb.element.ancestorOf(behavior)) {
            behavior = jsb.element.extend(behavior);
          }
          html5[tagName] = behavior;
        }
        rules[tagName] = behavior;
      }
      if (definition.extraRules) {
        _.extend(rules, definition.extraRules, true);
      }
    } else {
      var placeholder = html5[tagName] = jsb.element.extend();
      if (definition.methods) forEach.csv (definition.methods, function(name) {
        placeholder[name] = function(element) {
          return element[name].apply(element, _.slice(arguments, 1));
        };
      });
    }
  }
}
