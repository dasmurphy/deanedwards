
registerElement("time", {
  detect:  "dateTime",

  display: "inline",
  
  behavior: {
    dateTime: "",
    pubDate: false,
    
    "jsb:onattach": time_layout,

    get_valueAsDate: function(element, propertyName) {
      var dateTime = this.hasAttribute(element, "datetime") ?
        this.parseDateFromAttribute(element) :
        this.parseDateFromText(element);
      return isNaN(dateTime) ? null : new Date(dateTime);
    },

    parseDateFromAttribute: function(element) {
      var dateTime = this.get(element, "dateTime");
      if (dateTime) {
        if (dateTime.indexOf("T") === -1) dateTime += "T";
        return Date.parse(dateTime);
      }
      return NaN;
    },

    parseDateFromText: function(element) {
      var textContent = _.trim(this.get(element, "textContent"));
      var dateTime = Date.parse(textContent);
      if (!isNaN(dateTime)) return dateTime;
      dateTime = Date.parse(textContent + "T");
      if (!isNaN(dateTime)) return dateTime;
      dateTime = Date.parse("T" + textContent);
      return dateTime;
    },

    layout: time_layout
  }
});

function time_layout(element) {
  if (!this.get(element, "textContent")) {
    var dateTime = this.parseDateFromAttribute(element);
    if (!isNaN(dateTime)) {
      dateTime = new Date(dateTime);
      var showTime = this.get(element, "dateTime").indexOf("T") !== -1;
      if (Date.prototype.toLocaleString) {
        var textContent = showTime ? dateTime.toLocaleString() : dateTime.toLocaleDateString();
      } else {
        textContent = showTime ? dateTime : dateTime.toDateString();
      }
      this.set(element, "textContent", textContent);
    }
  }
}