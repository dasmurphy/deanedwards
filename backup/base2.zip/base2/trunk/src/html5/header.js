
var undefined;
var _private = _._;
var K        = _.K;
var base2    = _.base2;
var forEach  = _.forEach;

var document = window.document;

var SUPPORTS_BORDER_BOX  = _.detect("QuirksMode") || (7 !== document.documentMode && _.detect("(style.boxSizing)"));
    
var HOST          = jsb.host,
    IMAGES_URL    = HOST + "images/";

var styleSheet = {
  "[hidden],datalist,menu[type=context]": {
    display: "none",
    visibility: "collapse"
  }
};

var rules = {};
