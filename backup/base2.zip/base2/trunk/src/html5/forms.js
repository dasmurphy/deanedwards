
/* Web Forms 2.0 */

var SUPPORTS_WEB_FORMS_2 = _.detect("(document.implementation.hasFeature('WebForms','2.0'))"); // -@DRE

var FORMS_JS = HOST + "forms.js";
;doc; FORMS_JS = HOST + "forms.php";

var FORMS_METHODS = "checkValidity,setCustomValidity";

var _input = document.createElement("input");

// Opera does not support the "color" type.
// This is because it was specified after the publication of WF2.
// Hopefully, this will be the only such anomaly.
if (SUPPORTS_WEB_FORMS_2) {
  try {
    _input.type = "color";
  } catch (ex) {}
}
if (_input.type !== "color") {
  rules["input[type=color]"] = FORMS_JS + "#chrome.colorpicker";
}

forEach ({
  form: "checkValidity,dispatchFormChange,dispatchFormInput",
  fieldset: FORMS_METHODS,
  input: FORMS_METHODS + ",stepUp,stepDown",
  output: FORMS_METHODS,
  select: FORMS_METHODS,
  textarea: FORMS_METHODS
}, function(methods, tagName) {
  registerElement(tagName, {detect: "checkValidity", methods: methods});
});

if (!SUPPORTS_WEB_FORMS_2) {
  _.extend(rules, {
    "form": FORMS_JS + "#html5.form",
    "button,input,textarea,select,datalist,label,fieldset": FORMS_JS + "#chrome",
    "input[type=number]": FORMS_JS + "#chrome.spinner",
    "input[type=range]": FORMS_JS + "#chrome.slider",
    "input[type=date]": FORMS_JS + "#chrome.datepicker",
    "input[type=month]": FORMS_JS + "#chrome.monthpicker",
    "input[type=week]": FORMS_JS + "#chrome.weekpicker",
    "input[type=time]": FORMS_JS + "#chrome.timepicker",
    "input[list]": FORMS_JS + "#chrome.combobox"
  });
  if (!("autofocus" in _input)) {
    rules["button[autofocus],input[autofocus],textarea[autofocus],select[autofocus]"] = {
      "jsb:onattach": function(element) {
        try {
          element.focus();
          if (element.select) element.select();
        } catch (ex) {}
      }
    };
  }
  styleSheet[".html5-template"] = {display:"none!"};
}
