
html5.TimeRanges = _.Base.extend({
  length: 0,
  
  start: _.Undefined,
  end: _.Undefined
});
