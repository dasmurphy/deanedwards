
forEach.csv("every,filter,forEach,indexOf,lastIndexOf,map,reduce,reduceRight,slice,some", function(name) {
  ArrayLike_methods[name] = Array_prototype[name];
});

ArrayLike = Trait.extend(ArrayLike_methods);

var ArrayLike_map = ArrayLike.map;
