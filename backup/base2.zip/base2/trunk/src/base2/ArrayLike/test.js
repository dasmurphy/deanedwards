
Collection.implement(ArrayLike);

var ArrayLike_enumerable = {
  every: 1,
  filter: 1,
  forEach: 1,
  map: 1,
  reduce: 1,
  reduceRight: 1,
  some: 1
};

ArrayLike.test = function ArrayLike_test(object, method, args) {
  if (object == null) return false;

  switch (typeof object) {
    case "string": break;

    case "function": if (object.call) return false;
      // fall through to catch Safari NodeLists

    case "object":
      if (typeof object.length == "number") break;
      if (/*@ object.imap && @*/ object instanceof Collection) break;

    default:
      return false;
  }

  if (ArrayLike_enumerable[method] && typeof args[1] != "function") {
    return FUNCTION_REQUIRED_ERR;
  }

  return true;
};
