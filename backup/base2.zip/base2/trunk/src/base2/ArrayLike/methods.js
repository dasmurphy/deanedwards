
var ArrayLike_methods = {
  invoke: function ArrayLike__invoke(method /*, arg1, ..., argN */) {
    // Apply a method to each item in the enumerated object.
    var args = arguments.length > 1 ? Array__slice.call(arguments, 1) : null;

    switch (typeof method) {
      case "function":
        var invoker = args ? function _invoker(item) {
          return item == null ? undefined : method.apply(item, args);
        } : function _invoker(item) {
          return item == null ? undefined : method.call(item);
        };
        break;

      case "string":
        invoker = args ? function _invoker(item) {
          return item == null ? undefined : item[method].apply(item, args);
        } : function _invoker(item) {
          return item == null ? undefined : item[method]();
        };
        break;

      default:
        throw TypeError(Target(FUNCTION_REQUIRED_ERR, "invoke", this));
    }

    return ArrayLike_map(this, invoker);
  },

  plant: function ArrayLike__plant(propertyName, value) {
    forEach (this, function _planter(item) {
      if (item != null) item[propertyName] = value;
    });
  },

  pluck: function ArrayLike__pluck(propertyName) {
    return ArrayLike_map(this, function _plucker(item) {
      return item == null ? undefined : item[propertyName];
    });
  }
};
