
// A class for reading/writing the local file system. Works for Moz/IE/Rhino/WSH

var LocalFile = _.Base.extend({
  constructor: function LocalFile__constructor(path) {
    this.toString = _.K(FileSystem.resolve(LocalFileSystem.getPath(), path));
  },
  
  close: _INVALID_MODE,
  open: NOT_SUPPORTED,
  read: _INVALID_MODE,
  write: _INVALID_MODE,
  
  writeln: function LocalFile__writeln(text) {
    this.write(text + "\r\n");
  },

  "@(ActiveXObject)": {
    open: function LocalFile__open(mode) {
      var path = LocalFileSystem.toNativePath(this);
      var fso = new ActiveXObject("Scripting.FileSystemObject");
      
      switch (mode) {
        case READ:
          if (!fso.FileExists(path)) {
            throw new ReferenceError(FILE_DOES_NOT_EXIST + this);
          }
          var stream = fso.OpenTextFile(path, 1);
          this.read = function LocalFile__read() {
            return stream.ReadAll();
          };
          break;
          
        case WRITE:
          stream = fso.OpenTextFile(path, 2, true);
          this.write = function LocalFile__write(text) {
            stream.Write(text || "");
          };
          break;
      }
      
      this.close = function LocalFile__close() {
        stream.Close();
        delete this.read;
        delete this.write;
        delete this.close;
      };
    }
  },

  "@(Components)": { // XPCOM
    open: function LocalFile__open(mode) {
      var file = _xpcom_createFile(this);
      
      switch (mode) {
        case READ:
          if (!file.exists()) {
            throw new ReferenceError(FILE_DOES_NOT_EXIST + this);
          }
          var input = XPCOM.createObject("network/file-input-stream;1", "nsIFileInputStream");
          input.init(file, 1, 4, null);
          var stream = XPCOM.createObject("scriptableinputstream;1", "nsIScriptableInputStream");
          stream.init(input);
          this.read = function LocalFile__read() {
            return stream.read(stream.available());
          };
          break;
          
        case WRITE:
          if (!file.exists()) file.create(0, 436);
          stream = XPCOM.createObject("network/file-output-stream;1", "nsIFileOutputStream");
          stream.init(file, 34, 4, null);
          this.write = function LocalFile__write(text) {
            if (text == null) text = "";
            stream.write(text, text.length);
          };
          break;
      }
      
      this.close = function LocalFile__close() {
        if (mode == WRITE) stream.flush();
        stream.close();
        
        delete this.read;
        delete this.write;
        delete this.close;
      };
    }
  },

  "@!(Components)": {
    "@(java)": {
      open: function LocalFile__open(mode) {
        var path = LocalFileSystem.toNativePath(this);
        var io = java.io;

        switch (mode) {
          case READ:
            var file = _java_createFile(this);
            if (!file.exists()) {
              throw new ReferenceError(FILE_DOES_NOT_EXIST + this);
            }
            var stream = new io.BufferedReader(new io.FileReader(path));
            this.read = function LocalFile__read() {
              var lines = [], line, i = 0;
              while ((line = stream.readLine()) != null) {
                lines[i++] = line;
              }
              return lines.join("\r\n");
            };
            break;

          case WRITE:
            stream = new io.PrintStream(new io.FileOutputStream(path));
            this.write = function LocalFile__write(text) {
              stream.print(text || "");
            };
            break;
        }

        this.close = function LocalFile__close() {
          stream.close();

          delete this.read;
          delete this.write;
          delete this.close;
        };
      }
    }
  }
});
