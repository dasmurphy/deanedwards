
var LocalFileSystem = FileSystem.extend({
  constructor: function LocalFileSystem__constructor(path) {
    this.path = LocalFileSystem.getPath();
    this.base(path);
  },

  backup: function LocalFileSystem__backup(path, extension) {
    if (this.isFile(path)) {
      if (!extension) extension = ".backup";
      this.write(path + extension, this.read(path));
    }
  },
  
  read: function LocalFileSystem__read(path) {
    if (this.isDirectory(path)) {
      return new LocalDirectory(this.makepath(path));
    } else {
      var file = new LocalFile(this.makepath(path));
      file.open(READ);
      try {
        var text = file.read();
      } finally {
        file.close();
      }
      return text;
    }
  },

  write: function LocalFileSystem__write(path, text) {
    var file = new LocalFile(this.makepath(path));
    file.open(WRITE);
    try {
      file.write(text);
    } finally {
      file.close();
    }
  },

  "@(ActiveXObject)": {
    copy: function LocalFileSystem__copy(path1, path2) {
      _activex_exec(this.isDirectory(path1) ? "CopyFolder" : "CopyFile", this.makepath(path1), this.makepath(path2), true);
    },

    exists: function LocalFileSystem__exists(path) {
      return this.isFile(path) || this.isDirectory(path);
    },

    isFile: function LocalFileSystem__isFile(path) {
      return _activex_exec("FileExists", this.makepath(path));
    },
    
    isDirectory: function LocalFileSystem__isDirectory(path) {
      return _activex_exec("FolderExists", this.makepath(path));
    },
  
    mkdir: function LocalFileSystem__mkdir(path) {
      _activex_exec("CreateFolder", this.makepath(path));
    },
    
    move: function LocalFileSystem__move(path1, path2) {
      _activex_exec(this.isDirectory(path1) ? "MoveFolder" : "MoveFile", this.makepath(path1), this.makepath(path2));
    },
    
    remove: function LocalFileSystem__remove(path) {
      if (this.isFile(path)) {
        _activex_exec("DeleteFile", this.makepath(path));
      } else if (this.isDirectory(path)) {
        _activex_exec("DeleteFolder", this.makepath(path));
      }
    }
  },

  "@(Components)": { // XPCOM
    copy: function LocalFileSystem__copy(path1, path2) {
      var file1 = _xpcom_createFile(this.makepath(path1));
      var file2 = _xpcom_createFile(this.makepath(path2));
      
      file1.copyTo(file2.parent, file2.leafName);
    },
    
    exists: function LocalFileSystem__exists(path) {
      return _xpcom_createFile(this.makepath(path)).exists();
    },
    
    isFile: function LocalFileSystem__isFile(path) {
      var file = _xpcom_createFile(this.makepath(path));
      return file.exists() && file.isFile();
    },
    
    isDirectory: function LocalFileSystem__isDirectory(path) {
      var file = _xpcom_createFile(this.makepath(path));
      return file.exists() && file.isDirectory();
    },
  
    mkdir: function LocalFileSystem__mkdir(path) {
      _xpcom_createFile(this.makepath(path)).create(1);
    },
    
    move: function LocalFileSystem__move(path1, path2) {
      var file1 = _xpcom_createFile(this.makepath(path1));
      var file2 = _xpcom_createFile(this.makepath(path2));
      file1.moveTo(file2.parent, file2.leafName);
    },
    
    remove: function LocalFileSystem__remove(path) {
      _xpcom_createFile(this.makepath(path)).remove(false);
    }
  },

  "@!(Components)": {
    "@(java)": {
      exists: function LocalFileSystem__exists(path) {
        return _java_createFile(this.makepath(path)).exists();
      },

      isFile: function LocalFileSystem__isFile(path) {
        return _java_createFile(this.makepath(path)).isFile();
      },

      isDirectory: function LocalFileSystem__isDirectory(path) {
        return _java_createFile(this.makepath(path)).isDirectory();
      },

      mkdir: function LocalFileSystem__mkdir(path) {
        _java_createFile(this.makepath(path)).mkdir();
      },

      move: function LocalFileSystem__move(path1, path2) {
        var file1 = _java_createFile(this.makepath(path1));
        var file2 = _java_createFile(this.makepath(path2));
        file1.renameTo(file2);
      },

      remove: function LocalFileSystem__remove(path) {
        _java_createFile(this.makepath(path))["delete"]();
      }
    }
  }
}, {
  fromNativePath: _.I,
  toNativePath: _.I,

  supported: false,

  getPath: _.K("/"),

  "@(jscript)": _win_formatter,
  "@Win(32|64)": _win_formatter,

  "@!(Components)": {
    "@(java)": {
      "@(java.io.File.separator=='\\\\')": _win_formatter,
      getPath: function LocalFileSystem_getPath_java() {
        return this.fromNativePath(new java.io.File("").getAbsolutePath());
      }
    }
  },

  "@(ActiveXObject)": {
    getPath: function LocalFileSystem_getPath_activex() {
      var fso = new ActiveXObject("Scripting.FileSystemObject");
      var path = this.fromNativePath(fso.GetFolder(".").path);
      if (!/\/$/.test(path)) path += "/";
      return path;
    }
  },

  "@(location)": {
    getPath: function LocalFileSystem_getPath_browser() {
      return decodeURIComponent(location.pathname.replace(_TRIM_PATH, ""));
    }
  }
});

forEach.csv("copy,move", function(method) {
  _.extend(LocalFileSystem.prototype, method, function(path1, path2, overwrite) {
    if (!this.exists(path1)) {
      throw new ReferenceError(FILE_DOES_NOT_EXIST + path1);
    }
    if (this.exists(path2)) {
      if (overwrite) {
        this.remove(path2);
      } else {
        throw new ReferenceError("File already exists: " + path2);
      }
    }
    this.base(path1, path2);
  });
});

if (_.detect("(Components)")) {
  XPCOM.privelegedObject(LocalFileSystem.prototype);
}
