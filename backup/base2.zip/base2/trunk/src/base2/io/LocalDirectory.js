
var LocalDirectory = Directory.extend({
  "@(ActiveXObject)": {
    constructor: function LocalDirectory_activex(path) {
      this.base();
      
      if (typeof path == "string") {
        var directory = _activex_exec("GetFolder", path);
        forEach ([directory.SubFolders, directory.Files], function(list) {
          var enumerator = new Enumerator(list);
          while (!enumerator.atEnd()) {
            var file = enumerator.item();
            this.set(file.Name, file);
            enumerator.moveNext();
          }
        }, this);
      }
    }
  },

  "@(Components)": { // XPCOM
    constructor: function LocalDirectory_xpcom(path) {
      this.base();
      
      if (typeof path == "string") {
        var file = _xpcom_createFile(path);
        var directory = file.directoryEntries;
        var enumerator = directory.QueryInterface(Components.interfaces.nsIDirectoryEnumerator);
        while (enumerator.hasMoreElements()) {
          file = enumerator.nextFile;
          this.set(file.leafName, file);
        }
      }
    }
  },

  "@(!Components)": {
    "@(java)": {
      constructor: function LocalDirectory_java(path) {
        this.base();

        if (typeof path == "string") {
          var file = _java_createFile(path);
          var directory = file.list();
          for (var i = 0; i < directory.length; i++) {
            file = new java.io.File(directory[i]);
            this.set(file.getName(), file);
          }
        }
      }
    }
  }
}, {
  Item: {
    "@(ActiveXObject)": {
      constructor: function LocalDirectory_Item_activex(name, file) {
	      this.name = String(name);
	      this.isDirectory = "SubFolders" in file;
	      this.size = this.isDirectory ? 0 : file.Size || 0;
      }
    },

    "@(Components)": {
      constructor: function LocalDirectory_Item_xpcom(name, file) {
	      this.name = String(name);
	      this.isDirectory = file.isDirectory();
	      this.size = this.isDirectory ? 0 : file.fileSize || 0;
      }
    },

    "@(!Components)": {
      "@(java)": {
        constructor: function LocalDirectory_Item_java(name, file) {
		      this.name = String(name);
		      this.isDirectory = file.isDirectory();
		      this.size = this.isDirectory ? 0 : file.length() || 0;
        }
      }
    }
  }
});
