
var LocalDirectory = Directory.extend({
  "@(ActiveXObject)": {
    constructor: function LocalDirectory__constructor_activex(path) {
      this.base();
      
      if (typeof path == "string") {
        var directory = _activex_exec("GetFolder", path);
        forEach ([directory.SubFolders, directory.Files], function(list) {
          var enumerator = new Enumerator(list);
          while (!enumerator.atEnd()) {
            var file = enumerator.item();
            this.set(file.Name, file);
            enumerator.moveNext();
          }
        }, this);
      }
    }
  },

  "@(Components)": { // XPCOM
    constructor: function LocalDirectory__constructor_xpcom(path) {
      this.base();
      
      if (typeof path == "string") {
        var file = _xpcom_createFile(path);
        var directory = file.directoryEntries;
        var enumerator = directory.QueryInterface(Components.interfaces.nsIDirectoryEnumerator);
        while (enumerator.hasMoreElements()) {
          file = enumerator.nextFile;
          this.set(file.leafName, file);
        }
      }
    }
  },

  "@(!Components)": {
    "@(java)": {
      constructor: function LocalDirectory__constructor_java(path) {
        this.base();

        if (typeof path == "string") {
          var file = _java_createFile(path);
          var directory = file.list();
          for (var i = 0; i < directory.length; i++) {
            file = new java.io.File(directory[i]);
            this.set(file.getName(), file);
          }
        }
      }
    }
  }
}, {
  Item: {
    "@(ActiveXObject)": {
      constructor: function LocalDirectory_Item__constructor_activex(name, file) {
        this.base(name, file.Type | 16, file.Size);
      }
    },

    "@(Components)": {
      constructor: function LocalDirectory_Item__constructor_xpcom(name, file) {
        this.base(name, file.isDirectory(), file.fileSize);
      }
    },

    "@(!Components)": {
      "@(java)": {
        constructor: function LocalDirectory_Item__constructor_java(name, file) {
          this.base(name, file.isDirectory(), file.length());
        }
      }
    }
  }
});
