
var undefined;
var base2    = _.base2;
var forEach  = _.forEach;

function NOT_SUPPORTED() {
  throw Error("Not supported.");
}

function _INVALID_MODE() {
  throw TypeError("Invalid file open mode.");
}

var READ = 1, WRITE = 2;

var _RELATIVE       = /\/[^\/]+\/\.\./,
    _TRIM_PATH      = /[^\/]+$/,
    _SLASH          = /\//g,
    _BACKSLASH      = /\\/g,
    _LEADING_SLASH  = /^\//,
    _TRAILING_SLASH = /\/$/;

var FILE_DOES_NOT_EXIST = "File does not exist: ";

var _win_formatter = {
  fromNativePath: function LocalFileSystem_fromNativePath(path) {
    return "/" + String(path).replace(_BACKSLASH, "/");
  },

  toNativePath: function LocalFileSystem_toNativePath(path) {
    return String(path).replace(_LEADING_SLASH, "").replace(_SLASH, "\\");
  }
};

function _makeNativeAbsolutePath(path) {
  return LocalFileSystem.toNativePath(FileSystem.resolve(LocalFileSystem.getPath(), path));
};

var _fso; // FileSystemObject
function _activex_exec(method, path1, path2, flags) {
  if (!_fso) _fso = new ActiveXObject("Scripting.FileSystemObject");
  path1 = _makeNativeAbsolutePath(path1);
  if (arguments.length > 2) {
    path2 = _makeNativeAbsolutePath(path2);
  }
  switch (arguments.length) {
    case 2: return _fso[method](path1);
    case 3: return _fso[method](path1, path2);
    case 4: return _fso[method](path1, path2, flags);
  }
  return undefined; // Prevent strict warnings
}

function _xpcom_createFile(path) {
  var file = XPCOM.createObject("file/local;1", "nsILocalFile");
  file.initWithPath(_makeNativeAbsolutePath(path));
  return file;
}

function _java_createFile(path) {
  return new java.io.File(_makeNativeAbsolutePath(path));
}
