
/*@
function createCOMObject(libName) {
  var progId = "MSXML2." + libName + "." + msXmlVersion + ".0";
  return typeof ActiveXObject == "function" ? new ActiveXObject(progId) : WScript.CreateObject(progId);
};

// http://blogs.msdn.com/xmlteam/archive/2006/10/23/using-the-right-version-of-msxml-in-internet-explorer.aspx
var msXmlVersion = 6;
try {
  var xhr = createCOMObject("XMLHTTP");
} catch (ex1) {
  msXmlVersion = 3;
  try {
    xhr = createCOMObject("XMLHTTP");
  } catch (ex2) {
    msXmlVersion = 0;
  }
}
_private.createCOMObject = createCOMObject;

xhr = null;

if (typeof XMLHttpRequest == "undefined") {
  provides.XMLHttpRequest = function XMLHttpRequest() {
    return createCOMObject("XMLHTTP");
  };
}
@*/
