
base2.exec(function(_) { // begin: closure

var _private = _._;
var forEach  = _.forEach;

var Blob = _.Base.extend({
  constructor: function Blob__constructor(data) {
    data = data || "";
    var properties = _private.createGetters({
      size: data.length,
      type: ""
    });
    this.toString = _.K("[object Blob]");
    this.toString.data = data;
  },

  slice: _.Undefined
});

var BlobBuilder = _.Base.extend({
  constructor: function Blob__constructor(data) {
    this.toString = _.K("[object BlobBuilder]");
    this.toString.data = data || "";
  },

  append: function BlobBuilder__append(data) {
    switch (data.constructor) {
    }
    this.toString.data += data;
  }
});

}); // end: closure
