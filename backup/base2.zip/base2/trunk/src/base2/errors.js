
var OBJECT_REQUIRED_ERR   = "Object required by {0}().";
var FUNCTION_REQUIRED_ERR = "Function required by {0}().";

function ArityError(method, object) {
  this.message = formatErrorMessage("Not enough arguments for {0}().", method, object);
}
ArityError.prototype = new SyntaxError;

function TargetError(message, method, object) {
  this.message = formatErrorMessage(message, method, object);
}
TargetError.prototype = new TypeError;

function formatErrorMessage(message, method, object) {
  if (method == null) {
    return message.replace(" by {0}()", "");
  } else {
    if (object) {
      if (!method || method in object) {
        var separator = ".";
        if (typeof object == "object") {
          object = object.constructor;
          separator = "::";
        }
        if (typeof object == "function") {
          if (object == Namespace) {
            object = "_";
            separator = ".";
          } else {
            object = getClassName(object);
            if (!object) separator = "";
          }
        }
        method = object + separator + method;
      }
    }
    return format(message, method, object || "");
  }
}
