
var BASE_CALL = /return/.test(K) ? /\.base[.(]/ : True; // some platforms don't allow decompilation

var _prototyping_ = false;

function Base(properties) {
  if (properties && this instanceof Base) {
    extend(this, properties);
  }
}

;;; Base["#implements"] = [];
;;; Base["#implemented_by"] = [];

Base.prototype.toString = function toString() {
  return "[object " + getClassName(this.constructor, "Base") + "]";
};

function base() {
  // call this method from any other method to invoke that method's ancestor
}

Base.prototype.base = base;

var Base_static = {
  ancestor: null,
  
  ancestorOf: function Base_ancestorOf(klass) {
    return klass && klass.prototype instanceof this;
  },

  base: base,

  extend: function Base_extend(_instance, _static) {
    // Build the prototype.
    var proto = pcopy(this.prototype);
    if (_instance) {
      _prototyping_ = true;
      extend(proto, _instance);
      _prototyping_ = false;
    }
    proto.base = base;
    var subclass = proto.constructor;
    if (subclass == this) {
      subclass = proto.constructor = _inheritConstructor(this);
    }
    subclass.prototype = proto;

    // Build the static interface.
    for (var i in Base_static) subclass[i] = this[i];
    if (_static) extend(subclass, _static);
    subclass.ancestor = this;

    ;;; // introspection (removed when packed)
    ;;; delete subclass._underlyingFunction;
    ;;; subclass["#implements"] = [];
    ;;; subclass["#implemented_by"] = [];

    return subclass;
  },

  implement: function Base_implement(properties) {
    if (properties == null) throw new TargetError(OBJECT_REQUIRED_ERR, "implement", this);

    if (typeof properties == "function") {
      ;;; // introspection (removed when packed)
      ;;; if (properties.prototype instanceof Base) {
      ;;;   this["#implements"].push(properties);
      ;;;   properties["#implemented_by"].push(this);
      ;;; }
      if (Trait.ancestorOf(properties) && !properties.test(this.prototype)) {
        throw new TargetError(TRAIT_INVALID_TARGET_ERR, "", properties);
      }
      properties = properties.prototype;
    }
    // Add the interface using the extend() function.
    if (typeof properties == "object") {
      extend(this.prototype, properties);
    }
    return this;
  }
};

for (var name in Base_static) {
  Base[name] = Base_static[name];
}

// help

function _inheritConstructor(superClass) {
  var subClass = function _Faux__constructor() {
    arguments.length === 0 ? superClass.call(this) : superClass.apply(this, arguments);
    return this;
  };
  ;;; subClass.toString = K(String(superClass));
  return subClass;
}

function getClassName(klass) {
  return klass.toString._pretty ? klass.toString().slice(1, -1) : "";
}
