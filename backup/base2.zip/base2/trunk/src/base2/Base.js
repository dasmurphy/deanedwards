
var BASE_CALL = /return/.test(K) ? /\.base[.(]/ : True; // some platforms don't allow decompilation

function Base(object) {
  if (object) {
    if (/*@ this.valueOf && @*/ this instanceof Base) {
      object = extend(this, object, true);
    } else {
      object = extend(object, object, true);
      for (var i in object) if (i < "A" && i > "@") {
        delete object[i];
      }
    }
  }
  return object;
}

;doc; Base["#implements"] = [];
;doc; Base["#implemented_by"] = [];

Base.prototype.toString = function toString() {
  return "[object " + (getClassName(this.constructor) || "Base") + "]";
};

var Base_static = {
  ancestor: null,

  ancestorOf: function Base_ancestorOf(subclass) {
    return subclass && subclass.prototype instanceof this;
  },

  extend: function Base_extend(_instance, _static) {
    // Build the prototype.
    var proto = pcopy(this.prototype);
    if (_instance) {
      extend(proto, _instance, true);
    }
    var subclass = proto.constructor;
    if (subclass == this) {
      subclass = proto.constructor = _inheritConstructor(this);
    }
    subclass.prototype = proto;

    // Build the static interface.
    for (var i in Base_static) subclass[i] = this[i];
    if (_static) extend(subclass, _static, true);
    subclass.ancestor = this;

    ;doc; subclass["#implements"] = [];
    ;doc; subclass["#implemented_by"] = [];

    return subclass;
  },

  implement: function Base_implement(_interface) {
    if (typeof _interface == "function") {
      ;doc; if (_interface.prototype instanceof Base) {
      ;doc;   this["#implements"].push(_interface);
      ;doc;   _interface["#implemented_by"].push(this);
      ;doc; }

      if (Trait.ancestorOf(_interface) && !_interface.test(this.prototype)) {
        throw new TargetError(TRAIT_INVALID_TARGET_ERR, "", _interface);
      }

      _interface = _interface.prototype;
    }

    // Add the interface using the extend() function.
    if (typeof _interface == "object") {
      extend(this.prototype, _interface, true);
    }
    return this;
  }
};

for (var name in Base_static) {
  Base[name] = Base_static[name];
}

// help

function _inheritConstructor(superClass) {
  var Anonymous = function Anonymous() {
    arguments.length === 0 ? superClass.call(this) : superClass.apply(this, arguments);
  };
  ;doc; Anonymous._underlyingFunction = superClass._underlyingFunction || superClass;
  return Anonymous;
}

var FUNCTION_NAME = /^\s*function\s+(\w+)\s*\(/;

function getClassName(object) {
  return object.toString._pretty
    ? object.toString().slice(1, -1)
    : FUNCTION_NAME.test(object)
      ? String(object).match(FUNCTION_NAME)[1].replace("__constructor", "")
      : "";
}
