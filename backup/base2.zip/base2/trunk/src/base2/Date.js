
// http://developer.mozilla.org/es4/proposals/date_and_time.html

var NativeDate_parse = Date.parse;
var Date_prototype   = Date.prototype;

var SUPPORTS_ISO_DATE = NativeDate_parse("1970-01-01") === 0;

// big, ugly, regular expression
var DATE_PATTERN = /^(([+-]\d{6}|\d{4})(-(\d{2})(-(\d{2}))?)?)?(T(\d{2}):(\d{2})((:(\d{2})(\.(\d{1,3})(\d)?\d*)?)?)?)?(([+-])(\d{2})(:(\d{2}))?|Z)?$/;

var DATE_PARTS = "FullYear,Month,Date,Hours,Minutes,Seconds,Milliseconds".split(",");
for (var i = 0; i < 7; i++) DATE_PARTS[DATE_PARTS[i]] = i * 2 + 2;
DATE_PARTS.Minutes = 9;

var TIMEZONE_PARTS = {
  precision: 15,
  UTC: 16,
  Sign: 17,
  Hours: 18,
  Minutes: 20
};

now = preferNativeMethod(Date, "now", function now() {
  return +new Date;
});

function base2_Date(yy, mm, dd, h, m, s, ms) { // faux constructor
  if (!this || this.constructor != Date) {
    var date = Date();
  } else {
    switch (arguments.length) {
      case 0:
        date = new Date;
        break;

      case 1:
        date = String(yy) === yy ? new Date(Date_parse(yy)) : new Date(+yy);
        break;

      default:
        date = new Date(yy, mm, arguments.length === 2 ? 1 : dd, h || 0, m || 0, s || 0, ms || 0);
    }
  }
  date.toISOString = Date__toISOString;
  date.toJSON = Date__toJSON;
  return date;
}

function Date_parse(string) {
  // parse ISO date
  var parts = String(string).match(DATE_PATTERN);
  if (parts) {
    var month = parts[DATE_PARTS.Month];
    if (month) parts[DATE_PARTS.Month] = String(month - 1); // js months start at zero
    // round milliseconds on 3 digits
    if (parts[TIMEZONE_PARTS.precision] >= 5) parts[DATE_PARTS.Milliseconds]++;
    var utc = parts[TIMEZONE_PARTS.UTC] || parts[TIMEZONE_PARTS.Hours] ? "UTC" : "";
    var date = new Date(0);
    if (parts[DATE_PARTS.Date]) date["set" + utc + "Date"](14);
    for (var i = 0; i < 7; i++) {
      var part = DATE_PARTS[i];
      var value = parts[DATE_PARTS[part]];
      if (value) {
        // set a date part
        date["set" + utc + part](value);
        // make sure that this setting does not overflow
        if (date["get" + utc + part]() != parts[DATE_PARTS[part]]) {
          return NaN;
        }
      }
    }
    // timezone can be set, without time being available
    // without a timezone, local timezone is respected
    if (parts[TIMEZONE_PARTS.Hours]) {
      var hours = Number(parts[TIMEZONE_PARTS.Sign] + parts[TIMEZONE_PARTS.Hours]);
      var minutes = Number(parts[TIMEZONE_PARTS.Sign] + (parts[TIMEZONE_PARTS.Minutes] || 0));
      date.setUTCMinutes(date.getUTCMinutes() + (hours * 60) + minutes);
    }
    return +date;
  } else {
    return /^[TZ\d:.+\-]+$/.test(string) ? NaN : NativeDate_parse(string);
  }
}

var Date__toISOString = preferNativeMethod(Date_prototype, "toISOString", function toISOString() {
  var date = this, i = 0;
  return "####-##-##T##:##:##.###Z".replace(/#+/g, function(digits) {
    var part = DATE_PARTS[i++];
    var value = date["getUTC" + part]();
    var sign = "";
    if (part === "Month") value++; // js month starts at zero
    else if (part === "FullYear") {
      if (value > 9999) sign = "+";
      else if (value < 0) {
        sign = "-";
        value *= -1;
      }
      if (sign || !value) digits += "##";
    }
    return sign + ("00000" + value).slice(-digits.length); // pad
  });
});

var Date__toJSON = preferNativeMethod(Date_prototype, "toJSON", Date__toISOString);

base2_Date.UTC       = Date.UTC;
base2_Date.now       = now;
base2_Date.parse     = Date_parse;
base2_Date.prototype = Date_prototype;
base2_Date.toString  = K("[_.Date]");

if (!SUPPORTS_ISO_DATE) provides.Date = base2_Date;
