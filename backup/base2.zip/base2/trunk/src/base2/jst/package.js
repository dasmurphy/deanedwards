
base2.jst = new _.Package({
  name:    "base2.jst",
  version: base2.version,
  
  Command: Command,
  Environment: Environment,
  Interpreter: Interpreter
});
