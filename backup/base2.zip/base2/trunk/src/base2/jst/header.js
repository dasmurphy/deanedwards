
// JavaScript Templates

// Based on the work of Erik Arvidsson:
// http://erik.eae.net/archives/2005/05/27/01.03.26/

var undefined;
var base2    = _.base2;
var forEach  = _.forEach;

var CONST_STDIN    = 0;
var CONST_STDOUT   = 1;
var CONST_INCLUDES = 2;

var ESCAPE = new _.RegGrp([
  /\\/, '\\\\',
  /"/,  '\\"',
  /\n/, '\\n',
  /\r/, ''
]);

var NAMESPACE = "";
forEach.csv("base2,ArrayLike,Functional,lang", function(name) {
  var object = _[name];
  for (var i in object) {
    if (i in _ && /^([a-z]\w+)$/i.test(i)) {
      NAMESPACE += "var " + i + "=" + name + "." + i + ";";
    }
  }
});
