
// JavaScript Templates

// Based on the work of Erik Arvidsson:
// http://erik.eae.net/archives/2005/05/27/01.03.26/

var base2    = _.base2;
var forEach  = _.forEach;

var ESCAPE = new _.RegGrp([
  /\\/, '\\\\',
  /"/,  '\\"',
  /\n/, '\\n',
  /\r/, ''
]);

var VALID_NAME = /^([a-zA-Z_$]\w+)$/;

function buildNamespace(prefix, object) {
  var vars = [];
  forEach (object, function(method, name) {
    if (VALID_NAME.test(name)) {
      vars.push(name + "=" + prefix + "." + name);
    }
  }, null, {});
  if (!vars.length) return "";
  return "var " + vars.join(",") + ";\n";
}

var NAMESPACE = buildNamespace("_", _);
