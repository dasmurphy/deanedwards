
var Interpreter = _.Base.extend({
  constructor: function Interpreter__constructor(command, environment) {
    this.command = command || null;
    this.environment = new Environment(environment);
  },
  
  command: null,
  environment: null,

  parse: function Interpreter__parse(string) {
    var strings = string.split("<%");
    var length = strings.length;
    for (var i = 0; i < length; i++) {
      if (i === 0) {
        strings[0] = '\necho("' + ESCAPE.parse(strings[0]) + '");';
      } else {
        var blocks = strings[i].split("%>");
        if (blocks[0].indexOf("=") === 0) {
          strings[i] = '\necho(' + _.trim(blocks[0].slice(1)) + ');';
        } else {
          strings[i] = _.trim(blocks[0]);
        }
        strings[i] += '\necho("' + ESCAPE.parse(blocks[1]) + '");';
      }
    }
    var code = NAMESPACE +
      "\nwith(arguments[2])with(arguments[0])with(arguments[1]){\n" +
      "var data=arguments[2];\n" +
        _.trim(strings.join("\n")) +
      "}\nreturn arguments[0][1].join('')";
    // use new Function() instead of eval() so that the script is evaluated in the global scope
    return _.bind(Function(code), undefined);
  },

  interpret: function Interpreter__interpret(template, data) {
    return this.parse(template)(new Command(this.command), this.environment, data || {});
  }
});
