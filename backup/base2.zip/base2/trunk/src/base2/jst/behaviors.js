
base2.require("base2.jst,jsb", function(_, jst, jsb) {
  var interpreter = new jst.Interpreter;

  jsb.Rule("form", {
    "jsb:oncontentready": function(form) {
      this.output(form, "");
      this.ready(form);
    },

    onclick: function(form, event) {
      var target = event.target;
      if (target.nodeName === "BUTTON") {
        this[target.id](form);
      }
    },

    clear: function(form) {
      form.input.value = "";
      this.output(form, "");
      this.ready(form);
    },

    output: function(form, value) {
      this.set(this.find(form, "#output"), "textContent", value);
    },

    error: function(form, text, error) {
      this.message(form, text + ": " + error.message, "error");
    },

    message: function(form, text, className) {
      var message = this.find(form, "#message");
      message.innerHTML = text;
      message.className = className || "";
    },

    parse: function(form) {
      try {
        this.output(form, interpreter.parse(form.input.value));
      } catch (error) {
        this.error(form, "error parsing script", error);
      }
    },

    interpret: function(form) {
      try {
        this.output(form, interpreter.interpret(form.input.value));
      } catch (error) {
        this.error(form, "error interpreting script", error);
      }
    },

    ready: function(form) {
      this.message(form, "ready");
      form.input.focus();
    }
  });
});
