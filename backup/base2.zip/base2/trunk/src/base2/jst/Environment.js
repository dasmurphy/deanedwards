
var Environment = _.Base.extend({
  set: function Environment__set(name, value) {
    // Set a variable by name
    this[name] = value;
  },
  
  unset: function Environment__unset(name) {
    delete this[name];
  }
});
