
var Command = _.Base.extend({
  echo: _.Undefined
});
