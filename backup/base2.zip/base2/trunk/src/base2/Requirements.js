
// Private.

var Requirements = Collection.extend({
  constructor: function _Requirements__constructor(requirements, callback) {
    this.base(requirements);

    if (!isFunction(callback)) return;
    
    requirements = this;

    var total = requirements.size();
    var newSize = 0;

    deferUntil(function() { // defer
      // Create the namespace object.
      var names = {}, args = [];
      requirements.forEach(function(requirement, objectID) {
        var name = objectID.split(".").pop();
        args.push(names[name] = requirement.object);
      });
      args.unshift(new Namespace(args, names));
      // Execute the callback function.
      callback.apply(undefined, args);
    }, function() { // until
      var complete, oldSize = -1;
      while (newSize > oldSize) {
        oldSize = newSize;
        requirements.invoke("tick");
        complete = requirements.filter(_Requirement_isLoaded);
        newSize = complete.size();
      }
      return newSize === total;
    }, 0, TIMEOUT, function() { // ontimeout
      throw new Error("Failed to load requirements: " + requirements);
    });
  }
}, {
  Item: Requirement
});

// help

function _Requirement_isLoaded(requirement) {
  return !!requirement.object;
}
