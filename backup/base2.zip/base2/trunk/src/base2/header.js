
var info = {VERSION: "%%VERSION%%"};

//@cc_on

var oldBase2 = base2 || {};
if (info.VERSION === oldBase2.version) return oldBase2;

base2 = {}; // placeholder

var undefined, document;

var Object__toString       = {}.toString,
    Array_prototype        = Array.prototype,
    Array__concat          = Array_prototype.concat,
    Array__indexOf         = Array_prototype.indexOf,
    Array__forEach         = Array_prototype.forEach,
    Array__slice           = Array_prototype.slice,
    Function_prototype     = Function.prototype,
    Function__call         = Function_prototype.call;

function I(i) { // identity
  return i; // returns first argument
}

function II(i, ii) {
  return ii; // returns second argument
}

function K(value) { // returns a constant function that always returns 'value'
  return function() {
    return value;
  };
}

var Undefined = K();
var Null      = K(null);
var False     = K(false); False.contains = False.has = False.test = False;
var True      = K(true);  True.contains  = True.has  = True.test  = True;

var Object_protected    = {base: 1};
var Function_protected  = K();
Function_protected.bind = 1;
Function_protected.base = 1;

var Trait = Undefined; // initialise
var Collection = Undefined; // initialise

var commands = {"es5-shim": Undefined};

var base2_shims = {};

var counter = 0;

var assignID = oldBase2.assignID || function assignID(object, ID) {
  // Assign a unique ID to an object.
  var id = "b2__id" + counter++;
  if (object == null) return id;
  if (!ID) ID = object.nodeType === 1 ? "uniqueID" : "base2ID";
  if (!object[ID]) object[ID] = id;
  return object[ID];
};
