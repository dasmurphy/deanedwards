
;doc; // Declare to avoid errors.
;doc; var doc;

//@cc_on

var oldBase2 = base2 || {};
if (oldBase2 && oldBase2.version === "%%VERSION%%") return oldBase2;

var undefined;
var document = global.document;

var Object_prototype       = Object.prototype,
    Object__toString       = Object_prototype.toString,
    Array_isArray          = Array.isArray,
    Array_prototype        = Array.prototype,
    Array__concat          = Array_prototype.concat,
    Array__indexOf         = Array_prototype.indexOf,
    Array__forEach         = Array_prototype.forEach,
    Array__slice           = Array_prototype.slice,
    Function_prototype     = Function.prototype,
    Function__bind         = Function_prototype.bind,
    Function__call         = Function_prototype.call,
    Function__toString     = Function_prototype.toString;

function I(i) { // identity
  return i; // returns first argument
}

function II(i, ii) {
  return ii; // returns second argument
}

function K(value) { // returns a constant function that always returns 'value'
  return function() {
    return value;
  };
}

var Undefined = K();
var Null      = K(null);
var False     = K(false); False.contains = False.has = False.test = False;
var True      = K(true);  True.contains  = True.has  = True.test  = True;

var Trait = Undefined; // initialise

var providedDate = Date;
var Date_now = Date.now;

var commands = {
  "es5-shim": function() {
    // This doesn't overwrite anything even if it looks like it does.
    Function_prototype.bind = Function__bind; // for iOS
  }
};

var base2_info = {version: "%%VERSION%%"};

var idCounter = 0;

var assignID = oldBase2.assignID || function assignID(object, ID) {
  // Assign a unique ID to an object.
  var id = "b2__id" + idCounter++;
  if (object == null) return id;
  if (!ID) ID = object.nodeType === 1 ? "uniqueID" : "base2ID";
  if (!object[ID]) object[ID] = id;
  return object[ID] || id;
};

/*@
var CANNOT_ENUMERATE_BUILTINS = true;
var Object_builtins = csv("constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf");
var Function_builtins = Object_builtins.concat(csv("apply,call"));
for (var i in {toString: 1}) {
  CANNOT_ENUMERATE_BUILTINS = false;
}
@*/

function Object_keys(object) {
  var isFunction = typeof object == "function";
  var keys = [], i = 0;
  for (var key in object) {
    if (isFunction && key === "property") continue;
    ;doc; // Skip my own annotations.
    ;doc; if (key === "_underlyingFunction") continue;
    keys[i++] = key;
  }
  /*@ if (CANNOT_ENUMERATE_BUILTINS ) { // For MSIE.
    if (isFunction) {
      var Type_prototype = Function_prototype;
      var builtins = Function_builtins;
    } else {
      Type_prototype = Object_prototype;
      builtins = Object_builtins;
    }
    for (var j = 0; key = builtins[j]; j++) {
      if (object[key] != Type_prototype[key]) {
        keys[i++] = key;
      }
    }
  } @*/
  return keys;
}
