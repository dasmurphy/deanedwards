
var detect = (function() {
  // Two types of detection:
  //  1. Object detection
  //    e.g. detect("(java)");
  //    e.g. detect("!(document.addEventListener)");
  //  2. Platform detection
  //    e.g. detect("MSIE");
  //    e.g. detect("MSIE|Opera");

  var userAgent = "";
  var jscript = NaN/*@||@_jscript_version@*/; // http://dean.edwards.name/weblog/2007/03/sniff/#comment85164
  var args = "element,style,jscript";
  try {
    document = window.document;
    var element = document.createElement("span");
    var style   = element.style;
    var quirks  = false;
    userAgent = navigator.userAgent;
    element.expando = true;
    if (document.compatMode) {
      quirks = document.compatMode === "BackCompat";
    } else if (!document.xmlVersion) {
      style.width = 1; // Diego Perini
      quirks = style.width === "1px";
    }
  } catch (ex) {}
  if (userAgent) {
    // Close up the space between name and version number.
    //  e.g. MSIE 6.0 -> MSIE6.0
    userAgent = userAgent.replace(/([a-z])[\s\/](\d)/gi, "$1$2");
    
    ;;; userAgent = userAgent.replace(/\.NET CLR[\d\.]*/g, ""); // tidy
    
    // Remove false positives from ua string
    userAgent = userAgent.replace(/\blike \w+/gi, "");
    var MSIE  = /\bMSIE[\d.]*\b/g;
    if (jscript) { // MSIE
      userAgent = userAgent.match(MSIE)[0] + "; " + userAgent
        .replace(MSIE, "")
        .replace(/user\-agent.*$/i, ""); // crap gets appended here
    } else {
      userAgent = userAgent.replace(MSIE, "");
      if ("webkitAppearance" in style) {
        // Chrome is different enough that it counts as a different vendor.
        if (/\bChrome\d/.test(userAgent)) userAgent = userAgent.replace(/\bSafari[\d.]*\b/g, "");
      } else {
        userAgent = userAgent.replace(/\b(Chrome|Safari)[\d.]*\b/g, "");
        var opera = window.opera || window.operamini;
        if (opera && Object__toString.call(opera) === "[object Opera]") {
          if (/\bPresto/.test(userAgent)) userAgent = userAgent.replace(/Opera9\.80/, "").replace(/\bVersion/, "Opera");
        } else if (/\bGecko[\d.]*\b/.test(userAgent)) {
          userAgent = userAgent.replace(/Gecko/g, "Gecko/").replace(/rv:/, "Gecko");
        }
      }
    }
    
    if (quirks) userAgent += "; QuirksMode";
    userAgent += "; platform=" + navigator.platform + "; ";
    
    info["user-agent"] = userAgent;
    
    // http://code.google.com/p/base2/issues/detail?id=127
    if (!/\bGecko/.test(userAgent) && !("java" in window)) args += ",java";
  }
  var cache = {};
  var detect = function detect(expression) {
    var negated = expression.indexOf("!") === 0;
    if (negated) expression = expression.slice(1);
    if (!(expression in cache)) {
      var returnValue = false;
      var test = expression;
      if (/^\(.+\)$/.test(test)) { // Feature detection
        test = test
          .replace(/\bstyle\.(\w+)/g, function($, propertyName) {
            if (vendorPrefixes && !(propertyName in style)) {
              propertyName = getVendorPropertyName(style, propertyName);
            }
            return "style." + propertyName;
          })
          .replace(/^\(((?:<\w+>|\w+)\.[\w\.]+)\)$/, function($, feature) {
            feature = feature.split(".");
            var propertyName = feature.pop(), object = feature.join(".");
            return "('" + propertyName + "' in " + object + ")";
          })
          .replace(/<(\w+)>/g, function($, tagName) {
            return "document.createElement('" + tagName + "')";
          });
        returnValue = new Function(args, "try{return !!" + test +"}catch(e){return false}")(element, style, jscript);
      } else {
        // Browser sniffing.
        if (/^\/.+\/$/.test(test)) {
          test = test.slice(1, -1);
        }
        var uaString = userAgent + (_private.theme || ""); // this is cheating. :)
        returnValue = isBrowser ? new RegExp("(" + test + ")").test(uaString) : false;
      }
      cache[expression] = returnValue;
    }
    return !!(negated ^ cache[expression]);
  };
  
  return detect;
})();

var isBrowser = detect("(<script>)");
