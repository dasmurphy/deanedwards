
var TRAIT_INSTANTIATION_ERR              = "A Trait cannot be instantiated.";
var TRAIT_INVALID_TARGET_ERR             = "Invalid target for {1} methods.";
var TRAIT_INVALID_TARGET_FOR_METHOD_ERR  = "Invalid target for {0}().";

Trait = Base.extend({
  constructor: function Trait() {
    if (this instanceof Trait) {
      throw new TargetError(TRAIT_INSTANTIATION_ERR);
    }
  }
}, {
  extend: function Trait_extend(_instance, _static) {
    // Extend this Trait to create a new Trait.
    var trait = this.base({
      constructor: function Anonymous(object) {
        if (/*@ this.valueOf && @*/ this instanceof Trait) {
          // Attempt to instantiate a Trait.
          throw new TargetError(TRAIT_INSTANTIATION_ERR);
        } else {
          if (!trait.test(object)) {
            throw new TargetError(TRAIT_INVALID_TARGET_ERR, "", trait);
          }
          // Cast.
          return extend(object, trait.prototype, true);
        }
      }
    });
    if (_instance) extend(trait.prototype, _instance, true);
    _Trait_createStaticMethods(trait);
    trait.test = this.test;
    if (_static) extend(trait, _static, true);
    return trait;
  },

  implement: function Trait_implement(methods) {
    this.base(methods);
    _Trait_createStaticMethods(this);
    return this;
  },

  test: True
});

// help

var Trait_protected = pcopy(Base_static, {test: 1});

function _Trait_createStaticMethods(trait, untrusted) {
  var proto = trait.prototype;
  for (var name in proto) if (!(name in trait)) {
    var traitMethod = proto[name];
    if (!isFunction(traitMethod)) {
      throw new TypeError("Only methods can be added to a Trait.");
    }
    if (Trait_protected[name]) {
      throw new Error(format("'{0}' is reserved.", name));
    }
    _Trait_createStaticMethod(trait, name, traitMethod, untrusted);
  }
}

var traitMethodArgs = "trait,name,traitMethod,_call,TargetError,f,INVALID_TARGET_ERR,proto";
var traitMethodBody = 'return function {0}(object) {\n' +
  '  if (!trait.test(object)) {\n' +
  '    throw new TypeError(f(INVALID_TARGET_ERR, "{0}", this));\n' +
  '  }\n' +
  '  var method = object[name];\n' +
  '  if (typeof method != "function"{1}) {\n' +
  '    method = traitMethod;\n' +
  '  }\n' +
  '  return _call.apply(method, arguments);\n' +
  '}';

function _Trait_createStaticMethod(trait, name, traitMethod, untrusted) {
  // Delegate a static method to an instance method
  var body = format(traitMethodBody, name, untrusted ? ' || method === proto[name]' : '');
  var method = new Function(traitMethodArgs, body)(trait, name, traitMethod, Function__call, TargetError, formatErrorMessage, TRAIT_INVALID_TARGET_FOR_METHOD_ERR, untrusted);
  ;doc; method._underlyingFunction = traitMethod._underlyingFunction || traitMethod;
  trait[name] = method;
}
