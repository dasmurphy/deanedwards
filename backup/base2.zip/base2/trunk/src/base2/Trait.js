
var TRAIT_INSTANTIATION_ERR  = "A Trait cannot be instantiated.";
var TRAIT_INVALID_TARGET_ERR = "Invalid target for {0} methods.";

Trait = Base.extend({
  constructor: function Trait() {
    if (this instanceof Trait) {
      throw TypeError(TRAIT_INSTANTIATION_ERR);
    }
  }
}, {
  Error: function Trait_Error(message) {
    this.message = message;
  },

  extend: function Trait_extend(_instance, _static) {
    // Extend this Trait to create a new Trait.
    var trait = this.base({
      constructor: function Anonymous(object) {
        if (/*@ this && this.valueOf && @*/ this instanceof trait) {
          // Attempt to instantiate a Trait.
          throw TypeError(TRAIT_INSTANTIATION_ERR);
        }
        if (!trait.test(object)) {
          // Invalid target.
          throw TypeError(format(TRAIT_INVALID_TARGET_ERR, getClassName(trait) || "Trait"));
        }
        // Cast.
        return extend(object, trait.prototype, true);
      }
    });
    if (_instance) extend(trait.prototype, _instance, true);
    _Trait_createStaticMethods(trait);
    trait.test = this.test;
    if (_static) extend(trait, _static, true);
    return trait;
  },

  implement: function Trait_implement(methods) {
    this.base(methods);
    _Trait_createStaticMethods(this);
    return this;
  },

  test: True
});

// help

function _Trait_createStaticMethods(trait, untrusted) {
  var proto = trait.prototype;
  for (var name in proto) if (!(name in trait)) {
    var protoMethod = proto[name];

    if (!isFunction(protoMethod)) {
      throw TypeError("Only methods can be added to a Trait.");
    }

    _Trait_createStaticMethod(trait, name, protoMethod, untrusted);
  }
}

function _Trait_createStaticMethod(trait, name, protoMethod, u) {
  // Delegate a static method to an instance method
  var staticMethod = function _staticMethod(object) {
    var result = trait.test(object, name, arguments, this);
    if (result === false) {
      throw TypeError(Target(name, this));
    }
    if (result instanceof Trait.Error) {
      throw TypeError(result.message);
    }
    var method = object[name];
    if (typeof method != "function" || (u && method === u[name])) {
      method = protoMethod;
    }
    return Function__call.apply(method, arguments);
  };
  ;doc; // Try to expose as much raw source code as possible.
  ;doc; staticMethod._underlyingFunction = protoMethod._underlyingFunction || protoMethod;
  trait[name] = staticMethod;
}
