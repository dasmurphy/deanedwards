
var TRAIT_INSTANTIATION_ERR              = "A Trait cannot be instantiated.";
var TRAIT_INVALID_TARGET_ERR             = "Invalid target for {1} methods.";
var TRAIT_INVALID_TARGET_FOR_METHOD_ERR  = "Invalid target for {0}().";

Trait = Base.extend({
  constructor: function Trait__constructor() {
    if (this instanceof Trait) {
      throw new TargetError(TRAIT_INSTANTIATION_ERR);
    }
  }
}, {
  extend: function Trait_extend(_instance, _static) {
    // Extend this Trait to create a new Trait.
    if (!_instance) _instance = {};
    _instance.constructor = function _Trait__constructor(object) {
      if (this instanceof Trait) {
        // Attempt to instantiate a Trait.
        throw new TargetError(TRAIT_INSTANTIATION_ERR);
      } else {
        if (!trait.test(object)) {
          throw new TargetError(TRAIT_INVALID_TARGET_ERR, "", trait);
        }
        return extend(object, trait.prototype);
      }
    };
    var trait = this.base(_instance);
    _Trait_createStaticMethods(trait, _Trait_createStaticMethod);
    trait.test = this.test;
    if (_static) extend(trait, _static);
    return trait;
  },

  implement: function Trait_implement(methods) {
    this.base(methods);
    _Trait_createStaticMethods(this, _Trait_createStaticMethod);
    return this;
  },

  test: True
});

// help

var Trait_reserved = pcopy(Base_static, {test: 1});

function _Trait_createStaticMethods(trait, methodCreater) {
  forEach (trait.prototype, methodCreater, trait, Object_protected);
}

function _Trait_createStaticMethod(protoMethod, methodName) {
  var trait = this;

  if (!isFunction(protoMethod)) throw new TypeError("Only methods can be added to a Trait.");
  if (Trait_reserved[methodName]) throw new Error(format("'{0}' is reserved.", methodName));

  // Convert an instance method to a static method
  trait[methodName] = function _Trait_method(object) {
    // Throw an error if the supplied object is not a suitable target for this Trait.
    if (!trait.test(object)) {
      throw new TargetError(TRAIT_INVALID_TARGET_FOR_METHOD_ERR, methodName, trait);
    }
    // Traits are "soft", so if the object already implements the method then use that.
    var method = object[methodName];
    if (typeof method != "function") method = protoMethod;
    return Function__call.apply(method, arguments);
  };
  ;;; trait[methodName]._underlyingFunction = protoMethod._underlyingFunction || protoMethod;
}
