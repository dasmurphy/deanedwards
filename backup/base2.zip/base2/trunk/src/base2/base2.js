
base2 = new Package({
  name:   "base2",
  version: info.VERSION,
  
  Base: Base,
  Collection: Collection,
  Package: Package,
  RegGrp: RegGrp,
  Trait: Trait,
  
  ArrayLike: ArrayLike,
  Functional: Functional,

  assignID: assignID,
  detect: detect,
  
  info: function base2_info(key) {
    return key == "*" ? qcopy(info) : info[key];
  }
});

var lang = base2.lang = new Package({
  name:   "base2.lang",
  version: info.VERSION,

  assert: assert,
  assertArity: assertArity,
  assertType: assertType,

  extend: extend,
  forEach: forEach,

  isArray: isArray,
  isFunction: isFunction,

  now: now,

  format: format,
  trim: trim
});
