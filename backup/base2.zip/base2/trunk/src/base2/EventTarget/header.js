
var CONST_CAPTURING_PHASE = 1;
var CONST_AT_TARGET       = 2;
var CONST_BUBBLING_PHASE  = 3;

var CONST_PROPAGATION_STOPPED = 0;
var CONST_DEFAULT_PREVENTED   = 1;

var _private = _._;

if (!_private.events) _private.events = {};

var allEvents = _private.events;
