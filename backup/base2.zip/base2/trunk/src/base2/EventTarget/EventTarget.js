
var EventTarget = _.Trait.extend({
  addEventListener: function addEventListener(type, listener, useCapture) {
    // assign a unique id to both objects
    // create a hash table of event types for the target object
    var phase = useCapture ? CONST_CAPTURING_PHASE : CONST_BUBBLING_PHASE;
    var targetID = _.assignID(this);
    var listenerID = phase + _.assignID(listener);
    var typeMap = allEvents[type];
    if (!typeMap) typeMap = allEvents[type] = {};
    // create a hash table of event listeners for each object/event pair
    var listeners = typeMap[targetID];
    if (!listeners) listeners = typeMap[targetID] = {};
    // store the event listener in the hash table
    listeners[listenerID] = listener;
  },
  
  removeEventListener: function removeEventListener(type, listener, useCapture) {
    // delete the event listener from the hash table
    var typeMap = allEvents[type];
    if (typeMap) {
      var listeners = typeMap[this.nodeType === 1 ? this.uniqueID : this.base2ID];
      if (listeners) {
        var phase = useCapture ? CONST_CAPTURING_PHASE : CONST_BUBBLING_PHASE;
        var listenerID = phase + listener.base2ID;
        delete listeners[listenerID];
      }
    }
  },
  
  dispatchEvent: function dispatchEvent(type, data) {
    var event = new Event(type, data);
    _private.createGetter(event, "target", this);
    
    var typeMap = allEvents[type];
    if (typeMap) {
      var listeners = typeMap[this.nodeType === 1 ? this.uniqueID : this.base2ID];
      if (listeners) {
        var clonedListeners = {};
        for (var id in listeners) clonedListeners[id] = listeners[id];
        for (id in clonedListeners) {
          var listener = clonedListeners[id];
          if (typeof listener == "function") {
            continueIfThrow(listener, this, event);
          } else if (listener && typeof listener.handleEvent == "function") {
            continueIfThrow(listener.handleEvent, listener, event);
          }
        }
      }
    } else {
      var ontype = "on" + type;
      if (typeof this[ontype] == "function") {
        continueIfThrow(this[ontype], this, event);
      }
    }
    return !!event[CONST_DEFAULT_PREVENTED];
  }
});

EventTarget.test = function EventTarget_test(object) {
  return object && typeof object == "object";
};

new _.Package({ // prettify the trait name
  name: "base2",
  EventTarget: EventTarget
});

base2.EventTarget = EventTarget;
