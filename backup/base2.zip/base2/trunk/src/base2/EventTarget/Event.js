
var Event = _.Base.extend({
  constructor: function Event__constructor(type, data) {
    this.timeStamp = Date.now();
    _private.createGetter(this, "type", String(type));
    for (var i in data) this[i] = data[i];
  },
  
  CAPTURING_PHASE: CONST_CAPTURING_PHASE,
  AT_TARGET:       CONST_AT_TARGET,
  BUBBLING_PHASE:  CONST_BUBBLING_PHASE,

  type: "",
  target: null,
  currentTarget: null,
  bubbles: false,
  cancelable: false,
  defaultPrevented: false,
  eventPhase: 0,
  timeStamp: 0,
  
  preventDefault: function preventDefault() {
    if (this.cancelable) {
      this[CONST_DEFAULT_PREVENTED] = true;
      this.defaultPrevented = true;
    }
  },

  stopPropagation: function stopPropagation() {
    this[CONST_PROPAGATION_STOPPED] = true;
  },

  initEvent: function initEvent(type, bubbles, cancelable) {
    this.type = String(type);
    this.bubbles = !!bubbles;
    this.cancelable = !!cancelable;
    this.timeStamp = Date.now();
  },

  toString: _.K("[object Event]")
});

_private.Event = Event;
