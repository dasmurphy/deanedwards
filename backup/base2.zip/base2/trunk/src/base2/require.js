
var TIMEOUT = isBrowser ? 20000 : 0;

var base2_host = "";

function base2_exec(fn) {
  if (typeof fn == "string") fn = commands[fn];
  if (!isFunction(fn)) throw new TargetError(FUNCTION_REQUIRED_ERR, "base2.exec");
  
  return fn.call(undefined, new Namespace);
}

function base2_require(requirements, callback) {
  if (arguments.length < 2) throw new ArityError("base2.require");
  if (!isFunction(callback)) throw new TargetError(FUNCTION_REQUIRED_ERR, "base2.require");

  var strings = typeof requirements == "string" ? csv(requirements) : requirements;

  if (isArray(strings)) {
    requirements = [];
    for (var i = 0; i < strings.length; i++) {
      var parts = strings[i].split("#");
      if (parts.length === 1) { // package identifiers
        var objectID = parts[0];
        var fileName = objectID.replace(/\./g, "/") + ".js";
        requirements.push(objectID, base2_host + fileName);
      } else { // 3rd party scripts
        requirements.push(parts[1], parts[0]);
      }
    }
  }
  return new Requirements(requirements, callback);
}

base2.exec = base2_exec;
base2.require = base2_require;

base2.ready = function base2_ready(callback) {
  if (!isFunction(callback)) throw new TargetError(FUNCTION_REQUIRED_ERR, "base2.ready");

  return fn.call(undefined, new Namespace);
};

if (isBrowser) {
  // Get the current host.
  var SUPPORTS_EVENT_LISTENER = !!document.addEventListener;
  var COMPLETE = SUPPORTS_EVENT_LISTENER ? /loaded|complete/ : /complete/;
  var loadedScripts = {};
  var scripts = document.getElementsByTagName("script"), script, firstScript;
  var head = document.getElementsByTagName("head")[0] || document.documentElement;
  var i = 0;
  while ((script = scripts[i++])) {
    if (script.id === "base2.js") break;
    if (!firstScript && /base2\b[\w.-]*\.js/.test(script.src)) firstScript = script;
  }
  base2_host = (script || firstScript || "").src || location.pathname;
  base2_host = base2_host.replace(/\?.*$/, "").replace(/[^\/]*$/, "");
  info.host = base2_host;
  
  base2.ready = function base2_ready(callback) {
    if (!isFunction(callback)) throw new TargetError(FUNCTION_REQUIRED_ERR, "base2.ready");
    
    base2_require("base2.dom", function(_, dom) {
      callback = Function__bind.call(callback, undefined, _, dom);
      
      deferUntil(callback, function() {
        return _private.isReady;
      });
    });
  };

  _private.isReady = COMPLETE.test(document.readyState);
  
  if (SUPPORTS_EVENT_LISTENER && !_private.isReady) {
    document.addEventListener("DOMContentLoaded", function() {
      _private.isReady = true;
    }, false);
  }
}
