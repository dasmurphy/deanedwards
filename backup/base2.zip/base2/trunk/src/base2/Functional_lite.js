
var Function__bind = Function_prototype.bind;

function isFunction(object) {
  return typeof object == "function" && typeof object.call == "function";
}

function I(i) { // identity
  return i; // returns first argument
}

function II(i, ii) {
  return ii; // returns second argument
}

function K(value) { // returns a constant function that always returns 'value'
  return function() {
    return value;
  };
}

var Functional_instance = {
  bind: Function__bind,

  flip: function flip(fn) {
    var fn = this;

    // Swap the first two arguments in a function.
    var flippedFunction = function _flippedFunction() {
      var temp = arguments[0];
      arguments[0] = arguments[1];
      arguments[1] = temp;
      return fn.apply(this, arguments);
    };
    ;;; flippedFunction._underlyingFunction = fn._underlyingFunction || fn;
    return flippedFunction;
  },

  memoize: function Functional__memoize(keyFunction) {
    if (arguments.length > 0 && !isFunction(keyFunction)) {
      throw new TargetError(FUNCTION_REQUIRED_ERR, "memoize");
    }

    var fn = this;
    var Array__join = Array_prototype.join;

    var memoizedFunction = function _memoizedFunction() {
      var cache = memoizedFunction.cache;

      if (keyFunction) {
        var key = keyFunction.apply(this, arguments);
      } else if (arguments.length > 1) {
        key = Array__join.call(arguments, "\x00");
      } else {
        key = String(arguments[0]);
      }

      if (!(key in cache)) {
        cache[key] = fn.apply(this, arguments);
      }

      return cache[key];
    };

    memoizedFunction.cache = {}; // expose the cache

    ;;; memoizedFunction._underlyingFunction = fn._underlyingFunction || fn;

    return memoizedFunction;
  },

  not: function not(fn) {
    var fn = this;

    // Negate the return value of a function.
    var notFunction = function _notFunction() {
      return arguments.length === 0 ? !fn.call(this) : !fn.apply(this, arguments);
    };
    ;;; notFunction._underlyingFunction = fn._underlyingFunction || fn;
    return notFunction;
  },

  partial: function partial(/*, arg1/undefined, arg2/undefined, .. , argN */) {
    var fn = this;

    // Partial evaluation.
    var args = Array__slice.call(arguments);
    var partialFunction = function _partialFunction() {
      var specialised = args.concat();
      var length = arguments.length;
      var i = 0, j = 0;
      while (i < args.length && j < length) {
        if (typeof specialised[i] == "undefined") {
          specialised[i] = arguments[j++];
        }
        i++;
      }
      while (j < length) {
        specialised[i++] = arguments[j++];
      }
      while (i--) {
        if (typeof specialised[i] == "undefined") {
          return partial.apply(fn, specialised);
        }
      }
      return fn.apply(this, specialised);
    };
    ;;; partialFunction._underlyingFunction = fn._underlyingFunction || fn;
    return partialFunction;
  },

  unbind: function unbind() {
    var fn = this;

    // Unbind a method from an object.
    // Returns a function that has as its first parameter the object that would have been the "this" object.
    //
    // var slice = unbind([].slice);
    // var args = slice(arguments); // cast to Array

    var unboundFunction = function _unboundFunction(object) {
      if (object == null) throw new TargetError(OBJECT_REQUIRED_ERR);
      return Function__call.apply(fn, arguments);
    };
    ;;; unboundFunction._underlyingFunction = fn._underlyingFunction || fn;
    return unboundFunction;
  }
};

var Functional_static = {
  I: I,
  II: II,
  K: K,
  Null: Null,
  False: False,
  True: True,
  Undefined: Undefined
};

var Functional = Trait.extend(null, Functional_static);

Functional.test = isFunction;

extend(Functional.prototype, Functional_instance);

;;; for (var name in Functional) {
;;;   if (/^(Null|False|True|Undefined)$/.test(name)) {
;;;     Functional[name].toString = K("function " + name + "() {\n  return " + name.toLowerCase() + ";\n}");
;;;   }
;;; }
