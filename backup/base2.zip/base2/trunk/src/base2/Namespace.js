
// The "_" object.

function Namespace(objects, names) {
  if (objects) for (var i = 0, object; object = objects[i]; i++) {
    if (object instanceof Package) {
      for (var name in object) if (!(name in _)) {
        this[name] = object[name];
      }
    } else if (Trait.ancestorOf(object)) {
      for (name in object) if (!(name in Trait) && !(name in _)) {
        this[name] = object[name];
      }
    }
  }
  if (names) for (name in names) if (!(name in _)) {
    this[name] = names[name];
  }
}

var _ = Namespace.prototype;

// Initialise the "_" object
_.base2 = base2;
_Trait_createStaticMethods(ArrayLike, _Trait_createProtectedMethod);
_Trait_createStaticMethods(Functional, _Trait_createProtectedMethod);
extend(_, Functional_static);
for (var name in base2) _[name] = base2[name];
for (name in lang) _[name] = lang[name];
for (name in Package.prototype) delete _[name];
_.toString = function toString() {
  if ("imports" == arguments[0]) {
    var result = "";
    for (var i in this) if (!Object_protected[i] && i !== "_") {
      result += "var " + i + "=arguments[0]." + i + ";\n";
    }
    return result;
  }
  return "[object Namespace]";
};
_._ = _private;

function _Trait_createProtectedMethod(protoMethod, methodName) {
  // This is used to create the ArrayLike/Functional methods on the Namespace object (_).
  // These methods may provide ES5 compatibility so the "soft" behaviour of Traits is not appropriate.
  // This is primarily for protection against "bad" shims of the ES5 spec. :)
  var trait = this;
  trait[methodName] = _[methodName] = function _Trait_method(object) {
    // Throw an error if the supplied object is not a suitable target for this Trait.
    if (!trait.test(object)) {
      throw new TargetError(TRAIT_INVALID_TARGET_FOR_METHOD_ERR, methodName, this);
    }
    if (Array_enumerable[methodName]) { // throw early
      var fn = arguments[1];
      if (typeof fn != "function" || typeof fn.call != "function") {
        throw new TargetError(FUNCTION_REQUIRED_ERR, methodName, this);
      }
    }
    if (object.imap && object instanceof Collection) {
      var method = object[methodName];
    } else {
      method = protoMethod;
    }
    return Function__call.apply(method, arguments);
  };
  ;;; trait[methodName]._underlyingFunction = protoMethod._underlyingFunction || protoMethod;
}
