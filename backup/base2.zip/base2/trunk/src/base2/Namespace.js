
// The "_" object.

function Namespace(objects) {
  if (objects) {
    for (var i = 0, object; object = objects[i]; i++) {
      if (object instanceof Package) {
        for (var name in object) if (!(name in Namespace_protected)) {
          this[name] = object[name];
        }
      } else if (Trait.ancestorOf(object)) {
        for (name in object) if (!(name in Namespace_protected)) {
          this[name] = object[name];
        }
      }
    }
  }
}

var _ = Namespace.prototype;

var Namespace_protected = extend(pcopy(_, Package.prototype), Trait);

// Initialise the "_" object
_.base2 = base2;
Namespace.call(_, [base2, base2.lang, Functional, ArrayLike]);
_.bind = Functional.bind;
_.extend = extend;
_._ = _private;

_.toString = function toString() {
  if ("imports" == arguments[0]) {
    var result = "";
    for (var i in this) if (i !== "_") {
      result += "var " + i + "=arguments[0]." + i + ";\n";
    }
    return result;
  }
  return "[object Namespace]";
};
