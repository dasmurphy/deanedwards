
var Function__bind = preferNativeMethod(Function_prototype, "bind", function Functional__bind(context /*, arg1, arg2, .. , argN */) {
  // This solution does not fix the length property of the resulting function.
  
  var fn = this;

  if (typeof fn != "function" || typeof fn.call != "function") throw new TargetError(FUNCTION_REQUIRED_ERR, "bind", this);

  var initialArguments = arguments.length > 1 ? Array__slice.call(arguments, 1) : null;

  var boundFunction = function _boundFunction() {
    var instance = /*@ this.valueOf && @*/ this instanceof boundFunction ? pcopy(fn.prototype) : null;
    var callContext = instance || context;
    var hasArguments = arguments.length > 0;

    var result = initialArguments
      ? fn.apply(callContext, hasArguments ? Array__concat.apply(initialArguments, arguments) : initialArguments)
      : hasArguments ? fn.apply(callContext, arguments) : fn.call(callContext);

    if (instance && result !== Object(result)) result = instance;

    return result;
  };
  boundFunction.prototype = fn.prototype; // wrong, but the best alternative
  return boundFunction;
});

function Functional__partial(/*, arg1/undefined, arg2/undefined, .. , argN */) {
  var fn = this;

  // Partial evaluation (based on Oliver Steele's version).
  var args = Array__slice.call(arguments);
  var partialFunction = function _partialFunction() {
    var specialised = args.concat();
    var length = arguments.length;
    var i = 0, j = 0;
    while (i < args.length && j < length) {
      if (typeof specialised[i] == "undefined") {
        specialised[i] = arguments[j++];
      }
      i++;
    }
    while (j < length) {
      specialised[i++] = arguments[j++];
    }
    while (i--) {
      if (typeof specialised[i] == "undefined") {
        return Functional__partial.apply(fn, specialised);
      }
    }
    return fn.apply(this, specialised);
  };
  ;doc; partialFunction._underlyingFunction = fn._underlyingFunction || fn;
  return partialFunction;
}

var Functional = Trait.extend({
  bind: Function__bind,

  memoize: function Functional__memoize(keyFunction) {
    if (arguments.length > 0 && !isFunction(keyFunction)) {
      throw new TargetError(FUNCTION_REQUIRED_ERR, "memoize");
    }

    var fn = this;

    var memoizedFunction = function _memoizedFunction() {
      var cache = memoizedFunction.cache;

      if (keyFunction) {
        var key = keyFunction.apply(this, arguments);
      } else if (arguments.length > 1) {
        key = Array__slice.call(arguments, 0, fn.length).join("\x00");
      } else {
        key = String(arguments[0]);
      }

      if (!(key in cache)) {
        cache[key] = fn.apply(this, arguments);
      }

      return cache[key];
    };

    memoizedFunction.cache = {}; // expose the cache

    ;doc; memoizedFunction._underlyingFunction = fn._underlyingFunction || fn;

    return memoizedFunction;
  },

  once: function Functional__once() {
    var fn = this;
    var returnValue;
    var called = false;

    var onceFunction = function _onceFunction() {
      if (called) return returnValue;
      returnValue = fn.apply(this, arguments);
      called = true;
      return returnValue;
    };

    ;doc; onceFunction._underlyingFunction = fn._underlyingFunction || fn;

    return onceFunction;
  },

  partial: Functional__partial,

  unbind: function Functional__unbind() {
    var fn = this;

    // Unbind a method from an object.
    // Returns a function that has as its first parameter the object that would have been the "this" object.
    //
    // var slice = unbind([].slice);
    // var args = slice(arguments); // cast to Array

    var unboundFunction = function _unboundFunction(object) {
      if (object == null) throw new TargetError(OBJECT_REQUIRED_ERR);
      return Function__call.apply(fn, arguments);
    };
    ;doc; unboundFunction._underlyingFunction = fn._underlyingFunction || fn;
    return unboundFunction;
  }
}, {
  test: isFunction,
  I: I,
  II: II,
  K: K,
  Null: Null,
  False: False,
  True: True,
  Undefined: Undefined
});

_Trait_createStaticMethod(Functional, "bind", Function__bind, Function_prototype);

;doc; for (var name in Functional) {
;doc;   if (/^(Null|False|True|Undefined)$/.test(name)) {
;doc;     Functional[name].toString = K("function " + name + "() {\n  return " + name.toLowerCase() + ";\n}");
;doc;   }
;doc; }
