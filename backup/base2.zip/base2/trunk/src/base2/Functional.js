
var Function__bind = preferNativeMethod(Function_prototype, "bind", function Functional__bind(context /*, arg1, arg2, .. , argN */) {
  // This solution does not fix the length property of the resulting function.
  
  var fn = this;

  if (typeof fn != "function" || typeof fn.call != "function") throw new TargetError(FUNCTION_REQUIRED_ERR, "bind", this);

  var initialArguments = arguments.length > 1 ? Array__slice.call(arguments, 1) : null;

  var boundFunction = function _boundFunction() {
    var instance = this instanceof boundFunction ? pcopy(fn.prototype) : null;
    var callContext = instance || context;
    var hasArguments = arguments.length > 0;

    var result = initialArguments
      ? fn.apply(callContext, hasArguments ? Array__concat.apply(initialArguments, arguments) : initialArguments)
      : hasArguments ? fn.apply(callContext, arguments) : fn.call(callContext);

    if (instance && result !== Object(result)) result = instance;

    return result;
  };
  boundFunction.prototype = fn.prototype; // wrong, but the best alternative
  return boundFunction;
});

var Functional_instance = {
  bind: Function__bind,
  
  flip: function Functional__flip() {
    var fn = this;

    // Swap the first two arguments in a function.
    var flippedFunction = function _flippedFunction() {
      var temp = arguments[0];
      arguments[0] = arguments[1];
      arguments[1] = temp;
      return fn.apply(this, arguments);
    };
    ;;; flippedFunction._underlyingFunction = fn._underlyingFunction || fn;
    return flippedFunction;
  },

  memoize: function Functional__memoize(keyFunction) {
    if (arguments.length > 0 && !isFunction(keyFunction)) {
      throw new TargetError(FUNCTION_REQUIRED_ERR, "memoize");
    }
    
    var fn = this;

    var memoizedFunction = function _memoizedFunction() {
      var cache = memoizedFunction.cache;
      
      if (keyFunction) {
        var key = keyFunction.apply(this, arguments);
      } else if (arguments.length > 1) {
        key = Array__slice.call(arguments, 0, fn.length).join("\x00");
      } else {
        key = String(arguments[0]);
      }
      
      if (!(key in cache)) {
        cache[key] = fn.apply(this, arguments);
      }
      
      return cache[key];
    };

    memoizedFunction.cache = {}; // expose the cache
    
    ;;; memoizedFunction._underlyingFunction = fn._underlyingFunction || fn;

    return memoizedFunction;
  },

  not: function Functional__not() {
    var fn = this;

    // Negate the return value of a function.
    var notFunction = function _notFunction() {
      return arguments.length === 0 ? !fn.call(this) : !fn.apply(this, arguments);
    };
    ;;; notFunction._underlyingFunction = fn._underlyingFunction || fn;
    return notFunction;
  },

  partial: function Functional__partial(/*, arg1/undefined, arg2/undefined, .. , argN */) {
    var fn = this;

    // Partial evaluation (based on Oliver Steele's version).
    var args = Array__slice.call(arguments);
    var partialFunction = function _partialFunction() {
      var specialised = args.concat();
      var length = arguments.length;
      var i = 0, j = 0;
      while (i < args.length && j < length) {
        if (typeof specialised[i] == "undefined") {
          specialised[i] = arguments[j++];
        }
        i++;
      }
      while (j < length) {
        specialised[i++] = arguments[j++];
      }
      while (i--) {
        if (typeof specialised[i] == "undefined") {
          return partial.apply(fn, specialised);
        }
      }
      return fn.apply(this, specialised);
    };
    ;;; partialFunction._underlyingFunction = fn._underlyingFunction || fn;
    return partialFunction;
  },
  
  unbind: function Functional__unbind() {
    var fn = this;

    // Unbind a method from an object.
    // Returns a function that has as its first parameter the object that would have been the "this" object.
    //
    // var slice = unbind([].slice);
    // var args = slice(arguments); // cast to Array

    var unboundFunction = function _unboundFunction(object) {
      if (object == null) throw new TargetError(OBJECT_REQUIRED_ERR);
      return Function__call.apply(fn, arguments);
    };
    ;;; unboundFunction._underlyingFunction = fn._underlyingFunction || fn;
    return unboundFunction;
  }
};

var Functional_static = {
  I: I,
  II: II,
  K: K,
  Null: Null,
  False: False,
  True: True,
  Undefined: Undefined
};

var Functional = Trait.extend(null, Functional_static);

Functional.test = isFunction;

extend(Functional.prototype, Functional_instance);

;;; for (var name in Functional_static) {
;;;   if (/^(Null|False|True|Undefined)$/.test(name)) {
;;;     Functional[name].toString = K("function " + name + "() {\n  return " + name.toLowerCase() + ";\n}");
;;;   }
;;; }
