
// A collection of regular expressions and their associated replacement values.
// A Base class for creating parsers.

var CONST_COMPILED = 3;
var CONST_PATTERNS = 1; // CONST_KEYS;

// I can't feature detect this as it crashes Konqueror 3.x.
// This browser is not actually supported but it is still poor form to crash it. :)
var REGGRP_ALWAYS_RECOMPILE = detect("Konqueror");

var REGGRP_BACK_REF         = /\\(\d+)/g,
    REGGRP_ESCAPE_COUNT     = /\[(\\.|[^\]\\])+\]|\\.|\(\?/g,
    REGGRP_PAREN            = /\(/g,
    REGGRP_LOOKUP           = /\$(\d+)/,
    REGGRP_LOOKUP_SIMPLE    = /^\$\d+$/,
    REGGRP_DICT_ENTRY       = /^<#\w+>$/,
    REGGRP_DICT_ENTRIES     = /<#(\w+)>/g;

var RegGrp = Collection.extend({
  constructor: function RegGrp__constructor(dictionary, values) {
    if (arguments.length === 1) {
      values = dictionary;
      dictionary = null;
    }
    if (dictionary) {
      this.dictionary = new RegGrp_Dict(dictionary);
    }
    this.base(values);
  },
  
  dictionary: null,
  ignoreCase: false,

  clear: _RegGrp_recompile,

  exec: function RegGrp__exec(string, fn /* optional */) { // This method needs a lot more work -@DRE
    var group = this;
    var patterns = group[CONST_PATTERNS];
    var items = group[CONST_ITEMS], item;
    group[CONST_COMPILED] = new RegExp(group[CONST_COMPILED] ? group[CONST_COMPILED].source : group, group.ignoreCase ? "gi" : "g");
    var result = group[CONST_COMPILED].exec(string);
    if (result) {
      // Loop through the RegGrp items.
      var i = 0, offset = 1;
      while ((item = items[CONST_HASH + patterns[i++]])) {
        var next = offset + item.length + 1;
        if (result[offset]) {
          if (item.replacement === 0) {
            return group.exec(string);
          } else {
            var args = result.slice(offset, next);
            var j = args.length;
            while (--j) args[j] = args[j] || ""; // some platforms return null/undefined for non-matching sub-expressions
            args[0] = {match: args[0], item: item};
            return isFunction(fn) ? fn.call(args) : args;
          }
        }
        offset = next;
      }
    }
    return null;
  },

  parse: function RegGrp__parse(string) {
    string = String(string);
    var _replacement = arguments[1]; // optional argument (deprecated)
    var group = this;
    var patterns = group[CONST_PATTERNS];
    var items = group[CONST_ITEMS];
    var regexp = group[CONST_COMPILED];
    if (!patterns.length) return string;
    if (REGGRP_ALWAYS_RECOMPILE || !regexp || regexp.ignoreCase !== !!group.ignoreCase) {
      regexp = group[CONST_COMPILED] = new RegExp(regexp ? regexp.source : group, group.ignoreCase ? "gi" : "g");
    }
    return string.replace(regexp, function _RegGrp_parser(match) {
      var args = [], item, offset = 1, i = arguments.length;
      while (--i) args[i] = arguments[i] || ""; // some platforms return null/undefined for non-matching sub-expressions
      // Loop through the RegGrp items.
      while ((item = items[CONST_HASH + patterns[i++]])) {
        var next = offset + item.length + 1;
        if (args[offset]) { // do we have a result?
          var replacement = _replacement == null ? item.replacement : _replacement;
          switch (typeof replacement) {
            case "function":
              return replacement.apply(group, args.slice(offset, next));
              
            case "number":
              return args[offset + replacement];
              
            case "object":
              if (replacement instanceof RegGrp) {
                return replacement.parse(args[offset]);
              }
              
            default:
              return String(replacement);
          }
        }
        offset = next;
      }
      return match;
    });
  },

  removeAt: _RegGrp_recompile,
  reverse:  _RegGrp_recompile,
  sort:     _RegGrp_recompile,

  test: function RegGrp__test(string) { // The slow way to do it. Hopefully, this isn't called too often. :)
    return this.parse(string) != string;
  },
  
  toString: function RegGrp__toString() {
    var patterns = this[CONST_PATTERNS];
    if (!patterns) return "()";
    var string = patterns.join(")|(");
    if (this.dictionary || /\\\d/.test(string)) { // back refs
      var offset = 1;
      var keys = patterns;
      var items = this[CONST_ITEMS], item;
      patterns = [];
      for (var i = 0; item = items[CONST_HASH + keys[i]]; i++) {
        patterns[i] = item.source.replace(REGGRP_BACK_REF, function(match, index) {
          return "\\" + (offset + ~~index);
        });
        offset += item.length + 1;
      }
      string = patterns.join(")|(");
    }
    return "(" + string + ")";
  }
}, {
  IGNORE: null, // a null replacement value means that there is no replacement and the pattern is ignored

  count: RegGrp_count
});

// init

forEach ("add,get,has,indexOf,insertAt,remove,set".split(","), function(name) {
  var index = name === "insertAt" ? 1 : 0;
  var recompile = name === "set" || name === "remove";
  ;;; var underlyingFunction = this[name];
  this[name] = _override(this[name], function _RegGrp_method() {
    var args = Array__slice.call(arguments);
    if (args[index] instanceof RegExp) {
      args[index] = args[index].source;
    }
    if (recompile) {
      delete this[CONST_COMPILED];
      if (name === "set" && this.dictionary) {
        if (args.length < 2) args[1] = args[0];
        args[2] = this.dictionary;
      }
    }
    return this.base.apply(this, args);
  });
  ;;; this[name]._underlyingFunction = underlyingFunction;
}, RegGrp.prototype);

// help

function RegGrp_count(expression) {
  return (String(expression).replace(REGGRP_ESCAPE_COUNT, "").match(REGGRP_PAREN) || "").length;
}

function _RegGrp_recompile() {
  delete this[CONST_COMPILED];
  return this.base.apply(this, arguments);
}
