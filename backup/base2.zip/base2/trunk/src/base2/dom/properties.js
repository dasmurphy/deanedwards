
var CONST_WRITABLE = 0;
var CONST_READONLY = 1;

var DOM_PROPERTIES = {
  textContent:            CONST_WRITABLE,
  innerHTML:              CONST_WRITABLE,
  children:               CONST_READONLY,
  classList:              CONST_READONLY,
  dataset:                CONST_READONLY
};

for (var i in traversalAPI) DOM_PROPERTIES[i] = CONST_READONLY;

function dom_get(node, propertyName) {
  if (arguments.length < 2) {
    throw TypeError(Arity("get", this));
  }
  if (!node || !node.nodeType) {
    throw TypeError(Target("get", this));
  }
    
  var value = node[propertyName];
  
  if (typeof value == "undefined" && node.nodeType === 1) {
    var traversal = traversalAPI[propertyName];
    if (traversal) {
      return traversal.call(node);
    } else if (propertyName == "textContent") {
      return _MSIE_getTextContent.call(node);
    }
  }
  return value;
}

dom_get.properties = DOM_PROPERTIES;

function dom_set(node, propertyName, value) {
  if (arguments.length < 3) {
    throw TypeError(Arity("set", this));
  }

  if (!node || !node.nodeType) {
    throw TypeError(Target("set", this));
  }
  
  if (node.nodeType === 1) {
    if (DOM_PROPERTIES[propertyName] === CONST_READONLY) {
      throw TypeError("Cannot set read-only property: " + propertyName);
    }
    if (propertyName == "innerHTML") {
      /*@
        var document = node.ownerDocument;
        if (!(document.documentMode >= 9)) {
          node.innerHTML = "";
          var dummy = Function__call.call(_createElement, document, "div");
          document.body.appendChild(dummy);
          dummy.innerHTML = value;
          document.body.removeChild(dummy);
          while (dummy.firstChild) {
            node.appendChild(dummy.firstChild);
          }
          return node.innerHTML;
        }
      @*/
    } else if (propertyName == "textContent" && !(propertyName in node)) {
      return _MSIE_setTextContent.call(node, value);
    }
  }
  
  return node[propertyName] = value;
}

function _MSIE_getTextContent() {
  if (this.nodeName === "SCRIPT") return this.text;
  if (this.nodeName === "STYLE" && this.styleSheet) return this.styleSheet.cssText;
  return this.innerText;
}

function _MSIE_setTextContent(value) {
  if (this.nodeName === "SCRIPT") {
    this.text = value;
  } else if (this.nodeName === "STYLE") {
    var initialised = !!this.styleSheet;
    if (!initialised) {
      this.ownerDocument.appendChild(this);
    }
    this.styleSheet.cssText = value;
    if (!initialised) {
      this.ownerDocument.removeChild(this);
    }
  } else {
    this.innerText = value;
  }
}
