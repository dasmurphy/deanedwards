
element.expando = true;

var BROKEN_GET_ATTRIBUTE = element.getAttribute("xyz") !== null || element.getAttribute("expando");

var _removeAttribute, _setAttribute;

if (BROKEN_GET_ATTRIBUTE) {
  var _getAttribute = function getAttribute(name) {
    if (arguments.length === 0) {
      throw TypeError(Arity("getAttribute"));
    }

    name = String(name).toLowerCase();

    var attribute = this.getAttributeNode(name);
    var specified = attribute && attribute.specified;

    /*@
      if (this.style) {
        var defaultName = _DEFAULT_PROPERTY[name];
        if (typeof defaultName == "string" && defaultName in this) {
          if (name === "value") {
            if (this.nodeName === "INPUT") {
              return this.defaultValue || null;
            }
          } else return this[defaultName] ? "" : null;
        }

        var name2 = _BOOLEAN_ALIASES[name] || name;
        if (typeof this[name2] == "boolean") return this[name2] ? "" : null;

        if (specified && name === "style") return this.style.cssText.toLowerCase();

        if ((specified && _USE_IFLAG[name]) || name === "enctype" || name === "type") {
          var method = protoMethods["1getAttribute"];
          var value = method.call(this, name, 2);
          return value == null ? null : String(value);
        }
      }
    @*/

    return specified ? String(attribute.nodeValue) : null;
  };

  var _hasAttribute = function hasAttribute(name) {
    if (arguments.length === 0) {
      throw TypeError(Arity("hasAttribute"));
    }

    return _getAttribute.call(this, name) != null;
  };

  /*@
    var _DEFAULT_PROPERTY  = {checked:"defaultChecked", selected:"defaultSelected", value:"defaultValue"};
    var _USE_IFLAG         = {action:1, cite:1, colspan:1, codebase:1, data:1, dynsrc:1, enctype:1, href:1,
                              longdesc:1, lowsrc:1, profile:1, rowspan:1, src:1, type:1, usemap:1, url:1};
    var _BOOLEAN_ALIASES   = {readonly: "readOnly", ismap: "isMap"};
    var _EVENT_ATTRIBUTE   = /^on[a-z]{3,}$/;
    var _DEFAULT_VALUES = {
      COL:      {span: 1},
      COLGROUP: {span: 1},
      FORM:     {enctype: "application/x-www-form-urlencoded"},
      TEXTAREA: {rows: 2, cols: 20},
      TD:       {rowspan: 1, colspan: 1},
      TH:       {rowspan: 1, colspan: 1}
    };

    // Not aware of other browser bugs just MSIE6-8 (IE9 does not get this far unless it is in compatibility mode)
    _removeAttribute = function removeAttribute_msie(name) {
      if (arguments.length === 0) {
        throw TypeError(Arity("removeAttribute"));
      }

      // for MSIE6-8

      var attribute = this.getAttributeNode(name);
      
      if (attribute) {
        if (this.style) {
          name = String(name).toLowerCase();

          if (name === "class") {
            this.className = "";
          } else if (name === "style") {
            this.style.cssText = "";
          } else {
            var nodeName = this.nodeName;
            if (nodeName === "INPUT") {
              switch (name) {
                case "type":
                  return; // can't remove the type attribute but try not to error

                case "checked":
                  this.checked = this.defaultChecked = false;
                  return;

                case "value":
                  this.value = this.defaultValue = "";
              }
            }
            if (_EVENT_ATTRIBUTE.test(name)) {
              this[name] = null;
            } else {
              // reset the nodeValue to its default
              var defaultValues = _DEFAULT_VALUES[nodeName];
              if (defaultValues && name in defaultValues) {
                attribute.nodeValue = defaultValues[name];
              }
            }
          }
        }
        this.removeAttributeNode(attribute);
      }
    };

    _setAttribute = function setAttribute_msie(name, value) {
      if (arguments.length < 2) {
        throw TypeError(Arity("setAttribute"));
      }

      // for MSIE6-8
      
      name = String(name).toLowerCase();
      value = String(value);

      var isHTML = !!this.style;

      if (isHTML && name === "style") {
        this.style.cssText = value;
      } else {
        if (isHTML && this.nodeName === "INPUT") {
          switch (name) {
            case "checked":
              this.checked = this.defaultChecked = true;
              return;

            case "value":
              this.value = this.defaultValue = value;
          }
        }
        if (isHTML && _EVENT_ATTRIBUTE.test(name)) {
          var dummy = Function__call.call(_createElement, this.ownerDocument, this.nodeName);
          dummy.setAttribute(name, value);
          this.mergeAttributes(dummy);
        } else {
          var attribute = this.getAttributeNode(name);
          try {
            if (attribute) {
              attribute.nodeValue = typeof attribute.nodeValue == "boolean" ? true : value;
            } else {
              var method = protoMethods["1setAttribute"];
              method.call(this, name, value);
              //if (isHTML) this.className += ""; // recalc
            }
          } catch (ex) {
            // not much we can do here
          }
        }
      }
    };
  @*/
}
