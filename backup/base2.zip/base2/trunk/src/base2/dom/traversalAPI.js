
var SUPPORTS_TRAVERSAL_API = "nextElementSibling" in element;

function _getChildElementCount() {
  var count = 0;
  var node = this.firstChild;
  while (node) {
    if (node.nodeType === 1) count++;
    node = node.nextSibling;
  }
  return count;
}

function _getFirstElementChild() {
  var element = this.firstChild;
  while (element && element.nodeType !== 1) element = element.nextSibling;
  return element;
}

function _getLastElementChild() {
  var element = this.lastChild;
  while (element && element.nodeType !== 1) element = element.previousSibling;
  return element;
}

function _getNextElementSibling() {
  var element = this;
  do {
    element = element.nextSibling;
  } while (element && element.nodeType !== 1);
  return element;
}

function _getPreviousElementSibling() {
  var element = this;
  do {
    element = element.previousSibling;
  } while (element && element.nodeType !== 1);
  return element;
}

var traversalAPI = {
  childElementCount:      _getChildElementCount,
  firstElementChild:      _getFirstElementChild,
  lastElementChild:       _getLastElementChild,
  nextElementSibling:     _getNextElementSibling,
  previousElementSibling: _getPreviousElementSibling
};
