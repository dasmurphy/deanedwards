
var dom = new _.Package({
  name:    "base2.dom",
  version:  base2.version,

  get: dom_get,
  set: dom_set,

  Event: EventConstructor,
  CustomEvent: CustomEventConstructor,
  CSSSelectorParser: CSSSelectorParser,
  
  classList: classList,
  style:     style,
  
  getComputedStyle: _getComputedStyle
});
