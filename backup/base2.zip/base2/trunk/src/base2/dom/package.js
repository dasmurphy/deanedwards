
var dom = new _.Package({
  name:    "base2.dom",
  version:  base2.version,

  get: dom_get,
  set: dom_set,

  CSSSelectorParser: CSSSelectorParser,
  StaticNodeList:    StaticNodeList,
  
  classList:         classList,
  style:             style,
  
  getComputedStyle:  _getComputedStyle
});
