
// http://www.w3.org/TR/DOM-Level-2-Style/css.html#CSS-ViewCSS

if (SUPPORTS_GET_COMPUTED_STYLE) {
  _getComputedStyle = function getComputedStyle(element, pseudoElement) {
    if (arguments.length < 2) {
      throw new ArityError("getComputedStyle");
    }
    if (!element || element.nodeType !== 1) {
      throw new TargetError(DOM_TYPE_ERR, "getComputedStyle");
    }
    
    var view = element.ownerDocument.defaultView;
    var computedStyle = view.getComputedStyle(element, pseudoElement);
    
    if (FIX_COMPUTED_STYLE_COLOR || FIX_COMPUTED_STYLE_PERCENT || FIX_COMPUTED_STYLE_PADDING) {
      computedStyle = _private.pcopy(computedStyle);
      for (var propertyName in computedStyle) {
        var value = computedStyle[propertyName];
        if (FIX_COMPUTED_STYLE_COLOR && CSS_COLORS.test(propertyName)) {
          computedStyle[propertyName] = cachedColors[value] || toRGB(value);
        } else if (FIX_COMPUTED_STYLE_PERCENT && CSS_METRICS.test(propertyName)) {
          if (value === "auto") {
            value = computeAutoValue(element, propertyName);
          } else if (/%$/.test(value)) {
            var offset = CSS_METRICS_HORIZONTAL.test(propertyName) ? "offsetWidth" : "offsetHeight";
            value = Math.round((element.offsetParent || element)[offset] * value.slice(0, -1) / 100) + "px";
          }
          computedStyle[propertyName] = value;
        } else if (FIX_COMPUTED_STYLE_PADDING && propertyName == "width") {
          computedStyle[propertyName] = (element.clientWidth - parseInt(computedStyle.paddingLeft) - parseInt(computedStyle.paddingRight)) + "px";
        } else if (FIX_COMPUTED_STYLE_PADDING && propertyName == "height") {
          computedStyle[propertyName] = (element.clientHeight - parseInt(computedStyle.paddingTop) - parseInt(computedStyle.paddingBottom)) + "px";
        } else if (typeof value == "function") {
          computedStyle[propertyName] = _.bind(value, computedStyle);
        }
      }
    }
    
    return computedStyle;
  };
} else {
  _getComputedStyle = function getComputedStyle(element, pseudoElement) {
    if (arguments.length < 2) {
      throw new ArityError("getComputedStyle");
    }
    if (!element || element.nodeType !== 1) {
      throw new TargetError(DOM_TYPE_ERR, "getComputedStyle");
    }
    
    // for MSIE6-8
    var currentStyle = element.currentStyle || element.style;
    var computedStyle = {};

    for (var propertyName in currentStyle) {
      if (CSS_COLORS.test(propertyName)) {
        computedStyle[propertyName] = cachedColors[currentStyle[propertyName]] || style_compute(element, propertyName);
      } else if (CSS_METRICS.test(propertyName)) {
        computedStyle[propertyName] = style_compute(element, propertyName);
      } else if (!CSS_IGNORE[propertyName]) {
        computedStyle[propertyName] = currentStyle[propertyName];
      }
    }
    for (var i = 0; propertyName = CALCULATED_STYLE_PROPERTIES[i]; i++) {
      computedStyle[propertyName] = style_compute(element, propertyName);
    }
    return computedStyle;
  };
}
