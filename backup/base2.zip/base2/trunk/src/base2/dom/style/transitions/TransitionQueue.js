
var TransitionQueue = _.Collection.extend({
  constructor: function TransitionQueue__constructor(transitions) {
    this.base(transitions);
    this.tick = _.bind(this.tick, this);
  },
  
  add: function TransitionQueue__add(element, propertyName, value, delay, duration, timingFunction) {
    // Break shorthand properties into the longhand version.
    // This only parses property names. Values are parsed in Transition.js.
    if (/^border(Top|Right|Bottom|Left)?$/.test(propertyName)) { // shorthand border properties
      var values = splitPropertyValue(value);
      // recurse after we've broken down shorthand properties
      forEach.csv("Width,Style,Color", function(name, i) {
        this.add(element, propertyName + name, values[i] || "", delay, duration, timingFunction);
      }, this);
    } else if (/^(margin|padding|border(Width|Color|Style))$/.test(propertyName)) { // shorthand rect properties (T,R,B,L)
      var property = propertyName.replace(/Width|Color|Style/, "");
      var name = propertyName.replace(property, "");
      values = splitPropertyValue(value, true);
      forEach.csv("Top,Right,Bottom,Left", function(side, i) {
        this.add(element, property + side + name, values[i] || "", delay, duration, timingFunction);
      }, this);
    } else {
      var key = (element.uniqueID || _.assignID(element)) + "." + propertyName;
      this.set(key, element, propertyName, value, delay, duration, timingFunction);
    }
    if (!this._started) {
      this._started = true;
      setTimeout(this.tick, 0);
    }
  },

  tick: function TransitionQueue__tick() {
    this.invoke("tick", _.now());

    var complete = this.filter(isComplete);

    if (complete.size() > 0) {
      complete.forEach(this.remove, this);
      complete.forEach(fireTransitionEvent);
    }

    if (this.size() > 0) {
      setTimeout(this.tick, CONST_INTERVAL, null);
    } else {
      delete this._started;
    }
  }
}, {
  Item: Transition
});

var transitionQueue = new TransitionQueue;

// help

function isComplete(transition) {
  return transition.complete;
}
