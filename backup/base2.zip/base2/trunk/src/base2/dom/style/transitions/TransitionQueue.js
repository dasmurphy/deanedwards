
var TransitionQueue = _.Collection.extend({
  constructor: function TransitionQueue__constructor(transitions) {
    this.base(transitions);
    this.tick = _.bind(this.tick, this);
  },
  
  add: function TransitionQueue__add(element, propertyName, params) {
    var key = getTransitionKey(element, propertyName);
    transition = this.set(key, element, propertyName, params);
    if (!this._started) {
      this._started = true;
      requestAnimationFrame(this.tick);
    }
    return transition;
  },

  tick: function TransitionQueue__tick() {
    this.invoke("tick", _.now());

    var complete = this.filter(isComplete);

    if (complete.size() > 0) {
      complete.forEach(this.remove, this);
      complete.forEach(fireTransitionEvent);
    }

    if (this.size() > 0) {
      requestAnimationFrame(this.tick);
    } else {
      delete this._started;
    }
  }
}, {
  Item: Transition
});

var transitionQueue = new TransitionQueue;

// help

function isComplete(transition) {
  return transition.complete;
}
