
var NUMBER      = /\d/;
var CSS_PIXEL   = /\dpx$/i;

var CSS_IGNORE = {
  background: 1,
  border: 1,
  margin: 1,
  padding: 1,
  font: 1,
  styleFloat: 1
};

var CSS_METRICS = /((^w|W)idth|(^h|H)eight|(^t|T)op|(^b|B)ottom|(^l|L)eft|(^r|R)ight|X|Y|Radius|Size|Indent)$/;

var CSS_METRICS_HORIZONTAL = /((^w|W)idth|(^l|L)eft|(^r|R)ight|X)$/;

var CSS_COLORS = /(^c|C)olor$/;

var SUPPORTS_GET_COMPUTED_STYLE = false;
var FIX_COMPUTED_STYLE_COLOR    = false; // Opera 9
var FIX_COMPUTED_STYLE_PADDING  = false; // Opera 9
var FIX_COMPUTED_STYLE_PERCENT  = false; // Chrome

var SUPPORTS_TRANSITION = SUPPORTS_TRANSITION_END;
var SUPPORTS_TRANSFORM  = SUPPORTS_TRANSITION && _.detect("(style.transform)");

(function(getComputedStyle) {
try {
  var element = document.createElement("div");
  var style = element.style;
  style.position = "absolute";
  style.left = "-1000%";
  documentElement.appendChild(element);
  FIX_COMPUTED_STYLE_PERCENT = /%$/.test(getComputedStyle(element, null).left);
  SUPPORTS_GET_COMPUTED_STYLE = true;
  FIX_COMPUTED_STYLE_COLOR = getComputedStyle(documentElement, null).color.charAt(0) === "#";
  if (element.currentStyle) _private.deferUntil(function(){
    document.body.appendChild(element);
    style.width = "1px";
    style.padding = "1px";
    FIX_COMPUTED_STYLE_PADDING = element.currentStyle.pixelWidth !== 1;
    document.body.removeChild(element);
  }, function() {
    return document.body;
  });
} catch(ex){}
  if (element.parentNode) element.parentNode.removeChild(element);
})(window.getComputedStyle);

var CSS_INLINE_BLOCK = _.detect("Gecko1\\.[^9]") ? "-moz-inline-box" : "inline-block";

var CALCULATED_STYLE_PROPERTIES = "backgroundPosition,boxSizing,clip,cssFloat,opacity".split(",");

var MOZ_BORDER_RADIUS    = "MozBorderRadiusTopleft" in styleObject;
var BORDER_RADIUS_CORNER = /^border(\w+)Radius$/;

var SUPPORTS_VENDOR_EXTENSIONS = !_.detect("MSIE[678]");

var CSS_NAMED_BORDER_WIDTH = {
  thin: 1,
  medium: 2,
  thick: 4
};

var DASH_LOWER = /\-([a-z])/g;
function toUpper(match, chr) {
  return chr.toUpperCase();
}

var transitionProperties = {
  transitionDelay: "0s",
  transitionDuration: "0s",
  transitionProperty: "all",
  transitionTimingFunction: "cubiz-bezier(0.25, 0.1, 0.25, 1)"
};

var _createTransition;

var getStylePropertyName = _.memoize(function getStylePropertyName(propertyName) {
  propertyName += "";

  var isAttribute = /\-/.test(propertyName);

  if (isAttribute) {
    propertyName = propertyName.replace(DASH_LOWER, toUpper);
  }
  
  if (SUPPORTS_VENDOR_EXTENSIONS && !(propertyName in styleObject)) {
    if (MOZ_BORDER_RADIUS && BORDER_RADIUS_CORNER.test(propertyName)) {
      propertyName = propertyName.replace(BORDER_RADIUS_CORNER, function(match, corner) {
        return "MozBorderRadius" + corner.charAt(0) + corner.slice(1).toLowerCase();
      });
    } else {
      propertyName = getVendorPropertyName(styleObject, propertyName);
    }
  }
  
  return isAttribute ? propertyName.replace(/([A-Z])/g, "-$1").toLowerCase() : propertyName;
});

_private.getStylePropertyName = getStylePropertyName;

function getStylePropertyNames(names) {
  names = String(names).match(/[^\s,]+/g) || [];
  return _.map(names, getStylePropertyName).join(",");
}

var vendorPropertyNames = getStylePropertyName.cache = {
  cssFloat: "cssFloat" in styleObject ? "cssFloat" : "styleFloat"
};

if (!SUPPORTS_TRANSITION_END) {
  for (var i in transitionProperties) {
    vendorPropertyNames[i] = i;
    CALCULATED_STYLE_PROPERTIES.push(i);
  }
}

var parseInt16 = _.partial(parseInt, undefined, 16);

var toRGB = _.memoize(function toRGB(color) {
  if (color.indexOf("rgb(") === 0) {
    color = color.replace(/,(\d)/gi, ", $1");
  } else if (color.indexOf("#") === 0) {
    var hex = color.slice(1);
    if (hex.length === 3) {
      hex = hex.replace(/([0-9a-f])/g, "$1$1");
    }
    color = "rgb(" + _.map(hex.match(/([0-9a-f]{2})/gi), parseInt16).join(", ") + ")";
  }
  return color;
});

var cachedColors = toRGB.cache = {transparent: "transparent"};

var _colorDocument;
/*@
try {
  _colorDocument = new ActiveXObject("htmlfile");
  _colorDocument.write("");
  _colorDocument.close();
} catch (ex) {
  _colorDocument = createPopup().document;
}
@*/

function computeAutoValue(element, propertyName) {
  switch (propertyName) {
    case "left":
      return element.offsetLeft + "px";

    case "right":
      return ((element.offsetParent || element).offsetWidth - element.offsetWidth) + "px";
  }
}
