
var transitionQueue = new TransitionQueue;

return createTransition;

})(); // end: closure
