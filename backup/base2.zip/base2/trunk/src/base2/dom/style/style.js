
function style_get(element, propertyName) {
  if (arguments.length < 2) throw new ArityError("style.get");
  if (!element || element.nodeType !== 1) throw new TargetError(DOM_TYPE_ERR, "style.get");

  var style = element.style;

  /*@
    if (propertyName == "opacity") {
      return style.opacity || "";
    }
  @*/

  var isTransitionProperty = propertyName === "transitionProperty";

  var vendorName = vendorPropertyNames[propertyName];
  if (vendorName) {
    propertyName = vendorName;
  } else if (SUPPORTS_VENDOR_EXTENSIONS && !(propertyName in styleObject)) {
    propertyName = getStylePropertyName(propertyName);
  }

  if (propertyName in styleObject || transitionProperties[propertyName]) {
    var value = style[propertyName] || "";
    if (value === "-moz-inline-box") value = "inline-block";
  }
  return value && isTransitionProperty ? value.replace(/^\-\w+\-/, "") : value;
}

function style_set(element, propertyName, value, important) {
  if (arguments.length < 2) throw new ArityError("style.set");
  if (!element || element.nodeType !== 1) throw new TargetError(DOM_TYPE_ERR, "style.set");

  if (arguments.length > 2) {
    var properties = {};
    properties[propertyName] = value;
  } else {
    properties = _.extend({}, arguments[1]);
  }

  var style = element.style;

  if (!SUPPORTS_TRANSITION) {
    for (propertyName in transitionProperties) if (propertyName in properties) {
      value = String(properties[propertyName]);
      if (propertyName === "transitionProperty") {
        value = getStylePropertyNames(value);
      }
      style[propertyName] = value;
    }
    if (element[IS_CONNECTED] && parseInt(style.transitionDuration) > 0) {
      var transitionProperty = style.transitionProperty || "all";
      if (transitionProperty !== "all") {
        transitionProperty = transitionProperty.replace(DASH_LOWER, toUpper).match(/[^\s,]+/g);
      }
    }
  }

  for (propertyName in properties) {
    value = String(properties[propertyName]);
    if (propertyName === "transitionProperty") {
      value = getStylePropertyNames(value);
    } else if (value === "inline-block") {
      value = CSS_INLINE_BLOCK;
    }

    var vendorName = vendorPropertyNames[propertyName];
    if (vendorName) {
      propertyName = vendorName;
    } else if (SUPPORTS_VENDOR_EXTENSIONS && !(propertyName in styleObject)) {
      propertyName = getStylePropertyName(propertyName);
    }

    /*@
      if (propertyName == "opacity" && !(propertyName in styleObject)) {
        style.zoom = "1";
        style.filter = "alpha(opacity=" + ~~(value * 100) + ")";
        continue;
      }
    @*/

    if (propertyName in styleObject) {
      if (important) {
        propertyName = propertyName.replace(/([A-Z])/g, "-$1").toLowerCase();
        if (style.setProperty) {
          style.setProperty(propertyName, value, "important");
        } else {
          style.cssText += _.format(";{0}:{1}!important;", propertyName, value);
        }
      } else if (transitionProperty && (transitionProperty === "all" || _.indexOf(transitionProperty, propertyName) !== -1)) {
        _createTransition(element, propertyName, value);
      } else {
        style[propertyName] = value;
      }
    }
  }
}

if (SUPPORTS_GET_COMPUTED_STYLE) {
  var style_compute = function style_compute(element, propertyName) {
    if (arguments.length < 2) throw new ArityError("style.compute");
    if (!element || element.nodeType !== 1) throw new TargetError(DOM_TYPE_ERR, "style.compute");
    
    var vendorName = vendorPropertyNames[propertyName];
    if (vendorName) {
      propertyName = vendorName;
    } else if (SUPPORTS_VENDOR_EXTENSIONS && !(propertyName in styleObject)) {
      propertyName = getStylePropertyName(propertyName);
    }
    
    var view = element.ownerDocument.defaultView;
    var computedStyle = view.getComputedStyle(element, null);
    var value = computedStyle[propertyName];

    if (FIX_COMPUTED_STYLE_COLOR && CSS_COLORS.test(propertyName)) {
      value = cachedColors[value] || toRGB(value);
    } else if (FIX_COMPUTED_STYLE_PERCENT && /%$/.test(value)) {
      var offset = CSS_METRICS_HORIZONTAL.test(propertyName) ? "offsetWidth" : "offsetHeight";
      value = Math.round((element.offsetParent || element)[offset] * (value.slice(0, -1) / 100)) + "px";
    } else if (FIX_COMPUTED_STYLE_PADDING && propertyName == "width") {
      value = (element.clientWidth - parseInt(computedStyle.paddingLeft) - parseInt(computedStyle.paddingRight)) + "px";
    } else if (FIX_COMPUTED_STYLE_PADDING && propertyName == "height") {
      value = (element.clientHeight - parseInt(computedStyle.paddingTop) - parseInt(computedStyle.paddingBottom)) + "px";
    } else if (value === "auto") {
      value = computeAutoValue(element, propertyName);
    }
    
    return value;
  };
} else {
  style_compute = function style_compute(element, propertyName) {
    if (arguments.length < 2) throw new ArityError("style.compute");
    if (!element || element.nodeType !== 1) throw new TargetError(DOM_TYPE_ERR, "style.compute");

    // for MSIE6-8

    var currentStyle = element.currentStyle || element.style;
    var value = currentStyle[propertyName] || transitionProperties[propertyName] || "";

    if (CSS_METRICS.test(propertyName)) {
      if (value === "auto") {
        return computeAutoValue(element, propertyName);
      }
      if (CSS_PIXEL.test(value)) return value;
      if (propertyName.indexOf("border") === 0) {
        if (currentStyle[propertyName.replace("Width", "Style")] === "none") return "0px";
        value = CSS_NAMED_BORDER_WIDTH[value] || value;
        if (typeof value == "number") return value + "px";
      }
      if (NUMBER.test(value)) {
        var position = CSS_METRICS_HORIZONTAL.test(propertyName) ? "left" : "top";
        var styleLeft = element.style[position];
        var runtimeStyleLeft = element.runtimeStyle[position];
        element.runtimeStyle[position] = element.currentStyle[position];
        element.style[position] = value;
        value = element.style["pixel" + position.charAt(0).toUpperCase() + position.slice(1)];
        element.style[position] = styleLeft;
        element.runtimeStyle[position] = runtimeStyleLeft;
        return value + "px";
      }
    } else if (CSS_COLORS.test(propertyName)) {
      if (!cachedColors[value]) {
        var color = value;
        if (/^(#|rgb)/.test(color)) {
          color = toRGB(color);
        } else if (_colorDocument) {
          var body  = _colorDocument.body;
          var range = body.createTextRange();
          body.style.color = color;
          color = range.queryCommandValue("ForeColor");
          color = "rgb(" + (color & 0xff) + ", " + ((color & 0xff00) >> 8) + ", " + ((color & 0xff0000) >> 16) + ")";
        }
        cachedColors[value] = color;
      }
      return cachedColors[value];
    } else switch (propertyName) {
      case "opacity":
        return value === "" ? "1" : value;

      case "cssFloat":
        return currentStyle.styleFloat || "none";

      case "clip":
        return "rect(" + [
          currentStyle.clipTop,
          currentStyle.clipRight,
          currentStyle.clipBottom,
          currentStyle.clipLeft
        ].join(", ") + ")";

      case "backgroundPosition":
        return currentStyle.backgroundPositionX + " " + currentStyle.backgroundPositionY;

      case "boxSizing":
        return value === ""
          ? element.ownerDocument.compatMode === "BackCompat"
            ? "border-box"
            : "content-box"
          : value;
    }

    return value;
  };
}

style = {
  compute:  style_compute,
  get:      style_get,
  set:      style_set,
  toString: _.K("[base2.dom.style]")
};
