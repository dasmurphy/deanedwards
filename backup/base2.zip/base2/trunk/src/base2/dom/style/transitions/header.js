
var CONST_INTERVAL  = 14; // 70 fps
var CONST_PRECISION = 1000;

var CUBIC_BEZIER = /^cubic\-bezier\([.\d]+,[.\d]+,[.\d]+,[.\d]+\)$/;
var NUMERIC      = /^\-?\.?\d/;
var NON_NEGATIVE = /((^w|W)idth|(^h|H)eight|Radius|^(opacity|fontSize))$/;

function fireTransitionEvent(transition) {
  if (transition.elapsedTime > .016) {
    var element = transition.element;
    var event = dom.createEvent(element.ownerDocument, "Event");
    event.initEvent("transitionend", true, false);
    event.propertyName = transition.propertyName.replace(/([A-Z])/g, "-$1").toLowerCase();
    event.elapsedTime = transition.elapsedTime;
    dom.dispatchEvent(element, event);
  }
}

function splitPropertyValue(value, fill) { // used for splitting multiple CSS values
  if (value == null) return [];
  value = _.trim(value).split(/\s+/);
  if (fill) {
    if (value.length === 1) value[1] = value[0];
    if (value.length === 2) value[2] = value[0];
    if (value.length === 3) value[3] = value[1];
  }
  return value;
}

function parseTime(time) {
  return +String(time).replace(/(m)?s$/, function($, ms) {
    return ms ? "" : "000";
  });
}

var parseColor = _.memoize(function parseColor(rgb) { // return an array of rgb values
  return _.map(rgb.match(/\d+%?/g), function(value) {
    return /%/.test(value) ? Math.round(2.55 * value.slice(0, -1)) : ~~value;
  });
});
