
// Special parsing of colours and "clip" are bulking this out. :-(

var Transition = _.Base.extend({
  constructor: function Transition__constructor(key, element, propertyName, params) {
    _.extend(this, params);

    this.toString = _.K(key);
    this.element = element;
    this.propertyName = propertyName;

    this.start = style_compute(element, propertyName);
    
    var style = element.style;
    var timestamp = 0;
    var started = 0;
    var elapsedTime = 0;
    var delay = this.delay;
    var duration = this.duration;
    
    var ease = timingFunctions[this.timingFunction];
    if (!ease) {
      ease = String(this.timingFunction).replace(/\s+/g, "");
      if (CUBIC_BEZIER.test(ease)) {
        ease = cubizBezier.apply(null, ease.slice(13, -1).split(","));
      }
    }
    if (!_.isFunction(ease)) throw new TypeError("Invalid timing function.");

    if (this.end === "auto") {
      var value = style[propertyName];
      style[propertyName] = "";
      this.end = style_compute(element, propertyName);
      style[propertyName] = value;
    }
    
    // Parse the start/end values and create the easing function.
    if (/[cC]olor$/.test(propertyName)) {
      var startValue = cachedColors[this.start] || parseColor(this.start);
      var endValue = cachedColors[this.end] || parseColor(this.end);
      var delta = _.map(startValue, function(value, i) {
        return endValue[i] - value;
      });
      var calculateValue = function calculateValue_color(t) {
        return "rgb(" + _.map(startValue, function(startValue, i) {
          var value = Math.round(ease(t, startValue, delta[i], duration));
          if (value < 0) value = 0; else if (value > 255) value = 255;
          return value;
        }).join(", ") + ")";
      };
    } else if (propertyName === "clip") {
      startValue = _.map(this.start.match(DIGITS), Number);
      endValue = _.map(this.end.match(DIGITS), Number);
      delta = _.map(startValue, function(value, i) {
        return endValue[i] - value;
      });
      calculateValue = function calculateValue_clip(t) {
        return "rect(" + _.map(startValue, function(value, i) {
          return Math.round(ease(t, value, delta[i], duration));
        }).join("px, ") + "px)";
      };
    } else if (/^\-?\.?\d/.test(this.start)) { // Numeric.
      startValue = parseInt(this.start);
      style[propertyName] = this.end;
      this.end = style_compute(element, propertyName);
      endValue = parseInt(this.end);
      style[propertyName] = this.start;
      delta = endValue - startValue;
      var nonNegative = NON_NEGATIVE.test(propertyName);
      calculateValue = function calculateValue_number(t) {
        var value = Math.floor(ease(t, startValue, delta, duration) * CONST_PRECISION) / CONST_PRECISION;
        value = (nonNegative && value < 0 ? 0 : Math.round(value)) + "px";
        return value;
      };
    } else {
      endValue = this.end || "";
      calculateValue = function calculateValue_binary(t) { // flip only at the end
        return ease(t, 0, 1, duration) < 1 ? startValue : endValue;
      };
    }

    this.complete = this.compare(this.end, "start");
    
    this.tick = function Transition__tick(now) {
      if (!timestamp) timestamp = now;
      if (!this.complete) {
        elapsedTime = now - timestamp;
        if (!started && elapsedTime >= delay) {
          started = now;
        }
        if (started) {
          elapsedTime = Math.round(Math.min(now - started, duration));

          this.complete = elapsedTime >= duration;

          if (this.complete) {
            var value = this.end;
          } else {
            value = calculateValue(elapsedTime);
          }

          style[propertyName] = value;
          
          if (this.complete) {
            this.elapsedTime = (now - timestamp) / 1000;
          }
        }
      }
    };
  },

  complete: false,
  elapsedTime: 0,
  delay: 0,
  duration: 1, // seconds
  timingFunction: "ease",
  start: null,
  end: null,

  compare: function Transition__compare(value, position) {
    if (/[cC]olor$/.test(this.propertyName)) {
      var color1 = cachedColors[this[position]] || parseColor(this[position]);
      var color2 = cachedColors[value] || parseColor(value);
      return color1[0] === color2[0] && color1[1] === color2[1] && color1[2] === color2[2];
    } else if (this.propertyName === "clip") {
      // Stoopid incompatible clip rects:
      // http://www.ibloomstudios.com/articles/misunderstood_css_clip/
      var COMMAS = /,\s+/g;
      return this[position].replace(COMMAS, ",") === value.replace(COMMAS, ",");
    }
    return this[position] == value;
  }
});
