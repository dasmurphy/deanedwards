
var Transition = _.Base.extend({
  constructor: function Transition__constructor(key, element, propertyName, value, delay, duration, timingFunction) {
    this.toString = _.K(key);
    this.element = element;
    this.propertyName = propertyName;
    
    var style = element.style;
    var timestamp = _.now();
    var started = 0;

    var startValue = style_compute(element, propertyName);
    style[propertyName] = value;

    var endValue = style_compute(element, propertyName);
    style[propertyName] = startValue;

    this.complete = endValue === startValue;

    if (this.complete) return;
    
    // Parse the start/end values and create the easing function.
    if (/[cC]olor$/.test(propertyName)) {
      startValue = parseColor(startValue);
      endValue = parseColor(endValue);
      var delta = _.map(startValue, function(value, i) {
        return endValue[i] - value;
      });
      var calculateValue = function calculateValue_color(t) {
        return "rgb(" + _.map(startValue, function(startValue, i) {
          var value = Math.round(timingFunction(t, startValue, delta[i], duration));
          return value < 0 ? 0 : value > 255 ? 255 : value;
        }).join(", ") + ")";
      };
    } else if (propertyName === "clip") {
      startValue = _.map(startValue.match(/\d+/g), Number);
      endValue = _.map(endValue.match(/\d+/g), Number);
      delta = _.map(startValue, function(value, i) {
        return endValue[i] - value;
      });
      calculateValue = function calculateValue_clip(t) {
        return "rect(" + _.map(startValue, function(value, i) {
          return Math.round(timingFunction(t, value, delta[i], duration));
        }).join("px, ") + "px)";
      };
    } else if (/^\-?\.?\d/.test(endValue)) { // Numeric.
      var nonNegative = NON_NEGATIVE.test(propertyName);
      var unit = endValue.replace(/^[.\d-]+/, "");
      startValue = parseInt(startValue);
      endValue = parseInt(endValue);
      delta = endValue - startValue;
      calculateValue = function calculateValue_number(t) {
        var value = Math.floor(timingFunction(t, startValue, delta, duration) * CONST_PRECISION) / CONST_PRECISION;
        if (unit === "px") value = Math.round(value);
        return (nonNegative && value < 0 ? 0 : value) + unit;
      };
    } else {
      calculateValue = function calculateValue_binary(t) { // flip only at the end
        return timingFunction(t, 0, 1, duration) < 1 ? startValue : endValue;
      };
    }
    
    this.tick = function Transition__tick(now) {
      if (!this.complete) {
        if (!started && now - timestamp >= delay) {
          started = now;
        }
        if (started) {
          var t = now - started;

          this.complete = t >= duration;

          style[propertyName] = this.complete ? value : calculateValue(t);

          if (this.complete) {
            this.elapsedTime = t / 1000;
          }
        }
      }
    };
  },

  complete: false,
  elapsedTime: 0,
  tick: _.Undefined
});
