
_createTransition = function createTransition(element, propertyName, value) {
  var style = element.style;

  var delay = parseTime(style.transitionDelay) || 0;
  var duration = parseTime(style.transitionDuration) || 1000;
  var timingFunction = parseTimingFunction(style.transitionTimingFunction);

  // Some shorthand properties cannot be parsed yet. (I may fix backgroundPosition eventually).
  if (/^(font|background(Position)?)$/.test(propertyName)) {
    setTimeout(function() {
      style[propertyName] = value;
    }, delay);
  }

  transitionQueue.add(element, propertyName, value, delay, duration, timingFunction);
};
