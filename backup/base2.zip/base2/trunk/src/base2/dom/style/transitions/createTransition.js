
_createTransition = function createTransition(element, propertyName, value) {
  var style = element.style;

  var delay = parseTime(style.transitionDelay) || 0;
  var duration = parseTime(style.transitionDuration) || 1000;
  var timingFunction = style.transationTimingFunction || "ease";

  if (timingFunctions[timingFunction]) {
    timingFunction = timingFunctions[timingFunction];
  } else {
    timingFunction = String(timingFunction).replace(/\s+/g, "");
    if (CUBIC_BEZIER.test(timingFunction)) {
      timingFunction = cubizBezier.apply(null, timingFunction.slice(13, -1).split(","));
    }
  }

  if (!_.isFunction(timingFunction)) {
    throw new TypeError("Invalid timing function.");
  }

  // Some shorthand properties cannot be parsed. (I may fix backgroundPosition eventually).
  if (/^(font|background(Position)?)$/.test(propertyName)) {
    var timestamp = new Date;
    setTimeout(function() {
      style[propertyName] = value;
      fireTransitionEvent({
        element: element,
        propertyName: propertyName,
        elapsedTime: (new Date - timestamp) / 1000
      });
    }, delay);
  }

  transitionQueue.add(element, propertyName, value, delay, duration, timingFunction);
};
