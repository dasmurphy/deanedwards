
_createTransition = function createTransition(element, propertyName, value) {
  var style = element.style;

  // Break shorthand properties into the longhand version.
  // This only parses property names. Values are parsed in Transition.js.
  // Some shorthand properties cannot be parsed. (I may fix backgroundPosition eventually).
  if (/^(font|background(Position)?)$/.test(propertyName)) {
    var timestamp = new Date;
    setTimeout(function() {
      style[propertyName] = value;
      fireTransitionEvent({
        element: element,
        propertyName: propertyName,
        elapsedTime: (new Date - timestamp) / 1000
      });
    }, parseTime(style.transitionDelay) || 4);
  } else if (/^border(Top|Right|Bottom|Left)?$/.test(propertyName)) { // shorthand border properties
    var names = ["Width", "Style", "Color"];
    var values = splitPropertyValue(value);
    // recurse after we've broken down shorthand properties
    forEach (values, function(value, i) {
      _createTransition(element, propertyName + names[i], value);
    });
  } else if (/^(margin|padding|border(Width|Color|Style))$/.test(propertyName)) { // shorthand rect properties (T,R,B,L)
    var property = propertyName.replace(/Width|Color|Style/, "");
    var name = propertyName.replace(property, "");
    values = splitPropertyValue(value, true);
    forEach.csv("Top,Right,Bottom,Left", function(side, i) {
      _createTransition(element, property + side + name, values[i]);
    });
  } else {
    transitionQueue.add(element, propertyName, {
      end: value,
      delay: parseTime(style.transitionDelay) || 0,
      duration: parseTime(style.transitionDuration) || 1000,
      timingFunction: style.transationTimingFunction || "ease"
    });
  }
};
