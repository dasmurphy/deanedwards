
// http://www.w3.org/TR/css3-selectors/#w3cselgrammar (kinda)

var strings = [];

CSSSelectorParser = (function() {

  var VALID_SELECTOR = /^(\\.|['\s>+~#.\[\]:*(),\w\-\^|$=]|[^\x00-\xa0])+$/;

  var IMPLIED_ASTERISK    = /(^|[, >+~])([#.:\[])/g;
  var ESCAPED             = /'(\d+)'/g;
  var ESCAPE              = /\\/g;
  var HEX_ESCAPE          = /\\([\da-f]{2})/gi;
  var UNESCAPE            = /\\([nrtf'"])/g;

  var domElement = document.createElement("div");

  var matcher;

  var indexes = {};

  CSSSelectorParser = _.RegGrp.extend({
    dictionary: new _.RegGrp.Dict([
      "string1",         /'(\\.|[^'\\])*'/,
      "string2",         /"(\\.|[^"\\])*"/,
      "string",          /<#string1>|<#string2>/,
      "ident",           /\-?(\\.|[a-z_]|[^\x00-\xa0])(\\.|[\w\-]|[^\x00-\xa0])*/,
      "combinator",      /[\s>+~]/,
      "operator",        /[\^~|$*]?=/,
      "nth_arg",         /[+-]?\d+|[+-]?\d*n(?:\s*[+-]\s*\d+)?|even|odd/,
      "tag",             /\*|<#ident>/,
      "id",              /#(<#ident>)/,
      "class",           /\.(<#ident>)/,
      "pseudo",          /\:([\w\-]+)(?:\(([^)]+)\))?/,
      "attr",            /\[(<#ident>)(?:(<#operator>)((?:\\.|[^\]\[#.:])+))?\]/,
      "negation",        /:not\((<#tag>|<#id>|<#class>|<#attr>|<#pseudo>)\)/,
      "sequence",        /(\\.|[~*]=|\+\d|\+?\d*n\s*\+\s*\d|[^\s>+~,\*])+/,
      "filter",          /[#.:\[]<#sequence>/,
      "selector",        /[^>+~](\\.|[^,])*/,
      "grammar",         /^(<#selector>)((,<#selector>)*)$/
    ]),

    ignoreCase: true,

    escape: function CSSSelectorParser__escape(selector) {
      selector =
        this.normalize(_.trim(selector)
          .replace(HEX_ESCAPE, "\\x$1"))
          .replace(UNESCAPE, "$1")
          .replace(IMPLIED_ASTERISK, "$1*$2");
      if (!VALID_SELECTOR.test(selector)) throwSelectorError();
      return selector;
    },

    normalize: function CSSSelectorParser__normalize(selector) {
      normalize.setAt(0, function(string) {
        string = string.replace(UNESCAPE, "$1");
        var index = string in indexes ? indexes[string] : strings.length;
        strings[index] = string;
        indexes[string] = index;
        return "'" + index + "'";
      });
      return normalize.parse(selector);
    },

    split: function CSSSelectorParser__split(selector) {
      return _.map(this.escape(selector).split(","), this.unescape, this);
    },

    validate: _.memoize(function(selector) {
      try {
        dom.matches(domElement, selector);
        return true;
      } catch (ex) {
        return false;
      }
    }),

    unescape: function CSSSelectorParser__unescape(selector) {
      // put string values back
      return String(selector).replace(ESCAPED, function(match, index) {
        return strings[index];
      });
    }
  });

  // Trim and encode strings
  var normalize = new CSSSelectorParser([
    /<#string>/, "",
    /\\.|[~*]\s+=|\+\s+\d/, IGNORE,
    /\[\s+/, "[",
    /\(\s+/, "(",
    /\s+\)/, ")",
    /\s+\]/, "]",
    /\s*([,>+~]|<#operator>)\s*/, "$1",
    /\s+$/, "",
    /\s+/, " "
  ]);

  return CSSSelectorParser;
})();

function throwSelectorError() {
  var error = new SyntaxError("SYNTAX_ERR: CSSSelectorParser");
  error.code = 12;
  throw error;
}
