
var IGNORE = _.RegGrp.IGNORE;

var SUPPORTS_QSA         = !!element.querySelector;

var BLOCKS               = /\)\{/g;
var COMMA                = /,/;
var QUOTED               = /^['"]/;
var LAST_CHILD           = /last/i;

var SPACE                = /\s/;

var SIBLING              = (SUPPORTS_TRAVERSAL_API ? "Element" : "") + "Sibling";
var NEXT_SIBLING         = SUPPORTS_TRAVERSAL_API ? "e.nextElementSibling" : "(e.nextSibling&&_getNextElementSibling.call(e))";
var PREVIOUS_SIBLING     = SUPPORTS_TRAVERSAL_API ? "e.previousElementSibling" : "(e.previousSibling&&_getPreviousElementSibling.call(e))";

var NO_CHILDREN          = /^(base|br|hr|img|input|link|meta|param|source)$/i;

var NOT_NEXT_BY_TYPE     = "!_getElementSiblingByType(e,'next')&&";
var NOT_PREVIOUS_BY_TYPE = NOT_NEXT_BY_TYPE.replace("next", "previous");
    
var ID_ATTRIBUTE         = "(e.nodeName==='FORM'?e.getAttribute('id'):e.id)";

var QSA_GET_ATTRIBUTE    = BROKEN_GET_ATTRIBUTE ? "_getAttribute.call(e,'" : "e.getAttribute('";
var QSA_HAS_ATTRIBUTE    = BROKEN_GET_ATTRIBUTE ? "_hasAttribute.call(e,'" : "e.hasAttribute('";

var object = document.createElement("object");
object.appendChild(document.createElement("param"));
var BUGGY_OBJECT_SELECTORS = object.getElementsByTagName("*").length === 0;
object = null;

var useBase2 = {};

if (SUPPORTS_QSA) {
  var USE_BASE2 = _.False;
  
  // Fix for Safari 3.1/3.2 (http://code.google.com/p/base2/issues/detail?id=100)
  var CAPS_SELECTOR = /[#.](\\.|[\w\-]|[^\x00-\xa0])*[A-Z]/;
  var FIX_CAPS_SELECTOR = _.detect("WebKit52"); // This is a browser sniff as the target document may not be in quirks mode
  
  var pattern = "";
  element.innerHTML = "<a></a>";
  element.firstChild.href = location.href;
  // Empty attribute selectors (MSIE8/Opera10)
  if (element.querySelector("[href^='']")) {
    pattern += "|[\\^*~|$]=\\s*(['\"])\\1";
  }
  // Security
  if (element.querySelector(":visited") != null) {
    pattern += "|:link|:visited";
  }
  // Known bug with Gecko 1.9.0/1
  if (_.detect("Gecko1\\.9(\\.[01])?")) {
    pattern += "|:enabled|:disabled";
  }
  // Known bug with Opera10-10.52
  if (_.detect("Opera10(\\.[0-5])?")) {
    pattern += "|:checked";
  }
  /*@
    if (document.documentMode < 9) {
      pattern += "|\\[\\s*(value|ismap|checked|disabled|multiple|readonly|selected)|\\b(object|param|command)\\b";
    }
  @*/
  // Selectors API 2
  if (!_.detect("(element.querySelector(':scope'))")) {
    pattern += "|[^\\s\\S]";
  }
  if (pattern) {
    USE_BASE2 = new RegExp(pattern.slice(1), "i");
  }
}

// MSIE (and Opera) confuse the name attribute with id for some elements.
// Use document.all to retrieve elements with name/id instead.
try {
  var id = _.assignID();
  
  element.innerHTML = '<a name="' + id + '"></a>';
  documentElement.insertBefore(element, documentElement.firstChild);
  var BUGGY_BY_ID = document.getElementById(id) == element.firstChild;
  documentElement.removeChild(element);

  if (BUGGY_BY_ID && document.all) {
    _getElementById = function getElementById(id) {
      var result = this.all[id] || null;
      var getAttribute = _getAttribute || element.getAttribute;
      // Returns a single element or a collection.
      if (!result || (result.nodeType && getAttribute.call(result, "id") === id)) return result;
      // document.all has returned a collection of elements with name/id
      for (var i = 0; i < result.length; i++) {
        if (getAttribute.call(result[i], "id") === id) return result[i];
      }
      return null;
    }
  }
} catch(ex){}

// http://dean.edwards.name/weblog/2009/12/getelementsbytagname/
function _getElementsByTagName(node, tagName) {
  var anyTag = tagName === "*";
  
  if (node.getElementsByTagName && !(BUGGY_OBJECT_SELECTORS && anyTag && node.nodeName === "OBJECT")) {
    return node.getElementsByTagName(tagName);
  }
  var elements = [], i = 0;
  var next = node.firstChild;
  var TAGNAME = tagName.toUpperCase();
  while ((node = next)) {
    if (
      anyTag
        ? node.nodeType === 1
        : node.nodeName === TAGNAME || node.nodeName === tagName
    ) elements[i++] = node;
    next = node.firstChild || node.nextSibling;
    while (!next && (node = node.parentNode)) next = node.nextSibling;
  }
  return elements;
}

// Register a node and index its siblings.
_private.qIndex = 1;
var allIndexes = {qIndex: 1};

function _indexOf(element, last, ofType) {
  var parent = element.parentNode;
  if (!parent || parent.nodeType !== 1) return NaN;
  
  var tagName = ofType ? element.nodeName : "";
  if (tagName === "TR" && element.sectionRowIndex >= 0) {
    var index = element.sectionRowIndex;
    return last ? element.parentNode.rows.length - index + 1 : index;
  }
  if ((tagName === "TD" || tagName === "TH") && element.cellIndex >= 0) {
    index = element.cellIndex;
    return last ? element.parentNode.cells.length - index + 1 : index;
  }
  if (allIndexes.qIndex !== _private.qIndex) {
    allIndexes = {qIndex: _private.qIndex};
  }
  var id = (parent.uniqueID || _.assignID(parent)) + "-" + tagName;
  var indexes = allIndexes[id];
  if (!indexes) {
    indexes = {};
    var index = 0;
    var child = parent.firstChild;
    while (child) {
      if (ofType ? child.nodeName === tagName : child.nodeType === 1) {
        indexes[child.uniqueID || _.assignID(child)] = ++index;
      }
      child = child.nextSibling;
    }
    indexes.length = index;
    allIndexes[id] = indexes;
  }
  index = indexes[element.uniqueID];
  return last ? indexes.length - index + 1 : index;
}

function _getLang(element) {
  var lang = "";
  while (element && element.nodeType === 1) {
    lang = element.lang || element.getAttribute("lang") || "";
    if (lang) break;
    element = element.parentNode;
  }
  return lang;
}

function _isEmpty(element) {
  if (element.canHaveChildren === false) return false;
  if (element.style && NO_CHILDREN.test(element.nodeName)) return false;
  var node = element.firstChild;
  while (node) {
    if (node.nodeType === 3 || node.nodeType === 1) return false;
    node = node.nextSibling;
  }
  return true;
}

function _getElementSiblingByType(element, direction) {
  var tagName = element.nodeName;
  direction += SIBLING;
  do {
    element = element[direction];
    if (element && element.nodeName === tagName) break;
  } while (element);
  return element;
}
