
// http://www.w3.org/TR/selectors-api/#nodeselector

var prependScope = new CSSSelectorParser([
  /^\s*:scope/,  IGNORE,
  "<#string>",   IGNORE,
  /\\./,         IGNORE,
  /,\s*:scope/,  IGNORE,
  /^\s*(.)/,     ":scope $1",
  ",",           ",:scope "
]);

var scopeToId = new CSSSelectorParser([
  "<#string>", IGNORE,
  /\\./,       IGNORE
]);

var safeSelectors = {};

if (!_.detect("(element.matches(':scope'))")) {
  _matches = function matches(selector, refNode) {
    if (arguments.length < 1) throw new ArityError("matches");

    //selector = prependScope.parse(selector);

    var query = matchQuery.cache[selector];
    if (!query) {
      query = matchQuery.create(String(selector));
    }
    var result = query.call(this, refNode);

    if (result && result._isSyntaxError) throw result;

    return result;
  };
}

if (USE_BASE2 != _.False) {
  _querySelector = function querySelector(selector) {
    if (arguments.length < 1) throw new ArityError("querySelector");

    var result = _executeQuery("querySelector", this, selector);

    if (result && result._isSyntaxError) throw result;

    return result;
  };

  _querySelectorAll = function querySelectorAll(selector) {
    if (arguments.length < 1) throw new ArityError("querySelectorAll");

    var result = _executeQuery("querySelectorAll", this, selector);

    if (result._isSyntaxError) throw result;

    return result;
  };
}

if (!_.detect("(element.find(':scope'))")) {
  _find = function find(selector, refNode) {
    if (arguments.length < 1) throw new ArityError("find");

    var node = this;
    if (node.nodeType === 1) {
      refNode = this;
      node = node.parentNode || node;
    }

    var result = _executeQuery("querySelector", node, prependScope.parse(selector), refNode);

    if (result && result._isSyntaxError) throw result;

    return result;
  };

  _findAll = function findAll(selector, refNode) {
    if (arguments.length < 1) throw new ArityError("findAll");

    var node = this;
    if (node.nodeType === 1) {
      refNode = this;
      node = node.parentNode || node;
    }

    var result = _executeQuery("querySelectorAll", node, prependScope.parse(selector), refNode);

    if (result._isSyntaxError) throw result;

    return result;
  };
}

_executeQuery = function executeQuery(methodName, node, selector, refNode) {
  selector += "";
  
  var result;

  if (SUPPORTS_QSA) {
    var document = node.ownerDocument || node;
    if (!(selector in useBase2)) {
      useBase2[selector] = USE_BASE2.test(selector) || (FIX_CAPS_SELECTOR && document.compatMode === "BackCompat" && CAPS_SELECTOR.test(selector));
    }
    var shouldUseBase2 = useBase2[selector] ||
                        !(methodName in node) ||
                        (BUGGY_OBJECT_SELECTORS && node.nodeName === "OBJECT") ||
                        !/^HTML$/i.test(document.documentElement.nodeName); // XML
    if (!shouldUseBase2) {
      var scopedNode = refNode || node;
      var scopedSelector = selector;
      var isScoped = selector.indexOf(":scope") !== -1; // Probably. :) It's not worth parsing it fully just yet.
      if (isScoped) {
        if (scopedNode == document) {
          scopedNode = document.documentElement;
        }
        var fakeId = !scopedNode.id;
        if (fakeId) scopedNode.id = _.assignID();
        scopeToId.set(":scope", "[id='" + scopedNode.id + "']");
        scopedSelector = scopeToId.parse(selector);
        isScoped = selector !== scopedSelector;
      }
      
      var method = protoMethods[node[PROTO_TYPE] + methodName] || node[methodName];
      if (selector in safeSelectors) {
        result = method.call(node, scopedSelector);
      } else {
        try {
          result = method.call(node, scopedSelector);
          safeSelectors[selector] = true;
        } catch (ex) {
          // assume it's an unsupported selector
          useBase2[selector] = true;
        }
      }  
      if (isScoped && fakeId) {
        scopedNode.removeAttribute("id");
      }
    }
  }
  
  if (typeof result == "undefined") {  
    var query = selectQuery.cache[selector] || selectQuery.create(selector);
  
    result = query.call(node, methodName === "querySelector" ? null : new StaticNodeList, refNode);
  }

  return result;
};
