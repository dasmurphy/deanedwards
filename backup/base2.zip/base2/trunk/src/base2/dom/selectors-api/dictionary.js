
var dictionary: new _.RegGrp.Dict([
  "string1",                  /'(\\.|[^'\\])*'/,
  "string2",                  /"(\\.|[^"\\])*"/,
  "string",                   /<#string1>|<#string2>/,
  "ident",                    /\-?(\\.|[a-z_]|[^\x00-\xa0])(\\.|[\w\-]|[^\x00-\xa0])*/,
  "combinator",               /[\s>+~]\s*/,
  "namespace_prefix",         /(<#ident>|\*)?\|/,
  "element_name",             /<#ident>/,
  "nth_arg",                  /[+-]?\d+|[+-]?\d*n(?:\s*[+-]\s*\d+)?|even|odd/,
  "tag",                      /(<#namespace_prefix>)?(\*|<#ident>)/,
  "id",                       /#(<#ident>)/,
  "class",                    /\.(<#ident>)/,
  "pseudo",                   /\:([\w\-]+)(?:\(([^)]+)\))?/,
  "attrib",                   /\[((?:<#namespace_prefix>)?<#ident>)(?:(<#operator>)((?:\\.|[^\]\[#.:])+))?\]/,
  "simple_selector_sequence", //,
  "compound_selector",        /(<#tag>|<#id>|<#class>|<#attrib>|<#pseudo>)+/,
  "negation",                 /:not\((<#tag>|<#id>|<#class>|<#attrib>|<#pseudo>)\)/,
  "sequence",                 /(\\.|[~*]=|\+\d|\+?\d*n\s*\+\s*\d|[^\s>+~,\*])+/,
  "filter",                   /[#.:\[]<#sequence>/,
  "selector",                 /[^>+~](\\.|[^,])*/,
  "grammar",                  /^(<#selector>)((,<#selector>)*)$/
]);
