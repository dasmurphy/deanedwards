
// http://www.w3.org/TR/selectors-api/#staticnodelist

// A wrapper for an array of elements or a NodeList.

var INDEX_SIZE_ERR = "INDEX_SIZE_ERR: StaticNodeList";

StaticNodeList = _.Base.extend({
  constructor: function StaticNodeList__constructor(nodes) {
    if (nodes && nodes.length > 0) {
      var i = 0, node;
      while ((node = nodes[i])) {
        this[i++] = node;
      }
      this.length = i;
    }
  },
  
  length: 0,
  
  item: function StaticNodeList__item(index) {
    if (index < 0) throw new Error(INDEX_SIZE_ERR);
    var element = this[+index];
    return element || null;
  }
});
