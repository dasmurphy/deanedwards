
var SUPPORTS_VENDOR_EXTENSIONS = !_.detect("MSIE[678]");

var getStylePropertyName = _.memoize(function getStylePropertyName(propertyName) {
  if (!(propertyName in styleObject)) {
    propertyName = _getVendorPropertyName(styleObject, propertyName);
  }
  return propertyName;
});

_private.getStylePropertyName = getStylePropertyName;

var vendorPropertyNames = getStylePropertyName.cache;

style = {
  toString: _.K("[base2.dom.style]"),

  get: function style_get(element, propertyName) {
    if (arguments.length < 2) {
      throw TypeError(Arity("style.get"));
    }
    if (!element || element.nodeType !== 1) {
      throw TypeError(Target("style.get"));
    }

    var vendorName = vendorPropertyNames[propertyName];
    if (vendorName) {
      propertyName = vendorName;
    } else if (!(propertyName in styleObject)) {
      propertyName = getStylePropertyName(propertyName);
    }

    var value;
    if (propertyName in styleObject) {
      value = element.style[propertyName] || "";
    }
    return value;
  },

  set: function style_set(element, propertyName, value, important) {
    if (arguments.length < 2) {
      throw TypeError(Arity("style.set"));
    }
    if (!element || element.nodeType !== 1) {
      throw TypeError(Target("style.set"));
    }

    if (arguments.length > 2) {
      var properties = {};
      properties[propertyName] = value;
    } else {
      properties = _.extend({}, arguments[1]);
    }

    var style = element.style;

    for (propertyName in properties) {
      value = properties[propertyName];
      var vendorName = vendorPropertyNames[propertyName];
      if (vendorName) {
        propertyName = vendorName;
      } else if (!(propertyName in styleObject)) {
        propertyName = getStylePropertyName(propertyName);
      }
      if (propertyName in styleObject) {
        if (important) {
          propertyName = propertyName.replace(/([A-Z])/g, "-$1").toLowerCase();
          style.setProperty(propertyName, String(value), "important");
        } else {
          style[propertyName] = String(value);
        }
      }
    }
  }
};

_private.compute = function style_compute(element, propertyName) {
  if (arguments.length < 2) {
    throw TypeError(Arity("style.compute"));
  }
  if (!element || element.nodeType !== 1) {
    throw TypeError(Target("style.compute"));
  }

  var vendorName = vendorPropertyNames[propertyName];
  if (vendorName) {
    propertyName = vendorName;
  } else if (SUPPORTS_VENDOR_EXTENSIONS && !(propertyName in styleObject)) {
    propertyName = getStylePropertyName(propertyName);
  }

  var view = element.ownerDocument.defaultView;
  return view.getComputedStyle(element, null)[propertyName];
};
