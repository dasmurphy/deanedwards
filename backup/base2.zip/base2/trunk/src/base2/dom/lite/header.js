
var undefined;
var _private = _._;
var base2    = _.base2;
var forEach  = _.forEach;

var ARITY_ERR = "Not enough arguments.";

var document = window.document;
var element = document.createElement("div");
var styleObject = element.style;

var delegates = {
  createEvent:             "document,type",
  addEventListener:        "target,type,listener,useCapture",
  removeEventListener:     "target,type,listener,useCapture",
  dispatchEvent:           "target,event",
  querySelector:           "node,selector",
  querySelectorAll:        "node,selector",
  matches:                 "element,selector",
  getAttribute:            "element,name",
  hasAttribute:            "element,name",
  removeAttribute:         "element,name",
  setAttribute:            "element,name,value",
  getBoundingClientRect:   "element"
};

function createDelegate(name, args, realName) {
  args = args.split(",");
  return (Function(_.format('return function {0}(' + args.join(', ') + ') {\n' +
    '  if (arguments.length < {1}) {\n' +
    '    throw new SyntaxError("' + ARITY_ERR + '");\n' +
    '  }\n' +
    '  if (!{2} || !("{4}" in {2})) {\n' +
    '    throw new TypeError("{0}() not supported for this object.");\n' +
    '  }\n' +
    '  return {2}.{4}({3});\n' +
    '}'
  , realName || name, args.length, args[0], args.slice(1).join(", "), name)))();
}
