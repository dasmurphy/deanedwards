
_private.getOffsetFromBody = function _getOffsetFromBody(element) {
  var left = 0;
  var top = 0;

  if (!/^BODY$/i.test(element.nodeName)) {
    var document = element.ownerDocument;
    var view = document.defaultView;
    var documentElement = document.documentElement;
    var body = document.body;
    var clientRect = element.getBoundingClientRect();

    left = clientRect.left + Math.max(documentElement.scrollLeft, body.scrollLeft);
    top = clientRect.top + Math.max(documentElement.scrollTop, body.scrollTop);
  }

  return {
    left: left,
    top: top
  };
};

// Call a function in a new execution context.
// Even if the function errors, the next line in your program will still execute, you will also get an error message in the console.

// http://dean.edwards.name/weblog/2009/03/callbacks-vs-events/

var Function__bind = _.Functional.prototype.bind;
var Function__call = Function.prototype.call;

var SUPPORTS_CLICK = false;
var button = document.createElement("button");
button.onclick = function() {
  SUPPORTS_CLICK = true;
};
button.click();

if (SUPPORTS_CLICK) {
  var continueIfThrow = function continueIfThrow() {
    button.onclick = Function__call.apply(Function__bind, arguments);
    button.click();
    button.onclick = null;
  };
} else {
  var head = document.getElementsByTagName("script")[0].parentNode;
  var __exec__;
  head.addEventListener("base2:call", function(){__exec__()}, false);
  continueIfThrow = function continueIfThrow() {
    __exec__ = Function__call.apply(Function__bind, arguments);
    var dummyEvent = document.createEvent("Event");
    dummyEvent.initEvent("base2:call", false, false);
    head.dispatchEvent(dummyEvent);
    __exec__ = _.Undefined;
  };
}

_private.continueIfThrow = continueIfThrow;
