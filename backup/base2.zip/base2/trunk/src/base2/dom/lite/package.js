
var dom = base2.dom = new _.Package({
  name:    "base.dom",
  version:  base2.version + "(lite)",

  CSSSelectorParser: CSSSelectorParser,
  StaticNodeList: StaticNodeList,
  
  bind: _.I,

  classList: classList,
  style: style,

  get: function dom_get(node, propertyName) {
    return node[propertyName];
  },

  set: function dom_set(node, propertyName, value) {
    return node[propertyName] = value;
  },

  getComputedStyle: function getComputedStyle(element, pseudoElement) {
    if (arguments.length < 2) throw new SyntaxError("getComputedStyle: " + ARITY_ERR);
    if (!element || element.nodeType !== 1) throw new TypeError("getComputedStyle not supported for this object.");

    var view = element.ownerDocument.defaultView;
    return view.getComputedStyle(element, pseudoElement);
  }
});

forEach (delegates, function(args, name) {
  dom[name] = createDelegate(name, args);
});

if (!element.matches) {
  var vendorMatches = JS_PREFIX + "MatchesSelector";
  if (element[vendorMatches])
    dom.matches = createDelegate(vendorMatches, "element,selector", "matches");
  }
}

var matches = dom.matches;
