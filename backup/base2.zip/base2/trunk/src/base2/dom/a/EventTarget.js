
// http://www.w3.org/TR/DOM-Level-2-Events/events.html#Events-Registration-interfaces

function addEventListener(type, listener, useCapture) {
  var methodName = "addEventListener";

  if (arguments.length < 2) {
    throw TypeError(Arity(methodName));
  }

  if (eventWrappers[type]) {
    listener = eventWrappers[type](type, listener);
    type = wrappedTypes[type] || type;
  }

  var method = protoMethods[this.nodeType + methodName] || this[methodName];
  method.call(this, type, listener, !!useCapture);
}

function removeEventListener(type, listener, useCapture) {
  var methodName = "removeEventListener";

  if (arguments.length < 2) {
    throw TypeError(Arity(methodName));
  }

  listener = _unwrap(type, listener);
  type = wrappedTypes[type] || type;

  var method = protoMethods[this.nodeType + methodName] || this[methodName];
  method.call(this, type, listener, !!useCapture);
}

var wrappedListeners      = {};
var wrappedListenersCount = {};
var wrappedTypes          = {};

var eventWrappers = {
  transitionend: function _wrapTransitionEnd(type, listener) {
    return _wrap(type, listener, function _wrappedListener(event) {
      event = cloneEvent(event);
      event.type = type;
      event.propertyName = event.propertyName.replace(/^\-\w+\-/, "");
      _handleEvent(this, listener, event);
    });
  }
};

if (!_.detect("(document.createEvent('TransitionEvent'))")) {
  var transitionPrefixes = {MS: "MS", O: "o", Webkit: "webkit"};
  var transitionPrefix = transitionPrefixes[_getVendorPropertyName(styleObject, "transition").slice(0, -10)];
  if (transitionPrefix) {
    wrappedTypes.transitionend = transitionPrefix + "TransitionEnd";
  }
}

// All other browsers support onmousewheel even if they don't directly support the onmousewheel property
if (!("onmousewheel" in element) && _.detect("Gecko")) {
  wrappedTypes.mousewheel = "DOMMouseScroll";
  eventWrappers.mousewheel = function _wrapMouseWheel(type, listener) {
    return _wrap(type, listener, function _wrappedListener(event) {
      event = cloneEvent(event);
      event.type = type;
      event.wheelDelta = (-event.detail * 40) || 0;
      _handleEvent(this, listener, event);
    });
  };
}

function _wrapMouseEnterLeave(type, listener) {
  return _wrap(type, listener, function _wrappedListener(event) {
    if (_includes(this, event.target) && !_includes(this, event.relatedTarget)) {
      event = cloneEvent(event);
      event.currentTarget = this;
      event.target = this;
      event.type = type;
      event.bubbles = event.cancelable = false;
      _handleEvent(this, listener, event);
    }
  });
}

if (!("onmouseenter" in element)) {
  wrappedTypes.mouseenter = "mouseover";
  eventWrappers.mouseenter = _wrapMouseEnterLeave;
  wrappedTypes.mouseleave = "mouseout";
  eventWrappers.mouseleave = _wrapMouseEnterLeave;
}

function _wrap(type, listener, wrapper) {
  var key = type + "." + _.assignID(listener);
  if (!wrappedListeners[key]) {
    wrappedListeners[key] = wrapper;
    wrappedListenersCount[key] = 0;
  }
  wrappedListenersCount[key]++;
  return wrappedListeners[key];
}

function _unwrap(type, listener) {
  var key = type + "." + listener.base2ID;
  var wrappedListener = wrappedListeners[key];
  if (wrappedListener) {
    wrappedListenersCount[key]--;
    if (wrappedListenersCount[key] === 0) {
      delete wrappedListeners[key];
      delete wrappedListenersCount[key];
    }
  }
  return wrappedListener || listener;
}

function _handleEvent(target, listener, event) {
  if (typeof listener == "object") {
    target = listener;
    listener = target.handleEvent;
  }

  if (typeof listener == "function") {
    listener.call(target, event);
  }
}

function _includes(node, target) {
  while (target && node != target && (target = target.parentNode)) continue;
  return !!target;
}

function cloneEvent(event) {
  if (event.isClone) return event;

  var clone = {toString: _.K(String(event))};
  for (var i in event) clone[i] = event[i];

  clone.isClone = true;

  clone.stopPropagation = function stopPropagation() {
    event.stopPropagation();
  };

  clone.preventDefault = function preventDefault() {
    event.preventDefault();
  };

  return clone;
}
