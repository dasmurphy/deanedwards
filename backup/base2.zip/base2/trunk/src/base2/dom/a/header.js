
var undefined;
var _private = _._;
var base2    = _.base2;
var forEach  = _.forEach;

var ArityError = _private.ArityError;
var TargetError = _private.TargetError;

var Function__call = Function.prototype.call;

var element = document.createElement("div");
var styleObject = element.style;

var CSSSelectorParser;
