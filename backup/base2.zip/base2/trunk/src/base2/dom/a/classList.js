
var classList = {
  add: function(element, className) {
    element.classList.add(className);
  },

  contains: function(element, className) {
    element.classList.contains(className);
  },

  remove: function(element, className) {
    element.classList.remove(className);
  },

  toggle: function(element, className) {
    element.classList.toggle(className);
  },

  toString: _.K("[base2.dom.classList]")
};
