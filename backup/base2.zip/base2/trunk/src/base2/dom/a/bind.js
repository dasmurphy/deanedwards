
(function() {
  var IS_ELEMENT      = "getBoundingClientRect";
  var IS_QSA_TARGET   = "querySelectorAll";

  var aliases = _private.aliases = {};

  var iNode = createInterface(null, {
    contains:              [0, 0, 2],

    addEventListener:      [0, 0, 3, "on"],
    removeEventListener:   [0, 0, 3, "off"],
    dispatchEvent:         [0, 0, 2],

    find:                  [_find,    IS_QSA_TARGET, 2],
    findAll:               [_findAll, IS_QSA_TARGET, 2],

    querySelector:         [0, 0, 2],
    querySelectorAll:      [0, 0, 2],

    append:                [_append,  IS_QSA_TARGET, 1],
    prepend:               [_prepend, IS_QSA_TARGET, 1]
  });

  var iDocument = createInterface(iNode, {
    createEvent:           [0, 0, 2],
    getElementById:        [0, 0, 2]
  });

  var iElement = createInterface(iNode, {
    getAttribute:          [0, 0, 2],
    hasAttribute:          [0, 0, 2],
    removeAttribute:       [0, 0, 2],
    setAttribute:          [0, 0, 3],

    matches:               [_matches, IS_ELEMENT, 2],

    after:                 [_after,   IS_ELEMENT, 1],
    before:                [_before,  IS_ELEMENT, 1],
    replace:               [_replace, IS_ELEMENT, 1],
    remove:                [_remove,  IS_ELEMENT, 1],

    getBoundingClientRect: [0, 0, 1, "rect"]
  });

  var isBound = {};

  function bindDocument(document) {
    _.assignID(document);
    
    isBound[document.base2ID] = true;

    var view = document.defaultView;
    var elementProto = (view.HTMLElement || view.Element).prototype;

    for (var name in iElement) {
      elementProto[name] = iElement[name];
    }

    for (name in iDocument) {
      document[name] = iDocument[name];
    }
  }

  function createInterface(ancestor, methods) {
    var _interface = _private.pcopy(ancestor);

    forEach (methods, function(descriptor, name) {
      var method = descriptor[0];
      var test = descriptor[1] || name;
      var arity = descriptor[2];
      var alias = descriptor[3];

      if (method) _interface[name] = method;

      dom[name] = _createStaticMethod(name, method, arity, test, name);

      ;doc; // Try to expose as much raw source code as possible.
      ;doc; var protoMethod = method || (element[name] || document[name]);
      ;doc; dom[name]._underlyingFunction = protoMethod._underlyingFunction || protoMethod;

      if (alias) {
        aliases[alias] = _createStaticMethod(name, method, arity, test, alias);
        ;doc; // Try to expose as much raw source code as possible.
        ;doc; aliases[alias]._underlyingFunction = dom[name]._underlyingFunction;
      }
    });

    return _interface;
  }

  function _createStaticMethod(name, protoMethod, arity, test, alias) {
    // Delegate a static method to an instance method
    var staticMethod = function _staticMethod(node) {
      if (arguments.length < arity) {
        throw new ArityError(alias, this);
      }
      if (!node || !node[test]) {
        throw new TargetError(alias, this);
      }
      return Function__call.apply(protoMethod || node[name], arguments);
    };
    ;doc; // Try to expose as much raw source code as possible.
    ;doc; if (protoMethod) {
    ;doc;   staticMethod._underlyingFunction = protoMethod._underlyingFunction || protoMethod;
    ;doc; }
    return staticMethod;
  }
  
  dom.bind = function bind(node) {
    if (!node || !node.nodeType) {
      throw new TargetError("bind", this);
    }

    switch (node.nodeType) {
      case 9: // Document
        if (!isBound[node.base2ID]) bindDocument(node);
        break;

      case 1: // Element
        if (!isBound[node.ownerDocument.base2ID]) {
          throw new Error("Attempt to bind an element in an unbound document.");
        }
        
        if (!isBound[node.uniqueID]) {
          bindElements([node]);
        }
    }

    return node;
  };
})();
