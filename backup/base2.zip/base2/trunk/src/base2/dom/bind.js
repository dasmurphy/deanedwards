
var PROTO_TYPE = "nodeType";
var CANNOT_BIND_PROTOTYPE;
var protoMethods = {};
var isBound = {"undefined": true}
var _bindElements;

_.assignID(document);

(function() {
  var SUPPORTS_DOM_METHOD_CALL = !!element.getAttribute.call;

  var SUPPORTS_GETTERS = Object.defineProperty || {}.__defineGetter__;
  if (SUPPORTS_GETTERS) {
    var proto = (window.HTMLElement || window.Element || {}).prototype || {};
    var name = _.assignID();
    proto[name] = 1;
    var BIND_PROTOTYPE = element[name];
    delete proto[name];
    if (BIND_PROTOTYPE) {
      try {
        proto.getAttribute.call(element, "a");
      } catch (ex) {
        PROTO_TYPE = "base2ID";
        proto[PROTO_TYPE] = 0;
        _.assignID(window, PROTO_TYPE);
      }
    }
  }
  BIND_PROTOTYPE = !!BIND_PROTOTYPE;
  CANNOT_BIND_PROTOTYPE = !BIND_PROTOTYPE;

  var FORBIDDEN = {APPLET:1, EMBED:1, OBJECT:1};

  var createGetter = _private.createGetter;

  var IS_NODE         = [{}, "nodeType"];
  var IS_DOCUMENT     = [{9: 1}];
  var IS_ELEMENT      = [{1: 1}];
  var IS_EVENT_TARGET = [QSA_VALID_TYPES, EVENT_API];
  var IS_QSA_TARGET   = [QSA_VALID_TYPES];

  var aliases = _private.aliases = {};

  var iNode = createInterface(null, {
    contains:              [_contains,              IS_NODE,           2],

    addEventListener:      [_addEventListener,      IS_EVENT_TARGET,   3, "on"],
    removeEventListener:   [_removeEventListener,   IS_EVENT_TARGET,   3, "off"],
    dispatchEvent:         [_dispatchEvent,         IS_EVENT_TARGET,   2],

    find:                  [_find,                  IS_QSA_TARGET,     2],
    findAll:               [_findAll,               IS_QSA_TARGET,     2],

    querySelector:         [_querySelector,         IS_QSA_TARGET,     2],
    querySelectorAll:      [_querySelectorAll,      IS_QSA_TARGET,     2],

    append:                [_append,                IS_QSA_TARGET,     1],
    prepend:               [_prepend,               IS_QSA_TARGET,     1]
  });

  var iDocument = createInterface(iNode, {
    createEvent:           [_createEvent,           IS_DOCUMENT,       2],
    getElementById:        [_getElementById,        IS_DOCUMENT,       2]
  });

  var iElement = createInterface(iNode, {
    getAttribute:          [_getAttribute,          IS_ELEMENT,        2],
    hasAttribute:          [_hasAttribute,          IS_ELEMENT,        2],
    removeAttribute:       [_removeAttribute,       IS_ELEMENT,        2],
    setAttribute:          [_setAttribute,          IS_ELEMENT,        3],

    matches:               [_matches,               IS_ELEMENT,        2],

    after:                 [_after,                 IS_ELEMENT,        1],
    before:                [_before,                IS_ELEMENT,        1],
    replace:               [_replace,               IS_ELEMENT,        1],
    remove:                [_remove,                IS_ELEMENT,        1],

    getBoundingClientRect: [_getBoundingClientRect, IS_ELEMENT,        1, "rect"]
  });

  var iElementNew = {};
  var iElementOverride = {};

  for (var i in iElement) {
    (element[i] ? iElementOverride : iElementNew)[i] = iElement[i];
  }

  function bindDocument(document) {
    _DocumentState.getInstance(document);

    isBound[document.base2ID] = true;

    var view = document.defaultView;
    view = view || (document.defaultView = document.parentWindow);
    if (view && !view.getComputedStyle) {
      view.getComputedStyle = _getComputedStyle;
    }

    if (BIND_PROTOTYPE) {
      var elementProto = (view.HTMLElement || view.Element).prototype;
      for (var name in iElementNew) {
        elementProto[name] = iElementNew[name];
      }

      if (!SUPPORTS_CLASS_LIST) {
        createGetter(elementProto, "classList", null, get_classList);
      }
      if (!SUPPORTS_TRAVERSAL_API) for (name in traversalAPI) {
        createGetter(elementProto, name, null, traversalAPI[name]);
      }
      /*@
        if (!("textContent" in elementProto)) Object.defineProperty(elementProto, "textContent", {
          get: _MSIE_getTextContent,
          set: _MSIE_setTextContent
        });
      @*/

      if (PROTO_TYPE === "base2ID") { // FF2/3
        for (var type in Components.interfaces) {
        	if (type.match(/^nsIDOMHTML\w+Element$/)) {
        		type = type.slice(6);
            var proto = view[type].prototype;
            if (proto) {
              var protoID = _.assignID(proto, PROTO_TYPE);
              for (name in iElementOverride) {
                protoMethods[protoID + name] = proto[name];
                proto[name] = iElementOverride[name];
              }
            }
        	}
        }
        var documentID = document.base2ID;
        for (name in iDocument) {
          protoMethods[documentID + name] = document[name];
        }
      } else {
        for (name in iElementOverride) {
          elementProto[name] = iElementOverride[name];
        }
      }
      for (name in iDocument) {
        document[name] = iDocument[name];
      }
    } else {
      var _createElement = document.createElement;
      document.createElement = function createElement(tagName) {
        var element = Function__call.call(_createElement, document, tagName);
        _bindElements([element]);
        return element;
      };

      var _byId = _getElementById || document.getElementById;

      for (name in iDocument) {
        document[name] = iDocument[name];
      }

      document.getElementById = function getElementById(id) {
        var element = Function__call.call(_byId, document, id);
        if (element && !isBound[element.uniqueID]) {
          _bindElements([element]);
        }
        return element;
      };
    }
  }

  _bindElements = function bindElements(elements) {
    var i = 0, element;
    while ((element = elements[i++])) {
      var uniqueID = element.uniqueID;
      if (!isBound[uniqueID]) {
        isBound[uniqueID] = true;

        if (!FORBIDDEN[element.nodeName]) {
          if (!SUPPORTS_CLASS_LIST) {
            element.classList = new ClassList(element);
          }
          for (var name in iElement) element[name] = iElement[name];
        }
      }
      /*@if (@_jscript_version < 5.7) { // MSIE6
        // attribute methods are unique for each element:
        // element1.getAttribute != element2.getAttribute
        msieCache[uniqueID] = element;
        msieCache[uniqueID + "_getAttribute"] = element.getAttribute;
        msieCache[uniqueID + "_setAttribute"] = element.setAttribute;
        element = null;
      }
      /*@end @*/
    }
    return elements;
  };

  var currentID = 1;

  function get_classList() {
    var classList = new ClassList(this);
    try {
      return classList;
    } catch (ex) {
      // some browsers need the catch part
    } finally {
      if (currentID !== this.uniqueID) { // fixes a recusive bug in IE9
        currentID = this.uniqueID || 1;
        createGetter(this, "classList", classList);
      }
      return classList;
    }
  }

  /*@
  if (!SUPPORTS_DOM_METHOD_CALL) {
    protoMethods["1getAttribute"] = {
      call: function(element, name) {
        var getAttribute = msieCache[element.uniqueID + "_getAttribute"] || element.getAttribute;
        return Function__call.call(getAttribute, element, name, 2);
      }
    };

    protoMethods["1setAttribute"] = {
      call: function(element, name, value) {
        var setAttribute = msieCache[element.uniqueID + "_setAttribute"] || element.setAttribute;
        Function__call.call(setAttribute, element, value);
      }
    };
  }
  @*/

  function createInterface(ancestor, methods) {
    var _interface = _private.pcopy(ancestor);
    var type = document[PROTO_TYPE];

    forEach (methods, function(descriptor, name) {
      var method = descriptor[0];
      var test = descriptor[1];
      var arity = descriptor[2];
      var alias = descriptor[3];

      if (method) _interface[name] = method;

      dom[name] = _createStaticMethod(name, method, arity, test[0], test[1] || "", name);

      if (alias) {
        aliases[alias] = _createStaticMethod(name, method, arity, test[0], test[1] || "", alias);
      }

      protoMethods[1 + name] = element[name];
      protoMethods[type + name] = document[name];
    });

    return _interface;
  }

  function _createStaticMethod(name, protoMethod, arity, nodeTypes, test, alias) {
    // Delegate a static method to an instance method
    var staticMethod = function _staticMethod(node) {
      if (arguments.length < arity) {
        throw new ArityError(alias, this);
      }
      if (!node || !(nodeTypes[node.nodeType] || node[test])) {
        throw new TargetError(alias, this);
      }
      return Function__call.apply(protoMethod || node[name], arguments);
    };
    ;doc; if (protoMethod) staticMethod._underlyingFunction = protoMethod._underlyingFunction || protoMethod;
    return staticMethod;
  }

  dom.bind = function bind(node) {
    if (!node || !node.nodeType) {
      throw new TargetError("bind", this);
    }

    switch (node.nodeType) {
      case 9: // Document
        if (!isBound[node.base2ID]) bindDocument(node);
        break;

      case 1: // Element
        if (!isBound[node.ownerDocument.base2ID]) {
          throw new Error("Attempt to bind an element in an unbound document.");
        }

        if (!BIND_PROTOTYPE && !isBound[node.uniqueID]) {
          _bindElements([node]);
        }
    }

    return node;
  };
})();

new _DocumentState(document);

base2.dom = dom;
