
var PROTO_TYPE = "nodeType";

var protoMethods = {};

_.assignID(document);

(function() {
  var SUPPORTS_DOM_METHOD_CALL = !!element.getAttribute.call;

  var SUPPORTS_GETTERS = Object.defineProperty || {}.__defineGetter__;
  if (SUPPORTS_GETTERS) {
    var proto = (window.HTMLElement || window.Element || {}).prototype || {};
    var name = _.assignID();
    proto[name] = 1;
    var USE_PROTOTYPE = element[name];
    delete proto[name];
    if (USE_PROTOTYPE) {
      try {
        proto.getAttribute.call(element, "a");
      } catch (ex) {
        PROTO_TYPE = "base2ID";
        proto[PROTO_TYPE] = 0;
        _.assignID(window, PROTO_TYPE);
      }
    }
  }
  USE_PROTOTYPE = !!USE_PROTOTYPE;

  var FORBIDDEN = {APPLET:1, EMBED:1, OBJECT:1};

  var createGetter = _private.createGetter;

  var bindingMethods = USE_PROTOTYPE ? {} : {
    querySelector: function querySelector(selector) {
      if (arguments.length < 1) {
        throw new ArityError("querySelector");
      }
      
      var element = _executeQuery("querySelector", this, selector);
      if (element && !isBound[element.uniqueID]) bindElements([element]);

      return element;
    },

    querySelectorAll: function querySelectorAll(selector) {
      if (arguments.length < 1) {
        throw new ArityError("querySelectorAll");
      }
      
      return bindElements(_executeQuery("querySelectorAll", this, selector));
    }
  };

  var IS_NODE     = "!{2}.nodeType";
  var IS_DOCUMENT = "{2}.nodeType !== 9";
  var IS_ELEMENT  = "{2}.nodeType !== 1";
  var IS_EVENT_TARGET = "!{2}." + EVENT_API;
  var IS_QSA_TARGET   = "!_validType[{2}.nodeType]";

  var iNode = createInterface(null, {
    contains:              [_contains,              IS_NODE,           "parent,child"],
    
    addEventListener:      [_addEventListener,      IS_EVENT_TARGET,   "target,type,listener"],
    removeEventListener:   [_removeEventListener,   IS_EVENT_TARGET,   "target,type,listener"],
    dispatchEvent:         [_dispatchEvent,         IS_EVENT_TARGET,   "target,event"],

    find:                  [_find,                  IS_QSA_TARGET,     "node,selector"],
    findAll:               [_findAll,               IS_QSA_TARGET,     "node,selector"],

    querySelector:         [_querySelector,         IS_QSA_TARGET,     "node,selector"],
    querySelectorAll:      [_querySelectorAll,      IS_QSA_TARGET,     "node,selector"],

    append:                [_append,                IS_QSA_TARGET,     "target"],
    prepend:               [_prepend,               IS_QSA_TARGET,     "target"]
  });

  var iDocument = createInterface(iNode, {
    createEvent:           [_createEvent,           IS_DOCUMENT,       "document,eventType", document],
    getElementById:        [_getElementById,        IS_DOCUMENT,       "document,id",        document]
  });

  var iElement = createInterface(iNode, {
    getAttribute:          [_getAttribute,          IS_ELEMENT,        "element,name"],
    hasAttribute:          [_hasAttribute,          IS_ELEMENT,        "element,name"],
    removeAttribute:       [_removeAttribute,       IS_ELEMENT,        "element,name"],
    setAttribute:          [_setAttribute,          IS_ELEMENT,        "element,name,value"],

    matches:               [_matches,               IS_ELEMENT,        "element,selector"],

    after:                 [_after,                 IS_ELEMENT,        "element"],
    before:                [_before,                IS_ELEMENT,        "element"],
    replace:               [_replace,               IS_ELEMENT,        "element"],
    remove:                [_remove,                IS_ELEMENT,        "element"],

    getBoundingClientRect: [_getBoundingClientRect, IS_ELEMENT,        "element"]
  });

  var iElementNew = {};
  var iElementOverride = {};
  
  for (var i in iElement) {
    (element[i] ? iElementOverride : iElementNew)[i] = iElement[i];
  }

  var isBound = {};

  function bindDocument(document) {
    _DocumentState.getInstance(document);
    
    isBound[document.base2ID] = true;

    var view = document.defaultView;
    view = view || (document.defaultView = document.parentWindow);
    if (view && !view.getComputedStyle) {
      view.getComputedStyle = _getComputedStyle;
    }

    if (USE_PROTOTYPE) {
      var elementProto = (view.HTMLElement || view.Element).prototype;
      for (var name in iElementNew) {
        elementProto[name] = iElementNew[name];
      }

      if (!SUPPORTS_CLASS_LIST) {
        createGetter(elementProto, "classList", null, get_classList);
      }
      if (!SUPPORTS_TRAVERSAL_API) for (name in traversalAPI) {
        createGetter(elementProto, name, null, traversalAPI[name]);
      }
      /*@
        if (!("textContent" in elementProto)) Object.defineProperty(elementProto, "textContent", {
          get: _MSIE_getTextContent,
          set: _MSIE_setTextContent
        });
      @*/
      
      if (PROTO_TYPE === "base2ID") { // FF2/3
        for (var type in Components.interfaces) {
        	if (type.match(/^nsIDOMHTML\w*Element$/)) {
        		type = type.slice(6);
            var proto = view[type].prototype;
            if (proto) {
              var protoID = _.assignID(proto, PROTO_TYPE);
              for (name in iElementOverride) {
                protoMethods[protoID + name] = proto[name];
                proto[name] = iElementOverride[name];
              }
            }
        	}
        }
        var documentID = document.base2ID;
        for (name in iDocument) {
          protoMethods[documentID + name] = document[name];
        }
      } else {
        for (name in iElementOverride) {
          elementProto[name] = iElementOverride[name];
        }
      }
      for (name in iDocument) {
        document[name] = iDocument[name];
      }
    } else {
      var _createElement = document.createElement;
      document.createElement = function createElement(tagName) {
        var element = Function__call.call(_createElement, document, tagName);
        bindElements([element]);
        return element;
      };

      var _byId = _getElementById || document.getElementById;
      
      for (name in iDocument) {
        document[name] = iDocument[name];
      }

      document.getElementById = function getElementById(id) {
        var element = Function__call.call(_byId, document, id);
        if (element && !isBound[element.uniqueID]) {
          bindElements([element]);
        }
        return element;
      };
    }
  }

  function bindElements(elements) {
    var i = 0, element;
    while ((element = elements[i++])) {
      var uniqueID = element.uniqueID;
      if (!isBound[uniqueID]) {
        isBound[uniqueID] = true;

        if (!FORBIDDEN[element.nodeName]) {
          if (!SUPPORTS_CLASS_LIST) {
            element.classList = new ClassList(element);
          }
          for (var name in iElement) element[name] = iElement[name];
        }
      }
      /*@if (@_jscript_version < 5.7) { // MSIE6
        // attribute methods are unique for each element:
        // element1.getAttribute != element2.getAttribute
        msieCache[uniqueID] = element;
        msieCache[uniqueID + "_getAttribute"] = element.getAttribute;
        msieCache[uniqueID + "_setAttribute"] = element.setAttribute;
      }
      /*@end @*/
    }
    return elements;
  }
  
  var currentID = 1;
  
  function get_classList() { // -@DRE
    var classList = new ClassList(this);
    try {
      return classList;
    } catch (ex) {
      // some browsers need the catch part
    } finally {
      if (currentID !== this.uniqueID) { // fixes a recusive bug in IE9
        currentID = this.uniqueID || 1;
        createGetter(this, "classList", classList);
      }
      return classList;
    }
  }

  /*@
  if (!SUPPORTS_DOM_METHOD_CALL) {
    protoMethods["1getAttribute"] = {
      call: function(element, name) {
        var getAttribute = msieCache[element.uniqueID + "_getAttribute"] || element.getAttribute;
        return Function__call.call(getAttribute, element, name, 2);
      }
    };

    protoMethods["1setAttribute"] = {
      call: function(element, name, value) {
        var setAttribute = msieCache[element.uniqueID + "_setAttribute"] || element.setAttribute;
        Function__call.call(setAttribute, element, value);
      }
    };
  }
  @*/

  function createInterface(ancestor, methods) {
    var _interface = _private.pcopy(ancestor);

    var type = document[PROTO_TYPE];
    
    forEach (methods, function(descriptor, methodName) {
      var args = descriptor[2].split(",");
      var test = descriptor[1];
      var method = descriptor[0];

      if (method) {
        var CALL = "_call.apply(_method, arguments)";
        var ARGS = "_call,_method,_validType";
      } else {
        CALL = "{2}.{0}({3})";
        ARGS = "";
      }

      var BODY = 'return function {0}(' + args.join(', ') + ') {\n' +
        '  if (arguments.length < {1}) {\n' +
        '    throw new SyntaxError("' + DOM_ARITY_ERR + '");\n' +
        '  }\n' +
        '  if (!{2} || ' + test + ') {\n' +
        '    throw new TypeError("' + DOM_TYPE_ERR + '");\n' +
        '  }\n' +
        '  return ' + CALL + ';\n' +
        '}';
        
      var body = _.format(BODY, methodName, args.length, args[0], args.slice(1).join(", "), methodName);

      dom[methodName] = new Function(ARGS, body)(Function__call, method, QSA_VALID_TYPES);

      if (method) _interface[methodName] = bindingMethods[methodName] || method;
      
      ;doc; dom[methodName]._underlyingFunction = _interface[methodName];

      protoMethods[1 + methodName] = element[methodName];
      protoMethods[type + methodName] = document[methodName];
    });
    
    return _interface;
  }
  
  dom.bind = function bind(node) {
    if (!node || !node.nodeType) {
      throw new TargetError(DOM_TYPE_ERR, "dom.bind");
    }

    switch (node.nodeType) {
      case 9: // Document
        if (!isBound[node.base2ID]) bindDocument(node);
        break;

      case 1: // Element
        if (!isBound[node.ownerDocument.base2ID]) {
          throw new Error("Attempt to bind an element in an unbound document.");
        }
        
        if (!USE_PROTOTYPE && !isBound[node.uniqueID]) {
          bindElements([node]);
        }
    }

    return node;
  };
})();

new _DocumentState(document);

base2.dom = dom;
