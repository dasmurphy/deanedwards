
try {
  var event = new window.Event("test");
  if (event.type !== "test") throw TyperError();
} catch (ex) {
  var EVENT_MOUSE = /^mouse|^(dbl)?click$/;
  var EVENT_KEY   = /^key/;

  var NEEDS_SPECIFIC_TYPE = SUPPORTS_EVENT_TARGET; // Early Firefox

  testEvent("input", function() {
    NEEDS_SPECIFIC_TYPE = false;
  });

  EventConstructor = function Event(type, dict) {
    if (arguments.length === 0) {
      throw TypeError(Arity("Event"));
    }

    if (!dict) dict = {};

    var eventType = "Event";
    var args = [type, !!dict.bubbles, !!dict.cancelable];
    var createEvent = _createEvent || document.createEvent;

    if (NEEDS_SPECIFIC_TYPE) {
      args.push(window);
      if (!("detail" in dict)) dict.detail = 0;
      if (EVENT_MOUSE.test(type)) {
        eventType = "MouseEvent";
        args.push(dict.detail, 0, 0, 0, 0, false, false, false, false, 0, null);
      } else if (EVENT_KEY.test(type)) {
        eventType = "KeyboardEvent";
        args.push(false, false, false, false, 0, "");
      } else if (type === "input") {
        eventType = "UIEvent";
        args.push(dict.detail);
      }
    }

    var init = eventType === "KeyboardEvent" ? "initKeyEvent" : "init" + eventType;

    var event = createEvent.call(document, eventType);
    event[init].apply(event, args);

    return event;
  };

  CustomEventConstructor = function CustomEvent(type, dict) {
    var event = EventConstructor.apply(undefined, arguments);
    if (dict && dict.detail !== event.detail) {
      event.detail = dict.detail;
    }
    return event;
  };
}
