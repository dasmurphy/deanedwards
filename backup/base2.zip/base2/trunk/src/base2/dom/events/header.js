
var CONST_CAPTURING_PHASE = 1;
var CONST_AT_TARGET       = 2;
var CONST_BUBBLING_PHASE  = 3;

var SUPPORTS_OBJECT_LISTENER = true;  // feature tested later
// Firefox doesn't report errors using dispatchEvent().
// https://bugzilla.mozilla.org/show_bug.cgi?id=503244
var SILENT_DISPATCH = _.detect("Gecko"); // This bug is undetectable and still not fixed.
var USE_CONSOLE = SILENT_DISPATCH && _.detect("(console.log)");

var COMPLETE = SUPPORTS_EVENT_TARGET ? /loaded|complete/ : /complete/;

var wrappedListeners = {};
var wrappedListenersCount = {};

var wrappedTypes = {
  DOMContentLoaded: "base2:DOMContentLoaded"
};

if (!SUPPORTS_TRANSITION_END) {
  var transitionPrefixes = {
    MS: "MS",
    O:  "o",
    Webkit: typeof WebKitTransitionEvent == "undefined" ? "" : "webkit"
  };
  var transitionPrefix = transitionPrefixes[getVendorPropertyName(styleObject, "transition").slice(0, -10)];
  if (transitionPrefix) {
    SUPPORTS_TRANSITION_END = true;
    wrappedTypes.transitionend = transitionPrefix + "TransitionEnd";
  }
}

var eventWrappers = {
 DOMContentLoaded: function wrapDOMContentLoaded(type, listener) {
    return _wrap(type, listener, function _wrappedListener(event) {
      event = cloneEvent(event);
      event.type = type;
      event.eventPhase = 2; // AT_TARGET
      event.bubbles = event.cancelable = false;
      _removeEventListener.call(this, type, listener);
      _handleEvent(this, listener, event);
    });
  },

  transitionend: function wrapTransitionEnd(type, listener) {
    return _wrap(type, listener, function _wrappedListener(event) {
      event = cloneEvent(event);
      event.type = type;
      event.propertyName = event.propertyName.replace(/^\-\w+\-/, "");
      _handleEvent(this, listener, event);
    });
  }
};

function wrapMouseEnterLeave(type, listener) {
  return _wrap(type, listener, function _wrappedListener(event) {
    // https://bugzilla.mozilla.org/show_bug.cgi?id=497780
    var xulRelatedTarget = typeof XULElement == "function" && event.relatedTarget instanceof XULElement;
    if (!xulRelatedTarget && _includes(this, event.target) && !_includes(this, event.relatedTarget)) {
      event = cloneEvent(event);
      event.currentTarget = this;
      event.target = this;
      event.type = type;
      event.bubbles = event.cancelable = false;
      _handleEvent(this, listener, event);
    }
  });
}

if (!("onmouseenter" in element)) {
  wrappedTypes.mouseenter = "mouseover";
  eventWrappers.mouseenter = wrapMouseEnterLeave;
  wrappedTypes.mouseleave = "mouseout";
  eventWrappers.mouseleave = wrapMouseEnterLeave;
}

// All other browsers support onmousewheel even if they don't directly support the onmousewheel property
if (!("onmousewheel" in element) && _.detect("Gecko")) {
  wrappedTypes.mousewheel = "DOMMouseScroll";
  eventWrappers.mousewheel = function _wrapMouseWheel(type, listener) {
    return _wrap(type, listener, function _wrappedListener(event) {
      event = cloneEvent(event);
      event.type = type;
      event.wheelDelta = (-event.detail * 40) || 0;
      _handleEvent(this, listener, event);
    });
  };
}

if (_.detect("\\b(Linux|Mac)\\b|Opera\\d")) { // http://unixpapa.com/js/key.html
  eventWrappers.keydown = function _wrapKeyDown(type, listener) {
    // Some browsers do not fire repeated "keydown" events when a key
    // is held down. They do fire repeated "keypress" events though.
    // Cancelling the "keydown" event does not cancel the
    // "keypress" event. We fix all of this here...
    var pressed = false; // in case the browser sniff returns a false positive
    return _wrap(type, listener, function _wrappedListener(keydownEvent) {
      if (pressed) return;
      pressed = true;

      var target = this;
      var firedCount = 0;
      var cancelled = false;

      _.extend(keydownEvent, "preventDefault", function() {
        this.base();
        cancelled = true;
      });

      var handleEvent = function handle_keypress(event) {
        if (cancelled) event.preventDefault();
        if (event == keydownEvent || firedCount > 1) {
          _handleEvent(target, listener, keydownEvent);
        }
        firedCount++;
      };

      var onkeyup = function onkeyup() {
        target.removeEventListener("keypress", handleEvent, true);
        target.removeEventListener("keyup", onkeyup, true);
        pressed = false;
      };
      
      target.addEventListener("keyup", onkeyup, true);
      target.addEventListener("keypress", handleEvent, true);

      handleEvent.call(target, keydownEvent);
    });
  };
}

function wrapObjectListener(type, listener) {
  return _wrap(type, listener, function _wrappedListener(event) {
    listener.handleEvent(event);
  });
}

function wrapListener(type, listener) {
  return _wrap(type, listener, function _wrappedListener_gecko(event) {
    _handleEvent(this, listener, event);
  });
}

function _wrap(type, listener, wrapper) {
  var key = type + "." + _.assignID(listener);
  if (!wrappedListeners[key]) {
    wrappedListeners[key] = wrapper;
    wrappedListenersCount[key] = 0;
  }
  wrappedListenersCount[key]++;
  return wrappedListeners[key];
}

function _unwrap(type, listener) {
  var key = type + "." + listener.base2ID;
  var wrappedListener = wrappedListeners[key];
  if (wrappedListener) {
    wrappedListenersCount[key]--;
    if (wrappedListenersCount[key] === 0) {
      delete wrappedListeners[key];
      delete wrappedListenersCount[key];
    }
  }
  return wrappedListener || listener;
}

function _handleEvent(target, listener, event) {
  if (typeof listener == "object") {
    target = listener;
    listener = target.handleEvent;
  }
  if (typeof listener == "function" && listener.call) {
    if (SILENT_DISPATCH && event._userGenerated) { // Firefox
      // https://bugzilla.mozilla.org/show_bug.cgi?id=574941
      // Try to let the user know that an error occurred.
      try {
        listener.call(target, event);
      } catch (ex) {
        if (USE_CONSOLE) console.log(ex);    // this only works with Firebug
        setTimeout(function(){throw ex}, 0); // this does not do anything in Firefox 4
      }
    } else {
      listener.call(target, event);
    }
  }
}

function cloneEvent(event) {
  if (event.isClone) return event;

  var clone = {toString: _.K(String(event))};
  for (var i in event) clone[i] = event[i];

  clone.isClone = true;

  clone.stopPropagation = function stopPropagation() {
    if (event.stopPropagation) {
      event.stopPropagation();
    } else {
      event.cancelBubble = true;
    }
  };
  
  clone.preventDefault = function preventDefault() {
    if (event.preventDefault) {
      event.preventDefault();
    } else {
      event.returnValue = false;
    }
  };
  return clone;
}
