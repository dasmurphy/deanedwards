
// http://www.w3.org/TR/DOM-Level-2-Events/events.html#Events-DocumentEvent

var eventCounter = 1;

var createEventFix = function createEvent(eventType) {
  var methodName = "createEvent";
  if (arguments.length < 1) {
    throw new ArityError(methodName);
  }

  if (/^Events?$/.test(eventType)) eventType = "UIEvent";

  var method = protoMethods[this[PROTO_TYPE] + methodName] || this[methodName];
  var event = method.call(this, eventType);
  
  if (FORGETS_CUSTOM_DATA) { // for SamsungTV
    var view = this.defaultView;
    event.initEvent = function initEvent(type, bubbles, cancelable) {
      event.initUIEvent(type, bubbles, cancelable, view, eventCounter++);
    };
  }
  return event;
};

if (document.createEvent) {
  if (!_.detect("(document.createEvent('Event'))")) {
    _createEvent = createEventFix;
  }
} else {
  _createEvent = function createEvent(eventType) {
    if (arguments.length < 1) {
      throw new ArityError("createEvent");
    }

    if (!/^(Mouse)?Event$/.test(eventType)) {
      throw new Error("NOT_SUPPORTED_ERR");
    }

    return new eventTypes[eventType];
  };
}
