
// for MSIE6-8

/*@

var CONST_PROPAGATION_STOPPED = 0;
var CONST_DEFAULT_PREVENTED   = 1;

var BUTTON_MAP       = {2:2, 4:1};
var MSIE_FOCUS_EVENT = {focusin: "focus", focusout: "blur"};
var W3C_FOCUS_EVENT  = {focus: "focusin", blur: "focusout"};
var MOUSE_EVENT      = /^mouse|click$/;
var MOUSE_BUTTON     = /^mouse(up|down)|click$/;
var MOUSE_CLICK      = /click$/;
var NO_BUBBLE        = /^((before|un)?load|focus|blur|stop|(readystate|property|filter)change|losecapture)$/;
var CANCELABLE       = /^((dbl)?click|mouse(down|up|move|over|out|wheel)|key(down|up|press)|submit|(before)?(cut|copy|paste)|contextmenu|drag(start|enter|over)?|drop|before(de)?activate)$/;
var FORCE_BUBBLE     = {change:1, select:1, submit:1, reset:1};
var THROTTLE         = {scroll:1, select:1, resize: 1};

// break out of closures to attach events in MSIE
var MSIE_PRIVATE = "#base2_msie";
msieCache = window[MSIE_PRIVATE];
if (!msieCache) {
  var CONST_LISTENERS = 0, CONST_HANDLERS = 1;
  msieCache = window[MSIE_PRIVATE] = {0:{}, 1:[{},{},{},{}]};
  _private.attachEvent = function attachEvent_msie(target, type, listener, before, phase) {
    var targetID = target.nodeType === 1 ? target.uniqueID : target.base2ID || _.assignID(target);
    var listenerID = targetID + (listener.base2ID || _.assignID(listener));
    if (before) var beforeID = before.base2ID || _.assignID(before);
    var handlers = msieCache[CONST_HANDLERS][phase || 0];
    var handleEvent = handlers[listenerID];
    var listeners = msieCache[CONST_LISTENERS];

    if (!handleEvent) {
      if (before) listeners[beforeID] = before;
      listeners[listenerID] = listener;
      if (target.nodeType === 1) {
        var handler = Function("e",
          "var l=window['" + MSIE_PRIVATE + "'][0]," +
          "t=e.srcElement.ownerDocument.all['" + target.uniqueID + "'];" +
          (before ? "l['" + beforeID + "'].call(t,e," + phase + ",l['" + listenerID + "'])" : "l['" + listenerID + "'].call(t,e)")
        );
      } else {
        handler = function(e) {
          before ? before.call(target, e, phase, listener) : listener.call(target, e);
        };
      }
      handleEvent = handlers[listenerID] = handler;
    }
    target.attachEvent(type, handleEvent);
  };

  _private.detachEvent = function detachEvent_msie(target, type, listener, phase) {
    var targetID = target.nodeType === 1 ? target.uniqueID : target.base2ID;
    var listenerID = targetID + listener.base2ID;
    var handlers = msieCache[CONST_HANDLERS][phase || 0];
    var handler = handlers[listenerID];
    if (handler) target.detachEvent(type, handler);
    delete msieCache[CONST_LISTENERS][listenerID];
    delete handlers[listenerID];
  };
}

_DocumentState_msie = {
  constructor: function DocumentState__constructor(document) {
    this._events = {};
    this._forms = {};

    var state = this;
    var captureEvents = this._captureEvents = {};
    var lastWrappedEvent = {};
    var lastEventID = {};
    var eventCounter = 1;
    var throttle = {"undefined":{}, 1:{}, 3:{}};

    this.handleEvent = function DocumentState__handleEvent(event, phase, listener) {
      var type = event.type;
      var currentTarget = this;
      var target = event.target = event.srcElement || currentTarget;
      var atTarget = target == currentTarget;

      var currentEventID = event.returnValue; // use returnValue to uniquely identify an event
      if (currentEventID == null) {
        currentEventID = event.returnValue = eventCounter++;
      } else if (currentEventID == false && typeof currentEventID == "object") { // Boolean(false)
        currentEventID = currentEventID.value;
      }

      if (THROTTLE[type]) {
        var now = +new Date;
        var ignoreEvent = now - (throttle[phase][type] || 0) < 30;
        throttle[phase][type] = now;
        if (ignoreEvent) return;
      }

      var isNewEvent = lastEventID[type] != currentEventID;

      if (isNewEvent) {
        if (state["on" + type]) {
          state["on" + event.type](event);
        }
        lastEventID[type] = currentEventID;

        if (type === "click" && state._fakeClickEvent) {
          lastWrappedEvent[type] = state._fakeClickEvent;
        } else {
          lastWrappedEvent[type] = new EventWrapper(event, state);
        }
      }

      var wrappedEvent = lastWrappedEvent[type];

      if (listener) {
        // Dispatch the capture phase once per event
        if (isNewEvent && captureEvents[type]) {
          state.dispatchEvent(target, wrappedEvent, CONST_CAPTURING_PHASE);
        }
        // Only dispatch for the bubble phase
        if (((phase == CONST_BUBBLING_PHASE && !MSIE_FOCUS_EVENT[type]) || atTarget) && !wrappedEvent[CONST_PROPAGATION_STOPPED]) {
          wrappedEvent.eventPhase = atTarget ? CONST_AT_TARGET : CONST_BUBBLING_PHASE;
          wrappedEvent.currentTarget = currentTarget;
          if (typeof listener == "function") {
            listener.call(currentTarget, wrappedEvent);
          } else if (typeof listener == "object") {
            listener.handleEvent(wrappedEvent);
          }
          delete wrappedEvent[CONST_PROPAGATION_STOPPED];
        }
      }

      if (FORCE_BUBBLE[type] && state._isLastListener(event, listener) && !event.cancelBubble) {
        state.dispatchEvent(target, wrappedEvent, CONST_BUBBLING_PHASE);
      }

      if (wrappedEvent[CONST_DEFAULT_PREVENTED]) {
        var FALSE = new Boolean(false);
        FALSE.value = currentEventID;
        event.returnValue = FALSE;
      }
    };

    this.base(document);
  },

  _registerForm: function DocumentState__registerForm(form) {
    // Allow form events to bubble
    var formID = form.uniqueID;
    if (!this._forms[formID]) {
      this._forms[formID] = true;
      _private.attachEvent(form, "onsubmit", _.Undefined, this.handleEvent);
      _private.attachEvent(form, "onreset", _.Undefined, this.handleEvent);
    }
  },

  _isLastListener: function DocumentState__isLastListener(event, listener) {
    var typeMap = this._events[event.type];
    if (!typeMap) return false;
    var listeners = typeMap[event.srcElement.uniqueID];
    if (!listeners) return true;
    for (var id in listeners) {
      return listener == listeners[id];
    }
  },

  onactivate: function onactivate(event) {
    // Force certain events to bubble.
    var target = event.target;
    var forceBubble = _.Undefined; // just make sure it's registered
    var attached = {};
    for (var type in FORCE_BUBBLE) {
      if (("on" + type) in target) {
        _private.attachEvent(target, "on" + type, forceBubble, this.handleEvent);
        attached[type] = forceBubble;
      }
    }
    // Support the input event.
    if (this._events.input && target.nodeName === "TEXTAREA" || (target.nodeName === "INPUT" && !NON_TEXT_ELEMENT.test(target.type))) {
      var state = this;
      var keyDown, editing, fired, value;
      var onedit = function() {
        editing = true;
      };
      var events = {
        cut: onedit,
        paste: onedit,
        propertychange: function(event) {
          if ((keyDown || editing) && event.propertyName === "value") {
            state._dispatchInputEvent(target);
          }
          editing = false;
          fired = true;
        },
        keydown: function(event) {
          keyDown = !event.ctrlKey || event.keyCode === 89 || event.keyCode === 90;
          value = target.value;
          fired = false;
        },
        keyup: function(event) {
          keyDown = false;
          if (value !== target.value && !fired && event.keyCode !== 9) {
            state._dispatchInputEvent(target);
          }
        }
      };
      for (type in events) {
        _private.attachEvent(target, "on" + type, events[type]);
        attached[type] = events[type];
      }
    }
    
    var ondeactivate = function() {
      target.detachEvent("ondeactivate", ondeactivate);
      for (var type in attached) {
        _private.detachEvent(target, "on" + type, attached[type]);
      }
    };
    target.attachEvent("ondeactivate", ondeactivate);

    if (target.form) {
      this._registerForm(target.form);
    }
  },

  ondblclick: function ondblclick(event) {
    // Fire missing click event in MSIE
    if (!event._userGenerated) {
      event.srcElement.fireEvent("onclick", event);
    }
  },

  onmousedown: function onmousedown(event) {
    this.base(event);
    // remember the button number (it's missing in some event types)
    this._button = event.button;
  },

  onmouseup: function onmouseup(event) {
    this.base(event);
    var button = this._button;
    delete this._button;
    // Fire missing mousedown event in MSIE (on dblclick)
    if (!event._userGenerated && button == null) {
      event.srcElement.fireEvent("onmousedown", event);
    }
  },

  addEventListener: function DocumentState__addEventListener(target, type, listener, useCapture) {
    type = W3C_FOCUS_EVENT[type] || type;
    // assign a unique id to both objects
    var phase = useCapture ? CONST_CAPTURING_PHASE : CONST_BUBBLING_PHASE;
    var targetID = target.nodeType === 1 ? target.uniqueID : _.assignID(target);
    var listenerID = phase + _.assignID(listener);

    // create a hash table of event types for the target object
    var typeMap = this._events[type];
    if (!typeMap) typeMap = this._events[type] = {};

    // create a hash table of event listeners for each object/event pair
    var listeners = typeMap[targetID];
    if (!listeners) listeners = typeMap[targetID] = {};

    if (!listeners[listenerID]) {
      // store the event listener in the hash table
      listeners[listenerID] = listener;
      if (useCapture) {
        this._captureEvents[type] |= 0;
        this._captureEvents[type]++;
      }
      _private.attachEvent(target, "on" + type, listener, this.handleEvent, phase);
    }
  },

  removeEventListener: function DocumentState__removeEventListener(target, type, listener, useCapture) {
    // delete the event listener from the hash table
    type = W3C_FOCUS_EVENT[type] || type;
    var typeMap = this._events[type];
    if (typeMap) {
      var listeners = typeMap[target.nodeType === 1 ? target.uniqueID : target.base2ID];
      if (listeners) {
        var phase = useCapture ? CONST_CAPTURING_PHASE : CONST_BUBBLING_PHASE;
        var listenerID = phase + listener.base2ID;
        if (listeners[listenerID]) {
          delete listeners[listenerID];
          if (useCapture) {
            this._captureEvents[type] |= 0;
            this._captureEvents[type]--;
          }
          _private.detachEvent(target, "on" + type, listener, phase);
        }
      }
    }
  },

  dispatchEvent: function DocumentState__dispatchEvent(target, event, phase) {
    var type = event.type;
    type = W3C_FOCUS_EVENT[type] || type;
    if (!event.target) {
      event.target = target;
    }
    if (!phase && type === "click" && event.isClone && target.click && (target.parentElement || target.nodeName === "HTML")) {
      this._fakeClickEvent = event;
      target.click();
      delete this._fakeClickEvent;
    } else {
      var typeMap = this._events[type];
      if (typeMap) {
        // Collect nodes in the event hierarchy
        var nodes = [], i = 0;
        while ((target = target.parentNode || target.parentWindow)) {
          nodes[i++] = target;
        }
        // Dispatch.
        if (!phase || phase === CONST_CAPTURING_PHASE) {
          this._dispatchPhase(event, CONST_CAPTURING_PHASE, nodes, typeMap);
        }
        if (!phase && !event[CONST_PROPAGATION_STOPPED]) {
          this._dispatchPhase(event, CONST_AT_TARGET, [event.target], typeMap);
        }
        if ((!phase || phase === CONST_BUBBLING_PHASE) && event.bubbles && !event[CONST_PROPAGATION_STOPPED]) {
          this._dispatchPhase(event, CONST_BUBBLING_PHASE, nodes.reverse(), typeMap);
        }
      }
    }
    return !event[CONST_DEFAULT_PREVENTED];
  },

  _dispatchPhase: function DocumentState__dispatchPhase(event, phase, nodes, typeMap) {
    event.eventPhase = phase;
    var i = nodes.length;
    while (i-- && !event[CONST_PROPAGATION_STOPPED]) {
      var currentTarget = event.currentTarget = nodes[i];
      var listeners = typeMap[currentTarget.nodeType === 1 ? currentTarget.uniqueID : currentTarget.base2ID];
      if (listeners) {
        var clonedListeners = {};
        for (var id in listeners) clonedListeners[id] = listeners[id];
        for (id in clonedListeners) {
          if ((phase === CONST_AT_TARGET) ||
            (phase === CONST_BUBBLING_PHASE && id > "2") ||
            (phase === CONST_CAPTURING_PHASE && id < "2")) {
            var listener = clonedListeners[id];
            if (typeof listener == "function") {
              _private.continueIfThrow(listener, currentTarget, event);
            } else {
              _private.continueIfThrow(listener.handleEvent, listener, event);
            }
          }
        }
      }
    }
  },

  _registerEvent: function DocumentState__registerEvent(document, type) {
    _private.attachEvent(document, "on" + type, this.handleEvent);
  }
};

_createEvent = function() {
  return new EventWrapper;
};

_DOMContentLoaded_msie = {
  listen: function DOMContentLoadedEvent__listen_msie(document) {
    var self = this;
    var framed = true; // Rich Dougherty
    try {
      framed = document.parentWindow.frameElement != null;
    } catch (ex) {}
    if (!framed) {
      // Diego Perini: http://javascript.nwbox.com/IEContentLoaded/
      var element = document.createElement("div");
      _private.deferUntil(self.fire, function() {
        try {
          element.doScroll("left");
          return true;
        } catch (ex) {
          return false;
        }
      });
    }
    _private.attachEvent(document, "onreadystatechange", function() {
      if (document.readyState === "complete") self.fire();
    });
  }
};

var EventWrapper = _private.Event.extend({
  constructor: function EventWrapper__constructor(event) {
    for (var i in event) this[i] = event[i];
    delete this.cancelBubble;
    delete this.returnValue;

    var type = this.type;

    if (type) {
      var state = arguments[0];
      
      type = this.type = MSIE_FOCUS_EVENT[type] || type;
      var target = this.target;

      this.bubbles = !NO_BUBBLE.test(type);
      this.cancelable = CANCELABLE.test(type);
      this.timeStamp = +new Date;
      if (MOUSE_BUTTON.test(type)) {
        var button = MOUSE_CLICK.test(type) ? state._button : event.button;
        this.button = BUTTON_MAP[button] || 0;
      }

      this.relatedTarget = event[(target == event.fromElement ? "to" : "from") + "Element"] || null;

      if (this.cancelable) this.preventDefault = function preventDefault() {
        if (!this[CONST_DEFAULT_PREVENTED]) {
          this.defaultPrevented = true;
          this[CONST_DEFAULT_PREVENTED] = true;
          if (type === "mousedown") { // cancel a mousedown event
            var body = target.ownerDocument.body;
            var onbeforedeactivate = function(event) {
              body.detachEvent("onbeforedeactivate", onbeforedeactivate);
              event.returnValue = false;
            };
            body.attachEvent("onbeforedeactivate", onbeforedeactivate);
          }
        }
      };

      this.stopPropagation = function stopPropagation() {
        this[CONST_PROPAGATION_STOPPED] = true;
        event.cancelBubble = true;
      };
    }
  },
  
  isClone: true
});

@*/
