
// http://dean.edwards.name/weblog/2006/06/again

DOMContentLoadedEvent = _.Base.extend({
  constructor: function DOMContentLoadedEvent__constructor(document) {
    var self  = this;
    var fired = COMPLETE.test(document.readyState);
    var documentElement = document.documentElement;
    var createEvent = _createEvent || document.createEvent;
    var dispatchEvent = documentElement.dispatchEvent || _dispatchEvent;
    this.fire = function _DOMContentLoadedEvent_fire() {
      if (document == window.document) _private.isReady = true;
      if (!fired) {
        fired = true;
        var event = createEvent.call(document, "Event");
        event.initEvent("base2:DOMContentLoaded", true, false);
        dispatchEvent.call(documentElement, event);
      }
    };
    if (fired) this.fire(); else this.listen(document);
  },

  listen: function DOMContentLoadedEvent__listen(document) {
    // if all else fails fall back on window.onload
    _addEventListener.call(document.defaultView, "load", this.fire);
  },

  "@(document.addEventListener)": {
    listen: function DOMContentLoadedEvent__listen(document) {
      this.base(document);
      document.addEventListener("DOMContentLoaded", this.fire, false);
    }
  },

  "@MSIE[678]": _DOMContentLoaded_msie,

  "@KHTML": {
    listen: function DOMContentLoadedEvent__listen_webkit(document) {
      this.base(document);
      _private.deferUntil(this.fire, function() { // John Resig
        return COMPLETE.test(document.readyState);
      });
    }
  }
});
