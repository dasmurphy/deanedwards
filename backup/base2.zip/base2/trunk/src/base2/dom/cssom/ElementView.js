
// http://www.w3.org/TR/cssom-view/#extensions-to-the-element-interface

_private.getOffsetFromBody = getOffsetFromBody;

if (element.getBoundingClientRect) {
  if (_.detect("Gecko1\\.9([^\\.]|\\.0)")) { // bug in Gecko 1.9.0 only
    _getBoundingClientRect = function getBoundingClientRect_gecko_190() {
      var document = this.ownerDocument;
      var method = protoMethods[this[PROTO_TYPE] + "getBoundingClientRect"] || this.getBoundingClientRect;
      var clientRect = method.call(this);

      // This bug only occurs when the document body is absolutely positioned.
      if (!/^HTML$/i.test(this.nodeName) && "absolute" === _offsets._getBodyClient(document).position) {
        var offset = _offsets._getGeckoRoot(document);
        
        return {
          top:    clientRect.top - offset.y,
          right:  clientRect.right - offset.x,
          bottom: clientRect.bottom - offset.y,
          left:   clientRect.left - offset.x
        };
      }
      return clientRect;
    };
    _private.getOffsetFromBody = function getOffsetFromBody_gecko_pre190(element) {
      var offset = getOffsetFromBody(element);
      var document = element.ownerDocument;

      // Slightly different rules when the body is absolutely positioned
      if (!_offsets._getBodyClient(document).isAbsolute) {
        var rootOffset = _offsets._getGeckoRoot(document);
        offset.left -= rootOffset.x;
        offset.top -= rootOffset.y;
      }

      return offset;
    };
  }
} else if (_.detect("WebKit5|KHTML4")) {
  _getBoundingClientRect = function getBoundingClientRect_webkit() {
    var clientRect = getBoundingClientRect_calc.call(this);

    // Tweak the result for Safari 3.x if the document body is absolutely positioned.
    if (!/^HTML$/i.test(this.nodeName)) {
      var document = this.ownerDocument;
      var offset = _offsets._getBodyOffset(document);
      
      if (!offset.isAbsolute) {
        offset = _offsets._getViewport(document)
      }
      clientRect.left += offset.left;
      clientRect.top += offset.top;
    }

    return clientRect;
  };
  _private.getOffsetFromBody = function getOffsetFromBody_safari3(element) {
    var elementOffset = getOffsetFromBody(element);

    // Tweak the result for Safari 3.x if the document body is absolutely positioned.
    if (!/^BODY$/i.test(element.nodeName)) {
      var document = element.ownerDocument;
      var offset = _offsets._getBodyOffset(document);

      if (!offset.isAbsolute) {
        offset = _offsets._getViewport(document)
      }
      elementOffset.left -= offset.left;
      elementOffset.top -= offset.top;
    }

    return elementOffset;
  };
} else if (document.getBoxObjectFor) {
  _getBoundingClientRect = function getBoundingClientRect_gecko() {
    var document = this.ownerDocument;
    var view = document.defaultView;
    var documentElement = document.documentElement;
    var box = document.getBoxObjectFor(this);
    var computedStyle = view.getComputedStyle(this, null);
    var left = box.x - parseInt(computedStyle.borderLeftWidth);
    var top = box.y - parseInt(computedStyle.borderTopWidth);
    var parentNode = this.parentNode;

    if (this != documentElement) {
      while (parentNode && parentNode != documentElement) {
        left -= parentNode.scrollLeft;
        top -= parentNode.scrollTop;
        computedStyle = view.getComputedStyle(parentNode, null);
        if (computedStyle.position !== "absolute") {
          left += parseInt(computedStyle.borderTopWidth);
          top  += parseInt(computedStyle.borderLeftWidth);
        }
        parentNode = parentNode.parentNode;
      }

      if (computedStyle.position !== "fixed") {
        left -= view.pageXOffset;
        top -= view.pageYOffset;
      }

      var bodyPosition = view.getComputedStyle(document.body, null).position;
      if (bodyPosition === "relative") {
        var offset = document.getBoxObjectFor(documentElement);
      } else if (bodyPosition === "static") {
        offset = _offsets._getGeckoRoot(document);
      }
      if (offset) {
        left += offset.x;
        top += offset.y;
      }
    }

    return {
      top: top,
      right: left + this.clientWidth,
      bottom: top + this.clientHeight,
      left: left
    };
  };
} else {
  _getBoundingClientRect = getBoundingClientRect_calc;
}

function getBoundingClientRect_calc() {
  var document = this.ownerDocument;

  switch (this.nodeName) {
    case "html":
    case "HTML":
      var offset = _offsets._getViewport(document);
      break;

    case "body":
    case "BODY":
      offset = _offsets._getBodyClient(document);
      break;

    default:
      var left = this.offsetLeft;
      var top = this.offsetTop;
      var view = document.defaultView;
      var documentElement = document.documentElement;
      var computedStyle = view.getComputedStyle(this, null);
      var offsetParent = this.offsetParent;

      while (offsetParent && (offsetParent != documentElement || computedStyle.position === "static")) {
        left += offsetParent.offsetLeft - offsetParent.scrollLeft;
        top += offsetParent.offsetTop - offsetParent.scrollTop;

        computedStyle = view.getComputedStyle(offsetParent, null);

        if (FIX_BORDER.test(offsetParent.nodeName)) {
          if (offsetParent.clientLeft == null) {
            left += parseInt(computedStyle.borderLeftWidth);
            top  += parseInt(computedStyle.borderTopWidth);
          } else {
            left += offsetParent.clientTop;
            top  += offsetParent.clientLeft;
          }
        }
        offsetParent = offsetParent.offsetParent;
      }
      offset = {
        left: left,
        top: top
      };
  }

  return {
    top:    offset.top,
    right:  offset.left + this.offsetWidth,
    bottom: offset.top + this.offsetHeight,
    left:   offset.left
  };
}

function getOffsetFromBody(element) {
  var left = 0, top = 0;

  if (!/^BODY$/i.test(element.nodeName)) {
    var document = element.ownerDocument;
    var documentElement = document.documentElement;
    var body = document.body;
    var bodyOffset = _offsets._getBodyOffset(document);
    var getBoundingClientRect = _getBoundingClientRect || element.getBoundingClientRect;
    var clientRect = Function__call.call(getBoundingClientRect, element);

    left = clientRect.left + Math.max(documentElement.scrollLeft, body.scrollLeft);
    top = clientRect.top + Math.max(documentElement.scrollTop, body.scrollTop);

    /*@
      if (MSIE6 && body.currentStyle.position !== "relative") {
        left -= documentElement.clientLeft;
        top -= documentElement.clientTop;
      }
      if (@_jscript_version === 5.7 || document.documentMode === 7) {
        var rect = documentElement.getBoundingClientRect();
        left -= rect.left;
        top -= rect.top;
      }
      if (QUIRKS_MODE) {
        left -= body.clientLeft;
        top -= body.clientTop;
        bodyOffset.isAbsolute = false;
      }
    @*/

    if (bodyOffset.isAbsolute) {
      left -= bodyOffset.left;
      top -= bodyOffset.top;
    }
  }

  return {
    left: left,
    top: top
  };
}
