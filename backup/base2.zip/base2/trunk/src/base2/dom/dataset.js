
// NOT USED

var dataset = {
  get: function base2_dom_dataset_get(element, propertyName) {
    propertyName = propertyName.replace(_CHAR_UPPER, _dash_lower);
    return element.getAttribute(propertyName, "data-" + propertyName);
  },

  set: function base2_dom_dataset_set(element, propertyName, value) {
    propertyName = propertyName.replace(_CHAR_UPPER, _dash_lower);
    element.setAttribute(propertyName, "data-" + propertyName, String(value));
  },

  remove: function base2_dom_dataset_remove(element, propertyName) {
    propertyName = propertyName.replace(_CHAR_UPPER, _dash_lower);
    element.removeAttribute(propertyName, "data-" + propertyName);
  },
  
  toString: _.K("[base2.dom.dataset]")
};
