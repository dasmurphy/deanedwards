

if (!_.detect("(element.prepend)")) {
  var _after = function after() {
    this.parentNode && this.parentNode.insertBefore(toNode(arguments), this.nextSibling);
  };

  var _before = function before() {
    this.parentNode && this.parentNode.insertBefore(toNode(arguments), this);
  };

  var _append = function append() {
    this.appendChild(toNode(arguments));
  };

  var _prepend = function prepend() {
    this.insertBefore(toNode(arguments), this.firstChild);
  };

  var _replace = function replace() {
    this.parentNode && this.parentNode.replaceChild(toNode(arguments), this);
  };

  var _remove = function remove() {
    this.parentNode && this.parentNode.removeChild(this);
  };
}

// help

function toNode(node) {
  var length = arguments.lenth;
  if (length > 1) {
    node = document.createDocumentFragment();
    for (var i = 0; i < length; i++) {
      var child = arguments[i];
      if (typeof child == "string") {
        child = document.createTextNode(child);
      }
      node.appendChild(child);
    }
  } else {
    if (typeof node == "string") {
      node = document.createTextNode(node);
    }
  }
  return node;
}
