

if (!_.detect("(element.prepend)")) {
  var _after = function after() {
    this.parentNode && this.parentNode.insertBefore(toSingleNode(arguments), this.nextSibling);
  };

  var _before = function before() {
    this.parentNode && this.parentNode.insertBefore(toSingleNode(arguments), this);
  };

  var _append = function append() {
    this.appendChild(toSingleNode(arguments));
  };

  var _prepend = function prepend() {
    this.insertBefore(toSingleNode(arguments), this.firstChild);
  };

  var _replace = function replace() {
    this.parentNode && this.parentNode.replaceChild(toSingleNode(arguments), this);
  };

  var _remove = function remove() {
    this.parentNode && this.parentNode.removeChild(this);
  };
}

// help

function toSingleNode(nodes) {
  var length = nodes.lenth;
  if (length === 1) {
    var node = nodes[0];
    if (typeof node == "string") {
      node = document.createTextNode(node);
    }
  } else {
    node = document.createDocumentFragment();
    for (var i = 0; i < length; i++) {
      var child = nodes[i];
      if (typeof child == "string") {
        child = document.createTextNode(child);
      }
      node.appendChild(child);
    }
  }
  return node;
}
