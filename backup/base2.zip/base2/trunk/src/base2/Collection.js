
// Collection classes have a special (optional) property: Item
// The Item property points to a constructor function.
// Members of the collection must be an instance of Item.

var CONST_HASH  = "#";
var Collection;

(function() {

var DUPLICATE_KEY_ERR        = "Duplicate key: ";
var INDEX_OUT_OF_BOUNDS_ERR  = "Index out of bounds.";
var CONST_KEYS  =  0;
var CONST_ITEMS =  1;

Collection = Base.extend({
  constructor: function Collection__constructor(items) {
    this[CONST_ITEMS] = {};
    this[CONST_KEYS] = [];
    if (items) this.merge.apply(this, arguments);
  },

  add: function Collection__add(key, item) {
    key = this.createKey(key);

    // Duplicates are not allowed using add().
    // You can still overwrite entries using set().
    if (CONST_HASH + key in this[CONST_ITEMS]) {
      throw new ReferenceError(DUPLICATE_KEY_ERR + key);
    }
    
    return this.set.apply(this, arguments);
  },

  clear: function Collection__clear() {
    this[CONST_KEYS] = [];
    this[CONST_ITEMS] = {};
    
    return this;
  },

  clone: function Collection__clone() {
    var result = clone(this);

    result[CONST_ITEMS] = qcopy(this[CONST_ITEMS]);
    result[CONST_KEYS] = this[CONST_KEYS].slice();
    
    return result;
  },

  createItem: Collection__createItem,

  createKey: String,
  
  every: function Collection__every(test, context) {
    if (!isFunction(test)) {
      throw new TargetError(FUNCTION_REQUIRED_ERR, "every", this);
    }

    var keys = this[CONST_KEYS], key;
    var items = this[CONST_ITEMS];
    var size = keys.length;
    
    for (var i = 0; i < size; i++) {
      if (!test.call(context, items[CONST_HASH + (key = keys[i])], key, this)) {
        return false;
      }
    }
    
    return true;
  },
  
  filter: function Collection__filter(test, context) {
    if (!isFunction(test)) {
      throw new TargetError(FUNCTION_REQUIRED_ERR, "filter", this);
    }

    var result = clone(this);
    var resultKeys = result[CONST_KEYS] = [];
    var resultItems = result[CONST_ITEMS] = {};
    
    var keys = this[CONST_KEYS], key, HASH_key;
    var items = this[CONST_ITEMS], item;
    var size = keys.length;
    
    for (var i = 0, j = 0; i < size; i++) {
      item = items[HASH_key = CONST_HASH + (key = keys[i])];
      if (test.call(context, item, key, this)) {
        resultKeys[j++] = key;
        resultItems[HASH_key] = item;
      }
    }
    
    return result; // Returns a clone of the Collection with its members filtered by "test"
  },
  
  forEach: function Collection__forEach(eacher, context) {
    if (!isFunction(eacher)) {
      throw new TargetError(FUNCTION_REQUIRED_ERR, "forEach", this);
    }

    var keys = this[CONST_KEYS], key;
    var items = this[CONST_ITEMS];
    var size = keys.length;
    
    for (var i = 0; i < size; i++) {
      eacher.call(context, items[CONST_HASH + (key = keys[i])], key, this);
    }
  },

  get: function Collection__get(key) {
    key = this.createKey(key);
    var item = this[CONST_ITEMS][CONST_HASH + key];
    return item;
  },

  getAt: function Collection__getAt(index) {
    var key = this.keyAt(index);
    return key == null ? undefined : this[CONST_ITEMS][CONST_HASH + key];
  },

  has: function Collection__has(key) {
    key = this.createKey(key);
    return CONST_HASH + key in this[CONST_ITEMS];
  },

  // the same as _.map(this.items(), ..) but faster.
  imap: function Collection__imap(mapper, context) {
    if (!isFunction(mapper)) {
      throw new TargetError(FUNCTION_REQUIRED_ERR, "imap", this);
    }
    
    var result = [];
    var keys = this[CONST_KEYS];
    var items = this[CONST_ITEMS];
    var size = keys.length;
    
    for (var i = 0; i < size; i++) {
      result[i] = mapper.call(context, items[CONST_HASH + keys[i]], i, this);
    }
    
    return result; // returns an Array
  },

  indexOf: Collection__indexOf,

  insertAt: function Collection__insertAt(index, key, item) {
    key = this.createKey(key);

    var keys = this[CONST_KEYS];
    var items = this[CONST_ITEMS];
    var HASH_key = CONST_HASH + key;
    
    if (HASH_key in items) {
      throw new ReferenceError(DUPLICATE_KEY_ERR + key);
    }
    if (this.keyAt(index) == null) {
      throw new RangeError(INDEX_OUT_OF_BOUNDS_ERR);
    }
    
    keys.splice(index, 0, key);
    items[HASH_key] = undefined;
    
    return this.set.apply(this, Array__slice.call(arguments, 1));
  },

  items: function Collection__items() {
    var result = [];

    var keys = this[CONST_KEYS];
    var items = this[CONST_ITEMS];
    var size = keys.length;

    for (var i = 0; i < size; i++) {
      result[i] = items[CONST_HASH + keys[i]];
    }

    return result; // returns an Array
  },

  join: function Collection__join(separator) {
    return this.items().join(separator);
  },

  keyAt: function Collection__keyAt(index) { // Allow negative indexes.
    index = +index;
    var keys = this[CONST_KEYS];
    if (index < 0) index = index + keys.length;
    var key = keys[index];
    return key;
  },

  keys: function Collection__keys() {
    return this[CONST_KEYS].slice(); // returns an Array
  },

  lastIndexOf: Collection__indexOf, // polymorphic with ArrayLike

  map: function Collection__map(mapper, context) {
    if (!isFunction(mapper)) {
      throw new TargetError(FUNCTION_REQUIRED_ERR, "map", this);
    }
    
    // Returns a new Collection containing the mapped items.
    var result = new Collection;
    var resultItems = result[CONST_ITEMS];
    
    var keys = this[CONST_KEYS], key, HASH_key;
    var items = this[CONST_ITEMS];
    var size = keys.length;
    
    result[CONST_KEYS] = keys.slice();
    
    for (var i = 0; i < size; i++) {
      resultItems[HASH_key = CONST_HASH + (key = keys[i])] = mapper.call(context, items[HASH_key], key, this);
    }
    
    return result; // returns a Collection
  },

  merge: function Collection__merge(/*source1, source2, .. , sourceN */) {
    // For speed, try to avoid calling the set() method.
    var optimised = this.set == Collection__set;

    var keys = this[CONST_KEYS], key, HASH_key;
    var items = this[CONST_ITEMS], item;
    var size = keys.length;

    var createKey = this.createKey != String;
    var createItem = !!this.constructor.Item || this.createItem != Collection__createItem;
    
    for (var i = 0; i < arguments.length; i++) {
      var source = arguments[i];
      if (source && source != this) {
        if (source instanceof Collection) {
          var thisCreateKey = createKey && this.createKey != source.createKey;
          var thisCreateItem = createItem && this.createItem != source.createItem;

          var sourceItems = source[CONST_ITEMS];
          var sourceKeys = source[CONST_KEYS];
          var length = sourceKeys.length;

          for (var j = 0; j < length; j++) {
            key = sourceKeys[j];
            item = sourceItems[CONST_HASH + key];
            if (optimised) {
              if (thisCreateItem) item = this.createItem(key, item);
              if (thisCreateKey) key = this.createKey(key);
              HASH_key = CONST_HASH + key;
              if (!(HASH_key in items)) keys[size++] = key;
              items[HASH_key] = item;
            } else {
              this.set(key, item);
            }
          }
        } else if (Array_isArray(source)) { // An array of key,value pairs.
          length = source.length;
          for (j = 0; j < length; j++) {
            key = source[j++];
            item = source[j];
            if (optimised) {
              if (createItem) item = this.createItem(key, item);
              key = this.createKey(key);
              HASH_key = CONST_HASH + key;
              if (!(HASH_key in items)) keys[size++] = key;
              items[HASH_key] = item;
            } else {
              this.set(key, item);
            }
          }
        } else { // An object literal.
          var sourceKeys = Object_keys(source);
          var length = sourceKeys.length;
          for (var j = 0; j < length; j++) {
            key = sourceKeys[j];
            item = source[key];
            if (optimised) {
              if (createItem) item = this.createItem(key, item);
              if (createKey) key = this.createKey(key);
              HASH_key = CONST_HASH + key;
              if (!(HASH_key in items)) keys[size++] = key;
              items[HASH_key] = item;
            } else {
              this.set(key, item);
            }
          }
        }
      }
    }
    return this;
  },

  reduce: function Collection__reduce(reducer, result) {
    if (!isFunction(reducer)) {
      throw new TargetError(FUNCTION_REQUIRED_ERR, "reduce", this);
    }

    var initialised = arguments.length > 1;
    var keys = this[CONST_KEYS], key;
    var items = this[CONST_ITEMS], item;
    var size = keys.length;
    
    if (size > 0) {
      var start = 0;
      if (!initialised) {
        result = items[CONST_HASH + keys[start++]];
        initialised = true;
      }
      for (var i = start; i < size; i++) {
        result = reducer.call(undefined, result, items[CONST_HASH + (key = keys[i])], key, this);
      }
    }
    
    if (!initialised) {
      throw new Error(REDUCE_ERR);
    }
    
    return result;
  },

  reduceRight: function Collection__reduceRight(reducer, result) {
    if (!isFunction(reducer)) {
      throw new TargetError(FUNCTION_REQUIRED_ERR, "reduceRight", this);
    }

    var initialised = arguments.length > 1;
    var keys = this[CONST_KEYS], key;
    var items = this[CONST_ITEMS], item;
    var size = keys.length;
    
    if (size > 0) {
      var start = size - 1;
      if (!initialised) {
        result = items[CONST_HASH + keys[start--]];
        initialised = true;
      }
      for (var i = start; i >= 0; i--) {
        result = reducer.call(undefined, result, items[CONST_HASH + (key = keys[i])], key, this);
      }
    }
    
    if (!initialised) {
      throw new Error(REDUCE_ERR);
    }
    
    return result;
  },

  remove: function Collection__remove(key) {
    key = this.createKey(key);

    var items = this[CONST_ITEMS];
    var HASH_key = CONST_HASH + key;

    // The remove() method may be slow for older platforms, so check if the key exists first.
    if (HASH_key in items) {
      delete items[HASH_key];
      var keys = this[CONST_KEYS];
      var index = Array__indexOf.call(keys, key);
      keys.splice(index, 1);
    }
  },

  removeAt: function Collection__removeAt(index) {
    var removed = this[CONST_KEYS].splice(index, 1);
    if (removed.length === 1) {
      delete this[CONST_ITEMS][CONST_HASH + removed[0]];
    }
  },

  reverse: function Collection__reverse() {
    this[CONST_KEYS].reverse();
    return this;
  },

  set: Collection__set,

  setAt: function Collection__setAt(index, item) {
    var key = this.keyAt(index); // Allow negative indexes.

    if (key == null) {
      throw new RangeError(INDEX_OUT_OF_BOUNDS_ERR);
    }

    var args = arguments.length < 3 ? [key, item] : Array__slice.call(arguments);
    args[0] = key;
    return this.set.apply(this, args);
  },

  size: function Collection__size() {
    return this[CONST_KEYS].length;
  },

  slice: function Collection__slice(start, end) {
    var result = clone(this);

    var keys = this[CONST_KEYS];
    var items = this[CONST_ITEMS];

    var resultItems = result[CONST_ITEMS] = {};
    var resultKeys = result[CONST_KEYS] = Array__slice.apply(keys, arguments);

    var size = resultKeys.length;

    for (var i = 0, HASH_key; i < size; i++) {
      resultItems[HASH_key = CONST_HASH + resultKeys[i]] = items[HASH_key];
    }

    return result; // Returns a clone of the Collection
  },
  
  some: function Collection__some(test, context) {
    if (!isFunction(test)) {
      throw new TargetError(FUNCTION_REQUIRED_ERR, "some", this);
    }

    var keys = this[CONST_KEYS], key;
    var items = this[CONST_ITEMS];
    var size = keys.length;
    
    for (var i = 0; i < size; i++) {
      if (test.call(context, items[CONST_HASH + (key = keys[i])], key, this)) {
        return true;
      }
    }
    
    return false;
  },

  sort: function Collection__sort(compare) {
    if (compare) {
      var items = this[CONST_ITEMS];
      this[CONST_KEYS].sort(function _sorter(key1, key2) {
        return compare(items[CONST_HASH + key1], items[CONST_HASH + key2], key1, key2);
      });
    } else {
      this[CONST_KEYS].sort();
    }
    
    return this;
  },

  toString: function Collection__toString() {
    return this[CONST_KEYS].join(",");
  },

  union: function Collection__union(source /*, source1, source2, .. , sourceN */) {
    return this.merge.apply(this.clone(), arguments);
  }
}, {
  Item: null, // If specified, all members of the Collection must be instances of Item.

  extend: function Collection_extend(_instance, _static) {
    var thisCollection = this.base(_instance);
    if (_static) extend(thisCollection, _static, true);
    if (!thisCollection.Item) {
      thisCollection.Item = this.Item;
    } else if (typeof thisCollection.Item != "function") {
      thisCollection.Item = (this.Item || Base).extend(thisCollection.Item);
    }
    return thisCollection;
  }
});

// help

function clone(collection) {
  return pcopy(collection.constructor.prototype, collection);
}

function Collection__createItem(key, item) {
  var result = arguments.length < 2 ? key : item;
  // Make sure it's an instance of Item.
  var Item = this.constructor.Item;
  if (Item && !(/*@ result && result.valueOf && @*/ result instanceof Item)) {
    result = pcopy(Item.prototype);
    Item.apply(result, arguments);
  }
  return result;
}

function Collection__set(key, item) {
  item = this.createItem.apply(this, arguments);
  key = this.createKey(key);

  var HASH_key = CONST_HASH + key;
  var items = this[CONST_ITEMS];

  // Update the keys array.
  if (!(HASH_key in items)) {
    this[CONST_KEYS].push(key);
  }
  // Write the new item.
  items[HASH_key] = item;

  return item;
}

function Collection__indexOf(key) {
  key = this.createKey(key);

  return CONST_HASH + key in this[CONST_ITEMS]
    ? Array__indexOf.call(this[CONST_KEYS], key)
    : -1;
}

})();
