
// Collection classes have a special (optional) property: Item
// The Item property points to a constructor function.
// Members of the collection must be an instance of Item.

var DUPLICATE_KEY_ERR        = "Duplicate key: ";
var INDEX_OUT_OF_BOUNDS_ERR  = "Index out of bounds.";

var CONST_HASH  = "#";
var CONST_ITEMS =  0;
var CONST_KEYS  =  1;

Collection = Base.extend({
  constructor: function Collection__constructor(items) {
    this[CONST_ITEMS] = {};
    this[CONST_KEYS] = [];
    if (items) this.merge(items);
  },

  add: function Collection__add(key, item) {
    // Duplicates are not allowed using add().
    // You can still overwrite entries using set().
    if (CONST_HASH + key in this[CONST_ITEMS]) {
      throw new ReferenceError(DUPLICATE_KEY_ERR + key);
    }
    
    return this.set.apply(this, arguments);
  },

  clear: function Collection__clear() {
    this[CONST_KEYS] = [];
    this[CONST_ITEMS] = {};
    
    return this;
  },

  clone: function Collection__clone() {
    var result = pcopy(this.constructor.prototype, this);
    result[CONST_ITEMS] = qcopy(this[CONST_ITEMS]);
    result[CONST_KEYS] = this[CONST_KEYS].slice();
    
    return result;
  },
  
  every: function Collection__every(test, context) {
    if (!isFunction(test)) throw new TargetError(FUNCTION_REQUIRED_ERR, "every", this);

    var keys = this[CONST_KEYS], key;
    var items = this[CONST_ITEMS];
    var size = keys.length;
    
    for (var i = 0; i < size; i++) {
      if (!test.call(context, items[CONST_HASH + (key = keys[i])], key, this)) {
        return false;
      }
    }
    
    return true;
  },
  
  filter: function Collection__filter(test, context) {
    if (!isFunction(test)) throw new TargetError(FUNCTION_REQUIRED_ERR, "filter", this);

    var result = pcopy(this.constructor.prototype, this);
    
    var resultKeys = result[CONST_KEYS] = [];
    var resultItems = result[CONST_ITEMS] = {};
    
    var keys = this[CONST_KEYS];
    var items = this[CONST_ITEMS];
    var size = keys.length;
    
    for (var i = 0, j = 0, key, HASH_key, item; i < size; i++) {
      item = items[HASH_key = CONST_HASH + (key = keys[i])];
      if (test.call(context, item, key, this)) {
        resultKeys[j++] = key;
        resultItems[HASH_key] = item;
      }
    }
    
    return result; // Returns a clone of the current object with its members filtered by "test"
  },
  
  forEach: function Collection__forEach(eacher, context) {
    if (!isFunction(eacher)) throw new TargetError(FUNCTION_REQUIRED_ERR, "forEach", this);

    var keys = this[CONST_KEYS], key;
    var items = this[CONST_ITEMS];
    var size = keys.length;
    
    for (var i = 0; i < size; i++) {
      eacher.call(context, items[CONST_HASH + (key = keys[i])], key, this);
    }
  },

  get: function Collection__get(key) {
    var item = this[CONST_ITEMS][CONST_HASH + key];
    return item;
  },

  getAt: function Collection__getAt(index) {
    var key = this.keyAt(index);
    return key == null ? undefined : this[CONST_ITEMS][CONST_HASH + key];
  },

  has: function Collection__has(key) {
    return CONST_HASH + key in this[CONST_ITEMS];
  },

  imap: function Collection__imap(mapper, context) {
    if (!isFunction(mapper)) throw new TargetError(FUNCTION_REQUIRED_ERR, "imap", this);
    
    // the same as _.map(this.values(), ..) but faster.
    
    var result = [];
    
    var keys = this[CONST_KEYS];
    var items = this[CONST_ITEMS];
    var size = keys.length;
    
    for (var i = 0; i < size; i++) {
      result[i] = mapper.call(context, items[CONST_HASH + keys[i]], i, this);
    }
    
    return result; // returns an Array
  },

  indexOf: Collection__indexOf,

  insertAt: function Collection__insertAt(index, key, item) {
    var keys = this[CONST_KEYS];
    var items = this[CONST_ITEMS];
    var HASH_key = CONST_HASH + key;
    
    if (HASH_key in items) throw new ReferenceError(DUPLICATE_KEY_ERR + key);
    if (this.keyAt(index) == null) throw new RangeError(INDEX_OUT_OF_BOUNDS_ERR);
    
    keys.splice(index, 0, String(key));
    items[HASH_key] = undefined;
    
    return this.set.apply(this, Array__slice.call(arguments, 1));
  },

  join: function Collection__join(separator) {
    return this.values().join(separator);
  },

  keyAt: function Collection__keyAt(index) { // Allow negative indexes.
    index = +index;
    var keys = this[CONST_KEYS];
    if (index < 0) index = index + keys.length;
    var key = keys[index];
    return key;
  },

  keys: function Collection__keys() {
    return this[CONST_KEYS].concat(); // returns an Array
  },

  lastIndexOf: Collection__indexOf, // polymorphic with ArrayLike

  map: function Collection__map(mapper, context) {
    if (!isFunction(mapper)) throw new TargetError(FUNCTION_REQUIRED_ERR, "map", this);
    
    // Returns a new Collection containing the mapped items.
    var result = new Collection;
    var resultItems = result[CONST_ITEMS];
    
    var keys = this[CONST_KEYS], key, HASH_key;
    var items = this[CONST_ITEMS];
    var size = keys.length;
    
    result[CONST_KEYS] = keys.concat();
    
    for (var i = 0; i < size; i++) {
      resultItems[HASH_key = CONST_HASH + (key = keys[i])] = mapper.call(context, items[HASH_key], key, this);
    }
    
    return result; // returns a Collection
  },

  merge: function Collection__merge(source /*, source1, source2, .. , sourceN */) {
    // For speed, try to avoid calling the set() method.
    var optimised = !this.constructor.Item && this.set == Collection.prototype.set;

    var keys = this[CONST_KEYS], key, HASH_key;
    var items = this[CONST_ITEMS], item;
    var size = keys.length;
    
    for (var i = 0; i < arguments.length; i++) {
      source = arguments[i];
      if (source && source != this) {
        if (source.imap && source instanceof Collection) {
          var sourceItems = source[CONST_ITEMS];
          var sourceKeys = source[CONST_KEYS];
          var length = sourceKeys.length;
          for (var j = 0; j < length; j++) {
            key = sourceKeys[j];
            HASH_key = CONST_HASH + key;
            item = sourceItems[HASH_key];
            if (optimised) {
              if (!(HASH_key in items)) keys[size++] = key;
              items[HASH_key] = item;
            } else {
              this.set(key, item);
            }
          }
        } else if (isArray(source)) { // An array of key,value pairs.
          length = source.length;
          for (j = 0; j < length; j++) {
            key = source[j++];
            item = source[j];
            if (optimised) {
              HASH_key = CONST_HASH + key;
              if (!(HASH_key in items)) keys[size++] = String(key);
              items[HASH_key] = item;
            } else {
              this.set(key, item);
            }
          }
        } else { // An object literal.
          for (key in source) if (!(key in Object_protected)) {
            item = source[key];
            if (optimised) {
              HASH_key = CONST_HASH + key;
              if (!(HASH_key in items)) keys[size++] = key;
              items[HASH_key] = item;
            } else {
              this.set(key, item);
            }
          }
        }
      }
    }
    return this;
  },

  reduce: function Collection__reduce(reducer, result) {
    if (!isFunction(reducer)) throw new TargetError(FUNCTION_REQUIRED_ERR, "reduce", this);

    var initialised = arguments.length > 1;
    var keys = this[CONST_KEYS], key;
    var items = this[CONST_ITEMS], item;
    var size = keys.length;
    
    if (size > 0) {
      var start = 0;
      if (!initialised) {
        result = items[CONST_HASH + keys[start++]];
        initialised = true;
      }
      for (var i = start; i < size; i++) {
        result = reducer.call(undefined, result, items[CONST_HASH + (key = keys[i])], key, this);
      }
    }
    
    if (!initialised) throw new Error(REDUCE_ERR);
    
    return result;
  },

  reduceRight: function Collection__reduceRight(reducer, result) {
    if (!isFunction(reducer)) throw new TargetError(FUNCTION_REQUIRED_ERR, "reduceRight", this);

    var initialised = arguments.length > 1;
    var keys = this[CONST_KEYS], key;
    var items = this[CONST_ITEMS], item;
    var size = keys.length;
    
    if (size > 0) {
      var start = size - 1;
      if (!initialised) {
        result = items[CONST_HASH + keys[start--]];
        initialised = true;
      }
      for (var i = start; i >= 0; i--) {
        result = reducer.call(undefined, result, items[CONST_HASH + (key = keys[i])], key, this);
      }
    }
    
    if (!initialised) throw new Error(REDUCE_ERR);
    
    return result;
  },

  remove: function Collection__remove(key) {
    var items = this[CONST_ITEMS];
    var HASH_key = CONST_HASH + key;

    // The remove() method may be slow for older platforms, so check if the key exists first.
    if (HASH_key in items) {
      delete items[HASH_key];
      var keys = this[CONST_KEYS];
      var index = Array__indexOf.call(keys, String(key));
      keys.splice(index, 1);
    }
  },

  removeAt: function Collection__removeAt(index) {
    var removed = this[CONST_KEYS].splice(index, 1);
    if (removed.length === 1) {
      delete this[CONST_ITEMS][CONST_HASH + removed[0]];
    }
  },

  reverse: function Collection__reverse() {
    this[CONST_KEYS].reverse();
    return this;
  },

  set: function Collection__set(key, item) {
    var argsLength = arguments.length;
    if (argsLength < 2) item = key;
    key = String(key);

    var items = this[CONST_ITEMS];

    // Make sure it's an instance of Item.
    var Item = this.constructor.Item;
    if (Item && !(item && item.valueOf && item instanceof Item)) {
      var args = argsLength < 3 ? [key, item] : Array__slice.call(arguments);
      item = pcopy(Item.prototype);
      Item.apply(item, args);
    }

    // Update the keys array.
    var HASH_key = CONST_HASH + key;
    if (!(HASH_key in items)) {
      this[CONST_KEYS].push(key);
    }

    // Write the new item.
    items[HASH_key] = item;

    return item;
  },

  setAt: function Collection__setAt(index, item) {
    var key = this.keyAt(index); // Allow negative indexes.
    if (key == null) throw new RangeError(INDEX_OUT_OF_BOUNDS_ERR);
    var args = arguments.length < 3 ? [key, item] : Array__slice.call(arguments);
    args[0] = key;
    return this.set.apply(this, args);
  },

  size: function Collection__size() {
    return this[CONST_KEYS].length;
  },

  slice: function Collection__slice(start, end) {
    var result = this.clone();
    
    if (arguments.length > 0) {
      var removed = result[CONST_KEYS];
      var size = removed.length;
      start = _clamp(start, size);
      end = isNaN(end) ? size : _clamp(end, size);
      var keys = removed.splice(start, end - start);
      var i = removed.length;
      var resultItems = result[CONST_ITEMS];
      while (i--) delete resultItems[CONST_HASH + removed[i]];
      result[CONST_KEYS] = keys;
    }
    
    return result;
  },
  
  some: function Collection__some(test, context) {
    if (!isFunction(test)) throw new TargetError(FUNCTION_REQUIRED_ERR, "some", this);

    var keys = this[CONST_KEYS], key;
    var items = this[CONST_ITEMS];
    var size = keys.length;
    
    for (var i = 0; i < size; i++) {
      if (test.call(context, items[CONST_HASH + (key = keys[i])], key, this)) {
        return true;
      }
    }
    
    return false;
  },

  sort: function Collection__sort(compare) {
    if (compare) {
      var items = this[CONST_ITEMS];
      this[CONST_KEYS].sort(function _sorter(key1, key2) {
        return compare(items[CONST_HASH + key1], items[CONST_HASH + key2], key1, key2);
      });
    } else {
      this[CONST_KEYS].sort();
    }
    
    return this;
  },

  toString: function Collection__toString() {
    return this[CONST_KEYS].join(",");
  },

  union: function Collection__union(source /*, source1, source2, .. , sourceN */) {
    return this.merge.apply(this.clone(), arguments);
  },

  values: function Collection__values() {
    var result = [];

    var keys = this[CONST_KEYS];
    var items = this[CONST_ITEMS];
    var i = keys.length;

    while (i--) {
      result[i] = items[CONST_HASH + keys[i]];
    }
    
    return result; // returns an Array
  }
}, {
  Item: null, // If specified, all members of the collection must be instances of Item.

  extend: function Collection_extend(_instance, _static) {
    var klass = this.base(_instance);
    if (_static) extend(klass, _static);
    if (!klass.Item) {
      klass.Item = this.Item;
    } else if (typeof klass.Item != "function") {
      klass.Item = (this.Item || Base).extend(klass.Item);
    }
    
    return klass;
  }
});

Collection.implement(ArrayLike);

// help

function Collection__indexOf(key) {
  return CONST_HASH + key in this[CONST_ITEMS]
    ? Array__indexOf.call(this[CONST_KEYS], String(key))
    : -1;
}
