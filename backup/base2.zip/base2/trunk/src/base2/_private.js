
var _private = {};

function deferUntil(fn, test, interval, timeout, ontimeout) {
  var startTime = now();
  var tick = function tick() {
    if (test()) {
      fn();
    } else if (!timeout || (now() - startTime < timeout)) {
      setTimeout(tick, interval || 25);
    } else if (ontimeout) {
      ontimeout();
    }
  };
  tick();
}

function get(object, propertyName) {
  if (vendorPrefixes && !(propertyName in object)) {
    propertyName = getVendorPropertyName(object, propertyName);
  }
  return object[propertyName];
}

if (detect("MSIE[678]")) {
  var vendorPrefixes;
  var getVendorPropertyName = II;
} else {
  vendorPrefixes = "khtml,Khtml,khtml,o,O,o,MS,ms,Ms,moz,Moz,moz,WebKit,webkit,Webkit".split(",");

  getVendorPropertyName = function getVendorPropertyName(object, propertyName) {
    var i = vendorPrefixes.length;
    var PropertyName = propertyName.charAt(0).toUpperCase() + propertyName.slice(1);
    while (i--) {
      var vendorPropertyName = vendorPrefixes[i] + PropertyName;
      if (vendorPropertyName in object) {
        if (vendorPrefixes.length > 3) {
          vendorPrefixes = vendorPrefixes.slice(i = i - i % 3, i + 3);
          if (vendorPrefixes[0] === vendorPrefixes[2]) vendorPrefixes.length = 2;
        }
        return vendorPropertyName;
      }
    }
    return propertyName;
  };
}

function Dummy(){}

function pcopy(object, properties) {
  Dummy.prototype = object;
  var result = new Dummy;
  for (var i in properties) result[i] = properties[i];
  return result;
}

function qcopy(object) {
  var result = {};
  for (var i in object) result[i] = object[i];
  return result;
}

_private = {
  ArityError: ArityError,
  TargetError: TargetError,

  deferUntil: deferUntil,
  get: get,
  getVendorPropertyName: getVendorPropertyName,
  pcopy: pcopy,
  qcopy: qcopy,

  toString: K("_")
};
