
var CANNOT_INDEX_STRINGS = !(0 in Object("a"));

Array_extras = {
  every: function ArrayLike__every(test, context) {
    if (!isFunction(test)) {
      throw new TargetError(FUNCTION_REQUIRED_ERR, "every", this);
    }

    var array = Object(this), values = array;
    if (CANNOT_INDEX_STRINGS && values.charAt) {
      values = split(values)
    }
    var length = array.length >>> 0;

    for (var i = 0; i < length; i++) if (i in values) {
      if (!test.call(context, values[i], i, array)) return false;
    }

    return true;
  },

  filter: function ArrayLike__filter(test, context) {
    if (!isFunction(test)) {
      throw new TargetError(FUNCTION_REQUIRED_ERR, "filter", this);
    }

    var array = Object(this), values = array;
    if (CANNOT_INDEX_STRINGS && values.charAt) {
      values = split(values)
    }
    var length = array.length >>> 0;
    var result = [];

    for (var i = 0, j = 0, value; i < length; i++) if (i in values) {
      value = values[i];
      if (test.call(context, value, i, array)) {
        result[j++] = value;
      }
    }

    return result;
  },

  forEach: function ArrayLike__forEach(eacher, context) {
    if (!isFunction(eacher)) {
      throw new TargetError(FUNCTION_REQUIRED_ERR, "forEach", this);
    }

    var array = Object(this), values = array;
    if (CANNOT_INDEX_STRINGS && values.charAt) {
      values = split(values)
    }
    var length = array.length >>> 0;

    for (var i = 0; i < length; i++) if (i in values) {
      eacher.call(context, values[i], i, array);
    }
  },

  indexOf: function ArrayLike__indexOf(item, fromIndex) {
    var length = this.length >>> 0;

    if (fromIndex == null) {
      fromIndex = 0;
    } else {
      fromIndex = ~~+fromIndex;
      if (fromIndex < 0) {
        fromIndex += length;
        if (fromIndex < 0) fromIndex = 0;
      }
    }
    for (var i = fromIndex; i < length; i++) {
      if (item === this[i]) return i;
    }

    return -1;
  },

  lastIndexOf: function ArrayLike__lastIndexOf(item, fromIndex) {
    var length = this.length >>> 0;

    if (fromIndex == null) {
      fromIndex = length - 1;
    } else {
      fromIndex = ~~+fromIndex;
      if (fromIndex < 0) {
        fromIndex += length;
        if (fromIndex < 0) fromIndex = 0;
      }
    }
    for (var i = fromIndex; i >= 0; i--) {
      if (item === this[i]) return i;
    }

    return -1;
  },

  map: function ArrayLike__map(mapper, context) {
    if (!isFunction(mapper)) {
      throw new TargetError(FUNCTION_REQUIRED_ERR, "map", this);
    }
    var array = Object(this), values = array;
    if (CANNOT_INDEX_STRINGS && values.charAt) {
      values = split(values)
    }
    var length = array.length >>> 0;
    var result = new Array(length);

    for (var i = 0; i < length; i++) if (i in values) {
      result[i] = mapper.call(context, values[i], i, array);
    }

    return result;
  },

  reduce: function ArrayLike__reduce(reducer, initialValue) {
    if (!isFunction(reducer)) {
      throw new TargetError(FUNCTION_REQUIRED_ERR, "reduce", this);
    }

    var array = Object(this), values = array;
    if (CANNOT_INDEX_STRINGS && values.charAt) {
      values = split(values)
    }
    var length = array.length >>> 0;
    var result = initialValue;
    var initialised = arguments.length > 1;

    for (var i = 0; i < length; i++) if (i in values) {
      var value = values[i];
      result = initialised ? reducer.call(undefined, result, value, i, array) : value;
      initialised = true;
    }

    if (!initialised) {
      throw new Error(REDUCE_ERR);
    }

    return result;
  },

  reduceRight: function ArrayLike__reduceRight(reducer, initialValue) {
    if (!isFunction(reducer)) {
      throw new TargetError(FUNCTION_REQUIRED_ERR, "reduceRight", this);
    }

    var array = Object(this), values = array;
    if (CANNOT_INDEX_STRINGS && values.charAt) {
      values = split(values)
    }
    var length = array.length >>> 0;
    var result = initialValue;
    var initialised = arguments.length > 1;

    for (var i = length - 1; i >= 0; i--) if (i in values) {
      var value = values[i];
      result = initialised ? reducer.call(undefined, result, value, i, array) : value;
      initialised = true;
    }

    if (!initialised) {
      throw new Error(REDUCE_ERR);
    }

    return result;
  },

  some: function ArrayLike__some(test, context) {
    if (!isFunction(test)) {
      throw new TargetError(FUNCTION_REQUIRED_ERR, "some", this);
    }

    var array = Object(this), values = array;
    if (CANNOT_INDEX_STRINGS && values.charAt) {
      values = split(values)
    }
    var length = array.length >>> 0;

    for (var i = 0; i < length; i++) if (i in values) {
      if (test.call(context, values[i], i, array)) return true;
    }

    return false;
  }
};

// help

function split(object) {
  return Object__toString.call(object) === "[object String]" ? object.split("") : object;
}
