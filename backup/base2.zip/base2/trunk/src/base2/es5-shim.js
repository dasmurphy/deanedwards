
var global = (function(){return this || (1,eval)('this')})(); // kangax

function preferNativeMethod(object, methodName, fallback) {
  if (typeof object[methodName] != "function") return fallback;
  // This relies on a non-native method to not be enumerable.
  // If the method is implemented with Object.defineProperty() then
  // it may not be enumerable, hopefully it will be a good implmentation. :)
  for (var name in object) if (name === methodName) return fallback;
  return object[methodName];
}

var String_prototype = String.prototype;

isArray = preferNativeMethod(Array, "isArray", function isArray(object) {
  return object != null && Object__toString.call(object) === "[object Array]";
});

// http://perfectionkills.com/whitespace-deviations/
// http://blog.stevenlevithan.com/archives/faster-trim-javascript
var S = "[\\s\xa0\u180e\u2000-\u200a\u2028\u2029\u202f\u205f\u3000\\ufeff]";
var LTRIM = new RegExp("^SS*".replace(/S/g, S));
var RTRIM = new RegExp("SS*$".replace(/S/g, S));

String__trim = preferNativeMethod(String_prototype, "trim", function trim() {
  if (this == null) throw new TargetError(OBJECT_REQUIRED_ERR, "String::trim");
  return String(this).replace(LTRIM, "").replace(RTRIM, "");
});

commands["es5-shim"] = function() {
  // This doesn't overwrite anything even if it looks like it does.
  Array.isArray = isArray;
  for (var name in Array_extras) {
    Array_prototype[name] = Array_extras[name];
  }
  Array_prototype.slice = ArrayLike_instance.slice;
  if (!SUPPORTS_ISO_DATE) global.Date = base2_Date;
  Date.now = now;
  Date_prototype.toISOString = Date__toISOString;
  Date_prototype.toJSON = Date__toJSON;
  Function_prototype.bind = Function__bind;
  String_prototype.trim = String__trim;
};
