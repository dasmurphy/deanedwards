
function assert(condition, message, ErrorClass) {
  if (!condition) {
    throw new (ErrorClass || Error)(message || "Assertion failed.");
  }
}

function assertArity(args, arity) {
  if (args.length < arity) throw new ArityError;
}

function assertType(object, type, message) {
  if (object == null || (typeof type == "function" ? !object.valueOf || !(object instanceof type) : typeof object != type)) {
    throw new TypeError(message || "Invalid type.");
  }
}

function extend(object, source) { // or extend(object, key, value)
  if (object == null) throw new TargetError(OBJECT_REQUIRED_ERR, "extend", this);

  object = Object(object);

  if (arguments.length > 2) { // Extending with a key/value pair (always overrides).
    var key = source;
    var value = arguments[2];
    if (typeof value == "function" && value != object[key] && BASE_CALL.test(value)) {
      value = _override(object[key], value);
    }
    object[key] = value;
  } else if (source != null) {
    var casting = !_prototyping_ && source instanceof Trait;
    var Type_protected = typeof source == "function" && source.call ? Function_protected : Object_protected;
    
    if (_prototyping_ && source.constructor != Object) {
      extend(object, "constructor", source.constructor);
    }
    if (!casting && source.toString != Type_protected.toString) {
      extend(object, "toString", source.toString);
    }
    // Copy each of the source object's properties to the target object.
    var tests = [];
    for (key in source) if (!(key in Type_protected)) {
      value = source[key];
      if (key in object) {
        if (!casting) {
          if (typeof value == "function" && BASE_CALL.test(value)) { // Check for method overriding.
            value = _override(object[key], value);
          }
          object[key] = value;
        }
      } else if (!casting && key > "@" && key < "A") { // Feature detection.
        tests.push(key.slice(1), value);
      } else {
        object[key] = value;
      }
    }
    // Do feature tests last.
    for (var i = 0; i < tests.length; i++) {
      if (detect(tests[i++])) extend(object, tests[i]);
    }
  }

  // Hedger Wow
  /*@if (@_jscript_version < 5.7)
    try {
      return object;
    } finally {
      object = null;
    }
  /*@end @*/
  
  return object;
}

function _override(oldMethod, newMethod) {
  // Return a new method that overrides an existing method.
  var base = function base() {
    if (this == null) {
      var returnValue = newMethod.apply(this, arguments);
    } else {
      var restore = this.base;
      this.base = oldMethod || Undefined;
      returnValue = arguments.length === 0 ? newMethod.call(this) : newMethod.apply(this, arguments);
      this.base = restore;
    }
    return returnValue;
  };
  // introspection (removed when packed)
  ;;; if (oldMethod) base._underlyingFunction = oldMethod._underlyingFunction || oldMethod;
  ;;; base.toString = K(String(newMethod));
  return base;
}

function forEach(enumerable, eacher, context, mask) {
  if (!isFunction(eacher)) throw new TargetError(FUNCTION_REQUIRED_ERR, "forEach", this);
  
  if (enumerable == null) return; // don't throw

  if (mask == null) {
    switch (typeof enumerable) {
      case "function": if (enumerable.call) {
        mask = Function_protected;
        break;
      }
      // It's probably a crappy Safari NodeList

      case "object":
        if (typeof enumerable.length == "number") {
          if (!(enumerable.charAt && Object__toString.call(enumerable) === "[object String]")) {
            Array__forEach.call(enumerable, eacher, context);
          }
          return;
        }

        // Use the object's own forEach method (if it has one) // move up? -@DRE
        var method = enumerable.forEach;
        if (typeof method == "function" && method != forEach) {
          method.call(enumerable, eacher, context);
          return;
        }

        mask = Object_protected;
        break;

      default:
        return;
    }
  }

  for (var key in enumerable) if (!(key in mask)) { // ignore keys that are in mask
    eacher.call(context, enumerable[key], key, enumerable);
  }
}

forEach.csv = function forEach_csv(string, eacher, context) {
  forEach (csv(string), eacher, context);
};

function csv(string) { // private
  return String(string).split(/\s*,\s*/);
}

function format(string, replacement) {
  // e.g. format("{0} {1}{2} {1}a {0}{2}", "she", "se", "lls");
  //  or  format("{0} {1}{2} {1}a {0}{2}", ["she", "se", "lls"]);
  //  or  format("My name is {name} and I am {age} years old.", {name: "John", age: 34});
  
  switch (arguments.length) {
    case 0:
    case 1:
      throw new ArityError("format", this);

    case 2:
      if (replacement == null) throw new TargetError(OBJECT_REQUIRED_ERR, "format", this);

      if (typeof replacement != "object") {
        replacement = [replacement];
      }
      break;

    default:
      replacement = Array__slice.call(arguments, 1);
  }
  
  return String(string).replace(/\{([^{}]+)\}/g, function(match, key) {
    return key in replacement ? replacement[key] : match;
  });
}

var isArray = Array.isArray;

function isFunction(object) {
  return object != null && Object__toString.call(object) === "[object Function]";
}

var now = Date.now;

var String__trim = "".trim;

var trim = function trim(string) {
  if (string == null) throw new TargetError(OBJECT_REQUIRED_ERR, "trim", this);
  return String__trim.call(string);
};
