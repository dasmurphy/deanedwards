
function extend(object /*, source1, ..., sourceN */) { // or extend(object, key, value)
  if (object == null) {
    throw new TargetError(OBJECT_REQUIRED_ERR, "extend", this);
  }

  object = Object(object);

  var argsLength = arguments.length;

  if (argsLength === 3 && typeof source == "string") { // Extending with a key/value pair (always overrides).
    var key = arguments[1];
    var value = arguments[2];
    if (typeof value == "function" && value != object[key] && BASE_CALL.test(value)) {
      value = _override(object[key], value);
    }
    object[key] = value;
  } else {
    var special = arguments[argsLength - 1] === true;
    if (special) argsLength--;
    for (var i = 1; i < argsLength; i++) {
      var source = arguments[i];
      if (source != null) {
        var keys = Object_keys(source);
        var length = keys.length;
        if (special) {
          var tests = [];
          var casting = /*@ source.valueOf && @*/ source instanceof Trait;
          // Copy each of the source object's properties to the target object.
          for (var j = 0; j < length; j++) {
            key = keys[j];
            value = source[key];
            if (key < "A" && key > "@") { // Feature detection.
              tests.push(key.slice(1), value);
            } else {
              if (!(casting && key in object)) {
                if (typeof value == "function" && value.call && BASE_CALL.test(Function__toString.call(value))) { // Check for method overriding.
                  value = _override(object[key], value);
                }
                object[key] = value;
              }
            }
          }
        } else {
          for (j = 0; j < length; j++) {
            key = keys[j];
            object[key] = source[key];
          }
        }

        // Do feature tests last.
        if (special) for (var j = 0; j < tests.length; j++) {
          if (detect(tests[j++])) extend(object, tests[j], true);
        }
      }
    }
  }

  // Hedger Wow
  /*@if (@_jscript_version < 5.7)
    try {
      return object;
    } finally {
      object = null;
    }
  /*@end @*/
  
  return object;
}

function _override(oldMethod, newMethod) {
  // Return a new method that overrides an existing method.
  var base = function base() {
    if (this == null) {
      var returnValue = newMethod.apply(this, arguments);
    } else {
      var remove = /*@ this.valueOf && @*/ !("base" in this);
      var restore = this.base;
      this.base = oldMethod || Undefined;
      returnValue = arguments.length === 0 ? newMethod.call(this) : newMethod.apply(this, arguments);
      if (remove) {
        delete this.base;
      } else {
        this.base = restore;
      }
    }
    return returnValue;
  };
  base.toString = K(String(newMethod));
  return base;
}

function forEach(enumerable, eacher, context, mask) {
  if (arguments.length < 2) {
    throw new ArityError("forEach", this);
  }

  if (!isFunction(eacher)) {
    throw new TargetError(FUNCTION_REQUIRED_ERR, "forEach", this);
  }
  
  if (enumerable == null) return; // don't throw

  switch (typeof enumerable) {
    case "function": if (enumerable.call) {
      break;
    }
    // It's probably a crappy Safari NodeList

    case "string":
    case "object":
      if (mask === undefined) {
        if (typeof enumerable.length == "number") {
          Array__forEach.call(enumerable, eacher, context);
          return;
        }

        // Use the object's own forEach method (if it has one)
        var method = enumerable.forEach;
        if (typeof method == "function" && method != forEach) {
          method.call(enumerable, eacher, context);
          return;
        }
      }
      break;

    default:
      return;
  }

  var keys = Object_keys(enumerable);
  var length = keys.length;

  if (mask == null) {
    for (var i = 0; i < length; i++) {
      var key = keys[i];
      eacher.call(context, enumerable[key], key, enumerable);
    }
  } else {
    for (i = 0; key = keys[i]; i++) {
      key = keys[i];
      if (!(key in mask)) { // ignore keys that are in mask
        eacher.call(context, enumerable[key], key, enumerable);
      }
    }
  }
}

forEach.csv = function forEach_csv(string, eacher, context) {
  forEach (csv(string), eacher, context);
};

function csv(string) { // private
  return String(string).split(/\s*,\s*/);
}

function format(string, replacement) {
  // e.g. format("{0} {1}{2} {1}a {0}{2}", "she", "se", "lls");
  //  or  format("{0} {1}{2} {1}a {0}{2}", ["she", "se", "lls"]);
  //  or  format("My name is {name} and I am {age} years old.", {name: "John", age: 34});
  
  switch (arguments.length) {
    case 0:
    case 1:
      throw new ArityError("format", this);

    case 2:
      if (replacement == null || typeof replacement != "object") {
        replacement = [replacement];
      }
      break;

    default:
      replacement = Array__slice.call(arguments, 1);
  }
  
  return String(string).replace(/\{([^{}]+)\}/g, function(match, key) {
    return key in replacement ? replacement[key] : match;
  });
}

function isFunction(object) {
  return object != null && Object__toString.call(object) === "[object Function]";
}

var String__trim = "".trim;

var trim = function trim(string) {
  return String__trim.call(String(string));
};
