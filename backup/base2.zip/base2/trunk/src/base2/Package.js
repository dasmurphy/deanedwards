
var Package = Base.extend({
  constructor: function Package__constructor(properties) {
    if (properties) {
      extend(this, properties, true);
      var packageName = properties.name || "";
      if (packageName) packageName += ".";
      for (var name in this) {
        var property = properties[name];
        if (typeof property == "function" && Base.ancestorOf(property)) { // it's a class/behavior
          ;doc; var source = property.toString();
          (property.toString = K("[" + packageName + name + "]"))._pretty = true;
          ;doc; property.toString._source = source;
        }
      }
    }
  },

  name: "",
  version: "",
  
  toString: function toString() {
    return this.name ? "[" + this.name + "]" : "[object base2.Package]";
  }
});
