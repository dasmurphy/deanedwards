
var Package = Base.extend({
  constructor: function Package__constructor(properties) {
    if (properties) {
      var packageName = properties.name;
      if (packageName) packageName += ".";
      for (var name in properties) {
        var object = properties[name];
        if (object && object.ancestorOf && !object.toString._pretty) { // it's a class
          // Provide objects and classes with pretty toString methods
          (object.toString = K("[" + packageName + name + "]"))._pretty = true;
        }
        this[name] = object;
      }
    }
  },

  name: "",
  version: "",
  
  toString: function toString() {
    return this.name ? "[" + this.name + "]" : "[object base2.Package]";
  }
});
