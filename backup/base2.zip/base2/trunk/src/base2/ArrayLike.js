
var REDUCE_ERR = "Nothing to reduce.";

var Array_extras = {
  every: function ArrayLike__every(test, context) {
    if (!isFunction(test)) throw new TargetError(FUNCTION_REQUIRED_ERR, "every", this);

    var array = Object(this);
    var length = array.length >>> 0;

    for (var i = 0; i < length; i++) if (i in array) {
      if (!test.call(context, array[i], i, array)) return false;
    }

    return true;
  },

  filter: function ArrayLike__filter(test, context) {
    if (!isFunction(test)) throw new TargetError(FUNCTION_REQUIRED_ERR, "filter", this);

    var array = Object(this);
    var length = array.length >>> 0;
    var result = [];

    for (var i = 0, j = 0, value; i < length; i++) if (i in array) {
      value = array[i];
      if (test.call(context, value, i, array)) {
        result[j++] = value;
      }
    }

    return result;
  },

  forEach: function ArrayLike__forEach(eacher, context) {
    if (!isFunction(eacher)) throw new TargetError(FUNCTION_REQUIRED_ERR, "forEach", this);

    var array = Object(this);
    var length = array.length >>> 0;

    for (var i = 0; i < length; i++) if (i in array) {
      eacher.call(context, array[i], i, array);
    }
  },

  indexOf: function ArrayLike__indexOf(item, fromIndex) {
    var length = this.length >>> 0;

    if (fromIndex == null) {
      fromIndex = 0;
    } else {
      fromIndex = ~~+fromIndex;
      if (fromIndex < 0) {
        fromIndex += length;
        if (fromIndex < 0) fromIndex = 0;
      }
    }
    for (var i = fromIndex; i < length; i++) {
      if (item === this[i]) return i;
    }

    return -1;
  },

  lastIndexOf: function ArrayLike__lastIndexOf(item, fromIndex) {
    var length = this.length >>> 0;

    if (fromIndex == null) {
      fromIndex = length - 1;
    } else {
      fromIndex = ~~+fromIndex;
      if (fromIndex < 0) {
        fromIndex += length;
        if (fromIndex < 0) fromIndex = 0;
      }
    }
    for (var i = fromIndex; i >= 0; i--) {
      if (item === this[i]) return i;
    }

    return -1;
  },

  map: function ArrayLike__map(mapper, context) {
    if (!isFunction(mapper)) throw new TargetError(FUNCTION_REQUIRED_ERR, "map", this);

    var array = Object(this);
    var length = array.length >>> 0;
    var result = new Array(length);

    for (var i = 0; i < length; i++) if (i in array) {
      result[i] = mapper.call(context, array[i], i, array);
    }

    return result;
  },

  reduce: function ArrayLike__reduce(reducer, initialValue) {
    if (!isFunction(reducer)) throw new TargetError(FUNCTION_REQUIRED_ERR, "reduce", this);

    var array = Object(this);
    var length = array.length >>> 0;
    var result = initialValue;
    var initialised = arguments.length > 1;

    for (var i = 0; i < length; i++) if (i in array) {
      var value = array[i];
      result = initialised ? reducer.call(undefined, result, value, i, array) : value;
      initialised = true;
    }

    if (!initialised) throw new Error(REDUCE_ERR);

    return result;
  },

  reduceRight: function ArrayLike__reduceRight(reducer, initialValue) {
    if (!isFunction(reducer)) throw new TargetError(FUNCTION_REQUIRED_ERR, "reduceRight", this);

    var array = Object(this);
    var length = array.length >>> 0;
    var result = initialValue;
    var initialised = arguments.length > 1;

    for (var i = length - 1; i >= 0; i--) if (i in array) {
      var value = array[i];
      result = initialised ? reducer.call(undefined, result, value, i, array) : value;
      initialised = true;
    }

    if (!initialised) throw new Error(REDUCE_ERR);

    return result;
  },

  slice: function ArrayLike__slice(start, end) { // You should only see this code in MSIE6-8.
    var result = this;
    if (!result.valueOf) { // not a COM object
      result = [];
      var length = this.length >>> 0;
      for (var i = 0; i < length; i++) {
        result[i] = this[i];
      }
    }
    return Array__slice.apply(result, arguments);
  },

  some: function ArrayLike__some(test, context) {
    if (!isFunction(test)) throw new TargetError(FUNCTION_REQUIRED_ERR, "some", this);

    var array = Object(this);
    var length = array.length >>> 0;

    for (var i = 0; i < length; i++) if (i in array) {
      if (test.call(context, array[i], i, array)) return true;
    }

    return false;
  }
};

// derived

var ArrayLike_instance = {
  invoke: function ArrayLike__invoke(method /*, arg1, arg2, .. , argN */) {
    // Apply a method to each item in the enumerated object.
    var args = arguments.length > 1 ? Array__slice.call(arguments, 1) : null;

    switch (typeof method) {
      case "function":
        var invoker = args ? function _invoker(item) {
          return item == null ? undefined : method.apply(item, args);
        } : function _invoker(item) {
          return item == null ? undefined : method.call(item);
        };
        break;

      case "string":
        invoker = args ? function _invoker(item) {
          return item == null ? undefined : item[method].apply(item, args);
        } : function _invoker(item) {
          return item == null ? undefined : item[method]();
        };
        break;

      default:
        throw new TargetError(FUNCTION_REQUIRED_ERR, "invoke", this);
    }

    return _.map(this, invoker);
  },
  
  plant: function ArrayLike__plant(propertyName, value) {
    forEach (this, function _planter(item) {
      if (item != null) item[propertyName] = value;
    });
  },
  
  pluck: function ArrayLike__pluck(propertyName) {
    return _.map(this, function _plucker(item) {
      return item == null ? undefined : item[propertyName];
    });
  }
};

for (var name in Array_extras) ArrayLike_instance[name] = Array_extras[name];
delete Array_extras.slice;

var Array_extensions = {};
for (name in []) Array_extensions[name] = 1;
for (name in Array_extras) {
  if (Array_prototype[name] && !Array_extensions[name]) {
    ArrayLike_instance[name] = Array_prototype[name];
    delete Array_extras[name];
  }
}

Array__forEach = Array_extras.forEach || Array__forEach;
Array__indexOf = Array_extras.indexOf || Array__indexOf;

try {
  if (!isBrowser || Array__slice.call(document.childNodes) instanceof Array) {
    ArrayLike_instance.slice = Array__slice;
  }
} catch (ex) {}

var ArrayLike = Trait.extend();

extend(ArrayLike.prototype, ArrayLike_instance);
_Trait_createStaticMethods(ArrayLike, Array_prototype);

Collection.implement(ArrayLike);

ArrayLike.test = function ArrayLike_test(object) {
  if (object == null) return false;

  switch (typeof object) {
    case "function": if (object.call) return false;
      // fall through to catch Safari NodeLists

    case "object":
      if (typeof object.length == "number") {
         // strings not supported
        return !(object.charAt && Object__toString.call(object) === "[object String]");
      }
      // avoid using instanceof on COM objects
      return /*@ object.imap && @*/ object instanceof Collection;
  }

  return false;
};
