
var ArrayLike_instance = {
  invoke: function invoke(method /*, arg1, arg2, .. , argN */) {
    // Apply a method to each item in the enumerated object.
    var args = arguments.length > 1 ? Array__slice.call(arguments, 1) : null;

    switch (typeof method) {
      case "function":
        var invoker = args ? function _invoker(item) {
          return item == null ? undefined : method.apply(item, args);
        } : function _invoker(item) {
          return item == null ? undefined : method.call(item);
        };
        break;

      case "string":
        invoker = args ? function _invoker(item) {
          return item == null ? undefined : item[method].apply(item, args);
        } : function _invoker(item) {
          return item == null ? undefined : item[method]();
        };
        break;

      default:
        throw new TargetError(FUNCTION_REQUIRED_ERR, "invoke", this);
    }

    return _.map(this, invoker);
  },
  
  plant: function plant(propertyName, value) {
    forEach (this, function _planter(item) {
      if (item != null) item[propertyName] = value;
    });
  },
  
  pluck: function pluck(propertyName) {
    return _.map(this, function _plucker(item) {
      return item == null ? undefined : item[propertyName];
    });
  }
};

forEach ("indexOf,lastIndexOf,slice".split(","), function(name) {
  ArrayLike_instance[name] = Array_prototype[name];
});

var Array_enumerable = {};

forEach.csv("every,filter,forEach,map,reduce,reduceRight,some", function(name) {
  ArrayLike_instance[name] = Array_enumerable[name] = Array_prototype[name];
});

var ArrayLike = Trait.extend(ArrayLike_instance, {
  test: function ArrayLike_test(object) {
    if (object == null) return false;

    switch (typeof object) {
      case "function": if (object.call) return false;
        // fall through to catch Safari NodeLists

      case "object":
        if (typeof object.length == "number") {
           // strings not supported
          return !(object.charAt && Object__toString.call(object) === "[object String]");
        }
        // avoid using instanceof on COM objects
        return object.imap && (object instanceof Collection || object == Collection.prototype);
    }

    return false;
  }
});
