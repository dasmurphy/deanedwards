
// A collection of regular expressions and their associated replacement values.
// A Base class for creating parsers.

RegGrp = Collection.extend({
  constructor: function RegGrp__constructor(dictionary, items) {
    if (arguments.length === 1) {
      items = dictionary;
      dictionary = null;
    }
    if (dictionary) {
      this.dictionary = new RegGrp_Dict(dictionary);
    }
    this.base(items);
  },
  
  dictionary: null,
  ignoreCase: false,

  clear: _RegGrp__recompile,

  createItem: function RegGrp__createItem(key, item) {
    return this.base(key, item, this.dictionary);
  },

  createKey: RegGrp__createKey,

  exec: function RegGrp__exec(string, fn /* optional */) { // This method needs a lot more work -@DRE
    var group = this;
    var patterns = group[CONST_PATTERNS];
    var items = group[CONST_REPLACEMENTS], item;
    group[CONST_COMPILED] = new RegExp(group[CONST_COMPILED] ? group[CONST_COMPILED].source : group, group.ignoreCase ? "gi" : "g");
    var result = group[CONST_COMPILED].exec(string);
    if (result) {
      // Loop through the RegGrp items.
      var i = 0, offset = 1;
      while ((item = items[CONST_HASH + patterns[i++]])) {
        var next = offset + item.length + 1;
        if (result[offset]) {
          if (item.replacement === 0) {
            return group.exec(string);
          } else {
            var args = result.slice(offset, next);
            var j = args.length;
            while (--j) args[j] = args[j] || ""; // some platforms return null/undefined for non-matching sub-expressions
            args[0] = {match: args[0], item: item};
            return isFunction(fn) ? fn.call(args) : args;
          }
        }
        offset = next;
      }
    }
    return null;
  },

  parse: function RegGrp__parse(string) {
    string = String(string);
    var _replacement = arguments[1]; // optional argument (deprecated) -@DRE
    var group = this;
    var patterns = group[CONST_PATTERNS];
    var items = group[CONST_REPLACEMENTS];
    var regexp = group[CONST_COMPILED];
    if (!patterns.length) return string;
    if (REGGRP_ALWAYS_RECOMPILE || !regexp || regexp.ignoreCase !== !!group.ignoreCase) {
      regexp = group[CONST_COMPILED] = new RegExp(regexp ? regexp.source : group, group.ignoreCase ? "gi" : "g");
    }
    return string.replace(regexp, function _RegGrp_parser(match) {
      var args = [], item, offset = 1, i = arguments.length;
      while (--i) args[i] = arguments[i] || ""; // some platforms return null/undefined for non-matching sub-expressions
      // Loop through the RegGrp items.
      while ((item = items[CONST_HASH + patterns[i++]])) {
        var next = offset + item.length + 1;
        if (args[offset]) { // do we have a result?
          var replacement = _replacement == null ? item.replacement : _replacement;
          switch (typeof replacement) {
            case "function":
              return replacement.apply(group, args.slice(offset, next));
              
            case "number":
              return args[offset + replacement];
              
            case "object":
              if (replacement instanceof RegGrp) {
                return replacement.parse(args[offset]);
              }
              
            default:
              return String(replacement);
          }
        }
        offset = next;
      }
      return match;
    });
  },

  remove:   _RegGrp__recompile,
  removeAt: _RegGrp__recompile,
  reverse:  _RegGrp__recompile,
  set:      _RegGrp__recompile,
  sort:     _RegGrp__recompile,
  
  toString: function RegGrp__toString() {
    var patterns = this[CONST_PATTERNS];
    if (!patterns) return "()";
    var string = patterns.join(")|(");
    if (this.dictionary || /\\\d/.test(string)) { // back refs
      var offset = 1;
      var keys = patterns;
      var items = this[CONST_REPLACEMENTS], item;
      patterns = [];
      for (var i = 0; item = items[CONST_HASH + keys[i]]; i++) {
        patterns[i] = item.source.replace(REGGRP_BACK_REF, function(match, index) {
          return "\\" + (offset + ~~index);
        });
        offset += item.length + 1;
      }
      string = patterns.join(")|(");
    }
    return "(" + string + ")";
  }
}, {
  IGNORE: null, // a null replacement value means that there is no replacement and the match is ignored

  count: RegGrp_count
});

;doc; // Try to expose as much raw source code as possible.
;doc; forEach.csv("clear,remove,removeAt,reverse,set,sort", function(name) {
;doc;   this[name]._underlyingFunction = Collection.prototype[name];
;doc; }, RegGrp.prototype);

