
var RegGrp_Dict = RegGrp.extend({
  parse: function RegGrp_Dict__parse(phrase) {
    // Prevent sub-expressions in dictionary entries from capturing.
    var entries = this[CONST_REPLACEMENTS];
    return String(phrase).replace(REGGRP_DICT_ENTRIES, function(match, entry) {
      entry = entries[CONST_HASH + entry];
      return entry ? entry._nonCapturing : match;
    });
  },

  createItem: function RegGrp_Dict__createItem(expression, replacement) {
    // Get the underlying replacement value.
    if (replacement instanceof RegGrp_Item) {
      replacement = replacement.replacement;
    } else if (replacement instanceof RegExp) {
      replacement = replacement.source;
    }
    if (typeof replacement == "string") { // Don't translate functions.
      // Translate the replacement.
      // The result is the original replacement recursively parsed by this dictionary.
      var nonCapturing = replacement.replace(REGGRP_DICT_NON_CAPTURING, _RegGrp_Dict_noCapture);
      if (replacement.indexOf("(") !== -1) {
        var realLength = RegGrp_count(replacement);
      }
      replacement = this.parse(replacement);
      nonCapturing = this.parse(nonCapturing);
    }
    var item = this.base(expression, replacement);
    item._nonCapturing = nonCapturing;
    item._length = realLength || item.length; // underlying number of sub-groups
    return item;
  },

  toString: function RegGrp_Dict__toString() {
    var patterns = this[CONST_PATTERNS];
    if (!patterns || patterns.length === 0) return "()";
    return "(<#" + patterns.join(">)|(<#") + ">)";
  }
});

RegGrp.Dict = RegGrp_Dict;
