
var CONST_PATTERNS     = 0; // CONST_KEYS;
var CONST_REPLACEMENTS = 1; // CONST_ITEMS;
var CONST_COMPILED     = 3;

// We can't feature detect this as it crashes Konqueror 3.x.
// This browser is not officially supported but it is still poor form to crash it. :)
var REGGRP_ALWAYS_RECOMPILE   = detect("Konqueror");

var REGGRP_BACK_REF           = /\\(\d+)/g;
var REGGRP_ESCAPE_COUNT       = /\[(\\.|[^\]\\])+\]|\\.|\(\?/g;
var REGGRP_PAREN              = /\(/g;
var REGGRP_LOOKUP             = /\$(\d+)/;
var REGGRP_LOOKUP_SIMPLE      = /^\$\d+$/;

var REGGRP_DICT_ENTRY         = /^<#\w+>$/;
var REGGRP_DICT_ENTRIES       = /<#(\w+)>/g;
var REGGRP_DICT_NON_CAPTURING = /(\[(\\.|[^\]\\])+\]|\\.|\(\?)|\(/g;

function RegGrp_count(expression) {
  return (String(expression).replace(REGGRP_ESCAPE_COUNT, "").match(REGGRP_PAREN) || "").length;
}

function RegGrp__createKey(key) {
  return key instanceof RegExp || key instanceof RegGrp_Item
    ? key.source
    : String(key);
}

function _RegGrp__recompile() {
  delete this[CONST_COMPILED];
  return this.base.apply(this, arguments);
}

function _RegGrp_Dict_noCapture(match, escaped) {
  return escaped || "(?:"; // non-capturing
}
