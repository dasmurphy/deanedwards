
var myPackage;

if (!myPackage) base2.exec(function(_) {
  var LIFE = 42;

  var MyClass = _.Base.extend({
    // class definition
  });

  function sayHello() {
    alert("Hello!");
  }

  myPackage = new _.Package({
    name:     "myPackage",
    version:  "1.0",

    LIFE:     LIFE,
    MyClass:  MyClass,
    sayHello: sayHello
  });
});
