
base2.exec(function(_) {
  var names = "base,implement".split(",");
  _.forEach(_, function(value, name) {
    if (name != "_") names.push(name);
  });
  names = "\\b(" + names.join("|") + ")\\b";
  var javascript = colorize.javascript;
  javascript.add(names, '<span class="base2">$1</span>');
  javascript.add("\\b(behavior)\\b", '<span class="jsb-behavior">$1</span>');
  javascript.insertAt(0, /("@[^"]+"):/, '<span class="colorize-special">$1</span>:');
  javascript.tabStop = 2;
});
