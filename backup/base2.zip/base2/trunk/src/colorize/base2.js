
base2.exec(function(_) {
  var names = "base,implement".split(",");
  _.forEach(_, function(value, name) {
    if (name != "_") names.push(name);
  }, {});
  names = "\\b(" + names.join("|") + ")\\b";
  var js = colorize.js;
  js.add(names, '<span class="base2">$1</span>');
  js.add("\\b(behavior)\\b", '<span class="jsb-behavior">$1</span>');
  js.insertAt(0, /("@[^"]+"):/, '<span class="colorize-conditional-comment colorize-string">$1</span>:');
  js.tabStop = 2;
});
