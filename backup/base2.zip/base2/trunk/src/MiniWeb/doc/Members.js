
var Members = base2.Collection.extend({
  constructor: function(owner, test) {
    this.base();
    this.owner = owner;
    if (owner instanceof Reflection) {
      var reference = owner.reference
    } else {
      reference = owner;
    }
    forEach (reference, function(member, name) {
      if (VALID_NAME.test(name) && (!test || test.apply(undefined, arguments))) {
        this.set(name, member);
      }
    }, this, (typeof reference == "function" ? Function : Object).prototype);
    this.sort();
  },
  
  set: function(name, reference, inherited) {
    var member = this.base(name, reference, this.owner);
    if (arguments.length > 2) member.inherited = !!inherited;
    return member;
  },
  
  owner: null
}, {
  Item: {
    constructor: function(name, reference, owner) {
      var ancestor = owner.ancestor;
      if (ancestor) {
        if ((owner.reference == base2.Trait && name === "forEach") || (owner.reference == base2.Functional && name === "bind")) {
          this.inherited = false;
        } else if (typeof jsb == "object" && owner.reference == jsb.element) {
          this.inherited = name === "base";
        } else if (reference instanceof Function && !(isBaseClass(reference) && name !== "ancestor")) {
          this.inherited = name in ancestor;
        } else {
          this.inherited = typeof ancestor[name] != "undefined";
        }
      }
    },

    //name: "",
    inherited: false
  }
});
