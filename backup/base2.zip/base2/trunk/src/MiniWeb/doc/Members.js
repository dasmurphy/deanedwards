
var Member = _.Base.extend({
  constructor: function Member__constructor(name, reference, owner) {
    this.inherited = owner.ancestor && owner.ancestor[name] === reference;
  },

  inherited: false
});

var Members = _.Collection.extend({
  constructor: function Members__constructor(owner, test) {
    this.base();
    this.owner = owner;
    if (owner instanceof Reflection) {
      var reference = owner.reference
    } else {
      reference = owner;
    }
    forEach (reference, function _eacher(member, name) {
      if (VALID_NAME.test(name) && (!test || test.apply(undefined, arguments))) {
        this.set(name, member);
      }
    }, this, (typeof reference == "function" ? Function : Object).prototype);
    this.sort();
  },

  sort: function Members__sort() {
    return this.base(function(m1, m2, key1, key2) {
      key1 = key1.toLowerCase();
      key2 = key2.toLowerCase();
      return key1 < key2 ? -1 : key1 > key2 ? 1 : 0;
    });
  },

  createItem: function Members__createItem(name, reference, inherited) {
    var member = this.base(name, reference, this.owner);
    if (arguments.length > 2) member.inherited = !!inherited;
    return member;
  },
  
  owner: null
}, {
  Item: Member
});
