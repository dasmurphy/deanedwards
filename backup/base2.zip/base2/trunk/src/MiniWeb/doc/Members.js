
var Member = _.Base.extend({
  constructor: function Member__constructor(name, reference, owner) {
    this.inherited = owner.ancestor[name] === reference;
  },

  inherited: false
});

var Members = _.Collection.extend({
  constructor: function Members__constructor(owner, test) {
    this.base();
    this.owner = owner;
    if (owner instanceof Reflection) {
      var reference = owner.reference
    } else {
      reference = owner;
    }
    forEach (reference, function(member, name) {
      if (VALID_NAME.test(name) && (!test || test.apply(undefined, arguments))) {
        this.set(name, member);
      }
    }, this, (typeof reference == "function" ? Function : Object).prototype);
    this.sort();
  },

  createItem: function Members__createItem(name, reference, inherited) {
    var member = this.base(name, reference, this.owner);
    if (arguments.length > 2) member.inherited = !!inherited;
    return member;
  },
  
  owner: null
}, {
  Item: Member
});
