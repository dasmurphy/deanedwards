
var doc = MiniWeb.doc = new _.Package({
  name:    "MiniWeb.doc",
  version: "%%VERSION%%",
  
  show: {},
  
  getObject: function(objectID) {
    if (objectID === "namespace") return namespace;

    var refId = String(objectID).replace(/::/, '.prototype.');
    refId = refId.split('.');
    if (refId.length > 1) {
      refId[refId.length - 2] += '["' + refId.pop() + '"]';
    }
    refId = refId.join('.');
    return new Function("try{return " + refId + "}catch(e){}")();
  },

  beautify: String,

  "@Gecko": {
    beautify: function(source) {
      source = String(source).replace(/\s+doc;\r?\n[^\n]+\n/g, "");
      source = source.replace(/[\x20\t]*['"]use strict['"];[^\n]*\n/g, "");
      source = js_beautify(source, {indent_size: 2, keep_array_indentation: true});
      source = source.replace(/{(\[native code\])/, "{\n  $1");
      return source;
    }
  },

  beginEdit: function(textarea, width, height) {
    this._editor = CodeMirror.fromTextArea(textarea, {
      mode: "text/html",
      tabMode: "indent",
      tabSize: 2,
      autofocus: true,
      lineWrapping: true
    });
    this._editor.setSize(width, height);
  },

  stopEdit: function() {
    this._editor.toTextArea();
    delete this._editor;
  },

  colorize: function(pre) {
    var className = pre.className;
    var colorizer = colorize[className];
    
    if (colorizer) {
      colorizer.parseUrls = false;
      
      var textContent = dom.get(pre, 'textContent');

      // Convert tabs to spaces and then convert spaces to "&nbsp;".
      var indent = textContent.match(/\n(\s+)\}\s*$/);
      if (indent) {
        textContent = textContent.replace(new RegExp("\\n" + indent[1], "g"), "\n");
      }

      textContent = textContent.replace(/([\x20\t]*;(;|doc);[^\n]+\n)+\r?\n?/g, "");

      dom.classList.add(pre, "colorized");
      dom.classList.add(pre, "colorize-" + className);
      
      pre.innerHTML = colorizer.parse(textContent);
    }
  },
  
  Members: Members,
  Reflection: Reflection
});
