
var doc = MiniWeb.doc = new _.Package({
  name:    "MiniWeb.doc",
  version: "%%VERSION%%",
  
  show: {},
  
  getObject: function(objectID) {
    if (objectID === "namespace") return namespace;
    if (objectID === "Date") return Date;
    if (objectID === "Date::toISOString") return new Date().toISOString;

    var refId = String(objectID).replace(/::/, '.prototype.');
    refId = refId.split('.');
    if (refId.length > 1) {
      refId[refId.length - 2] += '["' + refId.pop() + '"]';
    }
    refId = refId.join('.');
    return Function("try{return " + refId + "}catch(e){}")();
  },

  beautify: function(source) {
    source = String(source).replace(/([\x20\t]*;(;|doc);[^\n]+\n)+\r?\n?/g, "");
    var indent = source.match(/\n(\s+)\}\s*$/);
    if (indent) {
      source = source.replace(new RegExp("\\n" + indent[1], "g"), "\n");
    }
    return source.replace(/{\s+(\[native code\])\s+\}/, "{\n  $1\n}");;
  },

  "@Gecko": {
    beautify: function(source) {
      source = String(source).replace(/\s+doc;\r?\n/g, "");
      source = source.replace(/[\x20\t]*['"]use strict['"];[^\n]*\n/g, "");
      source = js_beautify(source, {indent_size: 2, keep_array_indentation: true});
      return source.replace(/{(\[native code\])/, "{\n  $1");
    }
  },

  beginEdit: function(textarea, type, width, height) {
    var editor = CodeMirror.fromTextArea(textarea, {
      mode: mimeTypes[type] || "text/html",
      tabMode: "indent",
      tabSize: 2,
      autofocus: true,
      lineWrapping: true,
      onFocus: function() {
        dom.classList.add(element, "mw-focus");
      },
      onBlur: function() {
        dom.classList.remove(element, "mw-focus");
      }
    });
    var element = editor.getWrapperElement();
    dom.classList.add(element, "mw-editor");
    editor.setSize(width, height);
    textarea.className = "mw-offscreen";
    this._editor = editor;
    return editor;
  },

  stopEdit: function() {
    this._editor.toTextArea();
    delete this._editor;
  },

  colorize: function(pre) {
    var type = pre.className.split(/\s+/)[0];
    if (!mimeTypes[type]) return;

    var value = dom.get(pre, "textContent");

    CodeMirror.runMode(_.trim(value), mimeTypes[type], pre, {
      tabMode: "indent",
      tabSize: 2,
      lineWrapping: true
    });
  },
  
  Members: Members,
  Reflection: Reflection
});
