
var doc = MiniWeb.doc = new _.Package({
  name:    "MiniWeb.doc",
  version: "%%VERSION%%",
  
  show: {},
  
  getObject: function(objectID) {
    try {
      var refId = 'arguments[1]=' + String(objectID).replace(/::/, '.prototype.');
      refId = refId.split('.');
      if (refId.length > 1) {
        refId[refId.length - 2] += '["' + refId.pop() + '"]';
      }
      refId = refId.join('.');
      eval(refId);
    } catch (e){}
    return arguments[1];
  },

  colorize: function(pre) {
    var className = pre.className;
    if (className == "js") className = "javascript";
    var colorizer = colorize[className];
    
    if (colorizer) {
      colorizer.parseUrls = false;
      
      var textContent = dom.get(pre, 'textContent');

      // Convert tabs to spaces and then convert spaces to "&nbsp;".
      var indent = textContent.match(/\n(\s+)\}\s*$/);
      if (indent) {
        textContent = textContent.replace(new RegExp("\\n" + indent[1], "g"), "\n");
      }
      textContent = textContent.replace(/[ \t]*;;;[^\n]*\n/g, "");

      dom.classList.add(pre, "colorized");
      dom.classList.add(pre, "colorize-" + className);
      
      pre.innerHTML = colorizer.parse(textContent);
    }
  },
  
  Members: Members,
  Reflection: Reflection
});
