<!doctype html>
<meta charset="utf-8">
<title>MiniWeb: /doc/</title>
<script>
<?php
$server = $_SERVER['SERVER_NAME'];
print(file_get_contents("http://$server/base2/trunk/src/build.php?src=base2.js&doc=true"));
?>
</script>
<script>
<?php print(file_get_contents("http://$server/base2/trunk/src/build.php?src=base2/EventTarget.js&doc=true"));?>
</script>
<script>
<?php print(file_get_contents("http://$server/base2/trunk/src/build.php?src=base2/dom.js&doc=true"));?>
</script>
<script>
<?php print(file_get_contents("http://$server/base2/trunk/src/build.php?src=base2/jst.js&doc=true"));?>
</script>
<script>
<?php print(file_get_contents("http://$server/base2/trunk/src/build.php?src=base2/io.js&doc=true"));?>
</script>
<script>
<?php print(file_get_contents("http://$server/base2/trunk/src/build.php?src=JSON.js&doc=true"));?>
</script>
<script>
<?php print(file_get_contents("http://$server/base2/trunk/src/build.php?src=XMLHttpRequest.js&doc=true"));?>
</script>
<script>
<?php print(file_get_contents("http://$server/base2/trunk/src/build.php?src=jsb.js&doc=true"));?>
</script>
<script>
<?php print(file_get_contents("http://$server/base2/trunk/src/build.php?src=MiniWeb.js&doc=true"));?>
</script>
<script>
<?php print(file_get_contents("http://$server/base2/trunk/src/build.php?src=MiniWeb/doc.js&doc=true"));?>
</script>
