/*
  MiniWeb - copyright 2007-2011, Dean Edwards
  License: http://mit-license.org/
*/

// An active document thing

window.MiniWeb = new _.Package({
  name:    "MiniWeb",
  version: "%%VERSION%%",
  
  $$: {data: {}},
  
  client: null,
  dirty: false,
  readOnly: true,
  server: null,
  terminal: null,
  
  register: function(window) {
    this.client.register(window);
  },
  
  resolve: function(path, filename) {
    return io.FileSystem.resolve(path, filename);
  },
  
  save: function(name) {
    if (this.readOnly && !SUPPORTS_DOWNLOAD) {
      alert(
        location.protocol == "file:"
        ?
          "Your browser does not support local file access.\n" +
          "Use Internet Explorer or Firefox instead."
        :
          "You cannot save your changes over HTTP.\n" +
          "Instead, save this page to your hard disk.\n" +
          "If you edit the local version you will then\n" +
          "be able to save your changes."
      );
      return false;
    }

    // update the revision number of the document
    var REVISION = "/system/About/revision";
    var io = this.server.io;
    var revision = parseInt(io.read(REVISION), 10);
    io.write(REVISION, String(++revision));

    // collect external scripts
    var scripts = [];
    forEach (document.getElementsByTagName("script"), function(script) {
      if (script.src) {
        scripts.push(_.format(EXTERNAL_SCRIPT, HTML_ESCAPE.parse(script.getAttribute("src", 2))));
      }
    });

    forEach (this.$$, function(value, name) {
      if (name !== "data") {
        var entry = "MiniWeb.$$." + name + "=" + JSON.stringify(value).replace(/<\//g, "<\\/");
        scripts.push(_.format(INTERNAL_SCRIPT, entry));
      }
    }, this);
    
    var data = [];
    forEach (this.$$.data, function(value, name) {
      var entry = "MiniWeb.$$.data." + name + "=" + JSON.stringify(value).replace(/<\//g, "<\\/");
      data.push(_.format(INTERNAL_SCRIPT, entry));
    }, this);
    
    // it's mostly script :-)
    var html = flatten([
      DOCTYPE,
      '<meta charset="utf-8">',
      "<title>MiniWeb: " + this.client.address + "<\/title>",
      scripts,
      "<body>",
      data,
      ""
    ]).join("\r\n");

    if (_.LocalFileSystem.supported) {
      var path = name || decodeURI(location.pathname);
      var fs = new _.LocalFileSystem;
      if (!name) fs.backup(path);
      fs.write(path, html);
    } else if (SUPPORTS_DOWNLOAD) {
      download(html, name);
    }

    this.dispatchEvent("saved");

    return true;
  },
  
  send: function(request, data) {
    if (this.client) {
      request.referer = this.client.address;
    }
    this.server.respond(request, data);
  },
  
  Client: Client,
  Server: Server,
  JSONFileSystem: JSONFileSystem,
  JSONDirectory: JSONDirectory,
  FileSystem: FileSystem,
  Command: Command,
  Interpreter: Interpreter,
  Terminal: Terminal,
  Request: Request,
  History: History
});

MiniWeb.toString = _.K("MiniWeb");

EventTarget(MiniWeb);
