
var STATE = 0;

var Terminal = Command.extend({
  constructor: function Terminal__constructor() {
    this.base();

    this[STATE] = {
     commands: [],
     output:   "<pre>MiniWeb %%VERSION%%</pre><br>",
     path:     "/",
     position: 0,
     protocol: "json:"
    };
  },

  isCommand: function Terminal__isCommand(command) {
    return bin.hasOwnProperty(command);
  },

  path: "/",
  protocol: "json:"
});

Terminal.implement(bin);
