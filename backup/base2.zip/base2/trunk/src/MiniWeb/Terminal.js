
// It didn't start off that way but this is becoming more like the UNIX shell
//  (which I know very little about)

var STATE = 0;

var Terminal = Command.extend({
  constructor: function Terminal__constructor() {
    this.base();
    _.extend(this, "exec", function Terminal__exec() {
      try {
        return this.base.apply(this, arguments);
      } catch (error) {
        return String(error.message || error);
      }
    });
    this[STATE] = {
     commands: [],
     output:   "<pre>MiniWeb %%VERSION%%</pre><br>",
     path:     "/",
     position: 0,
     protocol: "json:"
    };
  },

  path: "/",
  protocol: "json:"
});
