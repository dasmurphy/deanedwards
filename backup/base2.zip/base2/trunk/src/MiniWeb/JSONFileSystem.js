
var _FETCH = "#fetch";
var CR     = /\r/g;

var JSONFileSystem = io.FileSystem.extend({
  constructor: function JSONFileSystem__constructor(data) {
    this[_FETCH] = function(path) {
      // fetch data from the JSON object, regardless of type
      path = this.makepath(path);
      return _.reduce(path.split("/"), function(file, name) {
        if (file && name) file = name in file ? file[name] : undefined; // code looks silly but stops warnings being generated in Firebug
        return file;
      }, data);
    };
  },
  
  exists: function JSONFileSystem__exists(path) {
    return typeof this[_FETCH](path) != "undefined";
  },
  
  isFile: function JSONFileSystem__isFile(path) {
    return typeof this[_FETCH](path) == "string";
  },
  
  isDirectory: function JSONFileSystem__isDirectory(path) {
    return typeof this[_FETCH](path) == "object";
  },

  copy: function JSONFileSystem__copy(path1, path2) {
    var data = this[_FETCH](path1);
    this.write(path2, JSON.parse(JSON.stringify(data)));
  },
  
  mkdir: function JSONFileSystem__mkdir(path) {
    // Create a directory.
    this.write(path, {});
  },
  
  move: function JSONFileSystem__move(path1, path2) {
    var data = this[_FETCH](path1);
    this.write(path2, data);
    this.remove(path1);
  },

  read: function JSONFileSystem__read(path) {
    // Read text from the JSON object.
    var file = this[_FETCH](path);
    return typeof file == "object" ? new JSONDirectory(file) : file || ""; // make read safe
  },
  
  remove: function JSONFileSystem__remove(path) {
    // Remove data from the JSON object.
    path = path.replace(/\/$/, "").split("/");
    var filename = path.splice(path.length - 1, 1);
    var directory = this[_FETCH](path.join("/"));
    if (directory) delete directory[filename];
  },

  write: function JSONFileSystem__write(path, data) {
    // Write data to the JSON object.
    path = path.split("/");
    var filename = path.splice(path.length - 1, 1);
    var directory = this[_FETCH](path.join("/"));
    if (!directory) {
      throw new ReferenceError("Directory not found.");
    }
    if (typeof data == "string") {
      data = data.replace(CR, "")
    }
    return directory[filename] = data || "";
  }
});
