
var JSONDirectory = io.Directory.extend(null, {
  Item: {
    constructor: function JSONDirectory_Item__constructor(name, item) {
      var isDirectory = typeof item == "object";
      var fileSize = isDirectory ? 0 : item.length;
      this.base(name, isDirectory, fileSize);
    }
  }
});
