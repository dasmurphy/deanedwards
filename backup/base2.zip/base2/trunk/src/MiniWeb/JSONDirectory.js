
var JSONDirectory = io.Directory.extend({
  createKey: function JSONDirectory__createKey(name) {
    return _.trim(name);
  },

  set: function JSONDirectory__set(name, item) {
    name = this.createKey(name);
    if (name !== "" && name !== JSONDirectory.HIDDEN) {
      this.base(name, item);
    }
  }
}, {
  HIDDEN: "__JSONDirectory_hidden_file__",

  Item: {
    constructor: function JSONDirectory_Item__constructor(name, item) {
      this.name = String(name);
      this.isDirectory = typeof item == "object";
      this.size = this.isDirectory ? 0 : item.length || 0;
    }
  }
});
