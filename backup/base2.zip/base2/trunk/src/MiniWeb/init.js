
// create page style
document.write("<style>\
html{overflow:hidden}\
html,body{margin:0;padding:0}\
body{position:absolute;left:0;top:0;right:0;bottom:0}\
#window{position:absolute;left:0;top:0;border:0;height:100%;width:100%;background:white;}\
</style>");

// delegate some methods to the client
forEach.csv ("navigateTo,refresh,reload,submit", function(method) {
  MiniWeb[method] = function() {
    var args = _.slice(arguments);
    var client = MiniWeb.client;
    // use a timer to jump out of an event
    setTimeout(function() {
      client[method].apply(client, args);
    }, 0);
  };
});

window.onload = function() {
  MiniWeb.readOnly = location.protocol !== "file:" || io.LocalFile.prototype.open == io.NOT_SUPPORTED;
  MiniWeb.server = new Server;
  MiniWeb.terminal = new Terminal;
  MiniWeb.client = new Client;
};
