
var _private = _._;
var forEach  = _.forEach;

var WILD_CARD      = /\*$/;
var TRIM_PATH      = /[^\/]+$/;
var SPACE          = /\s+/;

var DOCTYPE = '<!doctype html>';

var INTERNAL_SCRIPT = '<script>\n{0}\n<\/script>';
var EXTERNAL_SCRIPT = '<script src="{0}"><\/script>';

var HTML_ESCAPE = new _.RegGrp([
  "&", "&amp;",
  "<", "&lt;",
  ">", "&gt;"
]);

var INVALID_STATE = "Invalid state.";

function flatten(array) {
  var i = 0;
  var flattener = function _flattener(result, item) {
    if (_.isArray(item)) {
      _.reduce(item, flattener, result);
    } else {
      result[i++] = item;
    }
    return result;
  };
  return _.reduce(array, flattener, []);
};

function jsonCopy(data) {
  return JSON.parse(JSON.stringify(data))
};
