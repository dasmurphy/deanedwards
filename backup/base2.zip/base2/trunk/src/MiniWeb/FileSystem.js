
// This class wraps the various file retrieval systems.
// So far they are:
//   JSON (json:)
//   Local file system (file:)

var FileSystem = JSONFileSystem.extend({
  constructor: function FileSystem__constructor() {
    this.base(MiniWeb.$$);
  },
  
  remove: function FileSystem__remove(path) {
    MiniWeb.dirty = true;
    return this.base(path);
  },
  
  write: function FileSystem__write(path, data) {
    MiniWeb.dirty = true;
    return this.base(path, data);
  },
  
  protocol: "json:"
});
