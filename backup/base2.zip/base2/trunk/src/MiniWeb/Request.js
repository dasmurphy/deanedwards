
// We are basically mimicking the XMLHttpRequest object

var Request = _.Base.extend({
  constructor: function Request__constructor(method, url, data, headers) {
    this.headers = {};
    this.post = {};
    // allow quick open+send from the constructor if arguments are supplied
    if (arguments.length > 0) {
      this.open(method, url);
      for (var name in headers) {
        this.setRequestHeader(name, headers[name]);
      }
      this.send(data);
    }
  },
  
  headers: null,
  readyState: 0,
  status: 0,
//statusText: "",  // don't bother with this one
  method: "",
  responseText: "",
  post: null,
  url: "",
  
  open: function Request__open(method, url) {
    if (this.readyState !== 0) throw new Error(INVALID_STATE);
    this.readyState = 1;
    this.method = method;
    this.url = url;
  },
  
  send: function Request__send(data) {
    if (this.readyState !== 1) throw new Error(INVALID_STATE);
    this.readyState = 2;
    MiniWeb.send(this, data);
  },
  
  // there is no distinction between request/response headers at the moment
  
  getResponseHeader: function Request__getResponseHeader(header) {
    if (this.readyState < 3) throw new Error(INVALID_STATE);
    return this.headers[header];
  },
  
  setRequestHeader: function Request__setRequestHeader(header, value) {
    if (this.readyState !== 1) throw new Error(INVALID_STATE);
    this.headers[header] = value;
  }
});
