
// Manage back/forward buttons

var History = _.Base.extend({
  constructor: function(callback) {
    this.visited = {};
    
    var hash;
    if ("onhashchange" in window && !_.detect("MSIE7")) {
      window.onhashchange = onhashchange;
      setTimeout(onhashchange, 20); // kick-start
    } else {
      this.timer = setInterval(onhashchange, 20);
    }
    
    function onhashchange() {
      if (hash !== location.hash) {
        hash = location.hash;
        callback();
      }
    };
    
    this.add(location.hash || ("#" + (document.title.slice(9) || "/")));
  },
  
  timer: 0,
  visited: null,
  
  add: function(hash) {
    if (location.hash !== hash) {
      location.hash = hash;
    }
    this.visited[hash] = true;
  }
});

// the hash portion of the location needs to be set for history to work properly
// -- we need to do it before the page has loaded
if (!location.hash) location.replace("#" + (document.title.slice(9) || "/"));

if (_.detect("MSIE[67]")) {
  document.write("<iframe style=display:none></iframe>");
  writeHistoryToIFrame(location.hash.slice(1)); // make sure it's unique the first time
  _.extend(History.prototype, "add", function(hash) {
    writeHistoryToIFrame(hash);
    this.base(hash);
  });
}

function writeHistoryToIFrame(hash) {
  if (hash !== location.hash) {
    var document = frames[0].document;
    document.open();
    document.write("<script>parent.location.hash='" + hash + "'<\/script>");
    document.close();
  }
}
