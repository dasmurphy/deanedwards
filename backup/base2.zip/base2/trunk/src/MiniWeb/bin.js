
var bin = {
  cat: function cat(paths) {
    return _.map(paths.split(/\s+/), function(path) {
      return this.read(path);
    }, this).join("\n");
  },
  
  cd: function cd(path) {
    this.chdir(path);
  },

  clear: function clear() {
    // json:/system/terminal.js
  },

  cp: function cp(paths) {
    paths = paths.split(/\s+/);
    if (paths[0] && paths[1]) {
      if (this.exists(paths[0])) {
        this.copy(paths[0], paths[1]);
      } else {
        throw new Error(paths[0] + ": file not found.");
      }
    }
  },

  date: function date() {
    return new Date().toLocaleDateString();
  },

  ed: function ed(file) {
    // open the file in the system editor
    if (this.isDirectory(file)) {
      throw new Error("Cannot edit a directory.");
    } else if (this.isFile(file)) {
      MiniWeb.navigateTo("/system/edit!" + this.makepath(file));
    } else {
      MiniWeb.navigateTo("/system/create!" + this.makepath(file));
    }
  },

  go: function go(path) {
    if (this.exists(path)) {
      MiniWeb.navigateTo(this.makepath(path));
    } else {
      throw new Error("No such file or directory: " + path);
    }
  },

  grep: function grep(args) {
    args = args.split(/\s+/);
    var pattern = args[0];
    var path = args[1];
    if (!pattern) {
      throw new Error("Search parameter missing.");
    } else if (!path) {
      throw new Error("Path parameter missing.");
    } else {
      return terminal_grep(this, new RegExp(pattern), path)
    }
  },

  help: function help() {
    return new _.Collection(bin).keys().sort().join("  ");
  },

  ls: function ls(dir) {
    // display the contents of a directory
    if (this.isDirectory(dir)) {
      var PADDING = "           ";
      var files = this.read(dir).map(function(item, name) {
        name += item.isDirectory ? "/" : "";
        return name + PADDING.slice(name.length % PADDING.length);
      });
      return files.sort().join("");
    } else {
      throw new Error("No such directory.");
    }
  },

  man: function man(command) {
    if (this.isCommand(command)) {
      return "Help for command: " + command + "\n\n" + help[command];
    } else {
      throw new Error("Command not found: " + command);
    }
  },

  mkdir: function mkdir(dirname) {
    if (this.isDirectory(dirname)) {
      throw new Error(dirname + ": is already a directory.");
    } else if (this.isFile(dirname)) {
      throw new Error(dirname + ": is already a file.");
    } else {
      this.base(dirname);
    }
  },

  mv: function mv(paths) {
    paths = paths.split(/\s+/);
    if (paths[0] && paths[1]) {
      if (this.exists(paths[0])) {
        this.move(paths[0], paths[1]);
      } else {
        throw new Error(paths[0] + ": file not found.");
      }
    }
  },

  rm: function rm(path) {
    if (this.isFile(path)) {
      this.remove(path);
    } else if (this.isDirectory(path)) {
      throw new Error(path + ": cannot delete a directory. Use rmdir.");
    } else {
      throw new Error(path + ": file not found.");
    }
  },

  rmdir: function rmdir(path) {
    if (this.isDirectory(path)) {
      this.remove(path);
    } else if (this.isFile(path)) {
      throw new Error(path + ": is not a directory.");
    } else {
      throw new Error(path + ": directory not found.");
    }
  },

  save: function save(filename) {
    if (MiniWeb.save(filename)) {
      return filename ? "Saved as " + filename : "Saved.";
    }
  },

  sed: function sed(args) {
    args = args.split(/\s+/);
    var pattern = args[0];
    var path = args[1];
    var parts = pattern.replace(/\\\//g, "\x00").split("/");
    if (args.length >= 2 && parts[0] != "s") {
      throw new Error("Only substitution is allowed (use s/search/replace/[flags]).");
    } else {
      var search = (parts[1] || "").replace(/\x00/g, "\\\/");
      var replacement = (parts[2] || "").replace(/\x00/g, "/");
      if (!search) {
      	throw new Error("Search pattern missing.");
      } else if (!replacement) {
      	throw new Error("Replacement pattern missing.");
      } else if (!path) {
        throw new Error("Path parameter missing.");
      } else {
        var flags = parts[3] || "";
        var test = new RegExp(search, flags.replace("g", ""));
        search = new RegExp(search, flags);
        return terminal_sed(this, test, search, replacement, path);
      }
    }
  },

  time: function time() {
    return new Date().toLocaleTimeString();
  }
};

function terminal_grep(terminal, pattern, path) {
  if (terminal.isDirectory(path)) {
    if (!/\/$/.test(path)) path += "/";

    return _.reduce(terminal.read(path), function(result, data, name) {
      result += terminal_grep(terminal, pattern, path + name);
      return result;
    }, "");
  } else if (terminal.isFile(path)) {
    if (pattern.test(terminal.read(path))) {
      return '<br><a href="#/system/edit!' + path + '">' + path + '</a>';
    } else {
      return "";
    }
  }
}

function terminal_sed(terminal, test, search, replacement, path) {
  if (terminal.isDirectory(path)) {
    if (!/\/$/.test(path)) path += "/";
    return _.reduce(terminal.read(path), function(result, data, name) {
      result += terminal_sed(terminal, test, search, replacement, path + name);
      return result;
    }, "");
  } else if (terminal.isFile(path)) {
    var data = terminal.read(path);
    if (test.exec(data)) {
      data = data.replace(search, replacement);
      terminal.write(path, data);
      return '<br><a href="#/system/edit!' + path + '">' + path + '</a>';
    } else {
      return "";
    }
  }
}

var help = {
  cat:   "usage: cat [path1 [path2 [pathN]]]\n\nPrints the contents of the files identified by `path1` etc.",
  cd:    "usage: cd path\n\nChanges the working directory to the directory identified by `path`.",
  clear: "usage: clear\n\nClears the terminal screen.",
  cp:    "usage: cp <path1> <path2>\n\nCopy the file or directory identified by `path1` to `path2`.",
  date:  "usage: date\n\nShows the current date.",
  ed:    "usage: ed <path>\n\nEdit the file identified by `path`.",
  go:    "usage: go <path>\n\nView the file identified by `path`.",
  grep:  "usage: grep <pattern> <path>\n\nSearches `path` for files that contain text that matches `pattern`.",
  help:  "usage: help\n\nLists all of the terminal commands.",
  ls:    "usage: ls [path]\n\nLists the files in the directory identified by `path` or the current directory if `path` is omitted.",
  man:   "usage: man <command>\n\nDisplays help for terminal commands.",
  mkdir: "usage: mkdir <path>\n\nCreates a directory described by `path`.",
  mv:    "usage: mv <path1> <path2>\n\Moves the file or directory identified by `path1` to `path2`.",
  rm:    "usage: rm <path>\n\Removes the file identified by `path`.",
  rmdir: "usage: rmdir <path>\n\Removes the directory identified by `path`.",
  save:  "usage: save [filename]\n\nSaves the current state of the MiniWeb application to the local file identified by `filename`.\nIf filename is omitted then the current file name is used.",
  sed:   "usage: sed <s/pattern/replacement/flags> <path>\n\nSearches `path` for files that contain text that matches `pattern` and replaces it with `replacement`.",
  time:  "usage: time\n\nShows the current time."
};
