
var isFakeFormData = !FormData;

if (isFakeFormData) {
  FormData = (function() {
    function FormData(form) {
      this.toString = _.K("[object FormData]");
      this.toString._data = form ? serialize(form) : "";
    }

    // help

    function serialize(form) {
      var successful = _.filter(form.elements, isSuccessful);

      return _.map(successful, encode).join("&");
    }

    function isSuccessful(element) {
      if (!element.name || element.disabled) return false;

      switch (element.type) {
        case "radio":
        case "checkbox":
          return element.checked;

        case "button":
        case "reset":
          return false;

        case "image":
        case "submit":
          return element == element.ownerDocument.activeElement;

        case "select-multiple":
        case "select-one":
          while ((element = element.parentNode) && !/DATALIST/i.test(element.nodeName)) continue;
          return !element;

        default:
          return true;
      }
    }

    function encode(element) {
      return element.name + "=" + encodeURIComponent(element.value);
    }

    FormData.prototype.append = function append(key, value) {
      var data = this.toString._data;
      if (data) data += "&";
      data += key + "=" + encodeURIComponent(value);
      this.toString._data = data;
    };

    return FormData;
  })();
}
